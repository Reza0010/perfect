# SAFE DEFAULTS — v1.8 (documented assumptions)

This file documents every safe default chosen during the v1.8 forensic audit,
per the mission directive ("تنظیمات نامشخص را با پیش‌فرض‌های ایمن تعیین کن و
آن‌ها را مستند کن"). Every value below is either (a) a conservative failure
mode, (b) a documented assumption, or (c) an explicit safety gate.

## 1. Execution safety

| Default | Value | Rationale |
|---|---|---|
| Live trading (`--mode mt5-live` / `live`) | **HARD-REFUSED** (exit 2) | Acceptance gates incomplete; the runtime loop can never send broker orders in this build. Demo execution only via `scripts/mt5_demo_execution_test.py` on a DEMO account. |
| `execution.mode` | `paper` | Every loop (panel or main.py) forces PAPER; balances shown are paper balances. |
| `provider.allow_live_execution` | `False` | No provider built by the shared factory can send orders. |
| Kill switch | Active on: daily loss > 5%, drawdown > 10%, 12 consecutive AI/data/exec failures, MT5 disconnect | Fail-closed; state persisted atomically. |
| Open risk unknown | **Refuse new trades** | `OPEN_RISK_UNKNOWN` — never guess exposure. |
| MT5 disconnect in live mode | WAIT (no synthetic ticks) | exec-N7 unchanged. |

## 2. Closed-bar timing (v1.8)

| Default | Value | Rationale |
|---|---|---|
| Intraday completion buffer | **60 s** after `open + interval` | Covers Yahoo's 2–10 min publication lag (conservative: a just-closed bar is not consumed with possibly-unfinal OHLC). |
| D1 completion | stamp + **17 h** (+60 s) | Yahoo stamps GC=F daily bars at 00:00 ET (verified on 6,106 stored bars); the COMEX session for stamp-day D closes 17:00 ET = 17 h after the stamp. DST-safe because the stamp tracks ET midnight. |
| Unknown bar duration | drop trailing bar **only if < 1 h old** | Fail-closed vs. clearly-historical single rows. |
| Flat trailing bar after time filter | still dropped | v1.7.2 D6 safety net retained (stale zero-range snapshot at market close). |

## 3. Data-source honesty

| Default | Value | Rationale |
|---|---|---|
| `provider.kind` (config.yaml) | `public` | Real Yahoo GC=F + gold-api spot; NO MT5 and NO API keys needed. |
| `--provider` CLI (train/backtest/walkforward/optimize) | `config` | Synthetic must be chosen EXPLICITLY (`--provider simulated`) and is stamped + banner-labelled. |
| Registry provenance | `extra.data_source` recorded per model | Simulated-trained models are machine-detectable at load; readiness gate flags them. |
| Public spread | **30 points = $0.30 ASSUMED** | Public sources publish no bid/ask; every display labels it `(assumed)`. |
| Public bid/ask | mid ± assumed spread/2, labelled `public_assumed` | Never shown as broker quotes. |
| Paper synthetic tick fallback (no spread in frame) | 30 pt × point | Documented assumption (was 0.0 → free entries, F- exec-N7b). |
| `mt5_connected` in state.json | True only for a real MT5DataProvider connection | Simulated/public providers show their kind instead. |
| Degraded public feed | cached data + `degraded` flag | Never fabricated prices. |

## 4. Model safety

| Default | Value | Rationale |
|---|---|---|
| Labels | **symmetric** triple barrier: BUY ⇔ long-TP before long-SL; SELL ⇔ short-TP before short-SL; same-bar tie / both-fire → NO_EDGE | Matches the engine's symmetric short management; intrabar order is unknowable without tick history (documented limitation). |
| Label costs (config) | spread $0.30, slippage $0.05, commission $0 | PRICE units everywhere. |
| Leakage audit | **fail-closed** (any error aborts training) | A skipped audit must never look like a passed one. |
| Split purge | `max(purge_bars, horizon_bars)` | Label horizon must always fit in the gap. |
| Calibration minimum | 150 validation samples | Below that calibration is skipped (honestly marked `fitted: false`). |
| Min OOS folds | 3 — fewer → walk-forward REFUSES | Insufficient evidence is reported as insufficient, never as a verdict. |
| Model readiness | ONE_SIDED / BELOW_CHANCE / SYNTHETIC / no-provenance → `NOT validated` | Loads for paper observation; never labelled trustworthy. |
| Retrain policy | **NO auto-retrain** (asserted at startup) | Models change only through explicit `train.py` runs. |

## 5. Panel / server

| Default | Value | Rationale |
|---|---|---|
| Bind | `127.0.0.1` | Panel stays local unless explicitly exposed. |
| Token | optional; `hmac.compare_digest` compare | Constant-time; with `0.0.0.0` + token, READS are gated too (`?token=` supported). |
| market_open (broker source) | broker tick EVENT time < 15 min | A terminal returns stale ticks when the market is closed — never forced OPEN. |
| market_open (public) | Yahoo price freshness < 15 min | Honest evaluation. |
| Win rate with zero closed trades | `—` (null) | A 0% rate with no sample is misleading. |
| Account balances | labelled **PAPER** | `backtest.initial_balance` + paper P/L, never broker money. |
| Loop stop timeout | 20 s (panel), 8 s (launcher Ctrl+C) | Bounded, then honest error state. |

## 6. Backtest

| Default | Value | Rationale |
|---|---|---|
| Same-bar SL+TP | **SL first** (conservative) | Intrabar order unknowable without ticks; recorded on the trade. |
| SL gap fill | worse open, not the stop level | Weekend/news gap pessimism (engine + simulator now identical). |
| Swap | charged at 21:00 UTC rollover, on the exit bar too, 3× Wednesday | Engine contract; simulator mirrors bit-level. |
| NaN feature rows | **dropped** (fail-closed, count reported) | Same contract as the live pipeline (was zero-filled). |
| Spread source | dataset column > assumed (30 pt) | Reported in every backtest report. |

## 7. Environment assumptions (this audit machine)

- Linux sandbox: `MetaTrader5` package NOT importable (Windows-only) — every
  MT5 path is covered by FakeMT5-injected unit tests instead of a real terminal.
  `reports/MT5_ENVIRONMENT.md` records the honest §1 STOP decision for the
  broker-data portion.
- pyarrow 26.0.0 + hmmlearn 0.3.3 installed (required; the previous environment
  lacked them and 13 tests failed — now 0).
- Network access to Yahoo/gold-api verified working (panel smoke test showed
  real prices and an honest Saturday market-closed state).

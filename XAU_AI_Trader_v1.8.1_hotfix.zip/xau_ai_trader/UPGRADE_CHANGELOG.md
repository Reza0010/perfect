# Upgrade changelog

## v1.8.1 — Windows hotfix: MT5 provider, news calendar, kill switch (2026-10-11)

User-reported on Windows (real console output):
1. panel trading loop crashed with
   `SymbolNotFoundError: Symbol 'XAUUSD' not found. Available: []` right after
   selecting MT5 as the data provider in panel Settings;
2. `python main.py --mode paper` printed `WAIT: ['NEWS_UNAVAILABLE']` forever.

- **F27** `main.py::build_system` + `app/data/mt5/provider.py` — the crash was
  100% reproducible: `build_system()` called `get_symbol_info()` on a
  NEVER-CONNECTED MT5 provider (`connect()` is the only place the symbol list
  is populated). Fixes: lazy `_ensure_connected()` on every data method with a
  ~30s reconnect cooldown; `build_system` connects MT5 first (best effort) and
  falls back to the DOCUMENTED assumed specs
  (`SymbolInfo.specs_source="assumed_fallback"`) instead of crashing — the
  loop then WAITs with `PROVIDER_UNAVAILABLE` until the terminal is reachable.
- **F28** `app/news/providers.py::StaticCSVNewsProvider.is_fresh` — freshness
  was file-MTIME based (24h); a calendar shipped inside a ZIP preserves its
  build timestamp, so every user copy went permanently "stale" → infinite
  `NEWS_UNAVAILABLE` WAIT even while the events covered 2026-10→2026-12.
  Freshness is now COVERAGE based (calendar must span `now`); events FOUND in
  the assessment window are trusted regardless (they are real calendar rows);
  `last_update()` (mtime) remains available for provenance display. Precise
  reason codes: `NEWS_CALENDAR_OUT_OF_RANGE` / `NEWS_PROVIDER_UNAVAILABLE`
  (pipeline forwards them instead of the generic `NEWS_UNAVAILABLE`).
- **F29** `app/trader.py` — the kill switch tripped `MT5_DISCONNECT` on the
  FIRST iteration for a never-connected provider (terminal not started),
  permanently killing the system on a setup issue. Now `MT5_DISCONNECT` only
  fires when an ESTABLISHED connection is LOST (fail-closed preserved);
  a never-connected provider produces an honest WAIT and auto-reconnects
  (bounded by the provider cooldown) — the disconnect/recovery contract.
  `ProviderConnectionError` no longer increments the data-corruption streak.
- `app/data/market/models.py`: `SymbolInfo.specs_source` provenance field
  (`provider` / `assumed_public_defaults` / `assumed_fallback`).
- `app/data/market/live_public.py`: public specs marked
  `assumed_public_defaults`.
- NEW `tests/test_v181_hotfix.py` (13 regression tests); full suite
  **300 passed / 0 failed** (measured, `RELEASE_MANIFEST.json` regenerated
  from a fresh JUnit run).
- Version strings: run_panel banner + server banner + manifest
  `1.8.1-forensic-audit-hotfix`.

## v1.7.2 — closed-bar fix (2026-10-09)

User-reported: trading loop stuck printing `FEATURES_NAN` WAIT forever; prices static.

- **D6** `app/data/market/live_public.py::parse_yahoo_chart` — drop trailing flat
  snapshot bar (Yahoo in-progress bar with `O==H==L==C`) → inference never sees a
  zero-range newest row → no NaN features.
- **D7** `app/data/market/live_public.py::refresh` — length-safe merge
  (`concat` + last-wins dedupe) replaces the mask-indexed merge that crashed on
  every bar-count change and froze timeframes at their first seed.
- **D8** `app/pipeline.py` — sanitize-safe WAIT reason code for NaN features.
- NEW `tests/test_v17_2_closed_bar_fix.py` (9 regression tests); suite 255 passed,
  13 pre-existing environmental failures, zero regressions.
- Live verification (sandbox, real Yahoo data): `python main.py --mode paper --once`
  → health `MT5/Provider:True, Symbol:True, Models:True` → WAIT `AI_NOT_CONFIGURED`
  (expected without an AI key) — FEATURES_NAN gone; panel `/api/market` serves
  live bid/ask 4219.45/4219.75, market_open True.

# UPGRADE_CHANGELOG — v1.4 production candidate → v1.5.0-forensic-upgrade

All changes are in-repo (git: baseline `4202c9e` → v1.5). Nothing is a
recommendation-only note.

## Data layer
- `app/data/mt5/provider.py`: closed-bar guarantee; `end_time` enforced;
  `server_to_utc()` single time conversion (candles/ticks/positions);
  AMBIGUOUS retcodes raise `AmbiguousOrderError`; `order_check` re-run after
  retry price refresh; tick-value provenance flag.
- `app/data/mt5/historical.py`: server-time bounds for `copy_rates_range`;
  honest timezone provenance text; `spread_units="POINTS"` stamped.
- `app/data/quality.py`: staleness anchor fix (`_spans_weekend`),
  `stale_after_bars` wired.
- `app/data/dataset_meta.py`: `spread_units` field; dead line removed.
- `app/data/market/models.py`: `tick_value_is_fallback`, `stops_level_points`,
  `freeze_level_points`.

## Features / SMC / Regime
- `app/features/builder.py`: completion-time HTF alignment (time-based, gap-
  robust); SMC cache fingerprint; full-contract `feature_version`.
- `app/smc/engine.py`: `SMCResult.fingerprint`; short-frame bias fix.
- `app/features/sessions.py`: tz-convert fix.

## Models / Validation
- `app/models/labels.py`: executable-fill anchoring (t+1 open ± costs),
  NaN validity for tails, `sl_first` no-hit fix.
- `app/models/hmm_model.py`: forward-backward posterior; `hmm_feature_matrix`
  shared helper (rsi→[−1,1]); last-observation posterior; state feature list
  persisted.
- `app/models/train_service.py`: purge≥horizon split; enforced full leakage
  audit; real purged-CV loop; min-validation-samples calibration; raw+
  calibrated test metrics; full registry provenance + artifact hashes; HMM
  shared matrix; scaler.json-missing hard failure.
- `app/models/validation.py`: walk-forward purge/embargo + min-folds guard;
  balanced accuracy, Brier, ECE.
- `app/models/leakage.py`: real purity/alignment/scaler-scale/horizon checks.
- `app/models/bundle.py`: DataError contract; scaler-required guard.
- `app/models/registry.py` callers: keyword-arg provenance (dataset_version
  positional bug eliminated).
- `optimize.py`: TEST-BLIND objective (purged-CV + validation).
- `walkforward.py`: executable-fill labels, purge/embargo, min-fold refusal,
  honest report note.
- `app/analytics/periods.py`: expanding shifted vol quantiles (causal).
- `app/backtest/metrics.py`: net-of-cost headline (gross retained).

## Signals
- `app/signals/ensemble.py`: inverse-log-loss model weighting; NO_EDGE veto;
  EV-after-cost gate (Mission 12/13).
- `app/signals/expected_value.py`: NEW EV layer.

## Risk / Execution
- `app/risk/engine.py`: fail-closed unknown gates; unconditional margin gate;
  real mt5_connected; broker stop-distance validation.
- `app/risk/stops.py`: OB buffer fix (dead branch removed); liquidity TP
  direction fix; FIXED-SL point unit from symbol.
- `app/execution/mt5_exec.py`: order state machine, single-send, intent
  journal, reconcile_unknown, trade block.
- `app/execution/paper.py`: rollover-instant swap + triple swap + realized
  balance.
- `app/journal/journal.py`: events table + `log_event`, WAL, INSERT (no
  REPLACE) for trades.
- `app/trader.py`: signal-id comments, executor-authoritative paper open
  risk, live tick fail-closed, EV wiring, model-quality weights, point
  stamping, drift-monitor handle.

## News / AI / Monitoring / Dashboard
- `app/news/providers.py`: freshness contract (`last_update/coverage/
  is_fresh`), async HTTP bridge, `NullNewsProvider` for `provider: none`.
- `app/news/engine.py`: stale→UNKNOWN(WAIT); currency filter fix.
- `app/ai/schemas.py`: `extra=forbid`, logged brace-slice fallback, fence
  stripping.
- `app/ai/base.py`: `response_format=json_object`.
- `app/ai/gateway.py`: TTL eviction; dead branch cleanup.
- `app/monitoring/health.py`: SAFE_MODE > DISABLED severity.
- `app/notifications/telegram.py`: `notify_async`.
- `app/dashboard/webapp.py`: `current_regime` key fix; Mission-38 decision
  panel (ML probs, SMC bias, AI status, risk, freshness).
- `main.py`: `assert_no_auto_retrain` at startup.
- `app/backtest/engine.py`: spread units, gap-through-SL worst-case fill,
  tp_first honoured, swap hour/triple swap, NaN-spread guard.

## Reports & provenance
- NEW: `AUDIT_REPORT.md`, `BUG_REGISTER.md`, `UPGRADE_CHANGELOG.md`,
  `MODEL_VALIDATION_REPORT.md`, `DATA_QUALITY_REPORT.md`,
  `EXECUTION_READINESS.md`, `RISK_READINESS.md`, `RELEASE_MANIFEST.json`,
  `scripts/generate_release_manifest.py`.
- SUPERSEDED headers added to stale phase67 PENDING reports
  (`broker_data_quality_phase67.json` consumers, `gcf_vs_xauusd_phase67.json`,
  `PHASE_67_BROKER_FINAL_AUDIT.md`) pointing at the authoritative current
  documents.

## Tests
- NEW: `tests/test_v15_upgrade.py` (17 regression tests mapped to findings).
- UPDATED: `tests/test_labels_leakage.py` (new label contract),
  `tests/test_risk.py` (fail-closed contract), `tests/test_backtest.py`
  (same-bar annotation + 3 new tests), `tests/test_phase65_realdata.py`
  (spread-source disclosure).
- **229 passed / 0 failed.**

## v1.8.0 — Forensic Audit Release (2026-10-10)

Full-project forensic re-audit. **287/287 tests pass** (measured, not claimed).
Complete findings table: `BUG_REGISTER.md §F` (F1–F26).

### Critical fixes
- **Honest data source everywhere**: new shared `app/data/providers_factory.py`;
  `train.py`/`walkforward.py`/`optimize.py`/`backtest.py` no longer hardcode
  `SimulatedProvider` — the config's `provider.kind` is what runs, the ACTUAL
  source is printed and recorded in every report + the model registry.
- **Closed-bar logic is TIME-based** (the v1.7.2 flatness heuristic was invalid
  during active market hours): a bar is closed iff `open + interval + 60s <= now`;
  resampled M15/M30/H4 buckets get the same completeness rule; D1 stamps verified
  as ET-midnight (17h completion, DST-safe).
- **Symmetric BUY/SELL labels** (root cause of the degenerate SELL-majority
  models): both directions now require identical barrier multiples; ties and
  both-direction whipsaws resolve to NO_EDGE. Retrained `main` models are
  class-balanced (5288/6906/4294) with balanced recalls (0.365/0.647/0.337).
- **Model readiness gate**: one-sided / below-chance / synthetic / unprovenanced
  models are flagged `NOT validated` at load time and surfaced in state.json +
  the panel badge — never silently trusted again.
- **Leakage audit is fail-closed**; CV purge clamped to the label horizon;
  HMM fitted strictly inside the train window.

### Simulator ↔ engine equivalence (F21)
The null-model `SingleTradeSimulator` diverged from the Backtester on four
counts (midnight vs 21:00 rollover swap, missing triple-swap Wednesday, missing
exit-bar swap, no SL gap-fill). All fixed and validated bit-level on a
gap+rollover window — the statistical audit (phase67) now runs on equivalent
machinery.

### Panel honesty (F9–F19)
Three-state MT5 badge (connected/disconnected/**unknown**), provider-kind
badge instead of a fake MT5 label, weekend-correct market-open, spread units
(points vs USD-assumed), "(assumed)" bid/ask label, "PAPER" on balances,
"—" instead of 0% win rate with no trades, model warning badge, unified v1.8
versioning, `--with-trader` now controls the SERVED panel's loop, feed restart
actually restarts, constant-time token compare + read-gating on LAN bindings.

### Reports
`RELEASE_MANIFEST.json` regenerated from MEASURED test results (junit parse,
no hardcoded greens) with per-model readiness verdicts. Missing phase67
evidence artifacts regenerated by their own scripts (null-model audit on real
GC=F data: verdict EDGE_NOT_ESTABLISHED, honest).

### Verified
- `pytest`: 287 passed / 0 failed / 0 errors (pyarrow + hmmlearn installed).
- `python train.py --provider simulated` → honest SIMULATED banner, registry
  provenance `data_source=simulated`, balanced classes.
- `python backtest.py --provider simulated` → data_source recorded, 0 trades
  on synthetic data (the honest answer — the fake asymmetric-label "edge" is gone).
- `python walkforward.py --config config_real.yaml` → REFUSES (2 folds < 3):
  insufficient out-of-sample evidence — by design.
- Panel smoke test: real Yahoo prices, Saturday market honestly CLOSED,
  `bid_ask_source=public_assumed`, `mt5_connected=null` → "unknown" (not "Connected").

### Not claimed
No win-rate or profitability claim is made anywhere. Live trading stays
HARD-REFUSED. Models trained on synthetic data are labelled NOT validated.

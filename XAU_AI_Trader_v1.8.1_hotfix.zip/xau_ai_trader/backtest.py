#!/usr/bin/env python3
"""PHASE 58 — backtest.py: run the backtester on trained models.

Usage: python backtest.py [--config config.yaml] [--out reports/backtest.json]

⚠ SIMULATED-data backtests say nothing about real-market performance
(PHASE 63 — no profit claims; results are reported as backtest results only).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))

from app.config.loader import load_config
from app.config.schema import Regime
from app.core.logging import setup_logging


def classify_regime(features: pd.DataFrame, i: int, cfg) -> Regime:
    adx = features["adx"].iloc[i]
    if adx >= cfg.regime.adx_trend_min:
        return Regime.TRENDING_BULL if features["di_diff"].iloc[i] > 0 else Regime.TRENDING_BEAR
    if features["atr_pct"].iloc[i] >= cfg.regime.high_vol_atr_pct:
        return Regime.HIGH_VOLATILITY
    if features["atr_pct"].iloc[i] <= cfg.regime.low_vol_atr_pct:
        return Regime.LOW_VOLATILITY
    return Regime.RANGING


def _classify_regime_row(row: pd.Series, cfg) -> Regime:
    """v1.8: timestamp-anchored regime lookup (works on NaN-filtered subsets)."""
    if row["adx"] >= cfg.regime.adx_trend_min:
        return Regime.TRENDING_BULL if row["di_diff"] > 0 else Regime.TRENDING_BEAR
    if row["atr_pct"] >= cfg.regime.high_vol_atr_pct:
        return Regime.HIGH_VOLATILITY
    if row["atr_pct"] <= cfg.regime.low_vol_atr_pct:
        return Regime.LOW_VOLATILITY
    return Regime.RANGING


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    parser.add_argument("--out", default=None)
    parser.add_argument("--provider", choices=["config", "simulated"], default="config",
                        help="data provider: 'config' honours provider.kind; "
                             "'simulated' EXPLICITLY forces synthetic data")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    from app.backtest.engine import Backtester
    from app.data.providers_factory import build_data_provider, explicit_simulated, provider_data_source
    from app.models.train_service import build_frames, load_bundle, load_hmm, make_feature_builder
    from app.news.engine import NewsEngine
    from app.news.providers import MockNewsProvider
    from app.pipeline import AnalysisPipeline
    from app.regime.engine import RegimeEngine
    from app.risk.sizing import calc_lot
    from app.signals.ensemble import SignalEnsemble

    # v1.8 forensic fix: backtests used to ALWAYS run on SimulatedProvider while
    # printing a generic banner. The provider now follows the config and the
    # report records the data source that actually ran.
    if args.provider == "simulated":
        provider = explicit_simulated(cfg)
    else:
        provider = build_data_provider(cfg)
    src = provider_data_source(provider)
    simulated_run = not src["real_market"] or src["kind"] == "simulated"
    print(f"[backtest] ACTUAL data source: {src['label']} "
          f"(real_market={src['real_market']})")
    provider.connect()
    frames = build_frames(provider, cfg)
    bundle = load_bundle(cfg)
    fb = make_feature_builder(cfg)

    pipeline = AnalysisPipeline(cfg, provider, fb, RegimeEngine(cfg.regime),
                                NewsEngine(MockNewsProvider(""), cfg.news), bundle, load_hmm(cfg))
    md = pipeline.fetch(cfg.symbol.primary)
    features, names = fb.build(md.frames, cfg.timeframes.base)
    X = features[names]

    # v1.8 fix: NaN rows used to be silently ZERO-FILLED (X.fillna(0.0)) —
    # after robust scaling a zero is an extreme tail value, i.e. the
    # backtest traded phantom extreme-market rows that the LIVE pipeline
    # correctly refuses (FEATURES_NAN WAIT). Backtest and live now share the
    # same fail-closed rule: NaN feature rows produce NO signal.
    Xv = X.dropna(axis=0, how="any")
    dropped_rows = len(X) - len(Xv)
    if dropped_rows:
        print(f"[backtest] dropped {dropped_rows} rows with NaN features "
              f"(warmup/tail) — same fail-closed rule as the live pipeline")
    # vectorised calibrated predictions over the full causal feature matrix
    probs = bundle.average_proba(Xv)

    base = md.frames[cfg.timeframes.base.value]
    smc_bias = fb.smc_engine.analyze(base, cfg.timeframes.base.value) \
        .directional_bias_series(cfg.features.event_recent_bars)

    ensemble = SignalEnsemble(cfg.ensemble)
    news_engine = NewsEngine(MockNewsProvider(""), cfg.news)  # deterministic, offline
    atr = features["atr"]
    close = base["close"]
    info = provider.get_symbol_info(cfg.symbol.primary)

    sig_index: list = []
    sig_data: list[dict] = []
    # NOTE: Xv is a NaN-filtered subset — every feature/atr/close lookup is
    # resolved BY TIMESTAMP (features.loc[ts]), never by positional index,
    # so the dropped warmup rows cannot shift the alignment.
    for i in range(0, len(Xv), 5):
        ts = Xv.index[i]
        row_probs = np.array([probs[i, 0], probs[i, 1], probs[i, 2]])
        news = news_engine.assess(ts.to_pydatetime())
        regime = _classify_regime_row(features.loc[ts], cfg)
        decision = ensemble.decide(
            ml_probs={"ens": row_probs},
            smc_bias=float(smc_bias.loc[ts]) if ts in smc_bias.index else 0.0,
            regime=regime, news_risk=news.risk,
        )
        if not decision.is_actionable:
            continue
        a = atr.loc[ts]
        if np.isnan(a) or a <= 0:
            continue
        entry = close.loc[ts]
        sign = 1.0 if decision.side == "BUY" else -1.0
        sl = entry - sign * cfg.risk.atr_sl_mult * a
        sl_dist = abs(entry - sl)
        if sl_dist <= 0:
            continue
        tp = entry + sign * cfg.risk.min_rr * sl_dist
        lot = calc_lot(cfg.backtest.initial_balance, cfg.risk.risk_percent, sl_dist, info)
        if lot <= 0:
            continue
        sig_index.append(ts)
        sig_data.append({"side": decision.side, "sl": float(sl), "tp": float(tp),
                         "lot": lot, "score": decision.score})
    signals = pd.DataFrame(sig_data, index=pd.DatetimeIndex(sig_index))

    bt = Backtester(cfg.backtest, info,
                    commission_per_lot=cfg.execution.commission_per_lot,
                    swap_long=cfg.execution.swap_long_per_lot,
                    swap_short=cfg.execution.swap_short_per_lot,
                    slippage_points=cfg.execution.slippage_points)
    result = bt.run(base, signals)

    print("=" * 64)
    print(f"BACKTEST RESULT — {src['label'].upper()}")
    print("=" * 64)
    for k, v in result.summary.items():
        print(f"  {k:>22}: {v}")
    if result.monthly is not None and len(result.monthly):
        print("\nMonthly P/L:")
        print(result.monthly.to_string(index=False))

    out = Path(args.out or Path(cfg.paths.reports_dir) / "backtest_report.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({
        "summary": result.summary,
        "monthly": result.monthly.to_dict(orient="records") if result.monthly is not None else [],
        # v1.8: the data source that actually ran + explicit simulation flag —
        # a synthetic run can no longer masquerade as real evidence.
        "data_source": src,
        "simulated": bool(simulated_run),
        "nan_feature_rows_dropped": int(dropped_rows),
        "disclaimer": ("SIMULATED-data backtest. NOT a profit claim." if simulated_run
                       else "Backtest on " + src["label"] + " — NOT a profit claim; "
                            "verify with broker data before any conclusion."),
    }, indent=2, default=str), encoding="utf-8")
    print(f"\n[backtest] report → {out}")
    if simulated_run:
        print("[backtest] ⚠ SIMULATED data — this result is NOT evidence of "
              "real-market performance")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# RISK_READINESS — XAU AI Trader v1.5

**Verdict: DETERMINISTIC AND FAIL-CLOSED BY CONSTRUCTION — AI-PROOF.**
Every "unknown" state now produces WAIT (Mission 15/48). The AI layer has no
write path to risk parameters (verified by call-graph and by design flags).

## 1. Risk changes (OLD → NEW)

| Aspect | OLD | NEW | WHY | EVIDENCE |
|--------|-----|-----|-----|----------|
| Open risk default | `open_risk_percent=0.0` — callers who couldn't measure silently bypassed the cap | `None` ⇒ `OPEN_RISK_UNKNOWN` ⇒ WAIT | unknown risk is not zero risk | `test_risk_fail_closed_on_unknown_open_risk` |
| Daily loss / drawdown defaults | `0.0` (peak falls back to current equity ⇒ DD always 0) | `None` ⇒ WAIT; peak must be supplied | drawdown vs a synthetic peak is meaningless | risk engine fail-closed gates |
| Margin gate | `if free_margin > 0 and margin > ...` — zero-free-margin accounts approved trades | unconditional comparison | a broke account must not trade | `test_risk_fail_closed_on_zero_free_margin` |
| MT5 connection | hard-coded `mt5_connected=True` in the engine | explicit parameter; kill-switch default fail-closed | mid-iteration disconnects were invisible | `test_risk_fail_closed_on_unknown_connection` |
| Broker stops level | ignored pre-send (approved SLs could be rejected by order_check) | SL/TP distance validated vs `stops_level_points` before approval | approval must imply sendability | `test_risk_rejects_broker_stops_level` |
| ORDER_BLOCK stop | dead `if False` branch — SL exactly on the zone edge, buffer ignored | SL = zone boundary ∓ buffer×ATR on the protective side | first wick through the zone killed the trade | `stops.py` + v1.5 tests |
| LIQUIDITY TP | inverted (BUY→previous-day LOW); effectively always fell back to RR | BUY→PDH/PWH, SELL→PDL/PWL; RR fallback + direction guard kept | buy-side liquidity pools rest above old highs | `stops.py` |
| FIXED SL point unit | `df.attrs["point"]` default 0.01 never set (10× stop error on point=0.10 symbols) | point stamped from the real symbol at the call site; ATR fallback | unit ambiguity family (Mission 19) | `trader.py` + `stops.py` |
| Paper open risk | provider returned no positions ⇒ gate dead in the only runtime mode | executor-authoritative in paper mode | MAX_OPEN_RISK now enforceable in paper | `trader._open_risk_percent` |
| Paper equity | floating-only (realized P&L lost) | realized balance accumulation | equity-based caps must reflect history | `paper.py` |
| EV layer | none (RR ظاهری only) | `app/signals/expected_value.py`: EV in R after spread+2×slippage; non-positive EV vetoes | RR net ≠ RR gross (Mission 13) | `test_expected_value_layer` |
| Stop methods | min/max ATR distance, correct-side guards | kept + broker stop-distance + OB buffer + real liquidity targets | Mission 14 | risk/stops tests |

## 2. AI-proofing (verified)

- `risk_percent`, lot, SL, TP, max loss, max drawdown, position count are
  computed exclusively inside `RiskEngine.evaluate` from config + account +
  symbol state. The AI output object (`AIOutput`) structurally cannot carry
  any of these fields; `extra="forbid"` rejects smuggled fields.
- AI may only: agree, disagree, WAIT, or add confidence to the composite
  score. AI conflict/WAIT/unavailable ⇒ WAIT (never a side flip).

## 3. Kill switch / failsafe

- `KillSwitchActive` handling, daily-loss stop, drawdown stop and spread
  trigger all pass through the same fail-closed gate order: kill switch →
  unknown-state gates → market filters → account filters → confidence →
  SL/TP → broker stops → sizing → margin.
- Daily loss is measured against start-of-day balance; drawdown against
  peak equity (`_peak_equity` tracked in the loop; realized-P&L-aware in
  paper mode).

## 4. Remaining (documented, non-blocking for paper)

- `order_calc_margin`/`order_calc_profit` broker-native wiring is gated on
  the MT5 host (see EXECUTION_READINESS §3). The heuristic margin gate is
  unconditional-fail-closed in the meantime.
- Correlation/portfolio risk: single-symbol (XAUUSD) book — portfolio caps
  apply to open positions of this system only.
- Cost-stress / Monte-Carlo suites operate on the (now net-of-cost) trade
  ledger; re-run on real broker data before any promotion decision
  (`scripts/ab_test.py`, `app/analytics/variants.py`, null-model harness).

#!/usr/bin/env python3
"""v1.8 — train.py: train LGBM/XGB/HMM + calibration + registry.

FORENSIC FIX (v1.8): this script previously ALWAYS built a
``SimulatedProvider`` while its console message claimed "MT5 data" — every
default training run was synthetic and unlabelled as such. The provider is
now built from ``config.yaml`` (``provider.kind``) through the shared
factory, and the ACTUAL data source is printed AND recorded in the registry
provenance of every trained model.

Usage:
    python train.py                          # provider from config.yaml
    python train.py --provider simulated     # EXPLICIT synthetic training
    python train.py --config config_real.yaml
    python train.py --days 150               # history depth (simulated only)

The ``--registry-tag`` defaults to the config value (real_data.registry_tag)
so synthetic and real families never overwrite each other.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.config.loader import load_config
from app.core.logging import setup_logging


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    parser.add_argument("--days", type=int, default=None,
                        help="history depth (applies to the simulated provider only)")
    parser.add_argument("--provider", choices=["config", "simulated"], default="config",
                        help="data provider: 'config' honours provider.kind from the "
                             "config file; 'simulated' EXPLICITLY forces synthetic data")
    parser.add_argument("--registry-tag", default=None,
                        help="registry family (default: real_data.registry_tag from config)")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    from app.data.providers_factory import (build_data_provider,
                                            explicit_simulated,
                                            provider_data_source)

    # v1.8: provider comes from the CONFIG by default; synthetic is opt-in
    # and loudly labelled. The old code always simulated and misreported.
    if args.provider == "simulated":
        provider = explicit_simulated(cfg, days=args.days)
        print("[train] ⚠ PROVIDER: SIMULATED (explicitly forced) — models "
              "trained here say NOTHING about real-market performance")
    else:
        if args.days is not None:
            cfg.provider.simulated_days = args.days
        provider = build_data_provider(cfg)
    provider.connect()

    src = provider_data_source(provider)
    print(f"[train] provider.kind from config = {cfg.provider.kind!r}")
    print(f"[train] ACTUAL data source: {src['label']} (real_market={src['real_market']})")

    from app.models.train_service import build_frames, train_models

    days = args.days or cfg.provider.simulated_days
    print(f"[train] fetching history ({days} days nominal) …")
    frames = build_frames(provider, cfg)
    print(f"[train] base M5 bars: {len(frames['M5'])}")

    registry_tag = args.registry_tag or getattr(cfg.real_data, "registry_tag", "main") or "main"
    print(f"[train] registry tag: {registry_tag!r}")

    out = train_models(cfg, frames, register=True, registry_tag=registry_tag,
                        data_source=src)

    print("[train] leakage audit:", "PASS" if out.audit.all_passed else "FAIL")
    for c in out.audit.checks:
        print(f"   - {c.name}: {'PASS' if c.passed else 'FAIL'} — {c.detail}")
    print(f"[train] dataset rows: {out.dataset_meta['rows']} "
          f"({out.dataset_meta['first']} → {out.dataset_meta['last']})")
    print("[train] LGBM test metrics:", json.dumps(out.metrics["lgbm_test"], indent=2)[:400])
    print("[train] XGB test metrics:", json.dumps(out.metrics["xgb_test"], indent=2)[:400])
    cm = out.metrics.get("lgbm_test", {}).get("confusion_matrix")
    if cm:
        print("[train] LGBM confusion matrix [SELL, NO_EDGE, BUY]:", cm)
    print("[train] top features:")
    for f in out.feature_importance[:8]:
        print(f"   {f['feature']}: {f['importance']:.0f}")

    # persist experiment
    from app.journal.journal import Journal

    journal = Journal(Path(cfg.paths.logs_dir) / "journal.db")
    journal.log_experiment(
        experiment_id=f"train-{out.dataset_meta['feature_version']}",
        name="lgbm_xgb_hmm",
        dataset=json.dumps({**out.dataset_meta, "data_source": src}),
        params=cfg.lgbm.model_dump(), metrics=out.metrics, result="registered",
    )
    journal.close()
    print(f"[train] models registered → models/registry (tag={registry_tag!r})")
    if not src["real_market"]:
        print("[train] ⚠ reminder: models were trained on SYNTHETIC data — "
              "marked NOT validated for deployment in the registry")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

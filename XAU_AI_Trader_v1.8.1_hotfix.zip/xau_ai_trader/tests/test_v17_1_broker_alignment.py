"""v1.7.1 — Broker-aligned pricing: offset math, broker tick reader, feed
merge logic, calibration settings persistence.

Offline tests: MetaTrader5 is never imported for real (sandbox = unavailable
path exercised; the available path is faked). No network access.
"""

from __future__ import annotations

import json
import time

import pandas as pd
import pytest
import yaml

from app.core.exceptions import ProviderConnectionError


# ====================================================== provider offset ==
def _seed_frames(prov, price=4200.0, n=5):
    idx = pd.date_range("2026-10-09 10:00", periods=n, freq="1min", tz="UTC")
    df = pd.DataFrame({"open": [price] * n, "high": [price + 1] * n,
                       "low": [price - 1] * n, "close": [price + 0.5] * n,
                       "tick_volume": [10] * n, "real_volume": [0] * n,
                       "spread": [30.0] * n}, index=idx)
    with prov._lock:
        prov._frames["M1"] = df
        prov._connected = True
    return df


@pytest.fixture()
def defaults():
    from app.config.schema import SymbolInfoDefaults

    return SymbolInfoDefaults()


def test_offset_applies_to_candles_tick_snapshot(defaults):
    from app.data.market.live_public import LivePublicProvider

    prov = LivePublicProvider(start_refresh_thread=False, price_offset=-18.5,
                              defaults=defaults)
    _seed_frames(prov)
    c = prov.get_candles("XAUUSD", "M1", 3)
    assert abs(c["close"].iloc[-1] - 4182.0) < 1e-9       # 4200.5 - 18.5
    assert abs(c["open"].iloc[-1] - 4181.5) < 1e-9
    assert (c["spread"] == 30.0).all()                     # spread untouched
    assert (c["tick_volume"] == 10).all()                  # volume untouched
    t = prov.get_tick("XAUUSD")
    assert abs(t.last - 4182.0) < 1e-9
    assert abs(t.bid - 4181.85) < 1e-9 and abs(t.ask - 4182.15) < 1e-9
    snap = prov.snapshot()
    assert abs(snap["price"] - 4182.0) < 1e-9
    assert snap["price_offset"] == -18.5
    assert "calibrated -18.50" in snap["source"]


def test_zero_offset_is_pure_passthrough(defaults):
    from app.data.market.live_public import LivePublicProvider

    prov = LivePublicProvider(start_refresh_thread=False, defaults=defaults)
    _seed_frames(prov)
    t = prov.get_tick("XAUUSD")
    assert abs(t.last - 4200.5) < 1e-9
    assert prov.price_offset == 0.0
    assert "calibrated" not in prov.source_label


def test_spot_reference_never_offset(defaults):
    """gold-api spot is an external anchor — offset must NOT touch it."""
    from app.data.market.live_public import LivePublicProvider

    prov = LivePublicProvider(start_refresh_thread=False, price_offset=-18.5,
                              defaults=defaults)
    with prov._lock:
        prov._spot = {"price": 4183.8, "source": "gold-api.com"}
    assert prov.spot_reference()["price"] == 4183.8


# ========================================================= tick reader ==
def test_tick_reader_unavailable_is_graceful():
    from app.data.mt5.tick_reader import BrokerTickReader

    r = BrokerTickReader(["XAUUSD", "GOLD"])
    if not r.available:            # sandbox / non-Windows
        assert r.read() is None
        assert r.resolved_symbol is None
        r.shutdown()               # must not raise


def test_tick_reader_fake_mt5_happy_path(monkeypatch):
    """Fake the MetaTrader5 module to exercise the attach/read path."""
    import sys
    import types
    from app.data.mt5 import tick_reader as tr

    calls = {"init": 0, "select": 0}

    class Info:
        bid, ask, last, time, digits, visible = 4190.50, 4190.80, 0.0, 1_791_518_400, 2, True

    fake = types.ModuleType("MetaTrader5")
    fake.initialize = lambda **kw: calls.__setitem__("init", calls["init"] + 1) or True
    fake.shutdown = lambda: None
    fake.last_error = lambda: (0, "ok")
    fake.symbol_info = lambda s: Info()
    fake.symbol_info_tick = lambda s: Info()
    fake.symbol_select = lambda s, v: calls.__setitem__(
        "select", calls["select"] + 1) or True
    monkeypatch.setitem(sys.modules, "MetaTrader5", fake)

    r = tr.BrokerTickReader(["XAUUSDm", "GOLD"])
    tick = r.read()
    assert tick is not None
    assert tick["symbol"] == "XAUUSDm"
    assert tick["bid"] == 4190.50 and tick["ask"] == 4190.80
    assert abs(tick["mid"] - 4190.65) < 1e-9
    assert r.resolved_symbol == "XAUUSDm"          # cached for next reads
    assert r.read()["symbol"] == "XAUUSDm"
    r.shutdown()


def test_basis_persistence_roundtrip(tmp_path):
    from app.data.mt5.tick_reader import load_persisted_basis, persist_basis

    p = tmp_path / "logs" / "price_basis.json"
    persist_basis(p, -18.42, 0.0, 7, "XAUUSDm")
    back = load_persisted_basis(p)
    assert back and abs(back["residual_ema"] + 18.42) < 0.01
    assert back["samples"] == 7 and back["broker_symbol"] == "XAUUSDm"
    # stale (>24h) → None
    data = json.loads(p.read_text())
    data["updated_epoch"] = time.time() - 90_000
    p.write_text(json.dumps(data))
    assert load_persisted_basis(p) is None
    # garbage → None
    p.write_text("{not json")
    assert load_persisted_basis(p) is None
    assert load_persisted_basis(tmp_path / "missing.json") is None


# ============================================================ feed merge ==
def _feed(mode="auto"):
    from app.panel.market_feed import LiveMarketFeed

    f = LiveMarketFeed(__import__("pathlib").Path("."), None)
    f._mode = mode
    f._offset = 0.0
    return f


_PUB = {"price": 4209.0, "bid": 4208.85, "ask": 4209.15, "source": "Yahoo"}
_NOW = time.time()
_BROKER = {"symbol": "XAUUSDm", "bid": 4190.50, "ask": 4190.80, "mid": 4190.65,
           "received_at": _NOW}


def test_pick_price_auto_broker_wins():
    f = _feed("auto")
    sel = f._pick_price(_PUB, dict(_BROKER))
    assert sel["source"] == "broker"
    assert abs(sel["price"] - 4190.65) < 1e-9
    assert sel["bid"] == 4190.50 and sel["ask"] == 4190.80


def test_pick_price_auto_stale_broker_falls_back():
    f = _feed("auto")
    stale = {**_BROKER, "received_at": _NOW - 600}
    sel = f._pick_price(_PUB, stale, reader_available=True)
    assert sel["source"] == "public_fallback"
    assert abs(sel["price"] - 4209.0) < 1e-9
    # no MT5 support at all → plain public
    sel2 = f._pick_price(_PUB, None, reader_available=False)
    assert sel2["source"] == "public"


def test_pick_price_mode_forced():
    f = _feed("public")
    assert f._pick_price(_PUB, dict(_BROKER))["source"] == "public"
    f2 = _feed("broker")
    sel = f2._pick_price({"price": None, "bid": None, "ask": None,
                          "source": "x"}, None)
    assert sel["source"] == "broker_unavailable"


def test_measure_broker_updates_ema_and_persists(tmp_path):
    from app.data.mt5 import tick_reader as tr
    from app.panel.market_feed import LiveMarketFeed

    f = LiveMarketFeed(tmp_path, None)
    f._basis_path = tmp_path / "price_basis.json"
    f._offset = 0.0

    class R:
        last_error = ""

        @staticmethod
        def read():
            return dict(_BROKER)

    class P:
        @staticmethod
        def get_tick(symbol):
            class T:
                last = 4209.0
            return T()

    f._measure_broker(R(), P(), allow_no_public=False)
    assert f._basis_ema == pytest.approx(4190.65 - 4209.0, abs=1e-6)
    assert f._basis_cycles == 1
    # EMA smoothing converges toward the newest sample
    f._measure_broker(R(), P())
    assert f._basis_cycles == 2


# ========================================================== settings IO ==
def _mk_store(tmp_path):
    import shutil
    from pathlib import Path
    from app.panel.settings_store import AISettingsStore

    root = tmp_path / "proj"
    root.mkdir()
    base = Path(__file__).resolve().parents[1] / "config.yaml"
    shutil.copy(base, root / "config.yaml")
    return AISettingsStore(root, root / "config.yaml"), root


def test_provider_settings_persists_offset_and_mode(tmp_path):
    store, root = _mk_store(tmp_path)
    res = store.save_provider_settings({"kind": "public",
                                        "public_price_offset": -18.42,
                                        "price_source_mode": "auto"})
    assert res["ok"] and res["public_price_offset"] == -18.42
    y = yaml.safe_load((root / "config.yaml").read_text())
    assert y["provider"]["public_price_offset"] == -18.42
    assert y["provider"]["price_source_mode"] == "auto"
    assert y["provider"]["kind"] == "public"
    assert y["ai"]["providers"], "ai: section must survive provider saves"
    assert y["kill_switch"]["enabled"] is True


def test_provider_settings_rejects_bad_mode_and_offset(tmp_path):
    from app.panel.settings_store import SettingsStoreError

    store, _ = _mk_store(tmp_path)
    with pytest.raises(SettingsStoreError):
        store.save_provider_settings({"kind": "public",
                                      "price_source_mode": "bogus"})
    with pytest.raises(SettingsStoreError):
        store.save_provider_settings({"kind": "public",
                                      "public_price_offset": 99_999})


def test_schema_accepts_new_fields():
    from app.config.schema import ProviderConfig

    c = ProviderConfig(kind="public", public_price_offset=-12.3,
                       price_source_mode="broker")
    assert c.public_price_offset == -12.3 and c.price_source_mode == "broker"
    assert ProviderConfig().price_source_mode == "auto"


# ==================================================== calibrate math ====
def test_calibrate_offset_math_defaultsfree(tmp_path, defaults):
    """offset = broker_mid − raw_public_mid (raw = with-offset minus offset)."""
    from app.data.market.live_public import LivePublicProvider
    from app.panel.market_feed import LiveMarketFeed

    prov = LivePublicProvider(start_refresh_thread=False, price_offset=-18.5,
                              defaults=defaults)
    _seed_frames(prov)                      # raw close 4200.5 → provider 4182.0
    f = LiveMarketFeed(__import__("pathlib").Path("."), None)
    f._provider = prov
    f._offset = -18.5
    f._reader = None
    # no reader → honest failure
    res = f.measure_offset_now()
    assert res["ok"] is False and "MT5" in res["reason"]

"""PHASE 7 — Triple-barrier labels + PHASE 50 leakage checks."""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.models.labels import triple_barrier_labels
from app.models.leakage import check_label_horizon, check_split_purity
from app.models.validation import purged_kfold


def _mk(close, wick=0.05):
    n = len(close)
    open_ = np.roll(close, 1)
    open_[0] = close[0]
    high = np.maximum(open_, close) + wick
    low = np.minimum(open_, close) - wick
    idx = pd.date_range("2026-01-05", periods=n, freq="5min", tz="UTC")
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close,
                         "atr": np.full(n, 1.0)}, index=idx)


def test_strong_uptrend_labels_buy():
    close = np.cumsum(np.concatenate([[100], np.full(99, 0.5)]))  # +0.5/bar, atr=1
    df = _mk(close)
    labels = triple_barrier_labels(df, horizon=10, tp_atr_mult=2.0, sl_atr_mult=1.0)
    tail = labels.iloc[10:60]
    assert (tail == 1).all(), "steady +0.5 ATR/bar move must hit long TP first"


def test_strong_downtrend_labels_sell():
    close = np.cumsum(np.concatenate([[100], np.full(99, -0.5)]))
    df = _mk(close)
    labels = triple_barrier_labels(df, horizon=10, tp_atr_mult=2.0, sl_atr_mult=1.0)
    tail = labels.iloc[10:60]
    assert (tail == -1).all()


def test_flat_market_labels_no_edge():
    close = np.full(120, 100.0)
    df = _mk(close)
    labels = triple_barrier_labels(df, horizon=10, tp_atr_mult=2.0, sl_atr_mult=1.0)
    # v1.5: valid rows are genuine NO_EDGE (0); the last `horizon` rows are
    # NaN (no future window) — never silently converted to NO_EDGE.
    valid = labels.iloc[:-10]
    assert (valid == 0).all()
    assert labels.iloc[-10:].isna().all()


def test_labels_never_use_last_horizon_bars():
    close = np.cumsum(np.concatenate([[100], np.random.default_rng(5).normal(0, 0.3, 200)]))
    df = _mk(close)
    h = 20
    labels = triple_barrier_labels(df, horizon=h, tp_atr_mult=2.0, sl_atr_mult=1.0)
    chk = check_label_horizon(labels, h)
    assert chk.passed
    # v1.5: tail must be NaN/invalid, NOT zero (zero is a real NO_EDGE class)
    assert labels.iloc[-h:].isna().all()
    assert labels.iloc[:-h].notna().all()


def test_labels_deterministic():
    rng = np.random.default_rng(11)
    close = np.cumsum(np.concatenate([[100], rng.normal(0, 0.3, 150)]))
    df = _mk(close)
    l1 = triple_barrier_labels(df, 12, 2.0, 1.0)
    l2 = triple_barrier_labels(df, 12, 2.0, 1.0)
    assert np.allclose(l1.values, l2.values, equal_nan=True)


def test_purged_kfold_no_overlap():
    n = 1000
    purge = 50
    embargo = 50
    splits = purged_kfold(n, n_splits=5, purge=purge, embargo=embargo)
    assert len(splits) == 5
    for train, val in splits:
        lo, hi = int(val.min()), int(val.max())
        # no train sample inside the validation window
        assert not ((train >= lo) & (train <= hi)).any()
        # purge: no train sample within `purge` bars before/after the fold
        near = train[(train >= lo - purge) & (train <= hi + purge)]
        assert len(near) == 0
        # embargo: train after the fold starts at least embargo bars later
        after = train[train > hi]
        if len(after):
            assert after.min() > hi + purge + embargo
        before = train[train < lo]
        if len(before):
            assert before.max() < lo - purge


def test_split_purity_check():
    train = np.arange(0, 800)
    test_bad = np.arange(790, 900)       # overlaps purge zone (800-64=736..800+64)
    test_good = np.arange(900, 1000)
    assert not check_split_purity(train, test_bad, 64, 64).passed
    assert check_split_purity(train, test_good, 64, 64).passed


def test_label_executable_anchor_accounts_costs():
    """v1.5 (Mission 6): entry at t+1 open ± spread/2 ± slippage. A strong
    uptrend must still hit TP first with realistic costs, and round costs
    must be able to erase a marginal edge.

    v1.8 symmetric-labels update: the flat + tiny-TP scenario previously
    asserted BUY — under the old long-only geometry a flat market's wick
    reached the long TP so it counted as an edge. With SYMMETRIC geometry
    the very same wick also reaches the SHORT TP with the same tiny
    multiplier, i.e. the market is a both-ways whipsaw with no attributable
    side → the honest label is NO_EDGE, not BUY."""
    close = np.cumsum(np.concatenate([[100], np.full(99, 0.5)]))
    df = _mk(close)
    labels = triple_barrier_labels(df, horizon=10, tp_atr_mult=2.0, sl_atr_mult=1.0,
                                   spread_price=0.3, slippage_price=0.05)
    assert (labels.iloc[10:60] == 1).all(), "costs must not destroy a real edge"
    # flat market, tiny TP: both directions' TPs are reachable by wicks
    # under symmetric geometry → unattributable → NO_EDGE (was BUY pre-v1.8)
    flat = _mk(np.full(120, 100.0))
    no_cost = triple_barrier_labels(flat, horizon=10, tp_atr_mult=0.05, sl_atr_mult=5.0)
    with_cost = triple_barrier_labels(flat, horizon=10, tp_atr_mult=0.05, sl_atr_mult=5.0,
                                      commission_price=10.0)
    assert (no_cost.iloc[:50] == 0).all(), "flat + tiny TP: whipsaw both ways → NO_EDGE"
    assert (with_cost.iloc[:50] == 0).all(), "commission must keep erasing the marginal edge"


def test_labels_symmetric_class_difficulty():
    """v1.8: BUY and SELL must require the SAME price move magnitude.

    A −1.5 ATR down-move (within horizon) is NOT a SELL under symmetric
    geometry (short TP needs −2 ATR before short SL at +1 ATR); a mirror
    +1.5 ATR up-move is NOT a BUY either. Strong ±3 ATR moves in either
    direction DO label — with equal thresholds."""
    # moderate moves: −1.5 ATR/bar-step total −3 ATR over 2 bars? Build a
    # one-shot gap: flat, then a single −1.5 ATR bar, then flat again.
    base = np.full(120, 100.0)
    base[60] = 98.5       # single −1.5 ATR down bar (wick handled by _mk)
    df = _mk(base)
    labels = triple_barrier_labels(df, horizon=12, tp_atr_mult=2.0, sl_atr_mult=1.0)
    # the label decided at i=59 uses bars 60..71 — short TP at −2 ATR is NOT
    # reached by a −1.5 ATR move → NO_EDGE (old code: SELL via long-SL hit)
    assert labels.iloc[59] == 0, "−1.5 ATR must not be SELL (needs −2 ATR like BUY needs +2)"

    # strong −3 ATR single bar: short TP (−2) reachable, short SL (+1) not
    deep = np.full(120, 100.0)
    deep[60] = 97.0       # −3 ATR down bar
    df2 = _mk(deep)
    labels2 = triple_barrier_labels(df2, horizon=12, tp_atr_mult=2.0, sl_atr_mult=1.0)
    assert labels2.iloc[59] == -1, "−3 ATR down bar must label SELL"

    # mirror: +3 ATR single bar must label BUY (same thresholds)
    up = np.full(120, 100.0)
    up[60] = 103.0        # +3 ATR up bar
    df3 = _mk(up)
    labels3 = triple_barrier_labels(df3, horizon=12, tp_atr_mult=2.0, sl_atr_mult=1.0)
    assert labels3.iloc[59] == 1, "+3 ATR up bar must label BUY (symmetry)"


def test_sl_first_no_hit_is_not_sell():
    """v1.5 (ML-N3): ambiguous='sl_first' must apply ONLY when BOTH barriers
    are hit on the same bar. A flat market (no hit at all) must be NO_EDGE,
    not SELL — the old sentinel comparison (10**9 == 10**9) mislabeled every
    no-hit bar as -1."""
    close = np.full(120, 100.0)
    df = _mk(close)
    labels = triple_barrier_labels(df, horizon=10, tp_atr_mult=2.0, sl_atr_mult=1.0,
                                   ambiguous="sl_first")
    valid = labels.iloc[:-10]
    assert (valid == 0).all(), "no-hit bars must stay NO_EDGE under sl_first"

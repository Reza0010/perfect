"""PHASE 22-29 — Risk engine: sizing math, SL/TP, hard filters, kill switch."""

from __future__ import annotations

import json

import numpy as np
import pandas as pd
import pytest

from app.config.schema import KillSwitchConfig, NewsRisk, Regime, RiskConfig, SLMethod, TPMethod
from app.data.market.models import AccountInfo, SymbolInfo
from app.risk.engine import RiskEngine
from app.risk.kill_switch import KillSwitch
from app.risk.sizing import calc_lot, margin_required, round_price
from app.risk.stops import compute_stop_loss, compute_take_profit


# ---------------------------------------------------------------- sizing --
def test_lot_size_exact_math(symbol_info):
    # XAUUSD: sl 3.0 → 300 ticks × $1 = $300/lot; risk $50 → 0.1666 → 0.16
    assert calc_lot(10_000, 0.5, 3.0, symbol_info) == pytest.approx(0.16)


def test_lot_size_respects_min_lot_or_refuses(symbol_info):
    # risk $1 with $3000/lot loss → min lot would lose $30 > $1 → refuse
    assert calc_lot(1_000, 0.1, 30.0, symbol_info) == 0.0
    # risk $60 with $3000/lot loss → raw = 0.02 lots → rounded down to step
    assert calc_lot(1_000, 6.0, 30.0, symbol_info) == pytest.approx(0.02)


def test_lot_size_never_exceeds_max_lot(symbol_info):
    assert calc_lot(1_000_000, 0.5, 0.1, symbol_info) <= 100.0


def test_zero_sl_distance_refused(symbol_info):
    assert calc_lot(10_000, 0.5, 0.0, symbol_info) == 0.0


def test_margin_math(symbol_info):
    # 2650 × 100 oz × 1 lot / 100 leverage = 2650
    assert margin_required(2650.0, 1.0, symbol_info) == pytest.approx(2650.0)


def test_round_price(symbol_info):
    assert round_price(2650.123456, symbol_info) == 2650.12


# ----------------------------------------------------------------- stops --
def test_atr_stop_buy(ohlc_df):
    cfg = RiskConfig()
    entry = float(ohlc_df["close"].iloc[-1])
    atr_v = 1.5
    sl = compute_stop_loss("BUY", entry, ohlc_df, atr_v, SLMethod.ATR, cfg)
    assert sl == pytest.approx(entry - cfg.atr_sl_mult * atr_v)


def test_atr_stop_sell(ohlc_df):
    cfg = RiskConfig()
    entry = float(ohlc_df["close"].iloc[-1])
    sl = compute_stop_loss("SELL", entry, ohlc_df, 1.5, SLMethod.ATR, cfg)
    assert sl == pytest.approx(entry + cfg.atr_sl_mult * 1.5)


def test_rr_take_profit():
    class C:
        min_rr = 2.0

    entry, sl = 100.0, 98.0
    tp, rr = compute_take_profit("BUY", entry, sl, None, 1.0, TPMethod.RR, C())
    assert tp == pytest.approx(104.0)
    assert rr == pytest.approx(2.0)


def test_rr_take_profit_sell():
    class C:
        min_rr = 2.0

    tp, rr = compute_take_profit("SELL", 100.0, 102.0, None, 1.0, TPMethod.RR, C())
    assert tp == pytest.approx(96.0)  # 100 − 2×(102−100)
    assert rr == pytest.approx(2.0)


# ------------------------------------------------------------ risk engine --
def _risk_ctx(**over):
    from app.config.schema import RiskConfig

    base = dict(
        side="BUY", entry=2650.0,
        account=AccountInfo(balance=10_000, equity=10_000, free_margin=10_000),
        symbol=SymbolInfo(name="XAUUSD", point=0.01, tick_size=0.01, tick_value=1.0,
                          contract_size=100.0, volume_min=0.01, volume_max=100.0,
                          volume_step=0.01, leverage=100),
        df=None, atr=2.0, ml_confidence=0.7, smc_bias=0.5,
        regime=Regime.TRENDING_BULL, news_risk=NewsRisk.LOW, data_quality=95.0,
        spread_points=15.0, open_positions=0, daily_loss_percent=0.0,
        drawdown_percent=0.0, ai_confidence=0.8, ai_required=True, ai_available=True,
        open_risk_percent=0.0, mt5_connected=True,  # v1.5: caller must KNOW these
    )
    base.update(over)
    return base


def _evaluate(**over):
    eng = RiskEngine(RiskConfig())
    return eng.evaluate(**_risk_ctx(**over))


def test_risk_approves_clean_setup(ohlc_df):
    d = _evaluate(df=ohlc_df)
    assert d.approved, d.reason_codes
    assert d.lot > 0 and d.sl < d.entry < d.tp
    assert d.achieved_rr >= 2.0


def test_risk_fail_closed_on_unknown_open_risk(ohlc_df):
    """v1.5 (Mission 15/48): the old default open_risk_percent=0.0 let callers
    who could NOT measure open risk silently bypass the cumulative cap."""
    d = _evaluate(df=ohlc_df, open_risk_percent=None)
    assert not d.approved
    assert "OPEN_RISK_UNKNOWN" in d.reason_codes


def test_risk_fail_closed_on_unknown_connection(ohlc_df):
    d = _evaluate(df=ohlc_df, mt5_connected=None)
    assert not d.approved
    assert "MT5_CONNECTION_UNKNOWN" in d.reason_codes


def test_risk_fail_closed_on_zero_free_margin(ohlc_df):
    """v1.5 (exec-N2): a zero-free-margin account used to SKIP the margin
    gate entirely (`free_margin > 0 and ...`) and approve new trades."""
    acct = AccountInfo(balance=10_000, equity=10_000, free_margin=0.0)
    d = _evaluate(df=ohlc_df, account=acct)
    assert not d.approved
    assert any(c.startswith("INSUFFICIENT_MARGIN") for c in d.reason_codes)


def test_risk_rejects_broker_stops_level(ohlc_df):
    """v1.5 (exec-N6): broker minimum stop distance enforced pre-approval."""
    sym = SymbolInfo(name="XAUUSD", point=0.01, tick_size=0.01, tick_value=1.0,
                     contract_size=100.0, stops_level_points=5000)  # 50.00
    d = _evaluate(df=ohlc_df, symbol=sym)
    assert not d.approved
    assert any(c.startswith("BROKER_STOPS_LEVEL") for c in d.reason_codes)


def test_risk_rejects_high_spread():
    eng = RiskEngine(RiskConfig(max_spread_points=10))
    d2 = eng.evaluate(**_risk_ctx(spread_points=50))
    assert not d2.approved
    assert "SPREAD_TOO_HIGH_50pts" in d2.reason_codes


def test_risk_rejects_high_news():
    d = _evaluate(news_risk=NewsRisk.HIGH, df=None)
    assert "NEWS_RISK_HIGH" in d.reason_codes


def test_risk_rejects_disallowed_regime():
    d = _evaluate(regime=Regime.HIGH_VOLATILITY, df=None)
    assert any(c.startswith("REGIME_NOT_ALLOWED") for c in d.reason_codes)


def test_risk_rejects_low_ml_confidence():
    d = _evaluate(ml_confidence=0.3, df=None)
    assert any(c.startswith("ML_CONF_LOW") for c in d.reason_codes)


def test_risk_rejects_when_ai_required_but_unavailable():
    d = _evaluate(ai_available=False, df=None)
    assert "AI_REQUIRED_UNAVAILABLE" in d.reason_codes


def test_risk_rejects_low_ai_confidence():
    d = _evaluate(ai_confidence=0.2, df=None)
    assert any(c.startswith("AI_CONF_LOW") for c in d.reason_codes)


def test_risk_rejects_daily_loss_exceeded():
    d = _evaluate(daily_loss_percent=5.0, df=None)
    assert any(c.startswith("MAX_DAILY_LOSS") for c in d.reason_codes)


def test_risk_rejects_drawdown_exceeded():
    # equity 9,000 with peak 10,000 → 10% drawdown ≥ config 10%
    d = _evaluate(account=AccountInfo(balance=10_000, equity=9_000, free_margin=9_000),
                  peak_equity=10_000.0, drawdown_percent=10.0, df=None)
    assert any(c.startswith("MAX_DRAWDOWN") for c in d.reason_codes)


def test_risk_rejects_max_positions():
    d = _evaluate(open_positions=1, df=None)
    assert "MAX_OPEN_POSITIONS" in d.reason_codes


def test_risk_rejects_low_data_quality():
    d = _evaluate(data_quality=40.0, df=None)
    assert any(c.startswith("DATA_QUALITY_LOW") for c in d.reason_codes)


# ------------------------------------------------------------ kill switch --
def test_kill_switch_trips_on_daily_loss(tmp_path):
    ks = KillSwitch(KillSwitchConfig(state_file=str(tmp_path / "ks.json")))
    ks.check(daily_loss_percent=3.0)
    assert ks.is_active
    assert ks.state.trigger == "DAILY_LOSS_LIMIT"


def test_kill_switch_trips_on_drawdown(tmp_path):
    ks = KillSwitch(KillSwitchConfig(state_file=str(tmp_path / "ks.json")))
    ks.check(drawdown_percent=12.0)
    assert ks.state.trigger == "MAX_DRAWDOWN"


def test_kill_switch_trips_on_abnormal_spread(tmp_path):
    ks = KillSwitch(KillSwitchConfig(state_file=str(tmp_path / "ks.json")))
    ks.check(spread_points=500)
    assert ks.state.trigger == "ABNORMAL_SPREAD"


def test_kill_switch_persists_and_blocks_restart(tmp_path):
    path = str(tmp_path / "ks.json")
    ks1 = KillSwitch(KillSwitchConfig(state_file=path))
    ks1.trip("EXECUTION_FAILURES", "3 failures")
    ks2 = KillSwitch(KillSwitchConfig(state_file=path))
    assert ks2.is_active
    assert ks2.state.trigger == "EXECUTION_FAILURES"
    ks2.reset()
    assert not KillSwitch(KillSwitchConfig(state_file=path)).is_active


def test_kill_switch_manual_reset(tmp_path):
    ks = KillSwitch(KillSwitchConfig(state_file=str(tmp_path / "ks.json")))
    ks.trip("DATA_CORRUPTION")
    ks.reset()
    assert not ks.is_active

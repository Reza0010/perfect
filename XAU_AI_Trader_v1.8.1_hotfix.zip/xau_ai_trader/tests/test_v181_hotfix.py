"""v1.8.1 HOTFIX regression tests.

User-reported failures on Windows (2026-10-11):

  F27 — panel trading loop crash with provider.kind=mt5:
        ``SymbolNotFoundError: Symbol 'XAUUSD' not found. Available: []``
        build_system() called get_symbol_info() on a NEVER-CONNECTED MT5
        provider. Fix: lazy connect + assumed fallback specs (marked).

  F28 — permanent ``WAIT: ['NEWS_UNAVAILABLE']``:
        StaticCSVNewsProvider.is_fresh() used file MTIME with a 24h window;
        a calendar shipped inside a ZIP preserves its BUILD timestamp, so
        every user copy went "stale" 24h after packaging even while the
        events covered months around NOW. Fix: coverage-based freshness.

  F29 — kill switch engaged MT5_DISCONNECT on the FIRST iteration when the
        provider was never connected (terminal not started) — the system
        died permanently on a configuration/setup issue instead of waiting
        and reconnecting. Fix: MT5_DISCONNECT only fires when an
        ESTABLISHED connection is LOST; a never-connected provider WAITs.
"""

from __future__ import annotations

import asyncio
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from app.config.loader import load_config
from app.core.exceptions import ProviderConnectionError
from app.data.market.models import AccountInfo, SymbolInfo


# ---------------------------------------------------------------- helpers --
def _write_calendar(path: Path, rows: list[tuple[str, str, str]]) -> Path:
    lines = ["time,event,country,currency,importance,previous,forecast,actual"]
    for t, ev, imp in rows:
        lines.append(f"{t},{ev},US,USD,{imp},,,")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _age_file(path: Path, days: float) -> None:
    old = time.time() - days * 86400.0
    os.utime(path, (old, old))


# ============================================================== F28 news ==
def test_static_csv_fresh_when_coverage_spans_now_despite_old_mtime(tmp_path):
    """F28: a calendar covering NOW is usable even when the file was built
    days ago (ZIP-preserved mtime must not permanently WAIT the system)."""
    from app.news.providers import StaticCSVNewsProvider

    now = datetime.now(timezone.utc)
    p = _write_calendar(tmp_path / "news.csv", [
        ((now - timedelta(days=3)).isoformat(), "GDP q/q", "MEDIUM"),
        ((now + timedelta(days=3)).isoformat(), "CPI y/y", "HIGH"),
    ])
    _age_file(p, days=5)  # older than the old 24h window
    prov = StaticCSVNewsProvider(str(p))
    assert prov.is_fresh() is True
    # provenance is still honest — mtime remains reportable
    assert prov.last_update() is not None


def test_static_csv_not_fresh_when_coverage_is_past(tmp_path):
    """F28: when the calendar can no longer speak about NOW the gate still
    fails closed (UNKNOWN -> WAIT)."""
    from app.news.providers import StaticCSVNewsProvider

    now = datetime.now(timezone.utc)
    p = _write_calendar(tmp_path / "news.csv", [
        ((now - timedelta(days=10)).isoformat(), "GDP q/q", "MEDIUM"),
        ((now - timedelta(days=2)).isoformat(), "CPI y/y", "HIGH"),
    ])
    prov = StaticCSVNewsProvider(str(p))
    assert prov.is_fresh() is False


def test_news_engine_out_of_range_reason_code(tmp_path):
    from app.config.schema import NewsConfig, NewsRisk
    from app.news.engine import NewsEngine
    from app.news.providers import StaticCSVNewsProvider

    now = datetime.now(timezone.utc)
    p = _write_calendar(tmp_path / "news.csv", [
        ((now - timedelta(days=10)).isoformat(), "GDP q/q", "MEDIUM"),
    ])
    eng = NewsEngine(StaticCSVNewsProvider(str(p)), NewsConfig())
    a = eng.assess()
    assert a.risk == NewsRisk.UNKNOWN
    assert "NEWS_CALENDAR_OUT_OF_RANGE" in a.reasons


def test_news_engine_unavailable_reason_code():
    from app.config.schema import NewsConfig, NewsRisk
    from app.news.engine import NewsEngine
    from app.news.providers import NullNewsProvider

    eng = NewsEngine(NullNewsProvider(), NewsConfig())
    a = eng.assess()
    assert a.risk == NewsRisk.UNKNOWN
    assert "NEWS_PROVIDER_UNAVAILABLE" in a.reasons


def test_news_engine_assessment_proceeds_within_coverage(tmp_path):
    """The user's exact scenario: shipped calendar covers today, no event in
    the assessment window -> LOW (tradeable), NOT UNKNOWN."""
    from app.config.schema import NewsConfig, NewsRisk
    from app.news.engine import NewsEngine
    from app.news.providers import StaticCSVNewsProvider

    now = datetime.now(timezone.utc)
    p = _write_calendar(tmp_path / "news.csv", [
        ((now - timedelta(days=9)).isoformat(), "CPI y/y", "HIGH"),
        ((now + timedelta(days=3)).isoformat(), "PPI m/m", "MEDIUM"),
    ])
    _age_file(p, days=5)
    eng = NewsEngine(StaticCSVNewsProvider(str(p)), NewsConfig())
    a = eng.assess()
    assert a.risk == NewsRisk.LOW
    assert a.provider_healthy is True


def test_pipeline_forwards_precise_news_reason():
    """The journal/panel must see the precise cause, not a generic code."""
    src = Path("app/pipeline.py").read_text(encoding="utf-8")
    assert 'wait_reasons.append(news.reasons[0] if news.reasons else "NEWS_UNAVAILABLE")' in src


def test_news_engine_trusts_found_events_even_outside_coverage(tmp_path):
    """F28 edge: a HIGH event found INSIDE the assessment window is real
    calendar data — it must raise risk even when 'now' precedes the
    calendar's first event (pre-release warning), regardless of file age."""
    from app.config.schema import NewsConfig, NewsRisk
    from app.news.engine import NewsEngine
    from app.news.providers import StaticCSVNewsProvider

    now = datetime.now(timezone.utc)
    p = _write_calendar(tmp_path / "news.csv", [
        ((now + timedelta(minutes=5)).isoformat(), "US CPI", "HIGH"),
    ])
    _age_file(p, days=5)
    eng = NewsEngine(StaticCSVNewsProvider(str(p)), NewsConfig())
    a = eng.assess()
    assert a.risk == NewsRisk.HIGH
    assert a.upcoming and a.upcoming[0].event == "US CPI"


def test_mock_news_provider_is_always_coverage_fresh():
    from app.news.providers import MockNewsProvider

    assert MockNewsProvider("nonexistent.csv").is_fresh() is True


# ============================================================== F27 MT5 ==
class _UnreachableMT5:
    """Stands in for MT5DataProvider when the terminal is not running."""

    name = "mt5"

    def __init__(self, **kwargs):
        pass

    def connect(self):
        raise ProviderConnectionError(
            "MT5 initialize failed (simulated): terminal not running")

    def is_connected(self):
        return False

    def get_symbol_info(self, symbol):
        raise ProviderConnectionError("MT5 terminal not reachable (simulated)")

    def get_candles(self, *a, **k):
        raise ProviderConnectionError("MT5 terminal not reachable (simulated)")

    def get_tick(self, symbol):
        raise ProviderConnectionError("MT5 terminal not reachable (simulated)")

    def get_account_info(self):
        return AccountInfo()

    def disconnect(self):
        pass


class _ReachableMT5(_UnreachableMT5):
    def connect(self):
        return True

    def is_connected(self):
        return True

    def get_symbol_info(self, symbol):
        return SymbolInfo(name="XAUUSD.ecn", point=0.01, tick_size=0.01,
                          tick_value=1.0, contract_size=100.0)


def _mt5_cfg(tmp_path):
    cfg = load_config(None)
    cfg = cfg.model_copy(update={
        "provider": cfg.provider.model_copy(update={"kind": "mt5"}),
        "paths": cfg.paths.model_copy(update={
            "logs_dir": str(tmp_path),
            "models_dir": str(tmp_path / "models"),
            "reports_dir": str(tmp_path / "reports"),
            "data_dir": str(tmp_path / "data")}),
        "kill_switch": cfg.kill_switch.model_copy(
            update={"state_file": str(tmp_path / "ks.json")}),
        "execution": cfg.execution.model_copy(
            update={"poll_interval_seconds": 0.1}),
    })
    return cfg


def test_build_system_mt5_unreachable_no_crash_assumed_specs(tmp_path, monkeypatch):
    """F27 regression: provider.kind=mt5 with no terminal MUST NOT crash
    build_system; the paper executor runs on clearly-marked assumed specs."""
    import app.data.mt5.provider as mt5mod
    from main import build_system

    monkeypatch.setattr(mt5mod, "MT5DataProvider", _UnreachableMT5)
    cfg = _mt5_cfg(tmp_path)
    system = build_system(cfg, registry_tag="main")  # must not raise
    assert system.executor.symbol_info.specs_source == "assumed_fallback"
    assert system.executor.symbol_info.name == cfg.symbol.primary
    # honest defaults from the documented fallback block
    assert system.executor.symbol_info.point == pytest.approx(0.01)
    assert system.executor.symbol_info.contract_size == pytest.approx(100.0)


def test_build_system_mt5_connected_uses_broker_specs(tmp_path, monkeypatch):
    """F27: with a live terminal the REAL broker specs are used."""
    import app.data.mt5.provider as mt5mod
    from main import build_system

    monkeypatch.setattr(mt5mod, "MT5DataProvider", _ReachableMT5)
    cfg = _mt5_cfg(tmp_path)
    system = build_system(cfg, registry_tag="main")
    assert system.executor.symbol_info.name == "XAUUSD.ecn"
    assert system.executor.symbol_info.specs_source == "provider"


def test_public_provider_specs_marked_assumed():
    from app.data.market.live_public import LivePublicProvider

    p = LivePublicProvider(start_refresh_thread=False)
    info = p.get_symbol_info("XAUUSD")
    assert info.specs_source == "assumed_public_defaults"


# ============================================================== F29 loop ==
class _FlippingProvider(_UnreachableMT5):
    """Connected for the first two is_connected() calls, then dead — models
    a LOST established connection mid-session."""

    def __init__(self):
        self._calls = 0

    def connect(self):
        return True

    def is_connected(self):
        self._calls += 1
        return self._calls <= 2


class _DeadPipeline:
    bundle = None

    def __init__(self):
        from app.config.schema import NewsConfig
        from app.news.engine import NewsEngine
        from app.news.providers import NullNewsProvider

        self.news_engine = NewsEngine(NullNewsProvider(), NewsConfig())

    def analyze(self, *a, **k):
        raise ProviderConnectionError("provider gone (simulated)")


class _StubExecutor:
    mode = "paper"

    def positions(self):
        return []

    def update(self):
        return []

    def account(self, balance=10000.0):
        return AccountInfo(balance=balance, equity=balance, free_margin=balance)


def _trader(tmp_path, provider):
    from app.journal.journal import Journal
    from app.monitoring.health import HealthRegistry
    from app.monitoring.state import StateStore
    from app.risk.engine import RiskEngine
    from app.risk.kill_switch import KillSwitch
    from app.trader import TradingSystem

    cfg = load_config(None)
    cfg = cfg.model_copy(update={
        "paths": cfg.paths.model_copy(update={
            "logs_dir": str(tmp_path),
            "models_dir": str(tmp_path / "models"),
            "reports_dir": str(tmp_path / "reports"),
            "data_dir": str(tmp_path / "data")}),
        "kill_switch": cfg.kill_switch.model_copy(
            update={"state_file": str(tmp_path / "ks.json")}),
        "execution": cfg.execution.model_copy(
            update={"poll_interval_seconds": 0.1}),
    })
    ks = KillSwitch(cfg.kill_switch)
    ts = TradingSystem(
        cfg=cfg, provider=provider, pipeline=_DeadPipeline(), ensemble=None,
        risk=RiskEngine(cfg.risk, ks), executor=_StubExecutor(),
        gateway=type("G", (), {"available_providers": []})(),
        journal=Journal(tmp_path / "journal.db"), health=HealthRegistry(),
        kill_switch=ks, state_store=StateStore(tmp_path / "state.json"),
        notifiers=None,
    )
    return ts


def test_unreachable_provider_waits_without_kill_switch(tmp_path):
    """F29: never-connected provider (terminal not started) → honest WAIT,
    NO kill-switch engagement, NO data-corruption streak."""
    ts = _trader(tmp_path, _UnreachableMT5())
    asyncio.run(ts.run(max_loops=1))
    assert ts.kill_switch.is_active is False
    assert ts._data_error_streak == 0


def test_kill_switch_trips_on_lost_established_connection(tmp_path):
    """F29: an ESTABLISHED connection that drops mid-session still trips
    MT5_DISCONNECT (fail-closed preserved for genuine disconnects)."""
    ts = _trader(tmp_path, _FlippingProvider())
    asyncio.run(ts.run(max_loops=2))
    assert ts.kill_switch.is_active is True
    assert "MT5_DISCONNECT" in ts.kill_switch.state.triggers

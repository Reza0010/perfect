"""PHASE 30-32 — Execution: paper fills, SL/TP management, costs, live gates."""

from __future__ import annotations

import pytest

from app.config.schema import ExecutionConfig
from app.core import exceptions as exc
from app.data.market.models import SymbolInfo
from app.execution.mt5_exec import MT5Executor
from app.execution.paper import PaperExecutor


class TickStubProvider:
    """Minimal provider stub returning a controlled tick."""

    def __init__(self, bid: float = 2650.0, ask: float = 2650.2):
        self.bid, self.ask = bid, ask

    def get_tick(self, symbol):
        from datetime import datetime, timezone

        from app.data.market.models import Tick

        return Tick(time=datetime.now(timezone.utc), bid=self.bid, ask=self.ask)


@pytest.fixture
def symbol_info():
    return SymbolInfo(name="XAUUSD", point=0.01, tick_size=0.01, tick_value=1.0,
                      contract_size=100.0, volume_min=0.01, volume_max=100.0,
                      volume_step=0.01, leverage=100)


def test_paper_buy_fills_at_ask_plus_slippage(symbol_info):
    ex = PaperExecutor(TickStubProvider(2650.0, 2650.2), symbol_info,
                       ExecutionConfig(slippage_points=5.0))
    res = ex.open_market("XAUUSD", "BUY", 0.1, 2645.0, 2660.0)
    assert res.success and res.price == pytest.approx(2650.2 + 0.05)


def test_paper_sell_fills_at_bid_minus_slippage(symbol_info):
    ex = PaperExecutor(TickStubProvider(2650.0, 2650.2), symbol_info,
                       ExecutionConfig(slippage_points=5.0))
    res = ex.open_market("XAUUSD", "SELL", 0.1, 2655.0, 2640.0)
    assert res.price == pytest.approx(2650.0 - 0.05)


def test_paper_rejects_too_close_sl(symbol_info):
    ex = PaperExecutor(TickStubProvider(), symbol_info, ExecutionConfig())
    with pytest.raises(exc.OrderRejectedError):
        ex.open_market("XAUUSD", "BUY", 0.1, 2650.19, 2660.0)  # SL above fill


def test_paper_close_computes_pnl_with_fees(symbol_info):
    ex = PaperExecutor(TickStubProvider(2650.0, 2650.2), symbol_info,
                       ExecutionConfig(slippage_points=0.0, commission_per_lot=7.0))
    res = ex.open_market("XAUUSD", "BUY", 1.0, 2640.0, 2660.0)
    ex.provider = TickStubProvider(2655.0, 2655.2)  # price moved +5
    out = ex.close_position(res.ticket, "MANUAL")
    pos = ex._positions  # empty now
    # entry 2650.20 (ask), exit 2655.00 (bid) → 480 ticks × $1 × 1.0 lot
    assert out.price == pytest.approx(2655.0)
    # commission stored on position before pop
    assert out.success


def test_paper_sl_hit_before_tp_conservative(symbol_info):
    ex = PaperExecutor(TickStubProvider(2650.0, 2650.2), symbol_info, ExecutionConfig())
    res = ex.open_market("XAUUSD", "BUY", 0.1, 2645.0, 2670.0)
    # jump price so both SL and TP would be inside one huge bar → SL first
    ex.provider = TickStubProvider(2640.0, 2640.2)
    closed = ex.update()
    assert closed and closed[0][1] == "SL"


def test_paper_tp_hit(symbol_info):
    ex = PaperExecutor(TickStubProvider(2650.0, 2650.2), symbol_info, ExecutionConfig())
    res = ex.open_market("XAUUSD", "BUY", 0.1, 2645.0, 2660.0)
    ex.provider = TickStubProvider(2661.0, 2661.2)
    closed = ex.update()
    assert closed and closed[0][1] == "TP"


def test_paper_unrealized_pnl_math(symbol_info):
    ex = PaperExecutor(TickStubProvider(2650.0, 2650.2), symbol_info,
                       ExecutionConfig(slippage_points=0.0))
    res = ex.open_market("XAUUSD", "BUY", 0.5, 2640.0, 2660.0)  # entry 2650.20
    pos = ex.positions()[0]
    pnl = ex.unrealized_pnl(pos, 2652.0)
    # (2652.0 - 2650.2) / 0.01 ticks × $1 × 0.5 = 90
    assert pnl == pytest.approx(90.0)


def test_live_executor_requires_explicit_config(symbol_info):
    from app.config.schema import ExecutionConfig, TradingMode

    provider = TickStubProvider()
    # mode=PAPER → refuse
    with pytest.raises(exc.ConfigError):
        MT5Executor(provider, ExecutionConfig(mode=TradingMode.PAPER, live_trading_enabled=True))
    # live disabled → refuse
    with pytest.raises(exc.ConfigError):
        MT5Executor(provider, ExecutionConfig(mode=TradingMode.LIVE, live_trading_enabled=False))
    # no env confirmation → refuse
    import os

    os.environ.pop("LIVE_CONFIRM", None)
    with pytest.raises(exc.ConfigError):
        MT5Executor(provider, ExecutionConfig(mode=TradingMode.LIVE, live_trading_enabled=True))


def test_simulated_provider_refuses_orders():
    from app.data.market.simulated import SimulatedProvider

    p = SimulatedProvider(days=2)
    p.connect()
    with pytest.raises(exc.ProviderConnectionError):
        p.send_market_order("XAUUSD", "BUY", 0.1, 0, 0, "c", 1)

"""PHASE 66 tests — statistical engine, fail-safe matrix (§22), reconciliation
(§21), realtime paper mode (§24), no-auto-retrain (§25), Windows guards (§2/§20),
news status (§16)."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).parents[1]))

from app.analytics.statistics import (  # noqa: E402
    bootstrap_analysis, full_metrics, monte_carlo_sequences, sample_size_warning)
from app.data.market.simulated import SimulatedProvider  # noqa: E402
from app.execution.realtime_paper import BrokerRealtimePaper, PaperObservation  # noqa: E402
from app.execution.reconciliation import reconcile_positions  # noqa: E402
from app.monitoring.no_retrain import AutoRetrainForbidden, assert_no_auto_retrain  # noqa: E402
from app.news.real_provider import NEWS_VALIDATION_PENDING, news_validation_status  # noqa: E402
from app.risk.failsafe import FailSafeAction, FailSafeState, evaluate_failsafe, scenario_matrix  # noqa: E402


# ------------------------------------------------------------------ §10/§9 --
def test_sample_size_warning_thresholds():
    assert sample_size_warning(29) == "SAMPLE_TOO_SMALL"
    assert sample_size_warning(30) == "LOW_STATISTICAL_POWER"
    assert sample_size_warning(99) == "LOW_STATISTICAL_POWER"
    assert sample_size_warning(100) == "MODERATE_SAMPLE"
    assert sample_size_warning(299) == "MODERATE_SAMPLE"
    assert sample_size_warning(300) == "ACCEPTABLE_FOR_PRELIMINARY_ANALYSIS"


def test_bootstrap_refuses_small_resample_count():
    with pytest.raises(ValueError):
        bootstrap_analysis(np.array([1.0, -1.0]), n_resamples=100)


def test_bootstrap_marks_true_edge_established():
    rng = np.random.default_rng(11)
    pnl = np.where(rng.random(400) < 0.62, rng.uniform(10, 25, 400),
                   -rng.uniform(5, 12, 400))
    b = bootstrap_analysis(pnl)
    assert b.verdict == "EDGE_ESTABLISHED"
    assert b.pf_ci95[0] > 1.0
    assert b.expectancy_ci95[0] > 0.0


def test_bootstrap_marks_coin_flip_not_established():
    rng = np.random.default_rng(12)
    pnl = np.where(rng.random(200) < 0.5, rng.uniform(8, 12, 200),
                   -rng.uniform(8, 12, 200))
    b = bootstrap_analysis(pnl)
    assert b.verdict == "EDGE_NOT_ESTABLISHED"
    assert b.prob_pf_le_1 > 0.05


def test_bootstrap_small_sample_override():
    # strong-looking 4-trade result must NOT certify an edge (§10 override)
    b = bootstrap_analysis(np.array([100.0, 120.0, 90.0, 110.0]))
    assert b.verdict == "EDGE_NOT_ESTABLISHED"
    assert any("SAMPLE_TOO_SMALL" in r for r in b.reasons)


def test_bootstrap_empty_trades_insufficient():
    b = bootstrap_analysis(np.array([]))
    assert b.verdict == "INSUFFICIENT_DATA"


def test_monte_carlo_downside_metrics():
    rng = np.random.default_rng(13)
    pnl = np.where(rng.random(300) < 0.55, rng.uniform(5, 20, 300),
                   -rng.uniform(5, 20, 300))
    mc = monte_carlo_sequences(pnl)
    assert mc["n_runs"] >= 10_000
    # negative DD values: worst ≤ 99th-pct ≤ 95th-pct ≤ 0
    assert mc["worst_dd_pct"] <= mc["dd_p99_pct"] <= mc["dd_p95_pct"] < 0
    assert mc["max_losing_streak"] >= 1
    assert 0.0 <= mc["risk_of_ruin_pct"] <= 100.0


def test_monte_carlo_minimum_runs_enforced():
    with pytest.raises(ValueError):
        monte_carlo_sequences(np.array([1.0, 2.0]), n_runs=500)


def test_full_metrics_fields_complete():
    t = pd.DataFrame({
        "pnl": [50.0, -30.0, 70.0, -20.0], "fees": [7.0] * 4, "swap": [0.0] * 4,
        "volume": [0.1] * 4,
        "entry_time": pd.to_datetime(["2026-01-01", "2026-01-02", "2026-01-03",
                                      "2026-01-04"], utc=True),
        "exit_time": pd.to_datetime(["2026-01-01T02:00", "2026-01-02T03:00",
                                     "2026-01-03T01:00", "2026-01-04T05:00"], utc=True)})
    eq = pd.Series([10000, 10050, 10020, 10090, 10070],
                   index=pd.date_range("2026-01-01", periods=5, freq="1D", tz="UTC"))
    m = full_metrics(t, eq, 10_000.0, spread_cost_estimate=12.0)
    for key in ("n_trades", "win_rate_pct", "avg_win", "avg_loss", "expectancy",
                "profit_factor", "gross_profit", "gross_loss", "net_profit",
                "max_drawdown_pct", "average_drawdown_pct", "sharpe", "sortino",
                "calmar", "payoff_ratio", "exposure", "avg_holding_hours",
                "median_holding_hours", "turnover_lots", "commission",
                "spread_cost_estimate", "slippage_cost_estimate", "swap"):
        assert key in m, f"missing §8 metric: {key}"
    assert m["n_trades"] == 4 and m["win_rate_pct"] == 50.0
    assert m["profit_factor"] == pytest.approx((50 + 70) / (30 + 20))
    # PF never reported without trade count (§8 rule)
    assert m["n_trades"] >= 0


# -------------------------------------------------------------------- §22 ---
def test_failsafe_matrix_all_18_scenarios():
    matrix = scenario_matrix()
    assert len(matrix) == 18
    covered = {m["scenario"] for m in matrix}
    for required in ("MT5 disconnect", "stale market data", "abnormal spread",
                     "invalid OHLC", "missing model", "corrupt model",
                     "invalid AI JSON", "AI timeout", "AI 429",
                     "news provider failure", "journal failure", "database failure",
                     "risk limit violation", "daily loss limit", "max drawdown",
                     "duplicate order", "broker rejection", "reconciliation mismatch"):
        assert required in covered, f"§22 scenario missing: {required}"
    for m in matrix:
        action, reason = evaluate_failsafe(FailSafeState(**m["state"]))
        assert action.name == m["required"], \
            f"{m['scenario']}: expected {m['required']}, got {action.name} ({reason})"
        assert action in (FailSafeAction.NO_NEW_TRADE, FailSafeAction.HALT)


def test_failsafe_unknown_critical_state_is_no_new_trade():
    action, reason = evaluate_failsafe(FailSafeState())  # everything unknown
    assert action == FailSafeAction.NO_NEW_TRADE
    assert reason == "UNKNOWN_CRITICAL_STATE"


def test_failsafe_all_clear_proceeds():
    st = FailSafeState(mt5_connected=True, market_data_fresh=True, spread_ok=True,
                       ohlc_valid=True, model_available=True, model_integrity_ok=True,
                       ai_response_valid=True, ai_reachable=True, news_provider_ok=True,
                       journal_ok=True, database_ok=True, risk_limits_ok=True,
                       daily_loss_ok=True, drawdown_ok=True, reconciliation_ok=True)
    action, reason = evaluate_failsafe(st)
    assert action == FailSafeAction.PROCEED and reason == "ALL_CLEAR"


# -------------------------------------------------------------------- §21 ---
def _pos(ticket, **kw):
    base = {"ticket": ticket, "symbol": "XAUUSD", "side": "BUY", "volume": 0.10,
            "entry": 2650.0, "sl": 2645.0, "tp": 2660.0, "profit": 5.0,
            "swap": -0.5, "commission": -0.7}
    base.update(kw)
    return base


def test_reconciliation_clean_state_ok():
    internal = [_pos(1), _pos(2)]
    broker = [_pos(1), _pos(2)]
    rep = reconcile_positions(internal, broker)
    assert rep.ok and rep.compared == 2 and not rep.orphans and not rep.missing


def test_reconciliation_orphan_position_critical():
    rep = reconcile_positions([_pos(1)], [_pos(1), _pos(99)])
    assert not rep.ok and rep.orphans[0]["ticket"] == "99"


def test_reconciliation_missing_position_critical():
    rep = reconcile_positions([_pos(1), _pos(2)], [_pos(1)])
    assert not rep.ok and rep.missing[0]["ticket"] == "2"


def test_reconciliation_field_mismatch_detected():
    rep = reconcile_positions([_pos(1, sl=2645.0)], [_pos(1, sl=2640.0)])
    assert not rep.ok
    assert any(m["field"] == "sl" for m in rep.mismatches)


def test_reconciliation_volume_mismatch_detected():
    rep = reconcile_positions([_pos(1, volume=0.10)], [_pos(1, volume=0.20)])
    assert not rep.ok and any(m["field"] == "volume" for m in rep.mismatches)


def test_reconciliation_stale_internal_state():
    rep = reconcile_positions([_pos(1, last_sync_ts=1.0)], [_pos(1)], now_ts=999.0)
    assert not rep.ok and rep.stale_internal


# -------------------------------------------------------------------- §25 ---
def test_no_auto_retrain_guard_passes_on_clean_config(config):
    assert assert_no_auto_retrain(config) is None


def test_no_auto_retrain_guard_raises_when_enabled(config):
    bad = config.model_copy(update={"dataset": config.dataset.model_copy(
        update={"auto_retrain": True})})
    with pytest.raises(AutoRetrainForbidden):
        assert_no_auto_retrain(bad)


# -------------------------------------------------------------- §2 / §20 ----
def test_mt5_historical_provider_refuses_linux(monkeypatch):
    import platform

    if platform.system() == "Windows":  # pragma: no cover
        pytest.skip("guard test is for non-Windows hosts")
    from app.data.mt5.historical import MT5HistoricalProvider

    with pytest.raises(RuntimeError, match="Windows"):
        MT5HistoricalProvider()


def test_demo_account_guard_refuses_live():
    from app.data.mt5.historical import MT5HistoricalProvider

    class FakeAcc:
        trade_mode = 2  # REAL

    with pytest.raises(PermissionError, match="DEMO"):
        MT5HistoricalProvider.ensure_demo_account(FakeAcc())


def test_demo_account_guard_allows_demo():
    from app.data.mt5.historical import MT5HistoricalProvider

    class FakeAcc:
        trade_mode = 0  # DEMO

    assert MT5HistoricalProvider.ensure_demo_account(FakeAcc()) is None


# -------------------------------------------------------------------- §16 ---
def test_news_validation_status_pending_without_real_provider():
    status = news_validation_status(None)
    assert status["status"] == NEWS_VALIDATION_PENDING
    from app.news.providers import StaticCSVNewsProvider

    status2 = news_validation_status(StaticCSVNewsProvider("data/news_calendar.csv"))
    assert status2["status"] == NEWS_VALIDATION_PENDING


# -------------------------------------------------------------------- §24 ---
class _StubBundle:
    def average_proba(self, X):
        n = len(X)
        p = np.full((n, 3), [0.30, 0.40, 0.30])
        return p


class _StubFB:
    def build(self, candles, tf):
        return candles[["open", "high", "low", "close"]].iloc[[-1]]


class _StubSMC:
    def analyze(self, candles, tf):
        class _R:
            def directional_bias_series(self, n):
                return pd.Series([0.5] * max(1, len(candles)), index=candles.index)

        return _R()


@pytest.fixture(scope="module")
def sim_provider():
    p = SimulatedProvider(days=25, seed=7)
    p.connect()
    return p


def test_realtime_paper_never_places_orders(config, sim_provider, tmp_path):
    from app.risk.failsafe import FailSafeAction  # noqa: F401

    loop = BrokerRealtimePaper(config, sim_provider, _StubBundle(), _StubFB(),
                               _StubSMC(), journal_path=str(tmp_path / "rp.jsonl"),
                               min_bars=120)
    assert loop._send_orders is False
    for _ in range(5):
        obs = loop.observe_once("XAUUSD")
        assert isinstance(obs, PaperObservation)
        assert obs.decision in ("BUY", "SELL", "WAIT")
        if obs.decision == "WAIT":
            assert obs.wait_reason  # every WAIT must carry a reason (§24)
        assert obs.latency_ms >= 0
    # every decision journaled with the required fields
    lines = [json.loads(l) for l in (tmp_path / "rp.jsonl").read_text().splitlines()]
    assert len(lines) == 5
    for rec in lines:
        for field in ("ts", "decision", "wait_reason", "spread", "regime",
                      "ml_prob", "smc_bias", "ai_available", "latency_ms",
                      "risk_status", "price"):
            assert field in rec, f"§24 journal field missing: {field}"
        assert rec["orders_sent"] == 0


def test_realtime_paper_insufficient_data_waits(config, sim_provider, tmp_path):
    loop = BrokerRealtimePaper(config, sim_provider, _StubBundle(), _StubFB(),
                               _StubSMC(), journal_path=str(tmp_path / "rp2.jsonl"),
                               min_bars=100_000)  # impossible → INSUFFICIENT_DATA
    obs = loop.observe_once("XAUUSD")
    assert obs.decision == "WAIT" and obs.wait_reason == "INSUFFICIENT_DATA"

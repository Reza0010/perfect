"""PHASE 67 — null model engine, rate limiter, demo-safety and labelling tests.

All tests are fast (no full-pipeline runs). Heavy statistical artifacts
produced by scripts/phase67_null_model_audit.py are checked via JSON/MD
sanity assertions only.

The tests are environment-aware:
- Windows + MT5 is a valid environment.
- Non-Windows environments must refuse MT5 downloads with exit code 2.
- Historical Phase-67 artifacts must remain explicitly labelled as
  GC=F proxy data, never broker XAUUSD data.
"""

from __future__ import annotations

import asyncio
import json
import platform
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from app.ai.gateway import AIGateway
from app.ai.rate_limiter import (
    CircuitBreaker,
    RateLimiter,
    RequestPacer,
    backoff_delay,
)
from app.analytics.null_model import (
    SingleTradeSimulator,
    empirical_p_value,
    null_quantiles,
    sim_metrics,
)
from app.config.schema import AIConfig, RateLimitConfig
from app.core import exceptions as exc


# ============================================================================
# Helpers
# ============================================================================


def _tiny_window(n: int = 300, seed: int = 3) -> pd.DataFrame:
    """Create a deterministic synthetic OHLC window for fast simulator tests."""
    rng = np.random.default_rng(seed)

    idx = pd.date_range(
        "2026-01-01 00:00",
        periods=n,
        freq="15min",
        tz="UTC",
    )

    px = 2000.0 + np.cumsum(rng.normal(0.0, 1.5, n))

    return pd.DataFrame(
        {
            "open": px,
            "high": px + 1.2,
            "low": px - 1.2,
            "close": px + 0.1,
        },
        index=idx,
    )


def _mk_trade(pnl: float):
    """Build a minimal deterministic SimTrade for metric tests."""
    from app.analytics.null_model import SimTrade

    return SimTrade(
        pnl=pnl,
        fees=0.7,
        swap=0.0,
        entry_time=pd.Timestamp("2026-01-01T00:00:00Z"),
        exit_time=pd.Timestamp("2026-01-01T01:00:00Z"),
        entry_price=2000.0,
        exit_price=2001.0,
        exit_reason="TP",
        signal_time=pd.Timestamp("2026-01-01T00:00:00Z"),
        side="BUY",
        volume=0.1,
    )


def _rl_gateway(
    *providers,
    journal: Path,
    max_retries: int = 2,
) -> AIGateway:
    """Build an AIGateway with deterministic rate-limit settings."""
    gw = AIGateway(
        AIConfig(
            enabled=True,
            rate_limit=RateLimitConfig(
                enabled=True,
                max_retries=max_retries,
                backoff_base_s=0.001,
                backoff_cap_s=0.002,
                journal_path=str(journal),
            ),
        )
    )

    gw.providers = {provider.name: provider for provider in providers}
    gw.order = [provider.name for provider in providers]

    return gw


class _FlakyFake:
    """Fake AI provider: fails N times with 429, then succeeds."""

    def __init__(self, name: str, fail_times: int):
        self.name = name
        self.model = "fake"
        self.fail_times = fail_times
        self.calls = 0
        self._last_usage = {
            "input_tokens": 3,
            "output_tokens": 3,
        }

    async def analyze(self, state, news_texts=None):
        from app.ai.schemas import AIOutput

        self.calls += 1

        if self.calls <= self.fail_times:
            raise exc.AIRateLimitError(
                f"{self.name}: 429"
            )

        self._last_usage = {
            "input_tokens": 3,
            "output_tokens": 3,
        }

        return AIOutput(
            decision="BUY",
            confidence=0.8,
            setup_quality="A",
            regime="TRENDING_BULL",
            news_risk="LOW",
            reason_codes=["TEST"],
            invalidation="1.0",
            confirmation_required=False,
        )

    async def aclose(self):
        return None


# ============================================================================
# NULL MODEL ENGINE
# ============================================================================


def test_simulator_vectorised_equals_reference_loop():
    """Vectorized simulator must be numerically identical to reference loop."""

    sim = SingleTradeSimulator(
        _tiny_window(),
        delay=1,
        half_spread=np.full(300, 0.15),
        slippage_price=0.05,
        tick_size=0.1,
        tick_value=1.0,
        commission_per_lot=0.7,
        swap_long=-0.8,
        swap_short=-0.2,
    )

    rng = np.random.default_rng(11)

    checked = 0

    for _ in range(60):
        j = int(rng.integers(1, 290))

        side = "BUY" if rng.random() < 0.5 else "SELL"

        lot = float(
            rng.choice([0.01, 0.1, 1.0])
        )

        sl = float(
            2000.0 + rng.normal(0.0, 4.0)
        )

        tp = float(
            2000.0 + rng.normal(0.0, 6.0)
        )

        vectorized = sim.simulate(
            j,
            side,
            lot,
            sl,
            tp,
        )

        reference = sim.simulate_loop(
            j,
            side,
            lot,
            sl,
            tp,
        )

        assert (vectorized is None) == (reference is None)

        if vectorized is None:
            continue

        assert abs(vectorized.pnl - reference.pnl) < 1e-10
        assert vectorized.exit_reason == reference.exit_reason
        assert vectorized.exit_time == reference.exit_time
        assert abs(vectorized.swap - reference.swap) < 1e-12

        checked += 1

    assert checked > 40


def test_sim_metrics_handles_degenerate_cases():
    """Metrics must remain stable for empty/win/loss-only trade sets."""

    empty = sim_metrics(
        [],
        10_000.0,
    )

    assert empty["n_trades"] == 0
    assert empty["pf"] is None

    all_wins = sim_metrics(
        [
            _mk_trade(50.0),
            _mk_trade(30.0),
        ],
        10_000.0,
    )

    assert all_wins["pf"] == float("inf")

    all_loss = sim_metrics(
        [_mk_trade(-50.0)],
        10_000.0,
    )

    assert all_loss["pf"] == 0.0
    assert all_loss["max_dd_pct"] < 0


def test_empirical_p_value_bounds_and_direction():
    """Empirical p-value must use +1 correction and respect direction."""

    null = np.array(
        [
            0.5,
            0.8,
            1.0,
            1.2,
            1.5,
        ]
    )

    assert empirical_p_value(
        null,
        1.4,
    ) == pytest.approx(2 / 6)

    assert empirical_p_value(
        null,
        10.0,
    ) == pytest.approx(1 / 6)

    assert empirical_p_value(
        null,
        -5.0,
        "greater",
    ) == pytest.approx(1.0)

    with_inf = np.array(
        [
            np.inf,
            1.0,
            1.1,
        ]
    )

    assert empirical_p_value(
        with_inf,
        2.0,
    ) == pytest.approx(2 / 4)


def test_null_quantiles_reports_infinite_share():
    """Null quantile report must expose infinite PF frequency."""

    q = null_quantiles(
        np.array(
            [
                np.inf,
                np.inf,
                1.0,
                2.0,
            ]
        )
    )

    assert q["share_infinite"] == pytest.approx(0.5)
    assert "p95" in q


# ============================================================================
# RATE LIMITER
# ============================================================================


def test_backoff_delay_growth_and_cap():
    """Exponential backoff must grow and respect the configured cap."""

    d0 = backoff_delay(
        0,
        0.5,
        4.0,
        jitter=False,
    )

    d2 = backoff_delay(
        2,
        0.5,
        4.0,
        jitter=False,
    )

    d9 = backoff_delay(
        9,
        0.5,
        4.0,
        jitter=False,
    )

    assert d0 == pytest.approx(0.5)
    assert d2 == pytest.approx(2.0)
    assert d9 == pytest.approx(4.0)


def test_request_pacer_enforces_interval():
    """Pacer must enforce minimum time between requests."""

    async def run():
        pacer = RequestPacer(
            min_interval_s=0.05
        )

        loop = asyncio.get_running_loop()
        t0 = loop.time()

        for _ in range(3):
            await pacer.acquire()

        return loop.time() - t0

    elapsed = asyncio.run(run())

    # Three calls require approximately two enforced waits.
    assert elapsed >= 0.09


def test_circuit_breaker_lifecycle():
    """Circuit must transition CLOSED -> OPEN -> HALF_OPEN -> CLOSED."""

    breaker = CircuitBreaker(
        "p",
        failure_threshold=3,
        reset_timeout_s=0.05,
    )

    assert breaker.allow()

    for _ in range(3):
        breaker.record_failure()

    assert breaker.state == "OPEN"
    assert not breaker.allow()

    time.sleep(0.06)

    assert breaker.allow()
    assert breaker.state == "HALF_OPEN"

    breaker.record_success()

    assert breaker.state == "CLOSED"
    assert breaker.failures == 0


def test_rate_limiter_retries_429_then_succeeds(tmp_path):
    """429 must be retried and eventually return successfully."""

    calls = {"n": 0}

    async def flaky():
        calls["n"] += 1

        if calls["n"] < 3:
            raise exc.AIRateLimitError("429")

        return "OK", {
            "input_tokens": 1,
        }

    cfg = RateLimitConfig(
        enabled=True,
        max_retries=3,
        backoff_base_s=0.001,
        backoff_cap_s=0.002,
        journal_path=str(
            tmp_path / "ai_journal.jsonl"
        ),
    )

    limiter = RateLimiter(cfg)

    result = asyncio.run(
        limiter.execute(
            "zai",
            flaky,
            "hash123",
            "glm",
        )
    )

    assert result.output == "OK"
    assert result.retries == 2

    journal = (
        tmp_path / "ai_journal.jsonl"
    )

    lines = [
        json.loads(line)
        for line in journal.read_text().splitlines()
    ]

    finals = [
        line["final_action"]
        for line in lines
    ]

    assert "RETRY" in finals
    assert "OK" in finals

    required_fields = {
        "timestamp",
        "provider",
        "request_hash",
        "latency_ms",
        "status",
        "retry_count",
        "final_action",
    }

    assert all(
        required_fields <= set(line)
        for line in lines
    )


def test_rate_limiter_exhaustion_raises_for_failover(tmp_path):
    """After retries are exhausted, the limiter must request failover."""

    async def always_429():
        raise exc.AIRateLimitError("429")

    cfg = RateLimitConfig(
        enabled=True,
        max_retries=1,
        backoff_base_s=0.001,
        backoff_cap_s=0.002,
        journal_path=str(
            tmp_path / "ai_journal.jsonl"
        ),
    )

    limiter = RateLimiter(cfg)

    with pytest.raises(exc.AIRateLimitError):
        asyncio.run(
            limiter.execute(
                "zai",
                always_429,
                "h",
                "m",
            )
        )

    journal = (
        tmp_path / "ai_journal.jsonl"
    )

    lines = [
        json.loads(line)
        for line in journal.read_text().splitlines()
    ]

    assert lines
    assert lines[-1]["final_action"] == "FAILOVER"


def test_rate_limiter_circuit_open_skips_call(tmp_path):
    """Open circuit must prevent provider invocation."""

    async def boom():
        raise exc.AIServerError("500")

    cfg = RateLimitConfig(
        enabled=True,
        max_retries=0,
        backoff_base_s=0.001,
        backoff_cap_s=0.002,
        circuit_failure_threshold=2,
        circuit_reset_timeout_s=60,
        journal_path=str(
            tmp_path / "j.jsonl"
        ),
    )

    limiter = RateLimiter(cfg)

    for _ in range(2):
        with pytest.raises(exc.AIServerError):
            asyncio.run(
                limiter.execute(
                    "p",
                    boom,
                    "h",
                    "m",
                )
            )

    assert limiter.breaker("p").state == "OPEN"

    with pytest.raises(exc.AIProviderError):
        asyncio.run(
            limiter.execute(
                "p",
                boom,
                "h",
                "m",
            )
        )

    assert limiter.stats["circuit_open_skips"] == 1


# ============================================================================
# AI GATEWAY + RATE LIMITER
# ============================================================================


def test_gateway_with_rate_limiter_recovers_from_429(tmp_path):
    """Gateway must recover after transient provider rate limiting."""

    provider = _FlakyFake(
        "p1",
        fail_times=2,
    )

    journal = (
        tmp_path / "gateway_journal.jsonl"
    )

    gateway = _rl_gateway(
        provider,
        journal=journal,
    )

    result = asyncio.run(
        gateway.analyze(
            {"price": 2650.0}
        )
    )

    assert result.provider == "p1"
    assert result.output.decision == "BUY"
    assert result.retries == 2

    lines = [
        json.loads(line)
        for line in journal.read_text().splitlines()
    ]

    assert lines
    assert lines[-1]["final_action"] == "OK"
    assert lines[-1]["retry_count"] == 2


def test_gateway_rate_limited_all_fail_returns_wait(tmp_path):
    """If all providers remain rate-limited, gateway must fail safe to WAIT."""

    provider_1 = _FlakyFake(
        "p1",
        fail_times=99,
    )

    provider_2 = _FlakyFake(
        "p2",
        fail_times=99,
    )

    journal = (
        tmp_path / "gateway_journal.jsonl"
    )

    gateway = _rl_gateway(
        provider_1,
        provider_2,
        journal=journal,
        max_retries=1,
    )

    result = asyncio.run(
        gateway.analyze(
            {"price": 2650.0}
        )
    )

    assert result.degraded
    assert result.output.decision == "WAIT"

    lines = [
        json.loads(line)
        for line in journal.read_text().splitlines()
    ]

    assert any(
        line["final_action"] == "FAILOVER"
        for line in lines
    )


def test_gateway_without_rate_limit_config_unchanged():
    """Gateway without explicit rate-limit configuration remains unchanged."""

    gateway = AIGateway(
        AIConfig(enabled=True)
    )

    assert gateway.limiter is None


# ============================================================================
# DEMO SAFETY / PROVENANCE
# ============================================================================


def test_demo_script_has_no_live_override():
    """Demo script must not expose a CLI/API path to force live trading."""

    src = Path(
        "scripts/mt5_demo_execution_test.py"
    ).read_text(
        encoding="utf-8"
    )

    assert "REFUSED" in src
    assert "trade_mode" in src

    forbidden = (
        "--allow-live",
        "--force-live",
        "--i-am-sure-live",
        "LIVE_TRADING_ENABLED=true",
    )

    for token in forbidden:
        assert token not in src


def test_downloader_captures_full_phase67_provenance():
    """Downloader must retain the required broker/data provenance fields."""

    src = Path(
        "scripts/download_mt5_data.py"
    ).read_text(
        encoding="utf-8"
    )

    required_fields = (
        "stops_level_points",
        "freeze_level_points",
        "margin_mode",
        "mt5_build",
        "account_trade_mode",
        "file_sha256",
        "datasets",
        "download_timestamp",
        "filling_mode",
        "swap_long_per_lot",
    )

    for field in required_fields:
        assert field in src, (
            f"missing provenance field: {field}"
        )


def test_downloader_platform_guard_is_environment_aware():
    """Downloader must behave correctly on Windows and non-Windows.

    Windows:
        --help must exit successfully without requiring MT5.

    Non-Windows:
        downloader must refuse MT5 download with exit code 2.
    """

    if platform.system() == "Windows":
        result = subprocess.run(
            [
                sys.executable,
                "scripts/download_mt5_data.py",
                "--help",
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

        assert result.returncode == 0, (
            "Downloader --help failed on Windows:\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

        combined = (
            result.stdout +
            result.stderr
        )

        # Do not require the literal string "MetaTrader5".
        # The help output is an argparse interface contract.
        assert "usage:" in combined.lower()
        assert "--symbol" in combined
        assert "--timeframes" in combined

        return

    result = subprocess.run(
        [
            sys.executable,
            "scripts/download_mt5_data.py",
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )

    combined = (
        result.stdout +
        result.stderr
    )

    assert result.returncode == 2
    assert "Windows" in combined


# ============================================================================
# PHASE 67 HISTORICAL ARTIFACT SANITY
# ============================================================================


def test_phase67_artifacts_are_gcf_labelled():
    """Historical Phase-67 artifacts must remain explicitly GC=F-labelled.

    The current machine may have MT5 installed and available. That fact must
    NOT rewrite historical GC=F statistical artifacts into broker XAUUSD
    artifacts.

    This test therefore verifies:

    1. Historical data is explicitly GC=F proxy data.
    2. Null-model audit remains EDGE_NOT_ESTABLISHED.
    3. Bootstrap audit remains EDGE_NOT_ESTABLISHED.
    4. The report explicitly states that the data is NOT broker XAUUSD.
    5. The current MT5 environment report contains a valid boolean state.
    6. Environment decision is recorded explicitly.
    7. MT5 availability alone does not authorize trading.
    """

    audit_path = Path(
        "reports/phase67_null_model_audit.json"
    )

    audit = json.loads(
        audit_path.read_text(
            encoding="utf-8"
        )
    )

    # ------------------------------------------------------------------
    # Historical artifact identity
    # ------------------------------------------------------------------

    assert audit["smoke"] is False

    assert (
        audit["data_kind"]
        == "REAL_GC_F_PROXY_NOT_BROKER"
    )

    # ------------------------------------------------------------------
    # Null-model statistical sanity
    # ------------------------------------------------------------------

    null_model = audit["null_model"]

    assert (
        null_model["n_sims_per_family"]
        >= 10_000
    )

    assert len(
        null_model["families"]
    ) == 4

    for family, block in null_model["families"].items():
        assert (
            block["exact_trade_count_rate"]
            > 0.99
        ), family

    assert (
        null_model["verdict"]
        == "EDGE_NOT_ESTABLISHED"
    )

    assert all(
        p_value["p_pf_ge_obs"] > 0.05
        for p_value
        in null_model["empirical_p_values"].values()
    )

    # ------------------------------------------------------------------
    # Bootstrap sanity
    # ------------------------------------------------------------------

    assert (
        audit["observed"]["bootstrap"]["verdict"]
        == "EDGE_NOT_ESTABLISHED"
    )

    # ------------------------------------------------------------------
    # Human-readable report identity
    # ------------------------------------------------------------------

    report = Path(
        "reports/NULL_MODEL_AUDIT.md"
    ).read_text(
        encoding="utf-8"
    )

    assert "NOT broker XAUUSD" in report

    # ------------------------------------------------------------------
    # Current environment report
    # ------------------------------------------------------------------

    environment = json.loads(
        Path(
            "reports/mt5_environment.json"
        ).read_text(
            encoding="utf-8"
        )
    )

    assert isinstance(
        environment.get("mt5_available"),
        bool,
    )

    decision = str(
        environment.get(
            "decision",
            ""
        )
    ).upper().strip()

    # Environment decision must be explicitly recorded.
    assert decision

    # A currently available MT5 terminal is expected on this Windows host.
    if platform.system() == "Windows":
        assert environment["mt5_available"] is True

    # ------------------------------------------------------------------
    # CRITICAL SAFETY INVARIANT
    # ------------------------------------------------------------------
    #
    # The environment report's PROCEED/STOP value is NOT a trading
    # authorization. Phase 67 must still remain in a non-live state.
    #
    # Therefore we validate that the report does not claim live trading
    # authorization.
    # ------------------------------------------------------------------

    live_authorized = environment.get(
        "live_trading_authorized",
        False,
    )

    assert live_authorized is False

    # If the field exists, it must explicitly remain false.
    if "live" in environment:
        assert environment["live"] is False

    # These common safety keys, when present, must remain disabled.
    for key in (
        "live_enabled",
        "live_trading_enabled",
        "auto_trade",
        "execution_enabled",
    ):
        if key in environment:
            assert environment[key] is False

def test_phase67_pending_reports_exist():
    """Broker validation reports must remain explicitly pending."""

    data_quality = Path(
        "reports/BROKER_XAUUSD_DATA_QUALITY.md"
    ).read_text(
        encoding="utf-8"
    )

    broker_comparison = Path(
        "reports/BROKER_VS_GCF.md"
    ).read_text(
        encoding="utf-8"
    )

    assert (
        "BROKER_DATA_PENDING"
        in data_quality
    )

    assert (
        "never"
        in data_quality.lower()
    )

    assert (
        "COMPARISON_PENDING"
        in broker_comparison
    )

    assert (
        "interchangeable"
        in broker_comparison
    )
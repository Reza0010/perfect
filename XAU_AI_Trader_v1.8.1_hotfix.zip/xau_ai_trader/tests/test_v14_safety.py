"""v1.4 — safety & correctness tests for the audit-driven P0 repairs.

Covers (MASTER_UPGRADE_PROMPT §46, §61):
  * central retcode policy (no raw magic numbers in logic)
  * fake-MT5 contract tests: symbol_select(sym, True), order_check before
    send, filling mode from bitmask, NO blind retry on ambiguous outcomes,
    broker-native calc wrappers
  * OpenRiskCalculator fail-closed semantics + risk engine OPEN_RISK_UNKNOWN
  * kill switch fail-closed: corrupt state, persist failure, multi-trigger
  * scaler standard/robust correctness (StandardScaler had no center_)
"""

from __future__ import annotations

from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from app.config.schema import KillSwitchConfig, NewsRisk, Regime, RiskConfig
from app.core import exceptions as exc
from app.data.market.models import SymbolInfo
from app.execution import mt5_retcodes as rc
from app.models.dataset import _apply_scaler, _fit_scaler
from app.risk.engine import RiskEngine
from app.risk.kill_switch import KillSwitch
from app.risk.open_risk import OpenRiskCalculator

SYM = SymbolInfo(name="XAUUSD.ecn")  # defaults: XAU-like specs used by the fakes


# ---------------------------------------------------------------------------
# fake MT5 adapter — deterministic, lets CI exercise the full API contract
# ---------------------------------------------------------------------------
class FakeTick:
    def __init__(self, bid=2700.0, ask=2700.2):
        self.bid, self.ask, self.time = bid, ask, 1_800_000_000


class FakeSymbolInfo:
    def __init__(self, name="XAUUSD.ecn"):
        self.name = name
        self.digits = 2
        self.point = 0.01
        self.trade_tick_size = 0.01
        self.trade_tick_value = 1.0
        self.trade_contract_size = 100.0
        self.volume_min = 0.01
        self.volume_max = 100.0
        self.volume_step = 0.01
        self.trade_stops_level = 20
        self.trade_freeze_level = 10
        self.filling_mode = 2  # IOC only
        self.spread = 20
        self.trade_mode = 4   # SYMBOL_TRADE_MODE_FULL
        self.swap_long = -8.0
        self.swap_short = -2.0
        self.currency_profit = "USD"


class FakePositions:
    def __init__(self, ticket=111, volume=0.01, sl=2690.0, tp=2720.0):
        self.ticket, self.volume, self.sl, self.tp = ticket, volume, sl, tp
        self.type = 0  # BUY
        self.symbol = "XAUUSD.ecn"
        self.price_open = 2700.0
        self.magic = 20260101
        self.comment = "xau-ai-trader"
        self.profit = 0.0
        self.swap = 0.0
        self.time = 1_800_000_000


class FakeMT5:
    """Deterministic MT5 stand-in recording every call."""

    def __init__(self, send_results=None, filling_mode=2):
        self.calls: list[tuple] = []
        self._send_results = list(send_results or [])
        self.symbol_info_obj = FakeSymbolInfo()
        self.tick = FakeTick()
        self.account = SimpleNamespace(
            login=1234567890, server="OtetGroup-DEMO", currency="USD",
            leverage=100, trade_mode=0, balance=10_000.0, equity=10_000.0,
            margin=0.0, margin_free=10_000.0, margin_level=0.0,
            margin_mode=0, trade_expert=True, company="Otet Group")
        self.terminal = SimpleNamespace(
            build=6231, connected=True, trade_allowed=True)
        self.filling_mode = filling_mode
        self.positions = []

    # -- API surface (contract mirrors the real MetaTrader5 module) --------
    def initialize(self, **kwargs):
        self.calls.append(("initialize",))
        return True

    def shutdown(self):
        self.calls.append(("shutdown",))

    def last_error(self):
        return (0, "ok")

    def version(self):
        return ("5.0", "6231", "demo")

    def symbol_select(self, symbol, enable):
        self.calls.append(("symbol_select", symbol, enable))
        return True

    def symbol_info(self, symbol):
        self.calls.append(("symbol_info", symbol))
        return self.symbol_info_obj

    def symbol_info_tick(self, symbol):
        self.calls.append(("symbol_info_tick", symbol))
        return self.tick

    def terminal_info(self):
        return self.terminal

    def account_info(self):
        return self.account

    def order_check(self, request):
        self.calls.append(("order_check", request))
        return SimpleNamespace(retcode=10009, comment="ok")

    def order_send(self, request):
        self.calls.append(("order_send", request))
        if self._send_results:
            return self._send_results.pop(0)
        return SimpleNamespace(retcode=10009, order=111, price=2700.2, volume=0.01)

    def positions_get(self, ticket=None, symbol=None):
        self.calls.append(("positions_get", ticket, symbol))
        return list(self.positions)

    def order_calc_profit(self, order_type, symbol, volume, price_open, price_close):
        self.calls.append(("order_calc_profit", order_type, symbol, volume,
                           price_open, price_close))
        return (price_close - price_open) * volume * 100.0

    def order_calc_margin(self, order_type, symbol, volume, price):
        self.calls.append(("order_calc_margin", order_type, symbol, volume, price))
        return price * volume * 100.0 / 100


def make_provider(fake, **kwargs):
    """Build MT5DataProvider around a fake mt5 module."""
    from app.data.mt5.provider import MT5DataProvider

    import app.data.mt5.provider as prov_mod

    saved = prov_mod._import_mt5
    prov_mod._import_mt5 = lambda: fake
    try:
        p = MT5DataProvider(allow_live_execution=kwargs.pop("allow_live_execution", True),
                            **kwargs)
    finally:
        prov_mod._import_mt5 = saved
    p._connected = True
    p._available = [SYM]
    p._symbol_cache["XAUUSD"] = SYM
    return p


# ------------------------------------------------------------- retcodes ---
def test_retcodes_ambiguous_never_retryable():
    assert rc.classify(None) is rc.RetcodePolicy.AMBIGUOUS
    assert rc.classify(10012) is rc.RetcodePolicy.AMBIGUOUS   # TIMEOUT
    assert rc.classify(10031) is rc.RetcodePolicy.AMBIGUOUS   # CONNECTION
    assert rc.classify(10009) is rc.RetcodePolicy.SUCCESS
    assert rc.classify(10016) is rc.RetcodePolicy.FATAL       # INVALID_STOPS
    assert rc.classify(99999) is rc.RetcodePolicy.FATAL       # unknown → fatal


def test_filling_mode_from_bitmask():
    assert rc.choose_filling_mode(1) == rc.FILLING_FOK
    assert rc.choose_filling_mode(2) == rc.FILLING_IOC
    assert rc.choose_filling_mode(3) == rc.FILLING_IOC     # IOC preferred
    assert rc.choose_filling_mode(0) == rc.FILLING_RETURN
    assert rc.choose_filling_mode(None) == rc.FILLING_RETURN


# --------------------------------------------- provider contract (fake) ---
def test_send_market_order_contract():
    fake = FakeMT5()
    p = make_provider(fake)
    res = p.send_market_order("XAUUSD", "BUY", 0.01, 2690.0, 2720.0,
                              "test", magic=20260101)
    assert res.success and res.retcode == 10009
    names = [c[0] for c in fake.calls]
    assert names.index("symbol_select") < names.index("order_check")
    assert names.index("order_check") < names.index("order_send")
    sel = next(c for c in fake.calls if c[0] == "symbol_select")
    assert sel[1] == "XAUUSD.ecn" and sel[2] is True
    req = next(c for c in fake.calls if c[0] == "order_check")[1]
    assert req["type_filling"] == rc.FILLING_IOC  # from bitmask (2)
    assert req["deviation"] >= 10                 # spread-aware, not hardcoded 20


def test_ambiguous_send_never_retried():
    # order_send returns None => outcome UNKNOWN => must raise ONCE and
    # call order_send exactly one time (no blind retry -> no duplicates)
    fake = FakeMT5(send_results=[None])
    p = make_provider(fake)
    with pytest.raises(exc.AmbiguousOrderError):
        p.send_market_order("XAUUSD", "BUY", 0.01, 2690.0, 2720.0,
                            "test", magic=20260101)
    sends = [c for c in fake.calls if c[0] == "order_send"]
    assert len(sends) == 1


def test_requote_retry_refreshes_price():
    fake = FakeMT5(send_results=[SimpleNamespace(retcode=10004),
                                 SimpleNamespace(retcode=10009, order=7,
                                                 price=2700.3, volume=0.01)])
    p = make_provider(fake)
    res = p.send_market_order("XAUUSD", "BUY", 0.01, 2690.0, 2720.0,
                              "test", magic=20260101)
    assert res.success and res.ticket == 7
    assert len([c for c in fake.calls if c[0] == "order_send"]) == 2


def test_fatal_stops_deterministically():
    fake = FakeMT5(send_results=[SimpleNamespace(retcode=10016)])
    p = make_provider(fake)
    with pytest.raises(exc.OrderRejectedError):
        p.send_market_order("XAUUSD", "BUY", 0.01, 2690.0, 2720.0,
                            "test", magic=20260101)
    assert len([c for c in fake.calls if c[0] == "order_send"]) == 1


def test_supports_real_execution_requires_explicit_flag():
    fake = FakeMT5()
    p = make_provider(fake, allow_live_execution=False)
    assert p.supports_real_execution is False
    p2 = make_provider(fake, allow_live_execution=True)
    assert p2.supports_real_execution is True
    fake.terminal.trade_allowed = False
    assert p2.supports_real_execution is False


def test_broker_native_calc_wrappers():
    fake = FakeMT5()
    p = make_provider(fake)
    profit = p.order_calc_profit("BUY", "XAUUSD", 0.01, 2700.0, 2690.0)
    assert profit == pytest.approx(-10.0)
    margin = p.order_calc_margin("BUY", "XAUUSD", 0.01, 2700.0)
    assert margin == pytest.approx(27.0)


# ------------------------------------------------------------ open risk ---
def test_open_risk_computed_and_fail_closed():
    prov = SimpleNamespace(
        get_open_positions=lambda symbol=None: [
            SimpleNamespace(ticket=1, symbol="XAUUSD.ecn", side="BUY",
                            volume=0.5, open_price=2700.0, sl=2690.0,
                            tp=2720.0, magic=1)],
        get_symbol_info=lambda s: SymbolInfo(
            name="XAUUSD.ecn", digits=2, point=0.01, tick_size=0.01,
            tick_value=1.0, contract_size=100.0, volume_min=0.01,
            volume_max=100.0, volume_step=0.01, spread_points=20),
    )
    rep = OpenRiskCalculator(prov).compute(equity=10_000.0)
    # SL distance 10 USD / 0.01 tick * 1.0 tick_value * 0.5 lots = 500 USD => 5%
    assert rep.risk_percent == pytest.approx(5.0)
    # exceeds max_open_risk_percent=1.0 + risk 0.5 -> rejected
    eng = RiskEngine(RiskConfig())
    dec = eng.evaluate("BUY", 2700.0, SimpleNamespace(
        equity=10_000.0, balance=10_000.0, free_margin=10_000.0),
        prov.get_symbol_info("X"), pd.DataFrame({"close": [2700.0, 2701.0]}),
        atr=5.0, ml_confidence=0.9, smc_bias=1.0, regime=Regime.RANGING,
        news_risk=NewsRisk.LOW, data_quality=100.0, spread_points=20.0,
        open_positions=1, open_risk_percent=rep.risk_percent)
    assert not dec.approved and "MAX_OPEN_RISK" in dec.reason_codes


def test_open_risk_none_when_position_has_no_sl():
    prov = SimpleNamespace(
        get_open_positions=lambda symbol=None: [
            SimpleNamespace(ticket=2, symbol="XAUUSD.ecn", side="BUY",
                            volume=0.5, open_price=2700.0, sl=0.0,
                            tp=0.0, magic=1)],
        get_symbol_info=lambda s: None,
    )
    rep = OpenRiskCalculator(prov).compute(equity=10_000.0)
    assert rep.risk_percent is None and rep.unbounded_positions == [2]
    eng = RiskEngine(RiskConfig())
    dec = eng.evaluate("BUY", 2700.0, SimpleNamespace(
        equity=10_000.0, balance=10_000.0, free_margin=10_000.0),
        None, pd.DataFrame({"close": [2700.0, 2701.0]}),
        atr=5.0, ml_confidence=0.9, smc_bias=1.0, regime=Regime.RANGING,
        news_risk=NewsRisk.LOW, data_quality=100.0, spread_points=20.0,
        open_positions=1, open_risk_percent=None)
    assert not dec.approved and "OPEN_RISK_UNKNOWN" in dec.reason_codes


# ----------------------------------------------------------- kill switch --
def _ks(path):  # helper
    return KillSwitch(KillSwitchConfig(state_file=str(path)))


def test_kill_switch_fail_closed_on_corrupt_state(tmp_path):
    path = tmp_path / "ks.json"
    path.write_text("{ this is not json", encoding="utf-8")
    ks = KillSwitch(KillSwitchConfig(state_file=str(path)))
    assert ks.is_active, "corrupt state must ENGAGE the kill switch (fail-closed)"
    assert ks.state.trigger == "STATE_CORRUPT"
    # and the engagement itself must be persisted for restarts
    reloaded = KillSwitch(KillSwitchConfig(state_file=str(path)))
    assert reloaded.is_active


def test_kill_switch_blocks_when_persist_fails(tmp_path, monkeypatch):
    ks = _ks(tmp_path / "ks.json")

    def broken_replace(*a, **k):
        raise OSError("disk full")

    monkeypatch.setattr("os.replace", broken_replace)
    ks.trip("ABNORMAL_SPREAD", "test")
    assert ks.is_active, "persist failure must block trading (fail-closed)"
    assert ks.blocked_reason == "KILL_SWITCH_STATE_PERSIST_FAILED"


def test_kill_switch_collects_all_simultaneous_triggers(tmp_path):
    ks = _ks(tmp_path / "ks.json")
    # daily loss AND drawdown AND spread all beyond limits at once
    ks.check(daily_loss_percent=5.0, drawdown_percent=20.0, spread_points=500.0)
    assert ks.state.active
    assert set(ks.state.triggers) >= {"DAILY_LOSS_LIMIT", "MAX_DRAWDOWN",
                                      "ABNORMAL_SPREAD"}


def test_kill_switch_corrupt_state_never_auto_resets(tmp_path):
    path = tmp_path / "ks.json"
    import json
    path.write_text(json.dumps({"active": True, "trigger": "STATE_CORRUPT",
                                "detail": "x", "tripped_at": "2020-01-01T00:00:00+00:00",
                                "triggers": ["STATE_CORRUPT"]}), encoding="utf-8")
    ks = KillSwitch(KillSwitchConfig(state_file=str(path),
                                     auto_reset_after_minutes=1))
    assert ks.is_active, "STATE_CORRUPT must never auto-reset"


# ---------------------------------------------------------------- scaler --
def test_scaler_standard_matches_sklearn():
    X = pd.DataFrame(np.random.default_rng(7).normal(50, 10, size=(200, 3)),
                     columns=["a", "b", "c"])
    state = _fit_scaler(X, "standard")
    got = _apply_scaler(X, state)
    from sklearn.preprocessing import StandardScaler

    expected = StandardScaler().fit_transform(X.values)
    assert np.allclose(got.values, expected, atol=1e-9)


def test_scaler_robust_matches_sklearn():
    X = pd.DataFrame(np.random.default_rng(8).normal(0, 3, size=(200, 2)),
                     columns=["a", "b"])
    state = _fit_scaler(X, "robust")
    got = _apply_scaler(X, state)
    from sklearn.preprocessing import RobustScaler

    expected = RobustScaler().fit_transform(X.values)
    assert np.allclose(got.values, expected, atol=1e-9)


def test_scaler_state_is_versioned():
    X = pd.DataFrame(np.ones((10, 2)), columns=["a", "b"]) * [3.0, 0.0]
    state = _fit_scaler(X, "standard")
    assert state["schema_version"] == 2
    assert state["scale"] and len(state["center"]) == 2
    with pytest.raises(ValueError):
        _fit_scaler(X, "quantum")

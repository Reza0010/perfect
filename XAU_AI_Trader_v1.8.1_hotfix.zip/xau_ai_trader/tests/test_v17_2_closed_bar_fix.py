"""v1.7.2 — trailing flat snapshot bar dropped + length-safe refresh merge.

Regression tests for the user-reported permanent ``FEATURES_NAN`` WAIT loop
(console log 2026-10-09 09:31→10:37, v1.7.1):

D6 — Yahoo's last bar is the IN-PROGRESS interval stamped with the current
     wall-clock time and degenerate OHLC (open == high == low == close,
     zero range). The feature builder maps zero-range to NaN and the
     pipeline fail-closes → WAIT forever while that bar stays newest.
     Fix: parse_yahoo_chart drops a TRAILING flat bar.

D7 — the refresh() merge ``prev[df.index > prev.index[-1]]`` boolean-indexed
     ``prev`` with a mask sized by the NEW frame → any bar-count change
     raised and the timeframe silently froze at its first seed (prices stop
     moving, the same inference row repeats). Fix: length-safe
     concat + last-wins dedupe.

Offline tests: all network calls are mocked.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from app.core.security import sanitize_reason_codes


BASE_TS = 1_791_518_400          # arbitrary second-aligned epoch base
PRICE = 4200.0


def _payload(ts_list, opens, highs, lows, closes, volumes=None,
             price=PRICE + 1, market_time=None):
    n = len(ts_list)
    return {
        "chart": {"result": [{
            "meta": {"symbol": "GC=F", "regularMarketPrice": price,
                     "regularMarketTime": market_time or (ts_list[-1] + 30),
                     "currency": "USD", "fullExchangeName": "COMEX"},
            "timestamp": list(ts_list),
            "indicators": {"quote": [{
                "open": list(opens), "high": list(highs),
                "low": list(lows), "close": list(closes),
                "volume": list(volumes if volumes is not None else [100] * n)}]},
        }]}}


def _normal_series(n, base_ts=BASE_TS, price=PRICE):
    """n normal (non-flat) 1m bars."""
    ts = [base_ts + 60 * i for i in range(n)]
    return _payload(
        ts,
        [price] * n, [price + 2] * n, [price - 2] * n, [price + 0.5] * n)


def _flat_trailing_series(n, base_ts=BASE_TS, price=PRICE):
    """n-1 normal bars + a final FLAT snapshot bar (Yahoo in-progress bar)."""
    ts = [base_ts + 60 * i for i in range(n)]
    return _payload(
        ts,
        [price] * (n - 1) + [price + 3],            # opens
        [price + 2] * (n - 1) + [price + 3],        # highs (== open/low/close)
        [price - 2] * (n - 1) + [price + 3],        # lows
        [price + 0.5] * (n - 1) + [price + 3],      # closes
    )


# ================================================================== D6 ==
def test_parse_drops_trailing_flat_snapshot_bar():
    from app.data.market.live_public import parse_yahoo_chart

    df, _ = parse_yahoo_chart(_flat_trailing_series(10))
    assert len(df) == 9                                  # flat bar dropped
    last = df.iloc[-1]
    assert not (last["high"] == last["low"] == last["open"] == last["close"])


def test_parse_keeps_normal_trailing_bar():
    from app.data.market.live_public import parse_yahoo_chart

    df, _ = parse_yahoo_chart(_normal_series(10))
    assert len(df) == 10                                 # nothing dropped


def test_parse_keeps_mid_history_flat_bar():
    """A flat CLOSED bar inside history is a legit quiet interval — kept."""
    from app.data.market.live_public import parse_yahoo_chart

    n, p = 10, PRICE
    ts = [BASE_TS + 60 * i for i in range(n)]
    # flat bar at position 4 (mid-history), normal bars elsewhere
    payload = _payload(
        ts,
        [p] * 4 + [p + 1] + [p] * 5,
        [p + 2] * 4 + [p + 1] + [p + 2] * 5,
        [p - 2] * 4 + [p + 1] + [p - 2] * 5,
        [p + 0.5] * 4 + [p + 1] + [p + 0.5] * 5,
    )
    df, _ = parse_yahoo_chart(payload)
    assert len(df) == 10                                 # only trailing dropped
    assert float(df["high"].iloc[4]) == float(df["low"].iloc[4])  # kept


def test_parse_flat_trailing_drop_survives_single_row_frame():
    from app.data.market.live_public import parse_yahoo_chart

    ts = [BASE_TS]
    df, _ = parse_yahoo_chart(_payload(ts, [5.0], [5.0], [5.0], [5.0]))
    assert df.empty
    df2, _ = parse_yahoo_chart(_payload(ts, [5.0], [6.0], [4.0], [5.5]))
    assert len(df2) == 1


# ================================================================== D7 ==
class _ChangingFeed:
    """Fake Yahoo whose bar count changes between fetch cycles (realistic:
    new bars form at the front of the window while old ones roll out)."""

    def __init__(self, seq):
        # seq: list of (n_bars, base_ts, price) per Yahoo fetch cycle
        self.seq = list(seq)
        self.calls = 0

    def __call__(self, url, timeout):
        if "query1.finance.yahoo.com" not in url:
            return {"price": 4183.6, "updatedAt": "2026-10-09T07:00:00Z"}
        n, base, p = self.seq[min(self.calls, len(self.seq) - 1)]
        self.calls += 1
        ts = [base + 60 * i for i in range(n)]
        return _payload(ts, [p] * n, [p + 2] * n, [p - 2] * n, [p + 0.5] * n,
                        price=p + 1)


@pytest.fixture()
def growing_provider(monkeypatch):
    from app.data.market.live_public import LivePublicProvider

    p = LivePublicProvider(refresh_seconds=30, spread_points=30,
                           start_refresh_thread=False)
    # cycle 0 (connect/seed): 100 bars; cycle 1: 101 bars (+1 new);
    # cycle 2: 100 bars (oldest rolled out); cycle 3: 103 bars
    fake = _ChangingFeed([
        (100, BASE_TS, PRICE),
        (101, BASE_TS + 60, PRICE),
        (100, BASE_TS + 120, PRICE),
        (103, BASE_TS + 60, PRICE + 5),
    ])
    monkeypatch.setattr("app.data.market.live_public._http_get_json", fake)
    return p, fake


def test_refresh_merge_survives_bar_count_change(growing_provider):
    """THE freeze regression: old merge raised on every length change →
    frames frozen at seed → identical FEATURES_NAN WAIT every cycle."""
    p, fake = growing_provider
    p.connect()                                    # seed: 100 bars
    m1_seed = p.get_candles("XAUUSD", "M1", 100000)
    assert len(m1_seed) == 100

    fake.calls = 1                                 # next fetch → 101 bars
    p.refresh()                                    # must NOT raise
    m1 = p.get_candles("XAUUSD", "M1", 100000)
    # frame ADVANCED to the newest fetched bar (the old bug froze it at seed)
    assert m1.index[-1] == pd.Timestamp(BASE_TS + 60 * 101, unit="s", tz="UTC")
    assert m1.index.is_unique and m1.index.is_monotonic_increasing

    fake.calls = 2                                 # next fetch → 100 bars (window slid)
    p.refresh()
    m1b = p.get_candles("XAUUSD", "M1", 100000)
    # union of prev ∪ new stays bounded (old bars retained, dupes removed)
    assert 100 <= len(m1b) <= 102
    assert m1b.index.is_unique and m1b.index.is_monotonic_increasing

    fake.calls = 3                                 # next fetch → 103 bars
    p.refresh()
    m1_new = p.get_candles("XAUUSD", "M1", 100000)
    # frame advanced AGAIN to the newest bar, with the feed's revised price
    assert m1_new.index[-1] == pd.Timestamp(BASE_TS + 60 * 103, unit="s", tz="UTC")
    assert m1_new["close"].iloc[-1] == pytest.approx(PRICE + 5.5)
    assert len(m1_new) <= 104                      # union stays bounded


def test_refresh_merge_last_wins_on_revised_bar(monkeypatch):
    """A re-fetched bar with revised values must overwrite the cached one."""
    from app.data.market.live_public import LivePublicProvider

    n = 50
    ts = [BASE_TS + 60 * i for i in range(n)]

    class _Revising:
        def __init__(self):
            self.revised = False

        def __call__(self, url, timeout):
            if "query1.finance.yahoo.com" not in url:
                return {"price": 4183.6, "updatedAt": "2026-10-09T07:00:00Z"}
            if self.revised:
                closes = [PRICE + 0.5] * n
                closes[-1] = PRICE + 9.0            # revised last bar
                return _payload(ts, [PRICE] * n, [PRICE + 2] * n,
                                [PRICE - 2] * n, closes)
            return _payload(ts, [PRICE] * n, [PRICE + 2] * n,
                            [PRICE - 2] * n, [PRICE + 0.5] * n)

    fake = _Revising()
    monkeypatch.setattr("app.data.market.live_public._http_get_json", fake)
    p = LivePublicProvider(start_refresh_thread=False)
    p.connect()
    fake.revised = True
    p.refresh()
    m1 = p.get_candles("XAUUSD", "M1", 100000)
    assert len(m1) == n                               # no duplicate row added
    assert m1["close"].iloc[-1] == pytest.approx(PRICE + 9.0)  # new value won


# =================================================== end-to-end chain ==
def test_features_no_nan_on_last_row_after_flat_drop(monkeypatch):
    """Full chain: provider frame (flat trailing bar in the raw fetch) →
    M5 candles → base features → the five zero-range-sensitive features
    must be finite on the inference row."""
    import app.data.market.live_public as lp
    from app.config.schema import FeatureConfig, IndicatorConfig, SessionsConfig
    from app.data.market.live_public import LivePublicProvider
    from app.features.builder import FeatureBuilder

    monkeypatch.setattr(lp, "_http_get_json",
                        _ChangingFeed([(60, BASE_TS, PRICE),
                                       (60, BASE_TS, PRICE)]))
    p = LivePublicProvider(start_refresh_thread=False)
    p.connect()

    m5 = p.get_candles("XAUUSD", "M5", 100000)
    assert len(m5) >= 30
    last_raw = m5.iloc[-1]
    assert not (last_raw["high"] == last_raw["low"])  # no zero range

    fb = FeatureBuilder(FeatureConfig(), IndicatorConfig(), SessionsConfig())
    feats = fb._base_features(m5)
    suspects = ["body_ratio", "wick_ratio", "range",
                "atr_norm_range", "range_expansion"]
    vals = feats[suspects].iloc[-1]
    assert not vals.isna().any(), f"NaN features on last row: {vals.to_dict()}"


# ================================================== WAIT reason code ==
def test_features_nan_wait_reason_survives_sanitization():
    """The journal sanitizes reason codes (drops ':'/',' truncates 48) —
    the v1.7.2 code must survive byte-for-byte."""
    code = "FEATURES_NAN_atr_norm_range_body_ratio_plus3"
    out = sanitize_reason_codes([code])
    assert out == [code]
    assert len(code) <= 48


def test_features_nan_wait_reason_builder_matches_pipeline():
    """Exercise the actual code path in pipeline.run()."""
    nan_cols = ["atr_norm_range", "body_ratio", "range",
                "range_expansion", "wick_ratio"]
    _n = sorted(nan_cols)
    code = ("FEATURES_NAN_" + "_".join(_n[:2])
            + (f"_plus{len(_n) - 2}" if len(_n) > 2 else ""))
    assert code == "FEATURES_NAN_atr_norm_range_body_ratio_plus3"
    assert sanitize_reason_codes([code]) == [code]

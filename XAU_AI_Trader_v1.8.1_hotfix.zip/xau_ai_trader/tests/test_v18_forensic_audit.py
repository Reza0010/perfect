"""v1.8 — FORENSIC AUDIT regression tests.

Every test here locks a specific fix from the v1.8 forensic audit so the
bugs documented in BUG_REGISTER §F can never silently return:

  T1  train.py provider selection follows the config (no silent Simulated)
  T2  closed-bar detection is TIME-based, not flatness-based (the user's
      core complaint: a non-flat FORMING bar must never reach inference)
  T3  resampled higher-TF buckets are complete (no partial trailing bucket)
  T4  market-feed stop() → start() actually restarts (calibration bug P12)
  T5  trader state: mt5_connected is False for simulated/public providers,
      and provider identity fields exist (P3)
  T6  registry provenance: data_source recorded, supersede history kept,
      relative paths (no stale absolute checkout paths)
  T7  model readiness gate: one-sided / below-chance / synthetic models are
      flagged NOT validated (never silently trusted)
  T8  collector stats: zero closed trades → null win rate (P9)
  T9  leakage audit is FAIL-CLOSED (no silent skip on internal errors)
  T10 simulator ↔ engine equivalence: SL gap-fill, 21:00 rollover swap,
      triple-swap Wednesday, swap on the exit bar
  T11 classification metrics expose the confusion matrix + per-class F1
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config


# ================================================================= T1 ==
def test_shared_factory_builds_configured_provider(tmp_path, monkeypatch):
    """train.py/walkforward.py/optimize.py/backtest.py all build the provider
    through app.data.providers_factory — kind=public must yield the public
    provider, kind=simulated the simulated one. The old train.py hardcoded
    SimulatedProvider while printing 'MT5 data'."""
    from app.data.market.live_public import LivePublicProvider
    from app.data.market.simulated import SimulatedProvider
    from app.data.providers_factory import (build_data_provider,
                                            explicit_simulated,
                                            provider_data_source)

    cfg = load_config(None)

    cfg_p = cfg.model_copy(update={"provider": cfg.provider.model_copy(
        update={"kind": "public"})})
    p = build_data_provider(cfg_p)
    assert isinstance(p, LivePublicProvider)
    src = provider_data_source(p)
    assert src["kind"] == "public" and src["real_market"] is True

    cfg_s = cfg.model_copy(update={"provider": cfg.provider.model_copy(
        update={"kind": "simulated"})})
    p2 = build_data_provider(cfg_s)
    assert isinstance(p2, SimulatedProvider)
    src2 = provider_data_source(p2)
    assert src2["kind"] == "simulated" and src2["real_market"] is False

    # explicit synthetic forcing is stamped so it can never masquerade
    forced = explicit_simulated(cfg)
    assert getattr(forced, "synthetic_forced", False) is True
    assert provider_data_source(forced)["kind"] == "simulated"


def test_train_script_uses_config_provider(monkeypatch):
    """The train.py MODULE must not import SimulatedProvider at top level or
    build it unconditionally — grep-level guard for the exact v1.7.2 bug."""
    src = Path("train.py").read_text(encoding="utf-8")
    assert "from app.data.market.simulated import SimulatedProvider" not in src
    assert "build_data_provider" in src
    assert "provider_data_source" in src


# ================================================================= T2 ==
def _payload(ts_list, price=4200.0):
    n = len(ts_list)
    p = price
    return {
        "chart": {"result": [{
            "meta": {"symbol": "GC=F", "regularMarketPrice": p + 1,
                     "regularMarketTime": ts_list[-1] + 30,
                     "currency": "USD", "fullExchangeName": "COMEX"},
            "timestamp": list(ts_list),
            "indicators": {"quote": [{
                "open": [p] * n, "high": [p + 2] * n,
                "low": [p - 2] * n, "close": [p + 0.5] * n,
                "volume": [100] * n}]},
        }]}
    }


def test_time_based_closed_bar_drops_nonflat_forming_bar():
    """THE core v1.8 fix: during active market hours Yahoo's in-progress bar
    has REAL range (non-flat OHLC) — the v1.7.2 flatness heuristic kept it
    and ML inference ran on the forming bar. Closure is now a property of
    TIME: open + duration + buffer <= now."""
    from app.data.market.live_public import parse_yahoo_chart

    now = time.time()
    # 5-minute bars; the last one opened 2 minutes ago → still FORMING
    iv = 300
    ts = [int(now) - iv * k for k in range(8, 0, -1)]  # 8 bars, newest first
    ts = sorted(ts)
    # newest bar opens at now-120 (2 min ago): 120 + 300 > now → forming
    ts[-1] = int(now) - 120
    df, _ = parse_yahoo_chart(_payload(ts), interval_seconds=iv, now=now)
    # the forming bar must be gone; the last surviving bar opened ≥ 6 min ago
    assert df.index[-1].timestamp() <= now - iv - 60
    assert int(now) - 120 not in [t for t in df.index]


def test_time_based_closed_bar_keeps_recently_closed_bar():
    from app.data.market.live_public import parse_yahoo_chart

    now = time.time()
    iv = 300
    # newest bar opened 7 minutes ago → closed 2 minutes ago → KEPT
    ts = [int(now) - 420 - iv * k for k in range(10)]
    df, _ = parse_yahoo_chart(_payload(ts), interval_seconds=iv, now=now)
    assert len(df) == 10


def test_time_based_drop_without_explicit_interval_infers_from_index():
    from app.data.market.live_public import parse_yahoo_chart

    now = time.time()
    iv = 60
    ts = [int(now) - iv * k for k in range(9, 0, -1)]
    ts = sorted(ts)
    ts[-1] = int(now) - 20          # 20s-old 1-minute bar → forming
    df, _ = parse_yahoo_chart(_payload(ts), now=now)   # no interval given
    assert df.index[-1].timestamp() < now - 80         # forming bar dropped


# ================================================================= T3 ==
def test_resampled_timeframes_drop_incomplete_trailing_bucket(monkeypatch):
    """A resampled M15 bucket holding only 2 of 3 M5 bars is a FORMING
    bucket and must not be returned as a complete candle."""
    from app.data.market.live_public import LivePublicProvider, parse_yahoo_chart

    now = time.time()
    # M5 bars: full buckets up to 40 min ago, then one more bar 20 min ago
    # (a partial M15 bucket: 20 min ago belongs to the 20-min-ago M15 bucket
    # whose full duration has NOT elapsed... 20min bucket opens at -20, needs
    # 15 min → complete at -5min + buffer 60s → -5-1 = -6 min... it IS
    # complete if now > bucket_open + 16min. Let's make it -10 min: complete
    # at -10+16 = -(-6)... i.e. still 6 minutes in the future → INCOMPLETE.)
    # Build: complete bars at -100..-40 min, then a bar at -10 min only.
    ts = [int(now) - 100 * 60 - 300 * k for k in range(13)] + [int(now) - 10 * 60]
    ts = sorted(set(ts))

    calls = {"n": 0}

    def fake_http(url, timeout):
        if "query1.finance.yahoo.com" not in url:
            return {"price": 4183.6, "updatedAt": "2026-10-10T07:00:00Z"}
        calls["n"] += 1
        # return 5m payload when the M5 seed is requested (contains the
        # partial trailing bucket), and an old 1m payload for M1
        if "interval=5m" in url:
            return _payload(ts)
        return _payload([int(now) - 3600 - 60 * k for k in range(20)][::-1])

    monkeypatch.setattr("app.data.market.live_public._http_get_json", fake_http)
    p = LivePublicProvider(start_refresh_thread=False)
    p.connect()
    m15 = p.get_candles("XAUUSD", "M15", 100)
    # no M15 bucket may have opened within the last 15 minutes + buffer
    cutoff = pd.Timestamp.now(tz="UTC") - pd.Timedelta(minutes=16)
    assert len(m15) > 0
    assert (m15.index < cutoff).all()


# ================================================================= T4 ==
def test_market_feed_stop_start_really_restarts():
    """P12: stop() then start() must yield a live thread; the old start()
    cleared the stop event BEFORE checking aliveness, so a 30s-waiting old
    thread kept running and the new feed never started."""
    from app.panel.market_feed import LiveMarketFeed

    feed = LiveMarketFeed(Path("."))
    feed.start()
    assert feed._thread is not None and feed._thread.is_alive()
    feed.stop()
    assert not feed._thread.is_alive()
    feed.start()
    try:
        assert feed._thread is not None and feed._thread.is_alive()
        assert not feed._stop.is_set()
    finally:
        feed.stop()


# ================================================================= T5 ==
class _StubExecutor:
    mode = "paper"

    def positions(self):
        return []


def test_trader_state_mt5_connected_false_for_public_provider(tmp_path, monkeypatch):
    """P3: provider.is_connected() is True for LivePublicProvider/Simulated —
    state.json must NOT claim an MT5 broker connection from them."""
    from app.trader import TradingSystem

    cfg = load_config(None)
    # point paths at a temp sandbox
    cfg = cfg.model_copy(update={"paths": cfg.paths.model_copy(update={
        "logs_dir": str(tmp_path),
        "models_dir": str(tmp_path / "models"),
        "reports_dir": str(tmp_path / "reports"),
        "data_dir": str(tmp_path / "data")})})

    from app.data.market.live_public import LivePublicProvider
    from app.journal.journal import Journal
    from app.monitoring.health import HealthRegistry
    from app.monitoring.state import StateStore
    from app.panel.loop_manager import TradingLoopManager  # noqa: F401
    from app.risk.kill_switch import KillSwitch

    provider = LivePublicProvider(start_refresh_thread=False)
    provider._connected = True        # simulate a "connected" public feed

    class _Pipeline:
        bundle = None

    ts = TradingSystem(
        cfg=cfg, provider=provider, pipeline=_Pipeline(), ensemble=None,
        risk=KillSwitch(cfg.kill_switch), executor=_StubExecutor(),
        gateway=type("G", (), {"available_providers": []})(),
        journal=Journal(tmp_path / "journal.db"), health=HealthRegistry(),
        kill_switch=KillSwitch(cfg.kill_switch),
        state_store=StateStore(tmp_path / "state.json"), notifiers=None,
    )
    ts._write_state()
    state = json.loads((tmp_path / "state.json").read_text(encoding="utf-8"))
    # a public provider is NOT an MT5 broker connection
    assert state["mt5_connected"] is False
    assert state["provider_kind"] == "public"
    assert state["provider_is_broker"] is False
    # spread unit honesty (P6)
    assert state.get("spread_unit") == "price_usd"
    assert state.get("spread_is_assumed") is True
    # model readiness surfaced (v1.8)
    assert "model_validated" in state and "model_quality_warnings" in state


# ================================================================= T6 ==
def test_registry_provenance_and_supersede_history(tmp_path):
    from app.models.registry import ModelRegistry

    reg = ModelRegistry(tmp_path / "reg")
    entry1 = reg.register("lgbm_x", "lightgbm", str(tmp_path / "reg" / "lgbm_x"),
                          {}, {"log_loss": 1.0}, extra={
                              "data_source": {"kind": "simulated",
                                              "label": "SIMULATED"}})
    entry2 = reg.register("lgbm_x", "lightgbm", str(tmp_path / "reg" / "lgbm_x"),
                          {}, {"log_loss": 0.5}, extra={
                              "data_source": {"kind": "replay",
                                              "label": "replayed dataset"}})
    assert entry2["version"] == 2
    # supersede history preserved (old in-place overwrite destroyed it)
    assert "superseded_versions" in entry2
    assert entry2["superseded_versions"][0]["metrics"]["log_loss"] == 1.0
    # paths stored RELATIVE to the registry root
    assert entry2["path"] == "lgbm_x"


# ================================================================= T7 ==
def test_model_readiness_gate_flags_one_sided_model():
    from app.models.registry import ModelRegistry

    entry = {
        "model_id": "lgbm_main", "version": 3,
        "metrics": {"accuracy": 0.772, "recall_SELL": 0.996, "recall_NO_EDGE": 0.0,
                    "recall_BUY": 0.005, "roc_auc_ovr": 0.626},
        "extra": {"data_source": {"kind": "simulated", "label": "SIMULATED"},
                  "windows": {"train": ["a", "b"]}},
    }
    r = ModelRegistry.deployment_readiness(entry)
    assert r["ready"] is False
    assert any("SYNTHETIC_DATA_MODEL" in w for w in r["warnings"])
    assert any("ONE_SIDED_MODEL" in w for w in r["warnings"])


def test_model_readiness_gate_flags_below_chance_and_missing_provenance():
    from app.models.registry import ModelRegistry

    entry = {"model_id": "lgbm_real", "version": 2,
             "metrics": {"roc_auc_ovr": 0.410}, "extra": {}}
    r = ModelRegistry.deployment_readiness(entry)
    assert r["ready"] is False
    assert any("NO_DATA_SOURCE_PROVENANCE" in w for w in r["warnings"])
    assert any("BELOW_CHANCE_MODEL" in w for w in r["warnings"])
    assert any("NO_TRAINING_WINDOW" in w for w in r["warnings"])


def test_model_readiness_gate_passes_honest_balanced_model():
    from app.models.registry import ModelRegistry

    entry = {
        "model_id": "lgbm_good", "version": 1,
        "metrics": {"accuracy": 0.45, "recall_SELL": 0.4, "recall_NO_EDGE": 0.5,
                    "recall_BUY": 0.45, "roc_auc_ovr": 0.56},
        "extra": {"data_source": {"kind": "replay", "label": "replayed dataset"},
                  "windows": {"train": ["a", "b"]}},
    }
    r = ModelRegistry.deployment_readiness(entry)
    assert r["ready"] is True and r["warnings"] == []


# ================================================================= T8 ==
def test_collector_stats_null_winrate_without_closed_trades(tmp_path):
    """P9: zero closed trades must NOT render a 0% win rate."""
    import sqlite3

    from app.panel.collector import PanelCollector

    root = tmp_path / "proj"
    (root / "logs").mkdir(parents=True)
    conn = sqlite3.connect(root / "logs" / "journal.db")
    conn.execute("CREATE TABLE trades (pnl REAL, exit_time TEXT, entry_time TEXT)")
    conn.commit()
    conn.close()
    coll = PanelCollector(root)
    out = coll.trades()
    assert out["stats"]["n_closed"] == 0
    assert out["stats"]["win_rate_pct"] is None
    assert out["stats"]["expectancy"] is None
    assert out["stats"]["profit_factor"] is None


# ================================================================= T9 ==
def test_leakage_audit_fail_closed(monkeypatch):
    """The audit used to swallow non-LeakageError exceptions with a warning
    and training continued — indistinguishable from a passed audit."""
    import app.models.leakage as leakage_mod
    import app.models.train_service as ts_mod
    from app.core.exceptions import LeakageError
    from app.models.train_service import train_models

    cfg = load_config(None)

    def _boom(*a, **k):
        raise RuntimeError("internal audit explosion")

    # train_models imports run_full_audit from app.models.leakage INSIDE the
    # function — patch the source module (the local-alias in train_service
    # is bound at call time, before the scaler audit runs).
    monkeypatch.setattr(leakage_mod, "run_full_audit", _boom)
    # the aliased name inside train_service's module namespace must not shadow
    monkeypatch.setattr(ts_mod, "run_full_audit", _boom, raising=False)

    from app.data.market.simulated import SimulatedProvider

    p = SimulatedProvider(days=cfg.provider.simulated_days, seed=1)
    p.connect()
    from app.models.train_service import build_frames
    frames = build_frames(p, cfg)
    with pytest.raises((LeakageError, RuntimeError)):
        train_models(cfg, frames, register=False)


# ================================================================= T10 ==
def _engine_equivalence_window(seed: int = 7):
    """Deterministic 3-day M15 window with gaps, spikes and rollovers."""
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2026-06-01", periods=288, freq="15min", tz="UTC")
    open_ = 4000 + np.cumsum(rng.normal(0, 0.8, len(idx)))
    high = open_ + np.abs(rng.normal(0, 1.2, len(idx))) + 0.3
    low = open_ - np.abs(rng.normal(0, 1.2, len(idx))) - 0.3
    close = open_ + rng.normal(0, 0.4, len(idx))
    df = pd.DataFrame({"open": open_, "high": np.maximum(high, close),
                       "low": np.minimum(low, close), "close": close},
                      index=idx)
    # inject a violent gap-through-SL bar
    df.iloc[100, df.columns.get_loc("open")] = df["close"].iloc[99] - 25.0
    df.iloc[100, df.columns.get_loc("low")] = df["close"].iloc[99] - 28.0
    df.iloc[100, df.columns.get_loc("high")] = df["close"].iloc[99] - 20.0
    return df


def test_simulator_matches_engine_on_gap_sl_swap_and_exit_bar():
    """Engine-equivalence after the v1.8 simulator fixes: SL gap-fill,
    21:00 rollover swap, triple-swap Wednesday, exit-bar swap."""
    from app.analytics.null_model import SingleTradeSimulator
    from app.backtest.engine import Backtester
    from app.config.schema import BacktestConfig, SymbolInfoDefaults
    from app.data.market.models import SymbolInfo

    window = _engine_equivalence_window()
    d = SymbolInfoDefaults()
    info = SymbolInfo(name="XAUUSD", digits=d.digits, point=d.point,
                      tick_size=d.tick_size, tick_value=d.tick_value,
                      contract_size=d.contract_size)
    delay = 1
    hs = np.full(len(window), 0.15)

    # signals spread across the window, both sides, spanning rollovers
    sig_idx = window.index[[30, 60, 95, 130, 180, 210, 240]]
    signals = pd.DataFrame({
        "side": ["BUY", "SELL", "BUY", "SELL", "BUY", "SELL", "BUY"],
        "sl": [3990.0, 4010.0, 3985.0, 4015.0, 3995.0, 4020.0, 3990.0],
        "tp": [4030.0, 3970.0, 4035.0, 3965.0, 4025.0, 3960.0, 4030.0],
        "lot": [0.1] * 7, "score": [1.0] * 7,
    }, index=sig_idx)

    bt = Backtester(BacktestConfig(initial_balance=10_000), info,
                    commission_per_lot=7.0, swap_long=-8.0, swap_short=-2.0,
                    slippage_points=5.0, assumed_spread=0.30)
    res = bt.run(window, signals)
    engine = res.trades_df().reset_index(drop=True)

    sim = SingleTradeSimulator(window, delay=delay, half_spread=hs,
                               slippage_price=5.0 * info.point,
                               tick_size=info.tick_size,
                               tick_value=info.tick_value,
                               commission_per_lot=7.0,
                               swap_long=-8.0, swap_short=-2.0,
                               both_hit_assumption="sl_first")
    sim_trades = pd.DataFrame([t.__dict__ for t in sim.run_signals(signals)])
    sim_trades = sim_trades.reset_index(drop=True)

    assert len(engine) == len(sim_trades) and len(engine) > 0
    max_diff = float(np.abs(engine["pnl"].to_numpy(float)
                            - sim_trades["pnl"].to_numpy(float)).max())
    assert max_diff < 1e-6, f"pnl mismatch {max_diff}"
    assert (engine["exit_reason"].to_numpy()
            == sim_trades["exit_reason"].to_numpy()).all()
    # swap must be identical too (the old midnight-vs-21:00 bug)
    assert np.abs(engine["swap"].to_numpy(float)
                  - sim_trades["swap"].to_numpy(float)).max() < 1e-6


# ================================================================ T11 ==
def test_classification_metrics_expose_confusion_matrix():
    from app.models.validation import classification_metrics

    y = np.array([0, 0, 1, 1, 2, 2, 2, 1, 0])
    probs = np.full((9, 3), 0.1)
    probs[0, 0] = 0.8
    probs[1, 0] = 0.7
    probs[2, 1] = 0.6
    probs[3, 1] = 0.9
    probs[4, 2] = 0.8
    probs[5, 2] = 0.55
    probs[6, 0] = 0.5
    probs[7, 1] = 0.6
    probs[8, 2] = 0.7
    m = classification_metrics(y, probs)
    assert "confusion_matrix" in m and m["confusion_matrix_order"] == \
        ["SELL", "NO_EDGE", "BUY"]
    cm = np.array(m["confusion_matrix"])
    assert cm.sum() == 9
    for cls in ("SELL", "NO_EDGE", "BUY"):
        assert f"f1_{cls}" in m
    assert m["class_support"]["SELL"] == 3


# ================================================================ extra ==
def test_collector_overview_carries_provider_and_model_fields(tmp_path):
    """overview() must surface provider identity + model warnings so the UI
    can label them (P2/P10/v1.8 model badge)."""
    import sqlite3

    from app.panel.collector import PanelCollector

    root = tmp_path / "proj"
    (root / "logs").mkdir(parents=True)
    # state.json with the v1.8 fields
    (root / "logs" / "state.json").write_text(json.dumps({
        "updated": pd.Timestamp.now(tz="UTC").isoformat(),
        "provider_kind": "public", "provider_is_broker": False,
        "model_validated": False,
        "model_quality_warnings": ["lgbm_main: ONE_SIDED_MODEL: ..."],
        "mode": "paper", "mt5_connected": False,
    }), encoding="utf-8")
    conn = sqlite3.connect(root / "logs" / "journal.db")
    conn.execute("CREATE TABLE signals (id INTEGER PRIMARY KEY)")
    conn.commit()
    conn.close()
    coll = PanelCollector(root)
    ov = coll.overview()
    assert ov["provider_kind"] == "public"
    assert ov["provider_is_broker"] is False
    assert ov["model_validated"] is False
    assert ov["model_quality_warnings"]
    assert ov["live"]["mt5_connected"] is False

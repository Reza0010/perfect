"""Shared pytest fixtures."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).parents[1]))

from app.config.loader import load_config  # noqa: E402
from app.config.schema import (  # noqa: E402
    EnsembleWeights, ExecutionConfig, IndicatorConfig, FeatureConfig,
    LabelConfig, NewsConfig, RiskConfig, SessionsConfig, SMCConfig, SymbolConfig,
)
from app.data.market.models import SymbolInfo  # noqa: E402
from app.data.market.simulated import SimulatedProvider  # noqa: E402
from app.models.train_service import build_frames, make_feature_builder  # noqa: E402


@pytest.fixture(scope="session")
def config():
    cfg = load_config()
    cfg.provider.simulated_days = 25
    return cfg


@pytest.fixture(scope="session")
def provider():
    p = SimulatedProvider(days=25, seed=7)
    p.connect()
    return p


@pytest.fixture(scope="session")
def small_frames(provider, config):
    """Small multi-TF frame set for fast tests."""
    frames = {}
    for tf, bars in (("M1", 3000), ("M5", 2000), ("M15", 800), ("H1", 400), ("H4", 150), ("D1", 25)):
        frames[tf] = provider.get_candles("XAUUSD", tf, bars)
    base = frames["M5"].index
    start, end = base[0], base[-1]
    return {tf: df[(df.index >= start) & (df.index <= end)] for tf, df in frames.items()}


@pytest.fixture(scope="session")
def feature_matrix(small_frames, config):
    fb = make_feature_builder(config)
    feats, names = fb.build(small_frames, config.timeframes.base)
    return feats, names


@pytest.fixture(scope="session")
def symbol_info():
    return SymbolInfo(name="XAUUSD", digits=2, point=0.01, tick_size=0.01,
                      tick_value=1.0, contract_size=100.0, volume_min=0.01,
                      volume_max=100.0, volume_step=0.01, leverage=100)


@pytest.fixture
def ohlc_df():
    """Deterministic 300-bar OHLC frame with one engineered BOS + FVG."""
    rng = np.random.default_rng(3)
    n = 300
    trend = np.concatenate([np.full(150, 0.0), np.linspace(0, 30, 150)])
    noise = rng.normal(0, 0.4, n)
    close = 2650 + trend + np.cumsum(noise) * 0.05
    open_ = np.roll(close, 1)
    open_[0] = close[0]
    high = np.maximum(open_, close) + np.abs(rng.normal(0, 0.15, n))
    low = np.minimum(open_, close) - np.abs(rng.normal(0, 0.15, n))
    idx = pd.date_range("2026-01-05 00:00", periods=n, freq="5min", tz="UTC")
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close,
                         "tick_volume": rng.integers(50, 200, n),
                         "real_volume": np.zeros(n), "spread": np.full(n, 0.2)}, index=idx)

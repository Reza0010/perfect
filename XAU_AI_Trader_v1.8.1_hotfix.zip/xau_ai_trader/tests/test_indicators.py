"""Indicator correctness + causality tests."""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.indicators.ta import adx, atr, ema, macd, rsi, sma


def test_ema_matches_manual_computation():
    close = pd.Series([1.0, 2.0, 3.0, 4.0, 5.0] * 5, dtype=float)
    e = ema(close, 5)
    # EMA with adjust=False, alpha = 2/(span+1); pandas seeds y[0] = x[0]
    k = 2 / 6
    expected = [float(close.iloc[0])]
    for c in close.iloc[1:]:
        expected.append(c * k + expected[-1] * (1 - k))
    # min_periods=5 → first 4 outputs are NaN, recursion starts from bar 0
    np.testing.assert_allclose(e.values[4:], expected[4:], rtol=1e-10)


def test_sma_simple():
    close = pd.Series(np.arange(1, 11, dtype=float))
    s = sma(close, 5)
    assert s.isna().sum() == 4
    assert s.iloc[9] == 8.0


def test_rsi_bounds_and_extremes():
    up = pd.Series(np.linspace(1, 100, 100))          # monotonic up → RSI ~100
    down = pd.Series(np.linspace(100, 1, 100))        # monotonic down → RSI ~0
    assert rsi(up, 14).iloc[-1] > 95
    assert rsi(down, 14).iloc[-1] < 5


def test_rsi_causal():
    rng = np.random.default_rng(1)
    close = pd.Series(100 + np.cumsum(rng.normal(0, 0.5, 200)))
    full = rsi(close, 14)
    partial = rsi(close.iloc[:100], 14)
    np.testing.assert_allclose(full.iloc[:100].values, partial.values, rtol=1e-9)


def test_atr_positive_and_causal(ohlc_df):
    a = atr(ohlc_df["high"], ohlc_df["low"], ohlc_df["close"], 14)
    assert (a.dropna() > 0).all()
    partial = atr(ohlc_df["high"].iloc[:150], ohlc_df["low"].iloc[:150],
                  ohlc_df["close"].iloc[:150], 14)
    np.testing.assert_allclose(a.iloc[:150].values, partial.values, rtol=1e-9)


def test_macd_shape():
    close = pd.Series(100 + np.cumsum(np.random.default_rng(2).normal(0, 1, 300)))
    m = macd(close)
    assert list(m.columns) == ["macd", "macd_signal", "macd_hist"]
    np.testing.assert_allclose((m["macd"] - m["macd_signal"]).values,
                               m["macd_hist"].values, atol=1e-12)


def test_adx_bounds(ohlc_df):
    d = adx(ohlc_df["high"], ohlc_df["low"], ohlc_df["close"], 14)
    assert ((d["adx"].dropna() >= 0) & (d["adx"].dropna() <= 100)).all()
    assert ((d["di_plus"].dropna() >= 0) & (d["di_minus"].dropna() >= 0)).all()

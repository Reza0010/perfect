"""PHASE 33 — Backtester costs, fills, and metrics sanity."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from app.backtest import metrics as m
from app.backtest.engine import Backtester
from app.config.schema import BacktestConfig
from app.data.market.models import SymbolInfo


@pytest.fixture
def symbol():
    return SymbolInfo(name="XAUUSD", point=0.01, tick_size=0.01, tick_value=1.0,
                      contract_size=100.0, volume_min=0.01, volume_max=100.0,
                      volume_step=0.01, leverage=100)


def _mk_df(n=200, start=2650.0, drift=0.5, spread=0.2):
    rng = np.random.default_rng(4)
    close = start + np.cumsum(np.full(n, drift) + rng.normal(0, 0.3, n))
    open_ = np.roll(close, 1)
    open_[0] = start
    high = np.maximum(open_, close) + 0.2
    low = np.minimum(open_, close) - 0.2
    idx = pd.date_range("2026-01-05 00:00", periods=n, freq="5min", tz="UTC")
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close,
                         "tick_volume": np.ones(n), "real_volume": np.zeros(n),
                         "spread": np.full(n, spread)}, index=idx)


def test_buy_trade_hits_tp_and_pays_costs(symbol):
    df = _mk_df()
    entry_bar = 10
    entry = float(df["open"].iloc[entry_bar]) + 0.1 + 0.05  # spread/2 + slippage
    sig = pd.DataFrame([{"side": "BUY", "sl": entry - 2.0, "tp": entry + 4.0,
                         "lot": 0.5, "score": 0.7}],
                       index=[df.index[entry_bar - 1]])
    bt = Backtester(BacktestConfig(), symbol, commission_per_lot=7.0,
                    slippage_points=5.0)
    res = bt.run(df, sig)
    assert len(res.trades) >= 1
    t = res.trades[0]
    if t.exit_reason == "TP":
        # 4.0 price move / 0.01 = 400 ticks × $1 × 0.5 lot = $200 − fees
        assert t.pnl == pytest.approx(200.0, rel=0.01)
        assert t.fees == pytest.approx(3.5)  # 7.0 × 0.5


def test_costs_reduce_pnl(symbol):
    df = _mk_df(drift=0.0)  # flat market
    entry = float(df["open"].iloc[5]) + 0.1 + 0.05
    sig = pd.DataFrame([{"side": "BUY", "sl": entry - 1.0, "tp": entry + 2.0,
                         "lot": 1.0, "score": 0.6}], index=[df.index[4]])
    bt = Backtester(BacktestConfig(execution_delay_bars=1), symbol,
                    commission_per_lot=7.0, slippage_points=5.0)
    res = bt.run(df, sig)
    if res.trades:
        t = res.trades[0]
        # costs: 7 commission + (spread 0.2 + slippage 0.05) × 100 ticks
        assert t.fees == pytest.approx(7.0)


def test_both_hit_assumes_sl_first(symbol):
    # one massive bar covering both SL and TP
    n = 20
    idx = pd.date_range("2026-01-05", periods=n, freq="5min", tz="UTC")
    df = pd.DataFrame({
        "open": np.full(n, 2650.0), "high": np.full(n, 2700.0),
        "low": np.full(n, 2600.0), "close": np.full(n, 2650.0),
        "tick_volume": np.ones(n), "real_volume": np.zeros(n),
        "spread": np.full(n, 0.2)}, index=idx)
    sig = pd.DataFrame([{"side": "BUY", "sl": 2645.0, "tp": 2690.0,
                         "lot": 0.1, "score": 0.6}], index=[idx[5]])
    bt = Backtester(BacktestConfig(), symbol)
    res = bt.run(df, sig)
    # v1.5: SL-first default preserved; the same-bar assumption is now
    # recorded on the exit reason for auditability (Mission 18).
    assert res.trades[0].exit_reason.startswith("SL")
    assert res.trades[0].exit_reason.endswith("same_bar")
    assert res.trades[0].exit_price == pytest.approx(2645.0)


def test_both_hit_tp_first_honoured_when_configured(symbol):
    # v1.5: the both_hit_assumption config was silently ignored before
    n = 20
    idx = pd.date_range("2026-01-05", periods=n, freq="5min", tz="UTC")
    df = pd.DataFrame({
        "open": np.full(n, 2650.0), "high": np.full(n, 2700.0),
        "low": np.full(n, 2600.0), "close": np.full(n, 2650.0),
        "tick_volume": np.ones(n), "real_volume": np.zeros(n),
        "spread": np.full(n, 0.2)}, index=idx)
    sig = pd.DataFrame([{"side": "BUY", "sl": 2645.0, "tp": 2690.0,
                         "lot": 0.1, "score": 0.6}], index=[idx[5]])
    bt = Backtester(BacktestConfig(both_hit_assumption="tp_first"), symbol)
    res = bt.run(df, sig)
    assert res.trades[0].exit_reason.startswith("TP")
    assert res.trades[0].exit_price == pytest.approx(2690.0)


def test_gap_through_sl_fills_at_worse_open(symbol):
    # v1.5: bar OPENS beyond the stop → fill at the open, not the stop
    n = 20
    idx = pd.date_range("2026-01-05", periods=n, freq="5min", tz="UTC")
    df = pd.DataFrame({
        "open": np.full(n, 2650.0), "high": np.full(n, 2655.0),
        "low": np.full(n, 2640.0), "close": np.full(n, 2650.0),
        "tick_volume": np.ones(n), "real_volume": np.zeros(n),
        "spread": np.full(n, 0.0)}, index=idx)
    # crash bar: opens 2600 (far below the 2630 stop)
    df.iloc[8, df.columns.get_loc("open")] = 2600.0
    df.iloc[8, df.columns.get_loc("low")] = 2590.0
    df.iloc[8, df.columns.get_loc("close")] = 2610.0
    sig = pd.DataFrame([{"side": "BUY", "sl": 2630.0, "tp": 2690.0,
                         "lot": 0.1, "score": 0.6}], index=[idx[5]])
    bt = Backtester(BacktestConfig(), symbol)
    res = bt.run(df, sig)
    assert res.trades[0].exit_reason == "SL"
    assert res.trades[0].exit_price <= 2600.0, "gap fill must be at the worse open, not the stop"


def test_spread_points_converted_to_price(symbol):
    # v1.5 (Mission 19): MT5 dataset spread is in POINTS — with point=0.01
    # a spread column of 40 must model a 0.40 PRICE spread, not $40.
    n = 40
    idx = pd.date_range("2026-01-05", periods=n, freq="5min", tz="UTC")
    df = pd.DataFrame({
        "open": np.full(n, 2650.0), "high": np.full(n, 2652.0),
        "low": np.full(n, 2648.0), "close": np.full(n, 2650.0),
        "tick_volume": np.ones(n), "real_volume": np.zeros(n),
        "spread": np.full(n, 40.0)}, index=idx)  # points!
    sig = pd.DataFrame([{"side": "BUY", "sl": 2630.0, "tp": 2700.0,
                         "lot": 1.0, "score": 0.6}], index=[idx[5]])
    bt_price = Backtester(BacktestConfig(), symbol, spread_units="POINTS",
                          commission_per_lot=0.0, slippage_points=0.0)
    res = bt_price.run(df, sig)
    assert "POINTS" in bt_price.spread_source
    # entry = open + spread/2 + 0 = 2650 + 0.20
    assert res.trades[0].entry_price == pytest.approx(2650.20)
    bt_naive = Backtester(BacktestConfig(), symbol, spread_units="PRICE",
                          commission_per_lot=0.0, slippage_points=0.0)
    res_naive = bt_naive.run(df, sig)
    # naive interpretation would add $20 to the entry — clearly wrong
    assert res_naive.trades[0].entry_price == pytest.approx(2670.0)


def test_metrics_math():
    pnl = np.array([100.0, -50.0, 80.0, -30.0, 20.0])
    assert m.win_rate(pnl) == pytest.approx(60.0)
    assert m.profit_factor(pnl) == pytest.approx(200.0 / 80.0)
    assert m.expectancy(pnl) == pytest.approx(24.0)
    eq = pd.Series([100, 110, 90, 120, 100], dtype=float)
    assert m.max_drawdown(eq) == pytest.approx(-18.18, abs=0.05)
    assert m.max_drawdown(pd.Series([100, 120])) == 0.0


def test_equity_curve_and_summary(symbol):
    df = _mk_df(n=150, drift=0.6)
    sig = pd.DataFrame([{"side": "BUY", "sl": 2650.0, "tp": 2680.0,
                         "lot": 0.1, "score": 0.6}], index=[df.index[5]])
    bt = Backtester(BacktestConfig(), symbol)
    res = bt.run(df, sig)
    assert res.equity_curve is not None and len(res.equity_curve) > 0
    assert "profit_factor" in res.summary and "sharpe" in res.summary
    assert res.summary["n_trades"] == len(res.trades)

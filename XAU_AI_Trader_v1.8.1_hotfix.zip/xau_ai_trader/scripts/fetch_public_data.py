#!/usr/bin/env python3
"""PHASE 65 (§2/§31) — Real public gold data fetcher (for non-Windows hosts).

Fetches REAL gold market data from public sources and stores it in exactly the
same format as the MT5 downloader:

    data/raw/<SYMBOL>_<TF>.parquet + <SYMBOL>_<TF>.meta.json

Sources (clearly labelled in metadata — never presented as broker XAUUSD):
- yahoo_finance : GC=F  (CME COMEX Gold Futures front month — REAL prices,
                  ~23h/day trading, real traded volume)
- stooq         : XAUUSD spot daily (when reachable)

Yahoo intraday limits: 1m=7d, 5m/15m=60d, 1h=730d. Volume for futures is the
real exchanged contract volume. Broker spread is NOT public →
spread_available=false and backtests must use the documented assumed_spread.

Usage:
    python scripts/fetch_public_data.py --timeframes M15 H1 D1 [--out data/raw]
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd

from app.config.schema import Timeframe
from app.data.dataset_meta import DatasetMetadata, enrich_with_range, save_metadata

SYMBOL = "GC"          # dataset prefix; instrument described in metadata
YAHOO_SYMBOL = "GC=F"
YAHOO_MAX = {"M1": "7d", "M5": "60d", "M15": "60d", "M30": "60d",
             "H1": "730d", "H4": "730d", "D1": "max"}


def fetch_yahoo(interval: str, period: str) -> pd.DataFrame:
    import yfinance as yf

    df = yf.Ticker(YAHOO_SYMBOL).history(period=period, interval=interval, auto_adjust=False)
    if df is None or df.empty:
        raise RuntimeError(f"yahoo returned no data for {YAHOO_SYMBOL} {interval} {period}")
    df = df.tz_convert("UTC")
    out = pd.DataFrame(index=pd.DatetimeIndex(df.index, name="time"))
    out["open"] = df["Open"].astype(float)
    out["high"] = df["High"].astype(float)
    out["low"] = df["Low"].astype(float)
    out["close"] = df["Close"].astype(float)
    out["tick_volume"] = 0.0                       # not published for CME via yahoo
    out["real_volume"] = df["Volume"].fillna(0.0).astype(float)
    out["spread"] = 0.0                            # not public → assumed_spread downstream
    out = out[~out.index.duplicated(keep="first")].sort_index()
    out = out.dropna(subset=["open", "high", "low", "close"])
    return out


def sanity_check(df: pd.DataFrame, tf_minutes: int) -> list[str]:
    """Basic real-data sanity: OHLC logic + no Sunday-early bars for futures."""
    problems: list[str] = []
    bad = ((df.high < df[["open", "close"]].max(axis=1)) |
           (df.low > df[["open", "close"]].min(axis=1))).sum()
    if bad:
        problems.append(f"{bad} OHLC violations")
    if (df[["open", "high", "low", "close"]] <= 0).any().any():
        problems.append("non-positive prices")
    sun = df[df.index.dayofweek == 6]
    if len(sun) and (sun.index.hour < 22).any():
        problems.append("bars before Sunday 22:00 UTC (impossible for CME)")
    return problems


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeframes", nargs="+", default=["M15", "H1", "D1"])
    parser.add_argument("--out", default="data/raw")
    args = parser.parse_args()

    try:
        import yfinance  # noqa: F401
    except ImportError:
        print("ERROR: pip install yfinance first")
        return 2

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    failures: list[str] = []

    for tf in args.timeframes:
        interval = {"M1": "1m", "M5": "5m", "M15": "15m", "M30": "30m",
                    "H1": "1h", "H4": "1h", "D1": "1d"}[tf]
        period = YAHOO_MAX.get(tf, "60d")
        try:
            df = fetch_yahoo(interval, period)
        except Exception as e:
            print(f"[fetch] {tf}: FAILED — {e}")
            failures.append(f"{tf}: {e}")
            continue
        # resample 1h → 4h for H4
        if tf == "H4":
            df = df.resample("4h", label="left", closed="left").agg(
                {"open": "first", "high": "max", "low": "min", "close": "last",
                 "tick_volume": "sum", "real_volume": "sum", "spread": "mean"}
            ).dropna()
        problems = sanity_check(df, Timeframe(tf).minutes)
        # documented cleaning: OHLC-violating vendor rows are dropped and the
        # count recorded in metadata (transparent cleaning, never silent fixing)
        bad_mask = ((df.high < df[["open", "close"]].max(axis=1)) |
                    (df.low > df[["open", "close"]].min(axis=1)))
        n_bad = int(bad_mask.sum())
        if n_bad:
            df = df[~bad_mask]
            problems.append(f"dropped {n_bad} vendor OHLC-violating rows (recorded)")
        f = out_dir / f"{SYMBOL}_{tf}.parquet"
        df.to_parquet(f)
        meta = DatasetMetadata(
            symbol=SYMBOL, timeframe=tf, source="yahoo_finance", data_kind="real",
            instrument="COMEX Gold Futures front month (GC=F) — REAL market data, "
                       "NOT broker XAUUSD spot",
            broker=None, timezone="UTC",
            download_date=datetime.now(timezone.utc).isoformat(),
            spread_available=False, volume_kind="contract",
            columns=list(df.columns),
            notes="Fetched from public Yahoo Finance. Intraday history is limited "
                  "(15m/5m=60d, 1h=730d). Spread not public → use assumed_spread. "
                  f"sanity: {problems or 'clean'}",
            extra={"yahoo_symbol": YAHOO_SYMBOL, "yahoo_interval": interval,
                   "sanity_problems": problems},
        )
        enrich_with_range(meta, df.index)
        save_metadata(meta, f)
        print(f"[fetch] {tf}: {len(df)} REAL bars ({meta.start} → {meta.end}) -> {f}"
              + (f"  SANITY: {problems}" if problems else ""))

    (out_dir / "fetch_public_data_result.json").write_text(
        json.dumps({"ok": not failures, "failures": failures,
                    "generated_at": datetime.now(timezone.utc).isoformat()},
                   indent=2), encoding="utf-8")
    return 1 if failures and all(t in failures[0] for t in args.timeframes) else 0


if __name__ == "__main__":
    raise SystemExit(main())

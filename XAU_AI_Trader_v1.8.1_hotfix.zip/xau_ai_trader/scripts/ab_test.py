#!/usr/bin/env python3
"""PHASE 65 (§15) — A/B test: ML ONLY / ML+SMC / ML+SMC+REGIME / +AI.

All four variants are evaluated on the SAME real-data TEST segment with the
SAME risk/cost model. The AI variant only calls the real API on gated setups
(ML setup + SMC confirm + risk pre-pass, §17) and is capped.

If AI does not improve performance, the report says so honestly (§15).

Usage: python scripts/ab_test.py [--config config_real.yaml] [--with-ai]
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config
from app.config.schema import Regime
from app.core.logging import setup_logging

logging.getLogger("httpx").setLevel(logging.WARNING)


def classify_regime(features: pd.DataFrame, i: int, cfg) -> Regime:
    adx = features["adx"].iloc[i]
    if adx >= cfg.regime.adx_trend_min:
        return Regime.TRENDING_BULL if features["di_diff"].iloc[i] > 0 else Regime.TRENDING_BEAR
    if features["atr_pct"].iloc[i] >= cfg.regime.high_vol_atr_pct:
        return Regime.HIGH_VOLATILITY
    if features["atr_pct"].iloc[i] <= cfg.regime.low_vol_atr_pct:
        return Regime.LOW_VOLATILITY
    return Regime.RANGING


async def run(cfg, with_ai: bool, zai_config: str | None) -> dict:
    import os

    from app.ai.gate import should_call_ai
    from app.ai.testing import build_state_at_time
    from app.backtest.engine import Backtester
    from app.config.schema import AIConfig, AIProviderSettings, NewsRisk, SymbolInfoDefaults
    from app.data.market.models import SymbolInfo
    from app.data.market.replay import ReplayProvider
    from app.data.multi_tf import MultiTimeframeEngine
    from app.models.train_service import (build_xy, clean_feature_frame,
                                          load_bundle, make_feature_builder,
                                          temporal_split)
    from app.news.engine import NewsAssessment
    from app.risk.sizing import calc_lot
    from app.signals.ensemble import SignalEnsemble
    from app.smc.engine import SMCEngine

    rd = cfg.real_data
    symbol = rd.symbol
    provider = ReplayProvider.from_raw_dir(rd.raw_dir, symbol, rd.timeframes)
    provider.connect()
    info = SymbolInfo(name=symbol,
                      **cfg.symbol.fallback_symbol_info.model_dump())

    mtf = MultiTimeframeEngine(provider, cfg.timeframes, cfg.quality)
    md = mtf.fetch(symbol)
    if md.worst_score() < cfg.quality.min_score:
        return {"status": "ABORTED", "reason": "data quality below threshold"}

    fb = make_feature_builder(cfg)
    features, labels, close, fversion = build_xy(cfg, md.frames, fb)
    dataset = clean_feature_frame(features, labels)
    X = dataset.drop(columns=["label"])
    y_raw = dataset["label"]

    bundle = load_bundle(cfg, registry_tag="real")
    probs_all = bundle.average_proba(X)
    train_idx, val_idx, test_idx = temporal_split(len(dataset), cfg)
    test_ts = dataset.index[test_idx]

    base = md.frames[cfg.timeframes.base.value]
    smc_engine = fb.smc_engine or SMCEngine(cfg.smc)
    smc_bias = smc_engine.analyze(base, cfg.timeframes.base.value) \
        .directional_bias_series(cfg.features.event_recent_bars)
    news = NewsAssessment(risk=NewsRisk.LOW, reasons=["NEWS_NEUTRAL_AB_ASSUMPTION"])
    atr = features["atr"].reindex(dataset.index)
    close_s = close.reindex(dataset.index)

    bt_start = base.index[base.index.get_indexer([test_ts[0]], method="nearest")[0] - 100]

    def make_run_bt():
        def _run(sig):
            b = Backtester(cfg.backtest, info,
                           commission_per_lot=cfg.execution.commission_per_lot,
                           swap_long=cfg.execution.swap_long_per_lot,
                           swap_short=cfg.execution.swap_short_per_lot,
                           slippage_points=cfg.execution.slippage_points,
                           assumed_spread=cfg.backtest.assumed_spread)
            return b.run(base[base.index >= bt_start], sig)
        return _run

    run_bt = make_run_bt()

    def build_signals(weights: tuple, mlc: float, marg: float, msc: float,
                      smc_margin: float | None = None,
                      veto_regimes: bool = False) -> pd.DataFrame:
        ens_cfg = cfg.ensemble.model_copy(update={
            "ml": weights[0], "smc": weights[1], "ai": weights[2],
            "min_ml_confidence": mlc, "ml_conflict_margin": marg, "min_score": msc,
            "smc_conflict_margin": smc_margin if smc_margin is not None
            else cfg.ensemble.smc_conflict_margin})
        ens = SignalEnsemble(ens_cfg)
        idx, rows = [], []
        for ts in test_ts[::5]:
            i = dataset.index.get_loc(ts)
            p = probs_all[i]
            pos = base.index.get_indexer([ts], method="nearest")[0]
            regime = classify_regime(features, pos, cfg)
            if veto_regimes and regime in (Regime.HIGH_VOLATILITY, Regime.UNCERTAIN):
                continue
            d = ens.decide(ml_probs={"ens": np.array([p[0], p[1], p[2]])},
                           smc_bias=float(smc_bias.iloc[pos]) if pos < len(smc_bias) else 0.0,
                           regime=regime, news_risk=news.risk)
            if not d.is_actionable:
                continue
            a = atr.iloc[i]
            if np.isnan(a) or a <= 0:
                continue
            entry = float(close_s.iloc[i])
            sgn = 1.0 if d.side == "BUY" else -1.0
            sl = entry - sgn * cfg.risk.atr_sl_mult * float(a)
            dist = abs(entry - sl)
            if dist <= 0:
                continue
            lot = calc_lot(cfg.backtest.initial_balance, cfg.risk.risk_percent,
                           dist, info)
            if lot <= 0:
                continue
            idx.append(ts)
            rows.append({"side": d.side, "sl": float(sl),
                         "tp": float(entry + sgn * cfg.risk.min_rr * dist),
                         "lot": lot, "score": d.score})
        return pd.DataFrame(rows, index=pd.DatetimeIndex(idx))

    RELAX = (0.40, 0.08, 0.40)   # same relaxed gate as the sensitivity grid
    variants: dict[str, dict] = {}

    # v1 — ML ONLY (SMC hard gate effectively disabled, no SMC weight)
    sig = build_signals((1.0, 0.0, 0.0), *RELAX, smc_margin=10.0, veto_regimes=False)
    variants["ML_ONLY"] = {"n_signals": len(sig), "summary": run_bt(sig).summary}

    # v2 — ML + SMC
    sig = build_signals((0.70, 0.30, 0.0), *RELAX, smc_margin=None, veto_regimes=False)
    variants["ML_SMC"] = {"n_signals": len(sig), "summary": run_bt(sig).summary}

    # v3 — ML + SMC + REGIME veto
    sig = build_signals((0.70, 0.30, 0.0), *RELAX, smc_margin=None, veto_regimes=True)
    variants["ML_SMC_REGIME"] = {"n_signals": len(sig), "summary": run_bt(sig).summary}

    # v4 — + AI (gated, real API, capped) -----------------------------------
    ai_meta = {"status": "NOT_RUN", "reason": "--with-ai not passed"}
    if with_ai:
        from app.ai.bootstrap import load_zai_credentials_into_env
        cred = load_zai_credentials_into_env(zai_config)
        if cred or os.environ.get("ZAI_API_KEY"):
            base_url = os.environ.get("ZAI_BASE_URL", "https://api.z.ai/api/paas/v4")
            ai_cfg = AIConfig(enabled=True, require_ai_for_trade=False,
                              cache_ttl_seconds=86400,
                              providers=[AIProviderSettings(
                                  name="zai", api_key_env="ZAI_API_KEY",
                                  base_url=base_url,
                                  model=os.environ.get("ZAI_MODEL", "glm-4.6"),
                                  timeout_seconds=45.0, max_requests_per_day=100000,
                                  extra_headers_env="ZAI_EXTRA_HEADERS")],
                              failover_order=["zai"])
            from app.ai.gateway import AIGateway

            gateway = AIGateway(ai_cfg)
            ens_cfg = cfg.ensemble.model_copy(update={
                "ml": 0.45, "smc": 0.25, "ai": 0.30,
                "min_ml_confidence": RELAX[0], "ml_conflict_margin": RELAX[1],
                "min_score": RELAX[2]})
            ens = SignalEnsemble(ens_cfg)
            idx, rows = [], []
            ai_calls = ai_veto = ai_agree = 0
            cap = cfg.backtest.ai_max_calls_per_run
            for ts in test_ts[::5]:
                i = dataset.index.get_loc(ts)
                p = probs_all[i]
                pos = base.index.get_indexer([ts], method="nearest")[0]
                regime = classify_regime(features, pos, cfg)
                if regime in (Regime.HIGH_VOLATILITY, Regime.UNCERTAIN):
                    continue
                bias = float(smc_bias.iloc[pos]) if pos < len(smc_bias) else 0.0
                d0 = ens.decide(ml_probs={"ens": np.array([p[0], p[1], p[2]])},
                                smc_bias=bias, regime=regime, news_risk=news.risk)
                if not d0.is_actionable:
                    continue
                a = atr.iloc[i]
                if np.isnan(a) or a <= 0:
                    continue
                ml_side = "BUY" if p[2] >= p[0] else "SELL"
                gate = should_call_ai(
                    ml_actionable=True, ml_side=ml_side, smc_bias=bias,
                    smc_conflict_margin=cfg.ensemble.smc_conflict_margin,
                    quality_ok=True,
                    spread_ok=cfg.backtest.assumed_spread <= cfg.risk.max_spread_points
                    * float(info.point) * 100,
                    daily_loss_ok=True,
                    min_smc_alignment=cfg.backtest.ai_min_smc_alignment)
                if not gate.allowed:
                    continue
                if ai_calls >= cap:
                    ai_meta.update(reason=f"cap {cap} reached — AI calls stopped")
                    continue
                st = build_state_at_time(cfg, provider, bundle, ts, mtf=mtf, feature_builder=fb)
                if st is None:
                    continue
                try:
                    res = await gateway.analyze(st, [])
                except Exception:
                    await asyncio.sleep(2.0)
                    continue
                if res.degraded:
                    ai_calls += 1
                    await asyncio.sleep(2.0)
                    continue
                ai_calls += 1
                o = res.output
                if o.decision == "WAIT" or (o.decision != d0.side):
                    ai_veto += 1
                    continue
                ai_agree += 1
                entry = float(close_s.iloc[i])
                sgn = 1.0 if d0.side == "BUY" else -1.0
                sl = entry - sgn * cfg.risk.atr_sl_mult * float(a)
                dist = abs(entry - sl)
                lot = calc_lot(cfg.backtest.initial_balance, cfg.risk.risk_percent, dist, info)
                if lot <= 0:
                    continue
                idx.append(ts)
                rows.append({"side": d0.side, "sl": float(sl),
                             "tp": float(entry + sgn * cfg.risk.min_rr * dist),
                             "lot": lot, "score": d0.score})
                await asyncio.sleep(2.0)   # rate-limit pacing
            sig = pd.DataFrame(rows, index=pd.DatetimeIndex(idx))
            variants["ML_SMC_REGIME_AI"] = {"n_signals": len(sig),
                                            "summary": run_bt(sig).summary}
            await gateway.aclose()
            ai_meta = {"status": "OK", "ai_calls": ai_calls, "ai_vetoes": ai_veto,
                       "ai_agreements": ai_agree,
                       "endpoint_host": base_url.split("//")[-1].split("/")[0]}
        else:
            ai_meta = {"status": "NOT_RUN", "reason": "no AI credentials"}

    # honest comparison
    comparison = {}
    base_v = variants["ML_SMC_REGIME"]["summary"]
    for name, v in variants.items():
        s = v["summary"]
        comparison[name] = {
            "trades": s.get("n_trades"), "win_rate_pct": s.get("win_rate_pct"),
            "profit_factor": None if s.get("profit_factor") == float("inf")
            else s.get("profit_factor"),
            "expectancy": s.get("expectancy"), "max_dd_pct": s.get("max_drawdown_pct"),
            "sharpe": s.get("sharpe"), "sortino": s.get("sortino"),
            "net_pl": s.get("net_pl"),
        }
    ai_vs_base = None
    if "ML_SMC_REGIME_AI" in variants and variants["ML_SMC_REGIME_AI"]["summary"].get("n_trades"):
        s_ai = variants["ML_SMC_REGIME_AI"]["summary"]
        s_b = base_v
        ai_vs_base = {
            "delta_pf": (s_ai.get("profit_factor") or 0) - (s_b.get("profit_factor") or 0),
            "delta_expectancy": s_ai.get("expectancy", 0) - s_b.get("expectancy", 0),
            "delta_dd_pct": s_ai.get("max_drawdown_pct", 0) - s_b.get("max_drawdown_pct", 0),
        }

    return {
        "phase": "65 §15 — AI AB test",
        "generated": datetime.now(timezone.utc).isoformat(),
        "segment": "REAL-data TEST segment (strict temporal split, OOS)",
        "relaxed_gate": {"min_ml_confidence": RELAX[0], "ml_conflict_margin": RELAX[1],
                         "min_score": RELAX[2],
                         "note": "relaxed gates for evaluation only — primary config "
                                 "produced 0 trades (WAIT-first behaviour)"},
        "variants": comparison,
        "ai": ai_meta,
        "ai_vs_base": ai_vs_base,
        "disclaimer": "AI did NOT set lot/SL/TP/risk anywhere (§13). AI only "
                      "VALIDATE/CLASSIFY per §13. Results are real-data backtest "
                      "outputs, not profit claims.",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    parser.add_argument("--with-ai", action="store_true")
    parser.add_argument("--zai-config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)
    t0 = time.perf_counter()
    report = asyncio.run(run(cfg, args.with_ai, args.zai_config))
    out = Path(cfg.paths.reports_dir) / "ab_test_report.json"
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    print(f"[ab_test] → {out} ({time.perf_counter() - t0:.0f}s)")
    for name, m in report.get("variants", {}).items():
        print(f"  {name:>18}: trades={m['trades']} PF={m['profit_factor']} "
              f"wr={m['win_rate_pct']} DD={m['max_dd_pct']} sharpe={m['sharpe']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

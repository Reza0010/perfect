#!/usr/bin/env python3
"""v1.4 (§5 Downloader v2) — MT5 historical data downloader + provenance.

Production rewrite of the phase65/67 downloader (the fixed2 ZIP shipped a
broken loop: ``rates = out.to_parquet(f)`` executed before ``out``/``f``
existed — NameError on the first timeframe, every time).

Design contract (MASTER_UPGRADE_PROMPT §5/§7/§8, audited §2):

  * Windows + MetaTrader5 package + running terminal required. Any other
    platform exits with an actionable error and NEVER fabricates data.
  * ``mt5.symbol_select(symbol, True)`` — the official selection API.
  * History via chunked ``copy_rates_range`` with adaptive per-TF chunk
    sizes, one-bar overlap between chunks, timestamp deduplication and
    deterministic sort. Stop condition is the TARGET START timestamp (not
    a fixed iteration count); the oldest returned timestamp decides.
  * Canonical storage = TRUE UTC. MT5 returns bar times in the BROKER
    SERVER's wall clock; converting to UTC requires the server UTC offset.
    ``--server-utc-offset-hours`` must be provided (or auto-detected with
    ``--detect-server-offset`` via terminal clock comparison). The offset
    actually applied is recorded in the manifest under ``time_semantics``.
  * Atomic writes (temp file + os.replace). Existing files are NEVER
    silently overwritten — pass ``--overwrite`` explicitly (the old file
    is archived under data/raw/archive/ first).
  * Central immutable manifest: data/raw/broker_manifest.json with full
    symbol provenance, per-TF ranges and SHA-256 of every written file.
    Account login is REDACTED by default (spec §56).

Usage (Windows):
    python scripts/download_mt5_data.py --symbol XAUUSD.ecn \
        --timeframes M1 M5 M15 H1 D1 --bars-per-tf 20000 \
        --server-utc-offset-hours 2
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

TF_MINUTES = {"M1": 1, "M5": 5, "M15": 15, "M30": 30, "H1": 60, "H4": 240, "D1": 1440}

# v1.4 §5: adaptive chunk sizing (bars per chunk request). M1 needs small
# chunks (terminal history sync), D1 large ones. Configurable via --chunk-bars.
DEFAULT_CHUNK_BARS = {"M1": 2000, "M5": 4000, "M15": 4000, "M30": 6000,
                      "H1": 8000, "H4": 8000, "D1": 10000}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def exit_unsupported() -> int:
    print("ERROR: MetaTrader5 downloads require Windows + a running MT5 terminal.")
    print(f"       current platform: {platform.system()}")
    print("       On Linux use scripts/fetch_public_data.py for real public gold")
    print("       data (source-labelled), or place broker CSV/parquet exports in")
    print("       data/raw/ with a .meta.json sidecar (see app/data/dataset_meta.py).")
    return 2


def detect_server_utc_offset(mt5, symbol: str) -> float:
    """Estimate the broker-server UTC offset from a FRESH server quote.

    MT5 ``symbol_info_tick().time`` is the server wall clock of the last
    quote (epoch rendered in server-local terms). Offset = quote_time −
    local UTC now, rounded to 15 minutes. A stale quote (weekend / market
    closed) is REFUSED — detection must never guess from old data.
    """
    tick = mt5.symbol_info_tick(symbol)
    if tick is None or not getattr(tick, "time", 0):
        raise RuntimeError(f"symbol_info_tick({symbol!r}) unavailable: "
                           f"{mt5.last_error()} — cannot detect offset")
    now_s = datetime.now(timezone.utc).timestamp()
    diff_s = float(tick.time) - now_s
    # A live quote's server wall clock sits within ±15h of UTC now (all real
    # timezone offsets). Anything beyond that band is stale (market closed)
    # — detection must never guess from old data.
    if abs(diff_s) > 15 * 3600:
        age = diff_s / 3600.0
        raise RuntimeError(
            f"last quote is {age:+.1f}h off UTC now (stale/market closed?) — "
            "offset detection refused; pass --server-utc-offset-hours explicitly")
    # round to nearest quarter hour (some brokers use half-hour zones)
    return round(diff_s / 900.0) * 900.0 / 3600.0


def _atomic_write_parquet(df, path: Path, overwrite: bool, archive_dir: Path) -> bool:
    """Atomic + non-destructive write. Returns False when refusing."""
    if path.exists():
        if not overwrite:
            print(f"[mt5] REFUSING to overwrite existing {path} (use --overwrite)")
            return False
        archive_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        dest = archive_dir / f"{path.stem}_{stamp}{path.suffix}"
        shutil.move(str(path), str(dest))
        print(f"[mt5] archived previous file -> {dest}")
    tmp = path.with_suffix(path.suffix + ".tmp")
    df.to_parquet(tmp)
    os.replace(tmp, path)
    return True


def _write_json_atomic(path: Path, payload: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _chunked_history(mt5, symbol: str, tf: str, tf_code: int,
                     bars: int, chunk_bars: int,
                     server_offset_hours: float) -> list:
    """Download ``bars`` newest candles via ranged, overlapped chunks.

    Rationale (spec §5): single huge copy_rates_* calls silently truncate at
    the terminal's 'Max bars in chart'. Chunked ranged requests + dedupe are
    the reliable path. Stop condition = requested start timestamp reached,
    the walk-back passes the requested start (history exhausted), or no
    progress — never a fixed iteration count without verification.
    """
    minutes = TF_MINUTES[tf]
    chunk_span = timedelta(minutes=minutes * chunk_bars)
    overlap_span = timedelta(minutes=minutes)
    now_utc = datetime.now(timezone.utc)
    # server wall clock = UTC + offset; MT5 wants ranges in server terms
    to_server = now_utc + timedelta(hours=server_offset_hours)
    cursor_server = to_server
    oldest_target_server = to_server - timedelta(minutes=minutes * bars)
    rows: list = []
    seen_times: set[int] = set()
    max_rounds = max(2, (bars // max(chunk_bars, 1)) + 10)  # hard safety bound

    for _ in range(max_rounds):
        if cursor_server <= oldest_target_server:
            break  # walked back past the requested start — nothing more
        chunk_from = cursor_server - chunk_span - overlap_span
        rates = mt5.copy_rates_range(symbol, tf_code, chunk_from, cursor_server)
        if rates is None or len(rates) == 0:
            # gap in broker history (e.g. history starts long after the
            # target) — keep stepping back until target is passed (honest
            # emptiness is decided by the broker, never fabricated here)
            cursor_server = chunk_from
            continue
        fresh = [r for r in rates if int(r["time"]) not in seen_times]
        for r in fresh:
            seen_times.add(int(r["time"]))
        rows.extend(fresh)
        # oldest bar of this chunk, raw server-wall terms (MT5 epochs render
        # server wall clock); both comparison sides are tz-aware — never mix
        # naive and aware datetimes here.
        raw_oldest = datetime.fromtimestamp(int(rates[0]["time"]), tz=timezone.utc)
        if raw_oldest <= oldest_target_server:
            break  # requested start reached
        if raw_oldest.timestamp() >= cursor_server.timestamp():
            break  # no progress (safety)
        cursor_server = chunk_from + overlap_span
        time.sleep(0.15)
    rows.sort(key=lambda r: int(r["time"]))
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--symbol", default="XAUUSD.ecn")
    parser.add_argument("--timeframes", nargs="+",
                        default=["M1", "M5", "M15", "H1", "D1"],
                        choices=list(TF_MINUTES))
    parser.add_argument("--bars-per-tf", type=int, default=20000)
    parser.add_argument("--chunk-bars", type=int, default=None,
                        help="override adaptive chunk size (per TF)")
    parser.add_argument("--raw-dir", default="data/raw")
    parser.add_argument("--server-utc-offset-hours", type=float, default=None,
                        help="broker server wall clock = UTC + this offset. "
                             "REQUIRED for true-UTC storage; use "
                             "--detect-server-offset to infer it.")
    parser.add_argument("--detect-server-offset", action="store_true",
                        help="infer the server offset from the terminal clock "
                             "and use it (recorded in the manifest)")
    parser.add_argument("--overwrite", action="store_true",
                        help="allow replacing existing parquet files "
                             "(previous version is archived first)")
    args = parser.parse_args()

    if platform.system() != "Windows":
        return exit_unsupported()

    try:
        import MetaTrader5 as mt5
    except Exception as e:
        print(f"ERROR: MetaTrader5 package unavailable: {e}")
        return 2

    # ---- server offset resolution (v1.4 §6, see module docstring) --------
    if args.detect_server_offset:
        kwargs0 = {}
        try:
            if os.environ.get("MT5_LOGIN") and os.environ.get("MT5_SERVER"):
                kwargs0 = {"login": int(os.environ["MT5_LOGIN"]),
                           "password": os.environ.get("MT5_PASSWORD", ""),
                           "server": os.environ["MT5_SERVER"]}
            if not mt5.initialize(**kwargs0):
                print(f"ERROR: MT5 initialize failed: {mt5.last_error()}")
                return 2
            if not mt5.symbol_select(args.symbol, True):
                print(f"ERROR: symbol_select({args.symbol!r}) failed: "
                      f"{mt5.last_error()}")
                return 2
            inferred = detect_server_utc_offset(mt5, args.symbol)
            mt5.shutdown()
            print(f"[mt5] detected server UTC offset: {inferred:+g} h")
            if args.server_utc_offset_hours is None:
                args.server_utc_offset_hours = inferred
            elif abs(inferred - args.server_utc_offset_hours) > 0.26:
                print(f"ERROR: detected offset {inferred:+g} h contradicts "
                      f"--server-utc-offset-hours {args.server_utc_offset_hours:+g} h. "
                      "Refusing to mislabel time (no silent shift).")
                return 2
        except Exception as e:
            print(f"ERROR: server-offset detection failed: {e}")
            return 2
    if args.server_utc_offset_hours is None:
        print("ERROR: --server-utc-offset-hours is required (or use "
              "--detect-server-offset). MT5 bar times are SERVER wall clock; "
              "without the offset the data cannot be stored as true UTC.")
        return 2

    login = os.environ.get("MT5_LOGIN")
    password = os.environ.get("MT5_PASSWORD")
    server = os.environ.get("MT5_SERVER")
    kwargs = {}
    if login and password and server:
        kwargs = {"login": int(login), "password": password, "server": server}
    if not mt5.initialize(**kwargs):
        print(f"ERROR: MT5 initialize failed: {mt5.last_error()}")
        return 2

    try:
        if not mt5.symbol_select(args.symbol, True):
            raise RuntimeError(f"symbol_select({args.symbol!r}) failed: "
                               f"{mt5.last_error()}")
        info = mt5.symbol_info(args.symbol)
        if info is None:
            aliases = [s.name for s in (mt5.symbols_get() or [])
                       if "XAU" in s.name.upper() or "GOLD" in s.name.upper()]
            print(f"ERROR: symbol {args.symbol!r} not found. "
                  f"Gold-like symbols: {aliases}")
            return 2

        raw_dir = Path(args.raw_dir)
        raw_dir.mkdir(parents=True, exist_ok=True)
        archive_dir = raw_dir / "archive"

        acc = mt5.account_info()
        term = mt5.terminal_info()
        trade_modes = {0: "DEMO", 1: "CONTEST", 2: "LIVE"}
        margin_modes = {0: "RETAIL_NETTING", 1: "EXCHANGE", 2: "HEDGING"}

        manifest = {
            "schema_version": "2",
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "download_timestamp": datetime.now(timezone.utc).isoformat(),
            "symbol": info.name,
            "description": getattr(info, "description", ""),
            "path": getattr(info, "path", ""),
            "digits": info.digits,
            "point": info.point,
            "tick_size": info.trade_tick_size,
            "tick_value": info.trade_tick_value,
            "tick_value_profit": getattr(info, "trade_tick_value_profit", None),
            "tick_value_loss": getattr(info, "trade_tick_value_loss", None),
            "contract_size": info.trade_contract_size,
            "volume_min": info.volume_min,
            "volume_max": info.volume_max,
            "volume_step": info.volume_step,
            "volume_limit": getattr(info, "volume_limit", None),
            "stops_level_points": int(getattr(info, "trade_stops_level", 0)),
            "freeze_level_points": int(getattr(info, "trade_freeze_level", 0)),
            "spread_points_current": info.spread,
            "spread_float": bool(getattr(info, "spread_float", False)),
            "currency_base": getattr(info, "currency_base", None),
            "currency_profit": info.currency_profit,
            "currency_margin": getattr(info, "currency_margin", None),
            "swap_long_per_lot": info.swap_long,
            "swap_short_per_lot": info.swap_short,
            "swap_rollover_3days": int(getattr(info, "swap_rollover3days", -1)),
            # filling_mode = broker bitmask (SYMBOL_FILLING_FOK=1|IOC=2);
            # both keys carry the same int for contract compatibility
            "filling_mode": int(getattr(info, "filling_mode", 0)),
            "filling_mode_bitmask": int(getattr(info, "filling_mode", 0)),
            "order_mode": int(getattr(info, "order_mode", 0)),
            "expiration_mode": int(getattr(info, "order_gtc_mode", 0)),
            "symbol_trade_mode": int(getattr(info, "trade_mode", 0)),
            "trade_exec_mode": int(getattr(info, "trade_exemode", -1)),
            "margin_initial": getattr(info, "margin_initial", 0.0),
            "margin_maintenance": getattr(info, "margin_maintenance", 0.0),
            "broker_company": (acc.company if acc else None),
            "broker_server": server or (acc.server if acc else "terminal_default"),
            "account_trade_mode": (trade_modes.get(int(acc.trade_mode),
                                                   str(acc.trade_mode)) if acc else None),
            "account_login": "REDACTED",  # spec §56 — never ship identifiers
            "account_currency": (acc.currency if acc else None),
            "account_leverage": (acc.leverage if acc else None),
            "margin_mode": (margin_modes.get(int(acc.margin_mode),
                                             str(acc.margin_mode)) if acc else None),
            "mt5_build": (term.build if term else None),
            "terminal_connected": (bool(term.connected) if term else None),
            "time_semantics": {
                "raw_source": "MT5 bar times are broker SERVER wall clock",
                "storage": "true UTC",
                "server_utc_offset_hours_applied": args.server_utc_offset_hours,
                "detection": "auto" if args.detect_server_offset else "manual",
            },
            "requested_bars_per_tf": args.bars_per_tf,
            "timeframes": list(args.timeframes),
            "datasets": {},
            "file_sha256": {},
            "immutable_note": "parquet files must never be edited after "
                              "download; sha256 detects any modification",
        }
        manifest_path = raw_dir / "broker_manifest.json"

        import pandas as pd
        from app.data.dataset_meta import (DatasetMetadata, enrich_with_range,
                                           save_metadata)

        tf_code = {"M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5,
                   "M15": mt5.TIMEFRAME_M15, "M30": mt5.TIMEFRAME_M30,
                   "H1": mt5.TIMEFRAME_H1, "H4": mt5.TIMEFRAME_H4,
                   "D1": mt5.TIMEFRAME_D1}

        failures: list[str] = []
        for tf in args.timeframes:
            chunk_bars = args.chunk_bars or DEFAULT_CHUNK_BARS[tf]
            rates = _chunked_history(mt5, info.name, tf, tf_code[tf],
                                     args.bars_per_tf, chunk_bars,
                                     args.server_utc_offset_hours)
            if not rates:
                failures.append(f"{tf}: no history returned "
                                f"(last_error={mt5.last_error()})")
                continue
            df = pd.DataFrame(rates)
            idx = pd.to_datetime(df["time"], unit="s", utc=True) \
                - pd.Timedelta(hours=args.server_utc_offset_hours)
            df.index = pd.DatetimeIndex(idx, name="time")
            df["real_volume"] = df.get("real_volume", pd.Series(0.0, index=df.index))
            out = df[["open", "high", "low", "close", "tick_volume",
                      "real_volume", "spread"]].astype(float)
            before = len(out)
            out = out[~out.index.duplicated()].sort_index()
            deduped = before - len(out)
            f = raw_dir / f"{info.name}_{tf}.parquet"
            if not _atomic_write_parquet(out, f, args.overwrite, archive_dir):
                failures.append(f"{tf}: refused overwrite of {f.name}")
                continue
            manifest["file_sha256"][f.name] = _sha256(f)
            manifest["datasets"][tf] = {
                "bar_count": int(len(out)),
                "duplicates_removed": int(deduped),
                "start_utc": str(out.index[0]),
                "end_utc": str(out.index[-1]),
                "complete": bool(len(out) >= args.bars_per_tf),
            }
            _write_json_atomic(manifest_path, manifest)
            meta = DatasetMetadata(
                symbol=info.name, timeframe=tf, source="mt5_broker",
                data_kind="real",
                instrument=f"{info.name} ({getattr(info, 'description', '')})",
                broker=manifest["broker_server"], timezone="UTC",
                download_date=datetime.now(timezone.utc).isoformat(),
                spread_available=True, volume_kind="tick",
                columns=list(out.columns), extra=manifest,
            )
            enrich_with_range(meta, out.index)
            save_metadata(meta, f)
            trunc = "" if manifest["datasets"][tf]["complete"] else \
                "  [TRUNCATED — terminal history limit reached]"
            print(f"[mt5] {tf}: {len(out)} bars ({out.index[0]} → {out.index[-1]}, "
                  f"dedup {deduped}) -> {f}{trunc}")

        if failures:
            print("[mt5] COMPLETED WITH FAILURES (honest report):")
            for msg in failures:
                print(f"  - {msg}")
            return 1
        print(f"[mt5] manifest -> {manifest_path}")
        return 0
    finally:
        mt5.shutdown()


if __name__ == "__main__":
    raise SystemExit(main())

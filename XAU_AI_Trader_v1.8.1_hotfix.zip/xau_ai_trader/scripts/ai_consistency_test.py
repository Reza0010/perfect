#!/usr/bin/env python3
"""PHASE 65 (§14) — AI consistency test on ≥100 REAL market states.

For each real state the gateway is called with a real API. Recorded:
- invalid JSON / schema violations (gateway degraded results)
- decision vs ML-side agreement
- confidence distribution
- hallucinated numbers (numeric tokens in reasoning not present in the state)
- BUY/SELL contradiction across repeated identical states (stability, 10 pairs)

Writes reports/ai_consistency_test.json. No credentials → NOT RUN (honest).

Usage: python scripts/ai_consistency_test.py [--states 100] [--repeats 10]
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config
from app.core.logging import setup_logging

_NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")


def _hallucination_ratio(state: dict, reasoning: str) -> float:
    """Share of numeric tokens in reasoning NOT found in the state JSON."""
    if not reasoning:
        return 0.0
    state_str = json.dumps(state, default=str)
    nums = _NUM_RE.findall(reasoning)
    if not nums:
        return 0.0
    missing = sum(1 for nstr in nums
                  if nstr not in state_str and nstr.rstrip("0").rstrip(".") not in state_str)
    return missing / len(nums)


async def _call_with_retry(gateway, st, attempts: int = 3, backoff_s: float = 6.0):
    """Call the gateway, retrying rate-limits with backoff (429 handling)."""
    last = None
    for a in range(attempts):
        try:
            res = await gateway.analyze(st, [])
            if res.degraded and any("429" in e or "RATE" in e.upper() for e in res.errors):
                last = res
            else:
                return res
        except Exception as e:
            last = e
        await asyncio.sleep(backoff_s * (a + 1))
    if isinstance(last, Exception):
        raise last
    return last


async def run(cfg, n_states: int, n_repeats: int, zai_config: str | None) -> dict:
    import os

    from app.ai.bootstrap import load_zai_credentials_into_env
    from app.ai.gateway import AIGateway
    from app.ai.testing import (build_state_at_time, ml_side_from_state,
                                sample_state_timestamps)
    from app.config.schema import AIConfig, AIProviderSettings
    from app.data.market.models import SymbolInfo
    from app.data.market.replay import ReplayProvider
    from app.models.train_service import load_bundle

    cred = load_zai_credentials_into_env(zai_config)
    if not cred and not os.environ.get("ZAI_API_KEY"):
        return {"status": "NOT_RUN",
                "reason": "no AI credentials (ZAI_API_KEY) — nothing faked (§14/§31)"}

    provider = ReplayProvider.from_raw_dir(
        cfg.real_data.raw_dir, cfg.real_data.symbol, cfg.real_data.timeframes)
    provider.connect()
    bundle = load_bundle(cfg, registry_tag="real")

    t0 = time.perf_counter()
    ts_list = sample_state_timestamps(provider, cfg, n_states)
    states: list[dict] = []
    for ts in ts_list:
        st = build_state_at_time(cfg, provider, bundle, ts)
        if st:
            states.append(st)
    build_s = time.perf_counter() - t0
    print(f"  built {len(states)} real pipeline states in {build_s:.0f}s")

    base_url = os.environ.get("ZAI_BASE_URL", "https://api.z.ai/api/paas/v4")
    ai_cfg = AIConfig(enabled=True, require_ai_for_trade=False, cache_ttl_seconds=0,
                      providers=[AIProviderSettings(
                          name="zai", api_key_env="ZAI_API_KEY", base_url=base_url,
                          model=os.environ.get("ZAI_MODEL", "glm-4.6"),
                          timeout_seconds=45.0, max_requests_per_day=100000,
                          extra_headers_env="ZAI_EXTRA_HEADERS")],
                      failover_order=["zai"])
    gateway = AIGateway(ai_cfg)

    records = []
    invalid_json = schema_invalid = 0
    agreements, confidences, halluc = [], [], []
    pace_s = float(os.environ.get("AI_TEST_PACE_S", "2.5"))

    # ---- checkpoint/resume support (PHASE 65: long runs survive timeouts) ----
    out_path = Path(cfg.paths.reports_dir) / "ai_consistency_test.json"
    if out_path.exists():
        try:
            prev = json.loads(out_path.read_text(encoding="utf-8"))
            if prev.get("status") == "PARTIAL" and prev.get("records"):
                records = [r for r in prev["records"] if not r.get("degraded") and not r.get("error")]
                for r in records:
                    if r.get("agrees_ml") is not None:
                        agreements.append(r["agrees_ml"])
                    if "confidence" in r:
                        confidences.append(r["confidence"])
                    if "hallucination_ratio" in r:
                        halluc.append(r["hallucination_ratio"])
                print(f"  resumed: {len(records)} records already collected")
        except Exception:
            records = []

    start_i = records[-1]["i"] + 1 if records else 0
    t_calls = time.perf_counter()
    k = start_i
    while k < len(states):
        st = states[k]
        try:
            res = await _call_with_retry(gateway, st)
        except Exception as e:
            records.append({"i": k, "error": str(e)[:100]})
            invalid_json += 1
            k += 1
            await asyncio.sleep(pace_s)
            continue
        if res.degraded:
            schema_invalid += 1
            records.append({"i": k, "degraded": True, "errors": res.errors[:2]})
            k += 1
            await asyncio.sleep(pace_s)
            continue
        o = res.output
        ml_side = ml_side_from_state(bundle, st)
        agree = (o.decision == ml_side) if ml_side in ("BUY", "SELL") else None
        if agree is not None:
            agreements.append(agree)
        confidences.append(float(o.confidence))
        text_evidence = " ".join(o.reason_codes) + " " + (o.invalidation or "")
        h = _hallucination_ratio(st, text_evidence)
        halluc.append(h)
        records.append({"i": k, "decision": o.decision, "confidence": round(float(o.confidence), 3),
                        "ml_side": ml_side, "agrees_ml": agree,
                        "hallucination_ratio": round(h, 3)})
        if (k + 1) % 10 == 0:
            elapsed = time.perf_counter() - t_calls
            print(f"  {k+1}/{len(states)} states (+{elapsed:.0f}s this run)")
            # incremental checkpoint so interrupted runs resume (PHASE 65)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(json.dumps({
                "status": "PARTIAL", "collected": len(records),
                "records": records}, indent=2, default=str), encoding="utf-8")
        k += 1
        await asyncio.sleep(pace_s)
    call_s = time.perf_counter() - t_calls

    # ---- stability: repeat identical states through a fresh no-cache gateway --
    repeats = []
    contradictions = 0
    if n_repeats and states:
        for k in np.linspace(0, len(states) - 1, n_repeats).astype(int):
            st = states[int(k)]
            outs = []
            for _ in range(2):
                try:
                    r = await _call_with_retry(gateway, st, attempts=2)
                    outs.append(None if r.degraded else r.output)
                except Exception:
                    outs.append(None)
                await asyncio.sleep(2.2)
            if outs[0] is None or outs[1] is None:
                repeats.append({"i": int(k), "stable": None})
                continue
            same_side = outs[0].decision == outs[1].decision
            if outs[0].decision in ("BUY", "SELL") and outs[1].decision in ("BUY", "SELL") \
                    and outs[0].decision != outs[1].decision:
                contradictions += 1
            repeats.append({"i": int(k), "stable": same_side,
                            "conf_delta": round(abs(float(outs[0].confidence) -
                                                    float(outs[1].confidence)), 3)})
    await gateway.aclose()

    n = len(states)
    stable = [r["stable"] for r in repeats if r["stable"] is not None]
    elapsed_total = round(time.perf_counter() - t0, 1)
    result = {
        "status": "OK",
        "n_states": n,
        "state_build_seconds": round(build_s, 1),
        "call_seconds": round(call_s, 1),
        "invalid_json_or_errors": invalid_json,
        "schema_invalid": schema_invalid,
        "valid_rate": round(1 - (invalid_json + schema_invalid) / max(1, n), 3),
        "agreement_with_ml": round(float(np.mean(agreements)), 3) if agreements else None,
        "n_comparable_ml": len(agreements),
        "confidence_mean": round(float(np.mean(confidences)), 3) if confidences else None,
        "confidence_std": round(float(np.std(confidences)), 3) if confidences else None,
        "hallucination_ratio_mean": round(float(np.mean(halluc)), 3) if halluc else None,
        "hallucination_ratio_p95": round(float(np.percentile(halluc, 95)), 3) if halluc else None,
        "repeat_stability": {
            "pairs": len(stable),
            "same_side_rate": round(float(np.mean(stable)), 3) if stable else None,
            "buy_sell_contradictions": contradictions,
            "detail": repeats,
        },
        "note": "REAL API calls on REAL market states built from the gold dataset. "
                "News neutral assumption disclosed. AI cannot set lot/SL/TP/risk — "
                "output schema enforces ANALYZE-only (§13).",
        "records": records,
    }
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    parser.add_argument("--states", type=int, default=100)
    parser.add_argument("--repeats", type=int, default=10)
    parser.add_argument("--zai-config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)
    logging.getLogger("httpx").setLevel(logging.WARNING)

    report = asyncio.run(run(cfg, args.states, args.repeats, args.zai_config))
    out = Path(cfg.paths.reports_dir) / "ai_consistency_test.json"
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    print(f"[ai_consistency] status={report.get('status')} → {out}")
    if report.get("status") == "OK":
        print(f"  valid_rate={report['valid_rate']}  ml_agreement={report['agreement_with_ml']}  "
              f"conf_std={report['confidence_std']}  halluc_mean={report['hallucination_ratio_mean']}  "
              f"contradictions={report['repeat_stability']['buy_sell_contradictions']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""RELEASE_MANIFEST.json generator with REAL hashes and REAL test counts.

v1.8 fix: the old script HARDCODED ``tests_total: 229 / tests_passed: 229``
while the actual suite was 269+ tests (and 2 were failing on a clean
checkout). Numbers published in the release manifest must be MEASURED —
this version parses a pytest JUnit XML (``--junitxml``) when provided and
otherwise reports NOT_RUN instead of inventing a green suite.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # project root
sys.path.insert(0, str(ROOT))


def parse_junit(path: Path) -> dict:
    """pytest --junitxml → honest counts (no fabricated greens)."""
    try:
        root = ET.parse(path).getroot()
        suite = root if root.tag == "testsuite" else root.find("testsuite")
        if suite is None:
            return {"status": "NOT_RUN", "reason": f"no testsuite in {path}"}
        total = int(suite.get("tests", 0))
        failures = int(suite.get("failures", 0)) + int(suite.get("errors", 0))
        skipped = int(suite.get("skipped", 0))
        return {"status": "RUN",
                "tests_total": total,
                "tests_passed": total - failures - skipped,
                "tests_failed": failures,
                "tests_skipped": skipped,
                "source": str(path)}
    except FileNotFoundError:
        return {"status": "NOT_RUN", "reason": "no junit xml provided (--junit PATH)"}
    except Exception as e:
        return {"status": "NOT_RUN", "reason": f"{type(e).__name__}: {e}"}


def sha256_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def sha256_dir(p: Path) -> str:
    h = hashlib.sha256()
    for f in sorted(p.rglob("*")):
        if f.is_file() and "registry.json" not in f.name:
            h.update(str(f.relative_to(p)).encode())
            h.update(f.read_bytes())
    return h.hexdigest()


def git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except Exception:
        return "unknown"


def main() -> int:
    import argparse
    import platform

    parser = argparse.ArgumentParser()
    parser.add_argument("--junit", default=None,
                        help="pytest --junitxml output for REAL test counts "
                             "(omitted → validation_summary.status=NOT_RUN)")
    args = parser.parse_args()
    junit = parse_junit(Path(args.junit)) if args.junit else \
        {"status": "NOT_RUN", "reason": "generator invoked without --junit"}

    reg = json.loads((ROOT / "models" / "registry" / "registry.json").read_text())
    model_hashes = {}
    for mid, entry in reg.items():
        p = Path(entry.get("path", ""))
        if p.exists():
            model_hashes[mid] = {
                "version": entry.get("version"),
                "path": str(p),
                "sha256": sha256_dir(p),
                "feature_version": entry.get("feature_version", ""),
                "provenance_complete": bool(entry.get("extra", {}).get("config_hash")),
            }

    dataset_hashes = {}
    raw = ROOT / "data" / "raw"
    if raw.exists():
        for f in sorted(raw.glob("*.parquet")):
            meta_f = f.with_suffix("").with_suffix(".meta.json") \
                if False else f.parent / f"{f.stem}.meta.json"
            meta = {}
            if meta_f.exists():
                meta = json.loads(meta_f.read_text())
            dataset_hashes[f.name] = {
                "sha256": sha256_file(f),
                "spread_units": meta.get("spread_units", "UNDECLARED"),
                "bar_count": meta.get("bar_count"),
            }

    cfg_hash = hashlib.sha256((ROOT / "config.yaml").read_bytes()).hexdigest()[:16]
    feature_hash = reg.get("lgbm_main", {}).get("feature_version", "")

    # v1.8: readiness verdicts of the deployed families come from the SAME
    # gate the runtime uses — never a hardcoded "looks good".
    from app.models.registry import ModelRegistry

    readiness = {}
    for mid, entry in reg.items():
        r = ModelRegistry.deployment_readiness(entry)
        readiness[mid] = {"ready": r["ready"],
                          "warnings": [w.split(":")[0] for w in r["warnings"]],
                          "data_source": (r["data_source"] or {}).get("kind", "")}

    manifest = {
        "release_version": "1.8.1-forensic-audit-hotfix",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "git_commit": git_commit(),
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
        "config_hash": cfg_hash,
        "feature_hash": feature_hash,
        "label_hash": feature_hash,  # v1.5: label spec is hashed INTO feature_version
        "label_contract": {
            "anchoring": "executable fill at t+1 open ± spread/2 ± slippage (PRICE units)",
            "tail_policy": "NaN + excluded (never merged into NO_EDGE)",
            "costs_included": ["spread_price", "slippage_price", "commission_price (optional)"],
        },
        "dataset_hashes": dataset_hashes,
        "model_hashes": model_hashes,
        "model_deployment_readiness": readiness,
        "validation_summary": {
            **junit,
            "walkforward_min_folds_required": 3,
            "walkforward_purge_bars": 64,
            "walkforward_embargo_bars": 64,
            "data_kind": ("SIMULATED (no real-edge claim; broker data "
                          "re-download required)"),
        },
        "notes": [
            "v1.8 forensic audit: honest data-source labelling everywhere, TIME-based closed-bar logic,",
            "symmetric long/short labels, model readiness gate, fail-closed leakage audit, simulator↔engine equivalence.",
            "Per MISSION 29/53: NO 'production ready' or 'profitable' claim is made. Simulated-data results are NOT broker evidence.",
            "Live trading remains hard-refused in main.py; demo execution only via scripts/mt5_demo_execution_test.py.",
        ],
    }
    out = ROOT / "RELEASE_MANIFEST.json"
    out.write_text(json.dumps(manifest, indent=2, default=str))
    print(f"written {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

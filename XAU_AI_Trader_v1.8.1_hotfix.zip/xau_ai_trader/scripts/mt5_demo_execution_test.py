#!/usr/bin/env python3
"""PHASE 66 (§20) v1.4 — MT5 DEMO EXECUTION TEST — 15-step pre-live checklist.

Windows + MT5 terminal + DEMO account required. The script REFUSES to run
unless the account is DEMO (trade_mode == 0); there is NO override to trade a
live account, and LIVE_TRADING_ENABLED stays false throughout — this script
verifies execution plumbing on demo only, then closes everything safely.

v1.4 contract (MASTER_UPGRADE_PROMPT §24 + §20/§21):
  * mt5.symbol_select(symbol, True) — official API (no symbols_select).
  * request built from broker reality: filling mode from the symbol's
    filling-mode bitmask, deviation spread-aware, stops respect
    trade_stops_level, prices respect tick size.
  * mt5.order_check() gates every order before order_send().
  * results classified via the central retcode policy (no raw 10009s).
  * order_send happens ONLY when BOTH the config flag demo_send_enabled
    AND the explicit CLI --send flag are set (plus account verified DEMO).
    Without --send the run is a SAFE DRY RUN: everything through order_check.
  * account login is REDACTED in the written report.

Steps:
   1  MT5 connection                  9   order request construction
   2  account identification          10  order_check validation
   3  demo account detection          11  order placement (gated) / DRY RUN
   4  symbol availability             12  position reconciliation
   5  symbol specification            13  SL/TP verification
   6  current bid/ask                 14  journal consistency
   7  spread                          15  safe order closure
   8  volume rules

On non-Windows hosts: writes an honest NOT_RUN report and exits 0.

Usage (Windows):
    python scripts/mt5_demo_execution_test.py --symbol XAUUSD.ecn          # dry run
    python scripts/mt5_demo_execution_test.py --symbol XAUUSD.ecn --send   # real demo order
"""

from __future__ import annotations

import argparse
import json
import platform
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.execution import mt5_retcodes as rc  # noqa: E402

MAGIC = 20260101


def _redact(login) -> str:
    s = str(login or "")
    return "REDACTED" if not s else s[:2] + "***" + s[-2:] if len(s) > 6 else "REDACTED"


def _not_run_report(out: Path, symbol: str) -> None:
    report = {
        "status": "NOT_RUN",
        "reason": f"requires Windows + MT5 terminal + DEMO account "
                  f"(platform={platform.system()}). The 15-step checklist is "
                  "implemented below and runs unmodified on Windows. Nothing faked.",
        "checklist_15": [
            "mt5_connection", "account_identification", "demo_account_detection",
            "symbol_availability", "symbol_specification", "current_bid_ask",
            "spread", "volume_rules", "order_request_construction",
            "order_check_validation", "order_placement", "position_reconciliation",
            "sl_tp_verification", "journal_consistency", "safe_order_closure"],
        "live_trading": "LIVE_TRADING_ENABLED=false — refuses non-demo accounts",
        "generated": datetime.now(timezone.utc).isoformat(),
    }
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("[demo_test] NOT_RUN — Windows/MT5 required (honest status, nothing faked)")


def _fails(out: Path, results: dict, step: str, detail: dict) -> int:
    results[step] = {"passed": False, **detail}
    out.write_text(json.dumps({"status": "FAILURES_PRESENT",
                               "steps": results}, indent=2),
                   encoding="utf-8")
    return 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", default="XAUUSD.ecn")
    parser.add_argument("--out", default="reports/demo_execution_test.json")
    parser.add_argument("--volume", type=float, default=0.01)
    parser.add_argument("--send", action="store_true",
                        help="REQUIRED (together with config demo_send_enabled) "
                             "to actually place the demo order. Without it the "
                             "run is a safe dry run through order_check.")
    args = parser.parse_args()

    out = Path(args.out)
    if platform.system() != "Windows":
        _not_run_report(out, args.symbol)
        return 0

    import os

    try:
        import MetaTrader5 as mt5
    except Exception as e:
        print(f"ERROR: MetaTrader5 unavailable: {e}")
        return 2

    results: dict[str, dict] = {}

    # 1 — connection
    kwargs: dict = {}
    if os.environ.get("MT5_LOGIN") and os.environ.get("MT5_PASSWORD"):
        kwargs = {"login": int(os.environ["MT5_LOGIN"]),
                  "password": os.environ["MT5_PASSWORD"],
                  "server": os.environ.get("MT5_SERVER", "")}
    if not mt5.initialize(**kwargs):
        print(f"ERROR: MT5 initialize failed: {mt5.last_error()}")
        return 2
    results["mt5_connection"] = {"passed": True, "detail": f"build {mt5.version()}"}

    # 2 — account identification (login redacted in report)
    acc = mt5.account_info()
    if acc is None:
        print("ERROR: account_info() returned None")
        mt5.shutdown()
        return 2
    results["account_identification"] = {
        "passed": True, "login": _redact(acc.login), "server": acc.server,
        "currency": acc.currency, "leverage": acc.leverage}

    # 3 — demo detection + hard refusal on live (no override exists)
    if acc.trade_mode != 0:
        results["demo_account_detection"] = {
            "passed": False, "trade_mode": acc.trade_mode,
            "action": "REFUSED — DEMO ONLY; live accounts are never touched"}
        out.write_text(json.dumps({"status": "REFUSED_NOT_DEMO",
                                   "steps": results}, indent=2), encoding="utf-8")
        mt5.shutdown()
        return 2
    results["demo_account_detection"] = {"passed": True, "trade_mode": 0}

    # 4 — symbol availability (official selection API)
    if not mt5.symbol_select(args.symbol, True):
        return _fails(out, results, "symbol_availability",
                      {"detail": f"symbol_select({args.symbol!r}) failed: "
                                 f"{mt5.last_error()}"})
    info = mt5.symbol_info(args.symbol)
    if info is None:
        return _fails(out, results, "symbol_availability",
                      {"detail": f"{args.symbol} not visible in Market Watch"})
    results["symbol_availability"] = {"passed": True, "symbol": info.name}

    # 5 — symbol specification (captured verbatim, never normalised)
    point, digit = info.point, info.digits
    tick_size = info.trade_tick_size or point
    results["symbol_specification"] = {
        "passed": True, "digits": digit, "point": point,
        "tick_size": tick_size, "tick_value": info.trade_tick_value,
        "contract_size": info.trade_contract_size,
        "stops_level_points": info.trade_stops_level,
        "freeze_level_points": info.trade_freeze_level,
        "filling_mode_bitmask": int(getattr(info, "filling_mode", 0)),
        "swap_long": info.swap_long, "swap_short": info.swap_short}

    # 6/7 — bid/ask + spread
    tick = mt5.symbol_info_tick(args.symbol)
    spread_points = (tick.ask - tick.bid) / point if tick else None
    results["current_bid_ask"] = {"passed": bool(tick and tick.bid > 0 and tick.ask > 0),
                                  "bid": tick.bid if tick else None,
                                  "ask": tick.ask if tick else None}
    results["spread"] = {"passed": bool(spread_points and spread_points < 100),
                         "spread_points": spread_points}
    if not tick:
        return _fails(out, results, "current_bid_ask", {"detail": "no tick"})

    # 8 — volume rules
    vol = max(info.volume_min, min(args.volume, info.volume_max))
    vol = round(round(vol / info.volume_step) * info.volume_step, 8)
    results["volume_rules"] = {
        "passed": True, "requested": args.volume, "normalised": vol,
        "min": info.volume_min, "max": info.volume_max, "step": info.volume_step}

    # 9 — order request construction from BROKER reality (v1.4 §19)
    filling = rc.choose_filling_mode(int(getattr(info, "filling_mode", 0)))
    deviation = max(10, int(2 * (spread_points or 0)))
    stops_dist = max(info.trade_stops_level + 10, 50) * point
    req = {"action": rc.TRADE_ACTION_DEAL, "symbol": info.name, "volume": vol,
           "type": rc.ORDER_TYPE_BUY, "price": tick.ask,
           "sl": round(tick.ask - stops_dist, digit),
           "tp": round(tick.ask + 2 * stops_dist, digit),
           "deviation": deviation, "magic": MAGIC, "comment": "p66-demo",
           "type_time": 0, "type_filling": filling}
    stops_ok = (req["sl"] < tick.ask < req["tp"] and
                abs(tick.ask - req["sl"]) / point > info.trade_stops_level and
                abs(req["tp"] - tick.ask) / point > info.trade_stops_level)
    results["order_request_construction"] = {
        "passed": bool(stops_ok and vol >= info.volume_min),
        "request": dict(req),
        "respects_stops_level": stops_ok,
        "filling_chosen_from_bitmask": filling}

    # 10 — order_check validation (v1.4 §20 — always runs, sends nothing)
    check = mt5.order_check(req)
    check_policy = rc.classify(getattr(check, "retcode", None)) if check else None
    results["order_check_validation"] = {
        "passed": check_policy in (rc.RetcodePolicy.SUCCESS,
                                   rc.RetcodePolicy.SUCCESS_PARTIAL),
        "retcode": getattr(check, "retcode", None),
        "name": rc.describe(getattr(check, "retcode", None)),
        "comment": (getattr(check, "comment", "") or "")[:120],
    }
    if not results["order_check_validation"]["passed"]:
        out.write_text(json.dumps({"status": "FAILURES_PRESENT",
                                   "steps": results}, indent=2), encoding="utf-8")
        mt5.shutdown()
        return 1

    # 11 — placement: double gate (config demo_send_enabled AND --send flag)
    # Note: the config flag is read via env-convention demo_send_enabled=1 for
    # the standalone script; the runtime app enforces the yaml flag itself.
    send_allowed = args.send and os.environ.get("MT5_DEMO_SEND", "0") == "1"
    if not send_allowed:
        results["order_placement"] = {
            "passed": True, "action": "DRY_RUN — order_check passed; no order sent",
            "hint": "set --send AND MT5_DEMO_SEND=1 to place the demo order"}
        results["position_reconciliation"] = {"passed": True, "note": "dry run"}
        results["sl_tp_verification"] = {"passed": True, "note": "dry run"}
        results["journal_consistency"] = {"passed": True, "note": "dry run"}
        results["safe_order_closure"] = {"passed": True, "note": "nothing to close"}
        report = {"status": "DRY_RUN_OK", "mode": "DEMO ONLY — LIVE_TRADING_ENABLED=false (§20)",
                  "symbol": info.name, "steps": results,
                  "generated": datetime.now(timezone.utc).isoformat()}
        out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
        print(f"[demo_test] DRY_RUN_OK → {out} (order_check passed, nothing sent)")
        mt5.shutdown()
        return 0

    r = mt5.order_send(req)
    r_policy = rc.classify(getattr(r, "retcode", None)) if r else rc.classify(None)
    if r is None:
        # AMBIGUOUS — outcome unknown; NEVER auto-retry (duplicate risk)
        return _fails(out, results, "order_placement",
                      {"retcode": None, "policy": "AMBIGUOUS",
                       "comment": f"order_send returned None: {mt5.last_error()} — "
                                  "reconcile before any retry"})
    if r_policy is rc.RetcodePolicy.RETRYABLE:
        return _fails(out, results, "order_placement",
                      {"retcode": int(r.retcode), "policy": r_policy.value,
                       "comment": rc.describe(r.retcode) + " — refresh & rerun"})
    if r_policy is not rc.RetcodePolicy.SUCCESS:
        return _fails(out, results, "order_placement",
                      {"retcode": int(r.retcode), "policy": r_policy.value,
                       "comment": rc.describe(r.retcode)})
    ticket = r.order
    results["order_placement"] = {"passed": True, "ticket": ticket,
                                  "price": r.price,
                                  "retcode": rc.describe(r.retcode)}
    time.sleep(1.0)
    poses = mt5.positions_get(ticket=ticket)
    results["order_confirmation"] = {
        "passed": bool(poses), "position_found": bool(poses),
        "volume": poses[0].volume if poses else None,
        "open_price": poses[0].price_open if poses else None}

    # 12 — position reconciliation (internal request vs broker state)
    rec_ok = bool(poses) and abs(poses[0].volume - vol) < 1e-8 and \
        poses[0].symbol == info.name
    results["position_reconciliation"] = {
        "passed": rec_ok,
        "detail": "request vs broker position match" if rec_ok else "MISMATCH — HALT policy"}

    # 13 — SL/TP verification on the live position
    sl_tp_ok = bool(poses) and \
        abs(poses[0].sl - req["sl"]) < 10 * point and \
        abs(poses[0].tp - req["tp"]) < 10 * point
    results["sl_tp_verification"] = {"passed": sl_tp_ok,
                                     "sl": poses[0].sl if poses else None,
                                     "tp": poses[0].tp if poses else None}

    # 14 — journal consistency: every broker deal with our magic exists in journal
    try:
        from app.journal.journal import Journal

        j = Journal(Path("logs") / "journal.db")
        deals = mt5.history_deals_get(datetime.now(timezone.utc) - timedelta(days=1),
                                      datetime.now(timezone.utc) + timedelta(days=1))
        mt5_tickets = {d.order for d in deals or [] if d.magic == MAGIC}
        j_tickets = ({t["ticket"] for t in j.open_trades()} |
                     {t["ticket"] for t in j.recent_trades(limit=1000)})
        j.close()
        missing = mt5_tickets - j_tickets
        results["journal_consistency"] = {
            "passed": not missing,
            "magic_deals": len(mt5_tickets),
            "missing_in_journal": sorted(missing)[:5],
            "policy": "any mismatch → CRITICAL → trading disabled (§21)"}
    except Exception as e:
        results["journal_consistency"] = {"passed": False, "error": str(e)[:120]}

    # 15 — safe closure
    if poses:
        p = poses[0]
        t2 = mt5.symbol_info_tick(info.name)
        close_req = {"action": rc.TRADE_ACTION_DEAL, "symbol": p.symbol,
                     "volume": p.volume,
                     "type": rc.ORDER_TYPE_SELL if p.type == 0 else rc.ORDER_TYPE_BUY,
                     "position": ticket,
                     "price": t2.bid if p.type == 0 else t2.ask,
                     "deviation": deviation, "magic": MAGIC,
                     "comment": "p66-close", "type_time": 0,
                     "type_filling": filling}
        r2 = mt5.order_send(close_req)
        closed = r2 is not None and rc.classify(r2.retcode) in (
            rc.RetcodePolicy.SUCCESS, rc.RetcodePolicy.SUCCESS_PARTIAL)
        results["safe_order_closure"] = {
            "passed": closed, "ticket": ticket,
            "closed_price": getattr(r2, "price", None),
            "retcode": rc.describe(getattr(r2, "retcode", None))}
    else:
        results["safe_order_closure"] = {"passed": True, "note": "nothing to close"}

    mt5.shutdown()

    all_ok = all(v.get("passed") for v in results.values())
    report = {
        "status": "OK" if all_ok else "FAILURES_PRESENT",
        "mode": "DEMO ONLY — LIVE_TRADING_ENABLED=false (§20)",
        "symbol": info.name,
        "steps": results,
        "generated": datetime.now(timezone.utc).isoformat(),
    }
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    print(f"[demo_test] → {out} (all_ok={all_ok})")
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""PHASE 67 (§1) — MT5 environment verification.

Verifies, on the CURRENT host, every item the directive requires before any
broker-data work:

    Windows / Python version / MT5 package / MT5 terminal / terminal build /
    broker / server / account / demo-live status / terminal connection

Writes reports/MT5_ENVIRONMENT.md (+ reports/mt5_environment.json).

If MT5 is unavailable the report records the §1 STOP decision for the
broker-data portion. NOTHING is simulated and GC=F is NEVER renamed XAUUSD.
"""

from __future__ import annotations

import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

OUT_MD = Path("reports/MT5_ENVIRONMENT.md")
OUT_JSON = Path("reports/mt5_environment.json")


def main() -> int:
    is_windows = platform.system() == "Windows"
    checks: dict[str, dict] = {}

    checks["windows"] = {
        "required": "Windows",
        "observed": platform.platform(),
        "status": "OK" if is_windows else "UNAVAILABLE",
    }
    checks["python"] = {
        "required": "3.10+",
        "observed": sys.version.split()[0],
        "status": "OK",
    }
    try:
        import MetaTrader5 as mt5  # type: ignore

        checks["mt5_package"] = {"required": "installed", "observed": "installed",
                                 "status": "OK"}
    except Exception as e:  # ImportError or dll load failure
        checks["mt5_package"] = {
            "required": "installed",
            "observed": f"NOT INSTALLED ({e.__class__.__name__})",
            "status": "UNAVAILABLE",
        }
        mt5 = None

    terminal_ok = False
    if mt5 is not None and is_windows:
        try:
            terminal_ok = bool(mt5.initialize())
            if terminal_ok:
                build = mt5.version()
                checks["mt5_terminal"] = {"required": "running terminal",
                                          "observed": f"connected (build {build[2]})",
                                          "status": "OK"}
                checks["terminal_build"] = {"required": "recorded",
                                            "observed": str(build), "status": "OK"}
                acc = mt5.account_info()
                if acc is not None:
                    checks["broker"] = {"required": "recorded", "observed": acc.server,
                                        "status": "OK"}
                    checks["server"] = {"required": "recorded", "observed": acc.server,
                                        "status": "OK"}
                    checks["account"] = {"required": "recorded",
                                         "observed": str(acc.login), "status": "OK"}
                    checks["demo_live_status"] = {
                        "required": "DEMO for any execution test",
                        "observed": f"trade_mode={acc.trade_mode}",
                        "status": "OK"}
                checks["terminal_connection"] = {
                    "required": "connected to broker",
                    "observed": str(mt5.terminal_info().connected)
                    if mt5.terminal_info() else "unknown", "status": "OK"}
                mt5.shutdown()
        except Exception as e:
            checks["mt5_terminal"] = {"required": "running terminal",
                                      "observed": f"connection failed: {e}",
                                      "status": "UNAVAILABLE"}
    if "mt5_terminal" not in checks:
        checks["mt5_terminal"] = {
            "required": "running terminal",
            "observed": "NOT CHECKABLE — MetaTrader5 package/Windows absent",
            "status": "UNAVAILABLE"}
    for k in ("terminal_build", "broker", "server", "account", "demo_live_status",
              "terminal_connection"):
        if k not in checks:
            checks[k] = {"required": "recorded", "observed": "UNAVAILABLE — "
                         "requires Windows + MT5 package + running terminal",
                         "status": "UNAVAILABLE"}

    mt5_available = all(c["status"] == "OK" for k, c in checks.items()
                        if k not in ("python",))
    decision = ("PROCEED" if mt5_available else
                "STOP — broker-data portion (§3–§20) cannot run on this host. "
                "No broker data will be simulated; GC=F is never renamed XAUUSD. "
                "Linux-executable work (null-model audit, bootstrap, cost "
                "sensitivity, AI rate limiting, tooling, tests) proceeds.")

    now = datetime.now(timezone.utc).isoformat()
    lines = [
        "# PHASE 67 §1 — MT5 ENVIRONMENT REPORT", "",
        f"Generated (UTC): {now}", "",
        "## Environment checklist", "",
        "| Item | Required | Observed | Status |",
        "|---|---|---|---|",
    ]
    for k, c in checks.items():
        obs = str(c["observed"]).replace("|", "/")
        lines.append(f"| {k} | {c['required']} | {obs} | {c['status']} |")
    lines += ["", "## §1 Decision", "", decision, "",
              "## Consequences", ""]
    if not mt5_available:
        lines += [
            "- §3 broker XAUUSD download: **NOT COMPLETED** (no MT5 terminal here)",
            "- §4 broker data quality: **BROKER_DATA_PENDING** — tooling ready "
            "(`scripts/broker_data_quality.py`), will run unchanged on Windows",
            "- §5 broker vs GC=F: **PENDING** — tooling ready "
            "(`scripts/compare_gcf_xauusd.py`)",
            "- §6/§7/§8 broker feature rebuild / training / walk-forward: "
            "**NOT RUN** — no broker dataset exists on this host",
            "- §17 paper replay on broker data / §18 demo execution / "
            "§19 reconciliation / §20 realtime paper: **NOT RUN**",
            "- §9/§10/§11 statistical work executed on the REAL GC=F proxy is "
            "clearly labelled GC=F everywhere and is **never** presented as "
            "broker XAUUSD evidence", "",
            "Every broker-dependent conclusion in PHASE 67 is therefore",
            "`NOT_VALIDATED` / `INSUFFICIENT_DATA` until the Windows MT5 run",
            "described in `NEXT_ACTION` is executed.", "",
        ]
    lines.append("## Reproduce")
    lines += ["", "```", "python scripts/phase67_environment_check.py", "```", ""]

    OUT_MD.parent.mkdir(exist_ok=True)
    OUT_MD.write_text("\n".join(lines), encoding="utf-8")
    OUT_JSON.write_text(json.dumps(
        {"generated": now, "checks": checks, "decision": decision,
         "mt5_available": mt5_available}, indent=2), encoding="utf-8")
    print(f"[env] wrote {OUT_MD} and {OUT_JSON}")
    print(f"[env] decision: {decision}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

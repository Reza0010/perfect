#!/usr/bin/env python3
"""PHASE 66 (§4) — GC=F vs BROKER XAUUSD comparison report.

Compares overlapping periods between the available REAL GC=F dataset and a
REAL broker XAUUSD dataset (produced on Windows/MT5), measuring:

  OHLC correlation · return correlation · volatility correlation ·
  ATR correlation · session behaviour · timestamp differences ·
  price basis difference · spread/execution differences

Without broker data the report states PENDING explicitly and documents the
methodology — the two instruments are NOT assumed interchangeable (GC=F is
COMEX futures with its own basis, session calendar and spread profile).

Output: reports/GC_F_vs_BROKER_XAUUSD.md
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config


def _hourly_vol(close: pd.Series, minutes: int = 60) -> pd.Series:
    ret = close.pct_change()
    return ret.rolling(window=max(2, minutes // 1)).std().resample("1h").last()


def compare_frames(gcf: pd.DataFrame, xau: pd.DataFrame) -> dict:
    common = gcf.index.intersection(xau.index)
    if len(common) < 50:
        return {"overlap_bars": int(len(common)), "sufficient": False}
    a = gcf.loc[common]
    b = xau.loc[common]
    res: dict = {"overlap_bars": int(len(common)),
                 "overlap_start": str(common[0]), "overlap_end": str(common[-1]),
                 "sufficient": True}
    for col in ("open", "high", "low", "close"):
        res[f"ohlc_corr_{col}"] = round(float(a[col].corr(b[col])), 4)
    ra = a["close"].pct_change().dropna()
    rb = b["close"].pct_change().dropna()
    idx = ra.index.intersection(rb.index)
    res["return_corr"] = round(float(ra.loc[idx].corr(rb.loc[idx])), 4)
    va = ra.rolling(20).std().dropna()
    vb = rb.rolling(20).std().dropna()
    vi = va.index.intersection(vb.index)
    res["volatility_corr"] = round(float(va.loc[vi].corr(vb.loc[vi])), 4)
    from app.indicators.ta import atr

    aa = atr(a["high"], a["low"], a["close"], 14).dropna()
    ab = atr(b["high"], b["low"], b["close"], 14).dropna()
    ai = aa.index.intersection(ab.index)
    res["atr_corr"] = round(float(aa.loc[ai].corr(ab.loc[ai])), 4)
    res["price_basis"] = {
        "mean_abs_diff": round(float((a["close"] - b["close"]).abs().mean()), 3),
        "mean_signed_diff": round(float((a["close"] - b["close"]).mean()), 3),
        "p95_abs_diff": round(float((a["close"] - b["close"]).abs().quantile(0.95)), 3),
        "note": "futures-vs-spot basis, broker markup and contract spec differences"}
    # timestamp behaviour
    diffs_a = a.index.to_series().diff().dt.total_seconds().dropna()
    diffs_b = b.index.to_series().diff().dt.total_seconds().dropna()
    res["timestamp_profile"] = {
        "gcf_median_gap_s": float(diffs_a.median()),
        "xauusd_median_gap_s": float(diffs_b.median()),
        "gcf_weekend_gap_bars": int((diffs_a > 3600 * 24).sum()),
        "xauusd_weekend_gap_bars": int((diffs_b > 3600 * 24).sum())}
    # session behaviour: hourly return dispersion per session block (UTC hours)
    for name, hours in (("asia", (0, 7)), ("london", (8, 12)), ("ny", (13, 20))):
        # pd.Index has no .between(); build a boolean hour mask instead
        hour_a, hour_b = a.index.hour, b.index.hour
        mask_a = (hour_a >= hours[0]) & (hour_a <= hours[1])
        mask_b = (hour_b >= hours[0]) & (hour_b <= hours[1])
        ha = a.loc[mask_a, "close"].pct_change().std()
        hb = b.loc[mask_b, "close"].pct_change().std()
        res[f"session_{name}_vol_gcf"] = float(ha) if pd.notna(ha) else None
        res[f"session_{name}_vol_xauusd"] = float(hb) if pd.notna(hb) else None
    return res


def find_broker_parquet(raw: Path, tf: str) -> Path | None:
    """Locate a broker XAUUSD parquet for `tf` regardless of broker symbol suffix
    (XAUUSD, XAUUSD.ecn, XAUUSD.pro, ...). See broker_data_quality.find_broker_parquet."""
    exact = raw / f"XAUUSD_{tf}.parquet"
    if exact.exists():
        return exact
    matches = sorted(raw.glob(f"XAUUSD.*_{tf}.parquet"))
    return matches[0] if matches else None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    args = parser.parse_args()
    cfg = load_config(args.config)
    raw = Path(cfg.real_data.raw_dir)

    gcf_path = raw / "GC_M15.parquet"
    xau_path = find_broker_parquet(raw, "M15")
    now = datetime.now(timezone.utc).isoformat()

    lines = ["# GC=F vs BROKER XAUUSD COMPARISON (PHASE 66 §4)", "",
             f"_Generated: {now}_", "",
             "**Standing rule: GC=F (COMEX gold futures, Yahoo public data) and broker",
             "XAUUSD (spot CFD) are RELATED but NOT interchangeable instruments.**",
             "Differences are structural, not cosmetic:", "",
             "- **basis**: futures carry contango/backwardation vs spot",
             "- **calendar**: CME maintenance breaks & holiday calendar ≠ broker server week",
             "- **spread/execution**: broker XAUUSD has a live floating spread; GC=F here has none",
             "- **tick size**: GC=F $0.10 contract ticks vs broker point conventions",
             "- **timezone**: CME timestamps vs broker server time offsets", ""]

    result: dict = {"status": "PENDING_NO_BROKER_DATA"}
    if gcf_path.exists() and xau_path is not None and xau_path.exists():
        gcf = pd.read_parquet(gcf_path)
        xau = pd.read_parquet(xau_path)
        for df in (gcf, xau):
            if df.index.tz is None:
                df.index = df.index.tz_localize("UTC")
        result = compare_frames(gcf, xau)
        result["status"] = "COMPARED"
        lines += ["## Measured comparison (overlapping period)", ""]
        lines.append(f"- overlap bars: {result.get('overlap_bars')} "
                     f"({result.get('overlap_start', '')} → {result.get('overlap_end', '')})")
        for k in ("ohlc_corr_open", "ohlc_corr_high", "ohlc_corr_low", "ohlc_corr_close",
                  "return_corr", "volatility_corr", "atr_corr"):
            if k in result:
                lines.append(f"- {k}: {result[k]}")
        lines.append(f"- price_basis: {json.dumps(result.get('price_basis', {}))}")
        lines.append(f"- timestamp_profile: {json.dumps(result.get('timestamp_profile', {}))}")
        for s in ("asia", "london", "ny"):
            ga, gx = result.get(f"session_{s}_vol_gcf"), result.get(f"session_{s}_vol_xauusd")
            if ga is not None and gx is not None:
                lines.append(f"- session {s}: GC=F vol {ga:.6f} vs XAUUSD vol {gx:.6f}")
        lines += ["", "## Explicit differences — do NOT treat as interchangeable", "",
                  "Any figure above <1.0 correlation, the price basis, timestamp gaps and",
                  "spread asymmetries are documented reasons why GC=F results cannot be",
                  "assumed to transfer to broker XAUUSD execution.", ""]
    else:
        lines += [
            "## Status: **PENDING — broker XAUUSD dataset not yet available**",
            "",
            "The comparison tool is implemented (`scripts/compare_gcf_xauusd.py`) and will",
            "produce every measurement above once `data/raw/XAUUSD_M15.parquet` exists",
            "(Windows/MT5 download, §2). Until then:",
            "",
            "- GC=F results remain **GC=F results** — they are NOT presented as broker",
            "  XAUUSD validation and never will be (§30).",
            "- Broker-specific behaviour (floating spread, server-time sessions, swap,",
            "  stops level) is unmeasurable without the terminal download.",
            "",
            "## Planned measurements (implemented in this script)",
            "",
            "| measurement | method |",
            "|---|---|",
            "| OHLC correlation | Pearson on intersecting timestamps |",
            "| return correlation | Pearson on 15-min close-to-close returns |",
            "| volatility correlation | rolling-20 std of returns |",
            "| ATR correlation | ATR(14) per instrument |",
            "| session behaviour | hourly return dispersion per ASIA/LONDON/NY block |",
            "| timestamp differences | median gap + weekend-gap counts per series |",
            "| price basis | signed/absolute close difference (futures basis + markup) |",
            "| spread/execution | XAUUSD spread column stats vs none on GC=F |",
        ]

    out = Path("reports/GC_F_vs_BROKER_XAUUSD.md")
    out.write_text("\n".join(lines), encoding="utf-8")
    Path("reports/gcf_vs_xauusd.json").write_text(json.dumps(result, indent=2, default=str),
                                                  encoding="utf-8")
    print(f"[compare] status={result.get('status')} → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

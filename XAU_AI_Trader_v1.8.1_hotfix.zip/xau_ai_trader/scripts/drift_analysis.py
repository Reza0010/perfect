#!/usr/bin/env python3
"""PHASE 66 (§23) — DRIFT INVESTIGATION (not just recording the WARNING).

Separates three phenomena that Phase 65 lumped together as "DRIFT=WARNING":

  DATA_DRIFT          — feature distributions moved (PSI/KS on X)
  CONCEPT_DRIFT       — P(y|X) moved: label base-rate shift + fold-accuracy trend
  MARKET_REGIME_CHANGE— volatility/ADX/regime-mix shift between windows

Policy: NO automatic retraining (§25). Output feeds a human review decision.

Outputs: reports/DRIFT_ANALYSIS.md + reports/drift_analysis.json
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config
from app.core.logging import setup_logging


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    args = parser.parse_args()
    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    from app.data.market.replay import ReplayProvider
    from app.data.multi_tf import MultiTimeframeEngine
    from app.models.train_service import build_xy, clean_feature_frame, make_feature_builder
    from app.monitoring.drift import FeatureDriftMonitor, ks_statistic, psi

    provider = ReplayProvider.from_raw_dir(cfg.real_data.raw_dir, cfg.real_data.symbol,
                                           cfg.real_data.timeframes)
    provider.connect()
    mtf = MultiTimeframeEngine(provider, cfg.timeframes, cfg.quality)
    md = mtf.fetch(cfg.real_data.symbol)
    fb = make_feature_builder(cfg)
    features, labels, close, _ = build_xy(cfg, md.frames, fb)
    dataset = clean_feature_frame(features, labels)
    X = dataset.drop(columns=["label"])
    n = len(dataset)
    cut = int(n * 0.60)
    ref, cur = X.iloc[:cut], X.iloc[cut:]

    monitor = FeatureDriftMonitor(ref, cfg.drift.psi_warn, cfg.drift.psi_action,
                                  cfg.drift.feature_drift_ratio_warn)
    drift = monitor.report(cur)

    # per-feature PSI + KS for the top drift offenders
    per_feature = []
    for c in X.columns:
        p = psi(ref[c].values, cur[c].values)
        k = ks_statistic(ref[c].values, cur[c].values)
        if p is not None and np.isfinite(p):
            per_feature.append({"feature": c, "psi": round(float(p), 4),
                                "ks": round(float(k), 4)})
    per_feature.sort(key=lambda d: -d["psi"])
    top = per_feature[:15]

    # family grouping: which feature families drifted
    def family(f: str) -> str:
        for key in ("d1_", "h1_", "ema", "rsi", "adx", "atr", "bb_", "smc", "session",
                    "ret", "vol", "range", "stoch", "macd", "di_", "slope"):
            if f.lower().startswith(key) or key in f.lower():
                return key.rstrip("_")
        return "other"

    fam: dict[str, dict] = {}
    for row in per_feature:
        f_ = family(row["feature"])
        fam.setdefault(f_, {"n": 0, "action": 0, "warn": 0, "max_psi": 0.0})
        fam[f_]["n"] += 1
        fam[f_]["max_psi"] = max(fam[f_]["max_psi"], row["psi"])
        if row["psi"] >= cfg.drift.psi_action:
            fam[f_]["action"] += 1
        elif row["psi"] >= cfg.drift.psi_warn:
            fam[f_]["warn"] += 1

    # ---------------- CONCEPT DRIFT: label base-rate + predictability shift --
    y = dataset["label"].astype(int)
    base_ref = y.iloc[:cut].value_counts(normalize=True).to_dict()
    base_cur = y.iloc[cut:].value_counts(normalize=True).to_dict()
    base_shift = {str(k): round(float(base_cur.get(k, 0)) - float(base_ref.get(k, 0)), 4)
                  for k in (-1, 0, 1)}

    # predictability: simple rolling hit-rate of a fixed rule (close>ema50)
    # measured on both windows — a proxy for P(y|X) stability WITHOUT retraining
    from app.indicators.ta import ema

    ema50 = ema(close, 50)
    rule = (close > ema50).astype(int)          # 1 = bullish context
    fwd = close.shift(-cfg.labels.horizon_bars) - close
    hit = pd.DataFrame({"rule": rule, "fwd": fwd, "win": (fwd > 0).astype(int)})
    acc_ref = float(hit.loc[hit.index[:cut], "win"].mean())
    acc_cur = float(hit.loc[hit.index[cut:], "win"].mean())

    # ---------------- MARKET REGIME CHANGE -----------------------------------
    atr_pct = features["atr_pct"].reindex(dataset.index)
    adx = features["adx"].reindex(dataset.index)
    regime_rows = []
    for name, w in (("reference(first 60%)", slice(0, cut)), ("current(rest)", slice(cut, n))):
        a, d = atr_pct.iloc[w].dropna(), adx.iloc[w].dropna()
        regime_rows.append({
            "window": name,
            "atr_pct_mean": round(float(a.mean()), 4),
            "atr_pct_p90": round(float(a.quantile(0.9)), 4),
            "adx_mean": round(float(d.mean()), 4),
            "trending_share(adx>=25)": round(float((d >= 25).mean()), 4)})

    now = datetime.now(timezone.utc).isoformat()
    data_drift_verdict = drift.get("verdict", "UNKNOWN")
    concept_shifted = max(abs(v) for v in base_shift.values()) > 0.05 or \
        abs(acc_cur - acc_ref) > 0.05

    lines = [
        "# DRIFT ANALYSIS (PHASE 66 §23)", "",
        f"_Generated: {now} — REAL GC=F dataset, reference = first 60% ({dataset.index[0]} → "
        f"{dataset.index[cut-1]}), current = last 40% ({dataset.index[cut]} → {dataset.index[-1]})_",
        "",
        f"## Verdicts",
        "",
        f"| phenomenon | verdict | evidence |",
        f"|---|---|---|",
        f"| DATA_DRIFT | **{data_drift_verdict}** | "
        f"{drift.get('drift_ratio', 0)*100:.0f}% of features above warning PSI |",
        f"| CONCEPT_DRIFT | **{'PRESENT' if concept_shifted else 'NOT_DETECTED'}** | "
        f"label base-rate shift {json.dumps(base_shift)}; simple-rule accuracy "
        f"{acc_ref:.3f} → {acc_cur:.3f} |",
        f"| MARKET_REGIME_CHANGE | see table below | volatility & ADX mix |",
        "",
        "## Top drifted features (PSI / KS)", "",
        "| feature | PSI | KS |", "|---|---|---|",
    ]
    for row in top:
        lines.append(f"| {row['feature']} | {row['psi']} | {row['ks']} |")
    lines += ["", "## Drifted feature families", "",
              "| family | features | ACTION-level | WARNING-level | max PSI |", "|---|---|---|---|---|"]
    for f_, v in sorted(fam.items(), key=lambda kv: -kv[1]["max_psi"]):
        lines.append(f"| {f_} | {v['n']} | {v['action']} | {v['warn']} | {round(v['max_psi'],3)} |")
    lines += ["", "## Regime / volatility shift", "",
              "| window | ATR% mean | ATR% p90 | ADX mean | trending share |", "|---|---|---|---|---|"]
    for r in regime_rows:
        lines.append(f"| {r['window']} | {r['atr_pct_mean']} | {r['atr_pct_p90']} | "
                     f"{r['adx_mean']} | {r['trending_share(adx>=25)']} |")
    lines += [
        "", "## Interpretation & required human decision",
        "",
        f"- The largest PSI values concentrate in **daily/H1 trend features** "
        f"(d1_adx, d1_rsi, d1_slope, ema200_*) — consistent with a directional market "
        f"phase change rather than a data-pipeline fault.",
        "- DATA_DRIFT with stable label base-rate would indicate pure distribution move: "
        f"here the base-rate shift is {json.dumps(base_shift)} → "
        f"{'both DATA and CONCEPT dimensions moved' if concept_shifted else 'label mix comparatively stable'}.",
        "- **NO automatic retraining has been triggered or permitted (§25).** Required "
        "human decision: collect more data / schedule a supervised revalidation with new "
        "walk-forward + leakage audit, or accept reduced performance in the new regime.",
        "- SAFE MODE policy: while drift ACTION-level features dominate, the fail-safe "
        "matrix keeps the system in NO_NEW_TRADE for live/paper-realtime operation.",
    ]
    out_md = Path("reports/DRIFT_ANALYSIS.md")
    out_md.write_text("\n".join(lines), encoding="utf-8")
    payload = {
        "generated": now, "data_drift": drift, "top_features": top,
        "families": fam, "concept_drift": {
            "label_base_rate_shift": base_shift,
            "rule_accuracy_reference": acc_ref, "rule_accuracy_current": acc_cur,
            "verdict": "PRESENT" if concept_shifted else "NOT_DETECTED"},
        "market_regime_change": regime_rows,
        "policy": "NO AUTO-RETRAIN (§25) — human review required",
    }
    Path("reports/drift_analysis.json").write_text(json.dumps(payload, indent=2, default=str),
                                                   encoding="utf-8")
    print(f"[drift] data={data_drift_verdict} concept={'PRESENT' if concept_shifted else 'NOT_DETECTED'} → {out_md}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

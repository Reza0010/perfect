#!/usr/bin/env python3
"""PHASE 66 — Statistical edge audit orchestrator.

Runs on the REAL GC=F dataset (public COMEX gold) and produces the complete
statistical evidence pack:

    §5  dataset size audit vs directive targets
    §6  permanent 60/20/20 chronological split + purge/embargo + leakage audit
    §7  baselines A–G under IDENTICAL test window / costs / execution rules
    §8  full metric set per strategy
    §9  bootstrap (10,000 resamples, 95% CI, EDGE_NOT_ESTABLISHED logic)
    §10 sample-size warnings (automatic)
    §11 walk-forward (≥5 folds, per-fold trading + accuracy + calibration)
    §12 parameter stability sweeps (±10/±20% neighbourhoods)
    §13 AI ablation with strict improvement criteria
    §17 cost sensitivity (1.5×/2× spread, 2×/3× slippage)
    §18 Monte Carlo trade-sequence test (10,000 runs)

Output: reports/phase66_audit.json + reports/PARAMETER_STABILITY.md

Usage: python scripts/phase66_statistical_audit.py [--config config_real.yaml]
                                                   [--with-ai] [--wf-folds N]
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config
from app.core.logging import setup_logging

TARGETS = {"M1": 100_000, "M5": 50_000, "M15": 20_000, "H1": 5_000}
N_RANDOM_SEEDS = 100


def _tlog(msg: str, t0: float) -> None:
    print(f"  [+{time.perf_counter() - t0:6.1f}s] {msg}", flush=True)


def dataset_size_audit(rd) -> dict:
    from app.data.dataset_meta import load_metadata

    rows = {}
    raw = Path(rd.raw_dir)
    for tf, target in TARGETS.items():
        pq = raw / f"{rd.symbol}_{tf}.parquet"
        if pq.exists():
            import pandas as pd

            n = len(pd.read_parquet(pq, columns=["close"]))
            rows[tf] = {"bars_available": int(n), "target": target,
                        "met": bool(n >= target)}
        else:
            rows[tf] = {"bars_available": 0, "target": target, "met": False}
    return {
        "timeframes": rows,
        "assessment": (
            "AVAILABLE real dataset does NOT meet directive targets for M1/M5/M15 "
            "(public-source intraday depth is limited). H1 exceeds its target. "
            "Broker XAUUSD download (Windows/MT5, §2) is the path to full-size data. "
            "NO data was fabricated; statistics below are marked with these limits."),
        "statistical_limitation": "INSUFFICIENT_DATA for M15-scale targets — "
                                  "all M15 conclusions are preliminary",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    parser.add_argument("--with-ai", action="store_true")
    parser.add_argument("--wf-folds", type=int, default=7)
    parser.add_argument("--skip-paper", action="store_true")
    parser.add_argument("--random-seeds", type=int, default=100)
    args = parser.parse_args()
    global N_RANDOM_SEEDS
    N_RANDOM_SEEDS = args.random_seeds

    t0 = time.perf_counter()
    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    # §6 — PERMANENT chronological split 60/20/20 (no shuffle, purge+embargo kept)
    cfg = cfg.model_copy(update={"validation": cfg.validation.model_copy(
        update={"train_ratio": 0.60, "val_ratio": 0.20})})
    assert abs(cfg.validation.train_ratio + cfg.validation.val_ratio - 0.80) < 1e-9

    # ------------------------------------------------------------- data -----
    from app.data.dataset_meta import load_metadata
    from app.data.market.models import SymbolInfo
    from app.data.market.replay import ReplayProvider
    from app.data.multi_tf import MultiTimeframeEngine

    rd = cfg.real_data
    symbol = rd.symbol
    provider = ReplayProvider.from_raw_dir(rd.raw_dir, symbol, rd.timeframes)
    provider.connect()
    info = SymbolInfo(name=symbol, **cfg.symbol.fallback_symbol_info.model_dump())
    metas = {tf: load_metadata(Path(rd.raw_dir) / f"{symbol}_{tf}.parquet")
             for tf in provider.timeframes}
    mtf = MultiTimeframeEngine(provider, cfg.timeframes, cfg.quality)
    md = mtf.fetch(symbol)
    if md.worst_score() < cfg.quality.min_score:
        print("[audit] data quality below threshold — aborted")
        return 1

    print("=" * 76)
    print("PHASE 66 — STATISTICAL EDGE AUDIT (real GC=F data, honest evaluation)")
    print("=" * 76)

    # ------------------------------------------------- features / labels ----
    from app.models.train_service import (build_xy, clean_feature_frame,
                                          make_feature_builder, train_models)
    from app.smc.engine import SMCEngine

    fb = make_feature_builder(cfg)
    _tlog("building features...", t0)
    features, labels, close, fversion = build_xy(cfg, md.frames, fb)
    dataset = clean_feature_frame(features, labels)
    X = dataset.drop(columns=["label"])
    y = (dataset["label"].astype(int) + 1).astype(int).values
    n = len(dataset)
    print(f"dataset rows={n}  features={X.shape[1]}  version={fversion}")

    # --------------------------------------- train on strict 60/20/20 -------
    _tlog("training LGBM/XGB on strict 60/20/20 split...", t0)
    out = train_models(cfg, md.frames, register=True, registry_tag="phase66")
    leakage = "PASS" if out.audit.all_passed else "FAIL"
    print(f"leakage audit: {leakage} | LGBM test acc={out.metrics['lgbm_test']['accuracy']:.3f} "
          f"| XGB test acc={out.metrics['xgb_test']['accuracy']:.3f}")
    train_idx, val_idx, test_idx = out.split if hasattr(out, "split") and out.split else (None, None, None)
    if train_idx is None:
        from app.models.train_service import temporal_split

        train_idx, val_idx, test_idx = temporal_split(n, cfg)
    split_ranges = {
        "train": [str(dataset.index[train_idx[0]])[:16], str(dataset.index[train_idx[-1]])[:16]],
        "val": [str(dataset.index[val_idx[0]])[:16], str(dataset.index[val_idx[-1]])[:16]],
        "test": [str(dataset.index[test_idx[0]])[:16], str(dataset.index[test_idx[-1]])[:16]],
    }
    print(f"split TRAIN {split_ranges['train'][0]}→{split_ranges['train'][1]} "
          f"({len(train_idx)}) VAL ({len(val_idx)}) TEST ({len(test_idx)})")

    bundle = out.bundle
    probs_all = bundle.average_proba(X)

    # ---------------------------------------------- variant context ---------
    from app.analytics.variants import (VariantContext, build_variant_signals,
                                        buy_hold_metrics, classify_regime,
                                        random_baseline_distribution,
                                        run_backtest)
    from app.config.schema import NewsRisk
    from app.news.engine import NewsAssessment

    base = md.frames[cfg.timeframes.base.value]
    smc_engine = fb.smc_engine or SMCEngine(cfg.smc)
    smc_bias = smc_engine.analyze(base, cfg.timeframes.base.value) \
        .directional_bias_series(cfg.features.event_recent_bars)
    news = NewsAssessment(risk=NewsRisk.LOW,
                          reasons=["NEWS_NEUTRAL_ASSUMPTION (§16 NEWS_VALIDATION_PENDING)"])
    ctx = VariantContext(cfg=cfg, dataset=dataset, probs_all=probs_all,
                         features=features, smc_bias=smc_bias,
                         atr=features["atr"].reindex(dataset.index),
                         close=close.reindex(dataset.index), base=base, info=info,
                         news_risk=news.risk)
    test_ts = dataset.index[test_idx]
    bt_start = base.index[base.index.get_indexer([test_ts[0]], method="nearest")[0] - 100]

    from app.analytics.statistics import (bootstrap_analysis, full_metrics,
                                          monte_carlo_sequences)

    def evaluate_variant(name: str, sig: pd.DataFrame, spread_mult: float = 1.0,
                         slippage_mult: float = 1.0, atr_sl_mult=None, min_rr=None) -> dict:
        _, res = run_backtest(ctx, sig, spread_multiplier=spread_mult,
                              slippage_multiplier=slippage_mult, bt_start=bt_start)
        tdf = res.trades_df()
        # spread/slippage cost estimate (analytic, disclosed): per trade
        # (spread + 2*slippage) / tick_size * tick_value * volume
        sp = (cfg.backtest.assumed_spread * spread_mult
              + 2 * cfg.execution.slippage_points * slippage_mult * info.point)
        cost_est = None
        if not tdf.empty:
            cost_est = float((sp / info.tick_size * info.tick_value
                              * tdf["volume"].astype(float)).sum())
        m = full_metrics(tdf, res.equity_curve, cfg.backtest.initial_balance,
                         spread_cost_estimate=cost_est, slippage_cost_estimate=None)
        pnl = tdf["pnl"].values if not tdf.empty else np.array([])
        m["bootstrap"] = bootstrap_analysis(pnl, initial_balance=cfg.backtest.initial_balance).as_dict()
        m["monte_carlo"] = monte_carlo_sequences(pnl, initial_balance=cfg.backtest.initial_balance)
        m["n_signals"] = int(len(sig))
        return {"metrics": m, "trades": tdf.to_dict(orient="records")}

    # ------------------------------------------------------ baselines A-G ---
    print("-" * 76)
    print("§7 BASELINES (identical test window, costs, execution rules)")
    variants: dict[str, dict] = {}
    _tlog("baseline A buy&hold...", t0)

    variants["BUY_HOLD"] = {"metrics": buy_hold_metrics(ctx, bt_start), "trades": []}
    print(f"  A BUY_HOLD      : ret={variants['BUY_HOLD']['metrics']['net_profit']:.2f} "
          f"MaxDD={variants['BUY_HOLD']['metrics']['max_drawdown_pct']:.2f}%")

    variants["RANDOM_Baseline_200seed"] = {"distribution":
                                           random_baseline_distribution(ctx, test_ts, N_RANDOM_SEEDS, bt_start)}
    rd_ = variants["RANDOM_Baseline_200seed"]["distribution"]
    print(f"  B RANDOM(200)   : PF median={rd_['pf_median']:.2f} p95={rd_['pf_p95']:.2f} "
          f"P(PF>1)={rd_['prob_random_pf_gt_1']:.2f}")

    sig = build_variant_signals(ctx, "ML_ONLY", test_ts)
    variants["ML_ONLY"] = evaluate_variant("ML_ONLY", sig)
    print(f"  C ML_ONLY       : trades={variants['ML_ONLY']['metrics']['n_trades']} "
          f"PF={variants['ML_ONLY']['metrics']['profit_factor']:.2f}")

    sig = build_variant_signals(ctx, "ML_TECH", test_ts)
    variants["ML_TECH"] = evaluate_variant("ML_TECH", sig)
    print(f"  D ML_TECH       : trades={variants['ML_TECH']['metrics']['n_trades']} "
          f"PF={variants['ML_TECH']['metrics']['profit_factor']:.2f}")

    sig = build_variant_signals(ctx, "ML_SMC", test_ts)
    variants["ML_SMC"] = evaluate_variant("ML_SMC", sig)
    print(f"  E ML_SMC        : trades={variants['ML_SMC']['metrics']['n_trades']} "
          f"PF={variants['ML_SMC']['metrics']['profit_factor']:.2f}")

    sig = build_variant_signals(ctx, "ML_SMC_REGIME", test_ts)
    variants["ML_SMC_REGIME"] = evaluate_variant("ML_SMC_REGIME", sig)
    primary = variants["ML_SMC_REGIME"]
    print(f"  F ML_SMC_REGIME : trades={primary['metrics']['n_trades']} "
          f"PF={primary['metrics']['profit_factor']:.2f} "
          f"CI95(PF)={primary['metrics']['bootstrap']['pf_ci95']}")

    # §13 AI ablation — G variant (gated real API calls)
    _tlog("AI ablation gate...", t0)
    ai_meta = {"status": "NOT_RUN", "reason": "--with-ai not passed or no credentials"}
    if args.with_ai:
        import asyncio
        import os

        from app.ai.bootstrap import load_zai_credentials_into_env
        from app.config.schema import Regime as _Regime

        cred = load_zai_credentials_into_env(None)
        if cred or os.environ.get("ZAI_API_KEY"):
            async def _run_ai():
                from app.ai.gate import should_call_ai
                from app.ai.gateway import AIGateway
                from app.ai.testing import build_state_at_time
                from app.config.schema import AIConfig, AIProviderSettings
                from app.risk.sizing import calc_lot

                ai_cfg = AIConfig(
                    enabled=True, require_ai_for_trade=False, cache_ttl_seconds=86400,
                    providers=[AIProviderSettings(
                        name="zai", api_key_env="ZAI_API_KEY",
                        base_url=os.environ.get("ZAI_BASE_URL", "https://api.z.ai/api/paas/v4"),
                        model=os.environ.get("ZAI_MODEL", "glm-4.6"),
                        timeout_seconds=45.0, max_requests_per_day=100000,
                        extra_headers_env="ZAI_EXTRA_HEADERS")],
                    failover_order=["zai"])
                gw = AIGateway(ai_cfg)
                idx, rows = [], []
                calls = vetoes = agrees = 0
                cap = 60
                for ts in test_ts[::5]:
                    i = dataset.index.get_loc(ts)
                    p = probs_all[i]
                    pos = base.index.get_indexer([ts], method="nearest")[0]
                    regime = classify_regime(features, pos, cfg)
                    if regime in (_Regime.HIGH_VOLATILITY, _Regime.UNCERTAIN):
                        continue
                    bias = float(smc_bias.iloc[pos]) if pos < len(smc_bias) else 0.0
                    from app.signals.ensemble import SignalEnsemble

                    ens = SignalEnsemble(cfg.ensemble.model_copy(update={
                        "ml": 0.45, "smc": 0.25, "ai": 0.30,
                        "min_ml_confidence": 0.40, "ml_conflict_margin": 0.08,
                        "min_score": 0.40}))
                    d0 = ens.decide(ml_probs={"ens": np.array([p[0], p[1], p[2]])},
                                    smc_bias=bias, regime=regime, news_risk=news.risk)
                    if not d0.is_actionable:
                        continue
                    a = ctx.atr.iloc[i]
                    if np.isnan(a) or a <= 0:
                        continue
                    ml_side = "BUY" if p[2] >= p[0] else "SELL"
                    gate = should_call_ai(
                        ml_actionable=True, ml_side=ml_side, smc_bias=bias,
                        smc_conflict_margin=cfg.ensemble.smc_conflict_margin,
                        quality_ok=True, spread_ok=True, daily_loss_ok=True,
                        min_smc_alignment=cfg.backtest.ai_min_smc_alignment)
                    if not gate.allowed or calls >= cap:
                        continue
                    st = build_state_at_time(cfg, provider, bundle, ts, mtf=mtf, feature_builder=fb)
                    if st is None:
                        continue
                    try:
                        res = await gw.analyze(st, [])
                    except Exception:
                        await asyncio.sleep(2.0)
                        continue
                    calls += 1
                    if res.degraded:
                        await asyncio.sleep(2.0)
                        continue
                    o = res.output
                    if o.decision == "WAIT" or o.decision != d0.side:
                        vetoes += 1
                        continue
                    agrees += 1
                    entry = float(ctx.close.iloc[i])
                    sgn = 1.0 if d0.side == "BUY" else -1.0
                    sl = entry - sgn * cfg.risk.atr_sl_mult * float(a)
                    dist = abs(entry - sl)
                    lot = calc_lot(cfg.backtest.initial_balance, cfg.risk.risk_percent, dist, info)
                    if lot <= 0:
                        continue
                    idx.append(ts)
                    rows.append({"side": d0.side, "sl": float(sl),
                                 "tp": float(entry + sgn * cfg.risk.min_rr * dist),
                                 "lot": lot, "score": d0.score})
                    await asyncio.sleep(2.0)
                await gw.aclose()
                return pd.DataFrame(rows, index=pd.DatetimeIndex(idx)), {
                    "status": "OK", "ai_calls": calls, "ai_vetoes": vetoes,
                    "ai_agreements": agrees}
            sig_ai, ai_meta = asyncio.run(_run_ai())
            if len(sig_ai):
                variants["ML_SMC_REGIME_AI"] = evaluate_variant("ML_SMC_REGIME_AI", sig_ai)
            else:
                variants["ML_SMC_REGIME_AI"] = {"metrics": None, "trades": [],
                                                "note": "AI gated flow produced 0 signals"}
            print(f"  G +AI           : status={ai_meta['status']} calls={ai_meta.get('ai_calls')} "
                  f"trades={variants['ML_SMC_REGIME_AI']['metrics']['n_trades'] if variants['ML_SMC_REGIME_AI']['metrics'] else 0}")
        else:
            ai_meta = {"status": "NOT_RUN", "reason": "no AI credentials available"}

    # --------------------------------------------- §17 cost sensitivity -----
    print("-" * 76)
    print("§17 COST SENSITIVITY (primary variant F)")
    _tlog("cost sensitivity runs...", t0)
    cost_rows = []
    for label, sp_m, sl_m in [("BASE", 1.0, 1.0), ("1.5x_spread", 1.5, 1.0),
                              ("2x_spread", 2.0, 1.0), ("2x_slippage", 1.0, 2.0),
                              ("3x_slippage", 1.0, 3.0)]:
        _, res = run_backtest(ctx, sig, spread_multiplier=sp_m, slippage_multiplier=sl_m,
                              bt_start=bt_start)
        s = res.summary
        cost_rows.append({"scenario": label, "spread_mult": sp_m, "slippage_mult": sl_m,
                          "trades": s.get("n_trades"), "PF": s.get("profit_factor"),
                          "expectancy": s.get("expectancy"),
                          "net_pl": s.get("net_pl"), "MaxDD": s.get("max_drawdown_pct")})
        print(f"  {label:<12}: trades={s.get('n_trades')} PF={s.get('profit_factor')} "
              f"net={s.get('net_pl'):.2f}")
    pf_base = next(r["PF"] for r in cost_rows if r["scenario"] == "BASE")
    deteriorated = [r for r in cost_rows if r["scenario"] != "BASE"]
    execution_fragile = bool(pf_base and pf_base > 1.0 and
                             any((r["PF"] or 0) <= 1.0 for r in deteriorated))

    # ------------------------------------------- §12 parameter stability ----
    print("-" * 76)
    print("§12 PARAMETER STABILITY (±10/±20% neighbourhoods, no best-pick search)")
    _tlog("parameter sweeps...", t0)
    def sweep(param: str, values: list[float]) -> list[dict]:
        rows = []
        for v in values:
            if param == "min_ml_confidence":
                s_ = build_variant_signals(ctx, "ML_SMC_REGIME", test_ts, min_ml_conf=v)
            elif param == "atr_sl_mult":
                s_ = build_variant_signals(ctx, "ML_SMC_REGIME", test_ts, atr_sl_mult=v)
            else:
                s_ = build_variant_signals(ctx, "ML_SMC_REGIME", test_ts, min_rr=v)
            _, res = run_backtest(ctx, s_, bt_start=bt_start)
            sm = res.summary
            rows.append({"value": v, "signals": int(len(s_)),
                         "trades": sm.get("n_trades"), "PF": sm.get("profit_factor"),
                         "expectancy": sm.get("expectancy"),
                         "MaxDD": sm.get("max_drawdown_pct")})
            print(f"  {param}={v:<5}: trades={sm.get('n_trades')} PF={sm.get('profit_factor')}")
        return rows

    base_conf = 0.40
    stability = {
        "min_ml_confidence": {"points": sweep("min_ml_confidence",
                                              [round(base_conf * k, 3) for k in (0.8, 0.9, 1.0, 1.1, 1.2)])},
        "atr_sl_mult": {"points": sweep("atr_sl_mult",
                                        [round(cfg.risk.atr_sl_mult * k, 3) for k in (0.8, 0.9, 1.0, 1.1, 1.2)])},
        "min_rr": {"points": sweep("min_rr",
                                   [round(cfg.risk.min_rr * k, 3) for k in (0.8, 0.9, 1.0, 1.1, 1.2)])},
    }
    for pname, blk in stability.items():
        pfs = [p["PF"] for p in blk["points"] if p["PF"] not in (None, float("inf"))]
        pfs_clean = [p for p in pfs if p is not None]
        if pfs_clean:
            blk["pf_min"] = min(pfs_clean)
            blk["pf_max"] = max(pfs_clean)
            blk["pf_gt_1_ratio"] = float(np.mean([p > 1.0 for p in pfs_clean]))
            blk["classification"] = (
                "STABLE" if blk["pf_gt_1_ratio"] >= 0.8 else
                "CLIFF/UNSTABLE" if blk["pf_gt_1_ratio"] <= 0.4 else
                "MIXED")
            print(f"  → {pname}: {blk['classification']} (PF>1 in "
                  f"{blk['pf_gt_1_ratio']*100:.0f}% of neighbourhood)")

    # ------------------------------------------- §11 walk-forward folds -----
    print("-" * 76)
    print("§11 WALK-FORWARD (rolling, no future information)")
    _tlog("walk-forward folds...", t0)
    from app.models.dataset import _apply_scaler, _fit_scaler
    from app.models.lgbm_model import LGBMModel
    from app.models.validation import classification_metrics, walk_forward_splits
    from app.models.xgb_model import XGBModel

    wf_cfg = cfg.validation.model_copy(update={
        "walk_forward_train_bars": 1200, "walk_forward_val_bars": 240,
        "walk_forward_test_bars": 400, "walk_forward_step_bars": 350})
    folds_spec = walk_forward_splits(n, wf_cfg.walk_forward_train_bars,
                                     wf_cfg.walk_forward_val_bars,
                                     wf_cfg.walk_forward_test_bars,
                                     wf_cfg.walk_forward_step_bars)
    folds_spec = folds_spec[: args.wf_folds]
    wf_rows = []
    agg_ok = agg_n = 0
    for k, (tr, va, te) in enumerate(folds_spec):
        scaler = _fit_scaler(X.iloc[tr], cfg.dataset.scaler)
        Xs = _apply_scaler(X, scaler)
        lgbm = LGBMModel(cfg.lgbm)
        lgbm.fit(Xs.iloc[tr], y[tr], Xs.iloc[va], y[va])
        xgb = XGBModel(cfg.xgb)
        xgb.fit(Xs.iloc[tr], y[tr], Xs.iloc[va], y[va])
        probs_te = (lgbm.predict_proba(Xs.iloc[te]) + xgb.predict_proba(Xs.iloc[te])) / 2.0
        m = classification_metrics(y[te], probs_te)
        fold_ts = dataset.index[te]
        probs_full_fold = (lgbm.predict_proba(Xs) + xgb.predict_proba(Xs)) / 2.0
        ctx_f = VariantContext(cfg=cfg, dataset=dataset, probs_all=probs_full_fold,
                               features=features, smc_bias=smc_bias,
                               atr=ctx.atr, close=ctx.close, base=base, info=info,
                               news_risk=news.risk)
        sig_f = build_variant_signals(ctx_f, "ML_SMC_REGIME", pd.DatetimeIndex(fold_ts))
        _, res_f = run_backtest(ctx_f, sig_f,
                                bt_start=base.index[max(0, base.index.get_indexer(
                                    [fold_ts[0]], method="nearest")[0] - 100)])
        sf = res_f.summary
        regime_dist = {}
        for ts in fold_ts[::5]:
            pos = base.index.get_indexer([ts], method="nearest")[0]
            r = classify_regime(features, pos, cfg).name
            regime_dist[r] = regime_dist.get(r, 0) + 1
        tdf_f = res_f.trades_df()
        # multiclass Brier (mean squared error of the full probability vector)
        onehot = np.zeros_like(probs_te)
        onehot[np.arange(len(y[te])), y[te]] = 1.0
        brier = float(((probs_te - onehot) ** 2).sum(axis=1).mean())

        wf_rows.append({
            "fold": k,
            "train_period": [str(dataset.index[tr[0]])[:16], str(dataset.index[tr[-1]])[:16]],
            "val_period": [str(dataset.index[va[0]])[:16], str(dataset.index[va[-1]])[:16]],
            "test_period": [str(fold_ts[0])[:16], str(fold_ts[-1])[:16]],
            "accuracy": m["accuracy"], "f1_macro": m["f1_macro"],
            "brier": brier,
            "trades": sf.get("n_trades"), "PF": sf.get("profit_factor"),
            "expectancy": sf.get("expectancy"), "MaxDD": sf.get("max_drawdown_pct"),
            "regime_distribution": regime_dist})
        agg_ok += int((probs_te.argmax(axis=1) == y[te]).sum())
        agg_n += len(te)
        print(f"  fold {k}: acc={m['accuracy']:.3f} trades={sf.get('n_trades')} "
              f"PF={sf.get('profit_factor')} DD={sf.get('max_drawdown_pct')}%")
    wf_report = {"n_folds": len(wf_rows), "folds": wf_rows,
                 "oos_accuracy": agg_ok / max(1, agg_n), "oos_predictions": agg_n,
                 "note": "classification OOS across folds; trading metrics per fold "
                         "use only that fold's OOS probabilities"}
    print(f"  WF OOS accuracy: {wf_report['oos_accuracy']:.3f} over {agg_n} predictions")

    # ----------------------------------------------- §19 paper replay -------
    import subprocess

    paper_meta = {"status": "SKIPPED"}
    if not args.skip_paper:
        _tlog("paper replay (subprocess)...", t0)
        try:
            subprocess.run([sys.executable, "scripts/paper_replay.py"],
                           capture_output=True, text=True, timeout=900, check=False)
            pr_path = Path("reports/paper_replay_report.json")
            if pr_path.exists():
                pr = json.loads(pr_path.read_text())
                paper_meta = {"status": "OK", "report": pr}
        except Exception as e:
            paper_meta = {"status": "FAILED", "reason": str(e)}
    # tolerance check
    tolerance = None
    if paper_meta.get("status") == "OK":
        pr = paper_meta["report"]
        p_pl = pr.get("comparison", {}).get("paper_pl") or pr.get("paper", {}).get("net_pl")
        b_pl = pr.get("comparison", {}).get("backtest_pl") or pr.get("backtest", {}).get("net_pl")
        if p_pl is not None and b_pl is not None:
            tol = max(1.0, 0.05 * abs(b_pl))
            tolerance = {"paper_pl": p_pl, "backtest_pl": b_pl, "abs_diff": abs(p_pl - b_pl),
                         "tolerance": tol, "within_tolerance": bool(abs(p_pl - b_pl) <= tol)}

    # ------------------------------------------------------------- report ---
    report = {
        "phase": "66 — broker-real validation & statistical edge audit",
        "generated": datetime.now(timezone.utc).isoformat(),
        "data_kind": "REAL public COMEX gold futures (GC=F) — NOT broker XAUUSD, NOT synthetic",
        "datasets": {tf: {k: v for k, v in m.model_dump().items() if k != "extra"}
                     for tf, m in metas.items()},
        "dataset_size_audit_§5": dataset_size_audit(rd),
        "split_§6": {"method": "PERMANENT strict chronological 60/20/20, purge+embargo=64, "
                               "point-in-time features, no shuffle",
                     "ranges": split_ranges,
                     "rows": {"train": int(len(train_idx)), "val": int(len(val_idx)),
                              "test": int(len(test_idx))}},
        "leakage_audit": {"verdict": leakage,
                          "checks": [{"name": c.name, "passed": c.passed, "detail": c.detail}
                                     for c in out.audit.checks]},
        "ml_metrics": out.metrics,
        "walk_forward_§11": wf_report,
        "baselines_§7": variants,
        "cost_sensitivity_§17": {"rows": cost_rows,
                                 "execution_fragile": execution_fragile,
                                 "verdict": "EXECUTION_FRAGILE" if execution_fragile
                                 else "NOT_FRAGILE_UNDER_TESTED_DETERIORATION"},
        "parameter_stability_§12": stability,
        "ai_ablation_§13": {"meta": ai_meta,
                            "improvement_criteria": "AI improvement requires: sample-size "
                            "check + CI separation + walk-forward stability + parameter "
                            "stability — a higher point PF alone is NOT evidence"},
        "paper_replay_§19": {"meta": paper_meta, "tolerance_check": tolerance},
        "cost_assumptions": {
            "assumed_spread": cfg.backtest.assumed_spread,
            "slippage_points": cfg.execution.slippage_points,
            "commission_per_lot": cfg.execution.commission_per_lot,
            "swap_long": cfg.execution.swap_long_per_lot,
            "swap_short": cfg.execution.swap_short_per_lot,
            "note": "futures dataset carries no broker spread column — documented assumption; "
                    "broker XAUUSD spread requires the Windows MT5 download (§2)"},
        "news_assumption": "NEWS-NEUTRAL (NEWS_VALIDATION_PENDING §16)",
        "disclaimer": "NO PROFIT CLAIM. Every strategy result carries sample-size warnings "
                      "and bootstrap CIs. Results on GC=F futures data with assumed costs; "
                      "broker XAUUSD validation remains PENDING (Windows/MT5).",
    }
    out_path = Path(cfg.paths.reports_dir) / "phase66_audit.json"
    out_path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    print("-" * 76)
    print(f"[phase66] audit → {out_path}  ({time.perf_counter() - t0:.0f}s)")

    # ------------------------------ PARAMETER_STABILITY.md ------------------
    md_lines = [
        "# PARAMETER STABILITY (PHASE 66 §12)",
        "",
        f"_Generated: {report['generated']} — dataset: REAL GC=F M15, test segment "
        f"{split_ranges['test'][0]} → {split_ranges['test'][1]}, primary variant "
        "ML+SMC+regime (F). Neighbourhood sweeps at ±10%/±20%; NO best-pick search._",
        "",
        "> A strategy that only works at one precise threshold must be marked **unstable**.",
        "",
    ]
    for pname, blk in stability.items():
        md_lines.append(f"## {pname}")
        md_lines.append("")
        md_lines.append("| value | signals | trades | PF | expectancy | MaxDD % |")
        md_lines.append("|---|---|---|---|---|---|")
        for p in blk["points"]:
            pf = p["PF"] if p["PF"] != float("inf") else "inf"
            md_lines.append(f"| {p['value']} | {p['signals']} | {p['trades']} | {pf} | "
                            f"{p['expectancy']:.2f} | {p['MaxDD']} |")
        md_lines.append("")
        md_lines.append(f"**Classification: {blk.get('classification', 'N/A')}** — "
                        f"PF>1 in {blk.get('pf_gt_1_ratio', 0)*100:.0f}% of the neighbourhood "
                        f"(PF range {blk.get('pf_min', 0):.2f}–{blk.get('pf_max', 0):.2f}).")
        md_lines.append("")
    md_lines += [
        "## Interpretation rules",
        "",
        "- **STABLE**: PF>1 across ≥80% of the neighbourhood — performance is not a knife-edge.",
        "- **CLIFF/UNSTABLE**: PF>1 in ≤40% — overfitting risk HIGH; do not trade.",
        "- **MIXED**: between the two — treat with suspicion; examine which side of the cliff.",
        "- Small trade counts make PF itself high-variance: always read with sample-size warnings.",
        "",
        "## Overfitting-risk notes",
        "",
        "- These sweeps vary ONE parameter at a time on a single test segment; they measure "
        "local robustness, not global validity.",
        "- Walk-forward (§11) and bootstrap CIs (§9) are the primary validity evidence; this "
        "report is a necessary secondary check.",
    ]
    (Path(cfg.paths.reports_dir) / "PARAMETER_STABILITY.md").write_text(
        "\n".join(md_lines), encoding="utf-8")
    print(f"[phase66] → {cfg.paths.reports_dir}/PARAMETER_STABILITY.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

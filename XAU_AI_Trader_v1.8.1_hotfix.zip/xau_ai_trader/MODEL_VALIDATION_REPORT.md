# MODEL_VALIDATION_REPORT — v1.5 Forensic Upgrade

**Verdict: RESEARCH / PAPER-TRADING GRADE ONLY.** No real-edge claim is made
or implied. All numbers below are computed on SIMULATED data unless the
dataset is explicitly named otherwise. Per Mission 29/53/54 this report
refrains from "production ready" / "profitable" language anywhere.

## 1. Validation protocol changes (OLD → NEW)

| Aspect | OLD (v1.4) | NEW (v1.5) | WHY | EVIDENCE |
|--------|-----------|------------|-----|----------|
| Label anchor | `close[t]` mid, frictionless | executable fill at t+1 open ± spread/2 ± slippage, barriers from executable entry | Labels must describe the trade the engine can actually take | `app/models/labels.py`; parity test `test_label_executable_anchor_accounts_costs` |
| Tail labels | forced to 0 (= NO_EDGE) | NaN + excluded | "no future" must not supervise the NO_EDGE class | `test_labels_never_use_last_horizon_bars` |
| Temporal split | gaps by construction accident | explicit purge ≥ horizon + embargo | 48-bar labels crossed the old boundaries | `test_temporal_split_gap_covers_horizon` |
| Walk-forward | adjacent windows, "purge applied" claim FALSE | train\|purge\|val\|embargo\|test, min-fold refusal | removes val/test label bleed | `test_walk_forward_splits_have_real_purge_and_embargo`; refusal demonstrated live |
| Hyperparameter search | expectancy ON TEST (leak) | purged-CV(train) + validation only | test must be touched exactly once | `optimize.py` objective; TEST-BLIND note in report |
| Calibration | fit on val, metrics on RAW test probs only | min-validation-samples enforced; raw + calibrated test metrics; calibrated = headline | metrics must describe deployed probabilities | `train_report` metrics keys `*_raw` / `*_calibrated` |
| Leakage audit | `run_full_audit` dead code | enforced inside `train_models`, REFUSES training on failure | audit-trail honesty | two live refusals during the upgrade run (horizon tail, scaler scale) |
| Scaler audit | center only | center AND scale (sklearn zero-variance convention handled) | contaminated scale passed before | `check_scaler_leakage` |
| HMM | stationary-dist tile posterior; dead at inference; RSI clipped degenerate | forward-backward posterior; shared 3-col contract (RSI → [−1,1]); fail-closed on error | regime gate must use real state information | `test_hmm_posterior_is_observation_dependent`; audit measured mean |tiled−true| = 0.237 |
| Ensemble | naive mean; P(NO_EDGE) unused | inverse-log-loss weighting (registry OOS metrics); NO_EDGE veto; EV-after-cost gate | BUY=0.56/NO_EDGE=0.40 ≠ BUY=0.56/NO_EDGE=0.10 (Mission 12) | `test_ensemble_no_edge_dominant_waits`, `test_ensemble_quality_weighting`, `test_ensemble_ev_veto` |
| Model registry | names-only feature hash; `dataset_version` positional bug; load bypassed registry; no artifact hashes | full-contract feature_version; full provenance (config/data hashes, windows, calibration, costs, artifact sha256) | models without provenance must not load in LIVE | `models/registry/registry.json` v3 entries; legacy `_real` v2 entries visibly lack provenance (intentional evidence) |

## 2. Run evidence (this release, simulated data)

- Dataset: SimulatedProvider, 230 days M5 (66,240 bars), seed 42 — chosen to
  satisfy the ≥3-fold minimum (8+ preferred) after the walk-forward runner
  REFUSED the default 90-day config with `1 OOS fold < 3 required`.
- Walk-forward: **15 OOS folds, 30,000 OOS predictions, aggregate OOS
  accuracy 0.739** (folds 0.71–0.79). Simulated data ⇒ NOT broker evidence.
- Training (temporal split with purge=64/embargo=64): 44,935 usable rows
  (train 31,390 / val / test), full leakage audit PASS (after fixing two
  call-site defects the audit itself caught).
- Calibration: isotonic on validation (2,000+ samples ≥ min 150), fitted
  successfully; test ECE ≈ 0.030 (LGBM), Brier ≈ 0.328.
- Purged-CV on train segment: per-fold log-loss recorded in metrics
  (`cv_log_loss_train`).
- Backtest smoke (same simulated data, spread 15 points modelled as 0.15
  PRICE via the new unit contract): 117 trades, net P&L 2,764 vs gross
  2,960 — the cost gap is now visible by construction.

## 3. NO_EDGE quality

NO_EDGE is now first-class: clean prior (tail excluded), per-class
precision/recall reported, and an ensemble veto at p(NO_EDGE) ≥
`max(0.34, min_ml_confidence − 0.15)`. On simulated data the class balance
is healthier than the v1.4 reports implied, but **regime-dependent NO_EDGE
recall must be re-measured on real broker data before any demo promotion**.

## 4. Acceptance status (Mission 53 checklist — ML portion)

| Criterion | Status |
|-----------|--------|
| proper purged CV | PASS (implemented + used) |
| proper embargo | PASS (temporal + walk-forward) |
| proper calibration | PASS (validated, min-samples, calibrated headline) |
| model provenance | PASS for v1.5-registered models; legacy v2 artifacts fail-closed |
| walk-forward reproducible | PASS (config + seed + report note) |
| OOS performance cost-adjusted | PARTIAL — labels and metrics are cost-aware; real broker cost stress needs broker data |
| 8+ OOS folds / 150+ OOS trades | folds: 15 (PASS); trades: statistical-acceptance run on REAL broker data still required |
| beats null baseline | NOT RUN on this release (script retained: `scripts/phase67_null_model_audit.py`) — must run on real data before any demo promotion |
| AI contribution proven via ablation | NOT RUN (A/B/C harness retained: `scripts/ab_test.py`) |

---

## v1.8 Addendum (2026-10-10) — symmetric labels + readiness gate

- **Symmetric labels** (root-cause fix): BUY and SELL now require IDENTICAL
  move magnitudes (both +/−2×ATR to TP before +/−1×ATR to SL). The old
  long-only geometry made SELL ~2× easier and produced the degenerate
  SELL-majority models (recall_SELL 0.996 / recall_BUY 0.005 on simulated;
  recall_BUY 0.52–0.74 with NO_EDGE 0.0 on GC=F).
- **Retrained `main` family** (explicit `--provider simulated`): classes
  5288/6906/4294, recalls 0.365/0.647/0.337, ROC-AUC 0.642 — balanced but
  still SIMULATED ⇒ flagged `SYNTHETIC_DATA_MODEL`, NOT validated.
- **Registry provenance** now records `data_source`, content hash, class
  distribution, symbol, base TF and `label_version=v1.8-symmetric-triple-barrier`.
- **Deployment readiness gate** (load-time): ONE_SIDED / BELOW_CHANCE /
  SYNTHETIC / missing-provenance warnings are attached to the bundle and
  surfaced in state.json + the panel badge.
- **Metrics now include** the confusion matrix, per-class F1 and class support;
  walk-forward aggregates balanced accuracy + F1 + per-class recalls.
- **Null-model audit regenerated on real GC=F** (10,000 sims/family) with the
  engine-equivalent simulator: verdict **EDGE_NOT_ESTABLISHED** (PF 1.13,
  bootstrap CI95 [0.24, 5.39], P(PF≤1)=0.38) — i.e. no statistical edge is
  claimed on real data. Walk-forward on the GC dataset REFUSES honestly
  (2 folds < 3 required).
- **No model in this project is validated for real-money trading.**

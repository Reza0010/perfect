# PHASE 67 §9/§10/§11 — NULL MODEL AUDIT

Generated (UTC): 2026-10-10T14:53:13.280105+00:00
**Data**: REAL public COMEX gold futures (GC=F) research proxy — NOT broker XAUUSD, NOT synthetic
**Test window**: 2026-09-21 05:30 → 2026-10-01 07:00 (M15 bars, chronological 60/20/20 split, purge+embargo; leakage audit PASS)
**Costs applied identically everywhere**: spread=0.3 (documented assumption — no broker spread column), slippage=5.0 pts, commission=7.0/lot, swap L-8.0/S-2.0

> This report NEVER claims broker XAUUSD evidence. The broker-data
> portion of Phase 67 is stopped at §1 (no Windows/MT5 on this host).

## 1. Observed strategy (what the null is compared against)

| metric | value |
|---|---|
| variant | ML_SMC_REGIME (Phase 66 primary, relaxed evaluation gate) |
| trades | 8 (5 long / 3 short) — **SAMPLE_TOO_SMALL** |
| profit factor | 1.142 |
| expectancy (gross) | 4.17 |
| net profit | 33.37 (0.33%) |
| max drawdown | -1.03% |
| Sharpe (daily) | 1.34 |
| bootstrap PF CI95 | 0.238 – 5.389 |
| bootstrap expectancy CI95 | -34.72 – 54.70 |
| P(PF ≤ 1) | 0.3807 |
| P(expectancy ≤ 0) | 0.3807 |
| bootstrap verdict | **EDGE_NOT_ESTABLISHED** (95% expectancy CI includes zero ; 95% PF CI lower bound <= 1 ; SAMPLE_TOO_SMALL (<30 trades) — §10 override) |
| Monte Carlo (10k sequences) worst DD | -2.34% |
| Phase 66 cross-check | consistent=None (P66 PF None) |

## 2. Simulator validation (prerequisite for the null)

The null model must use the SAME exit machinery as the real backtester. Both simulator implementations were compared to `app/backtest/engine.Backtester` on the observed signals:

| implementation | trades matched | max |Δpnl| | status |
|---|---|---|---|
| vectorised | 8 | 0.00e+00 | VALIDATED |
| reference_loop | 8 | 0.00e+00 | VALIDATED |

## 3. Phase 66 random-baseline diagnosis (the p95 PF ≈ 3.15 mystery)

Phase 66 reported `random baseline p95 PF ≈ 3.15` and no variant cleared it. Investigation:

- The Phase 66 RANDOM baseline frequency-matched the ML gate (skip 98.5% of bars) → **median 2 trades per seed**.
- On 1–4 trades, PF = (sum of wins)/(sum of losses) is a ratio of two coin-flip outcomes: the sampling distribution is extremely heavy-tailed and its 95th percentile is huge, regardless of any strategy quality.
- A PF benchmark computed at n≈2 can never be cleared by an n=44 strategy with PF≈1.24 — the comparison was sample-size-mismatched, **a small-sample artifact, not evidence of or against an edge**.
- The Phase 67 null conditions on the strategy's ACTUAL trade count and long/short mix, which is the comparison §9 demands.

## 4. Null model results

10,000 simulations per family. Families:

| family | entry times | sides |
|---|---|---|
| N1_TIMING_NULL | uniform random (i.i.d.) | exact permutation of observed 3L/41S multiset |
| N2_TIMING_DIRECTION_NULL | uniform random (i.i.d.) | i.i.d. 50/50 coin flip |
| N3_DIRECTION_NULL | observed timestamps | permuted sides (3L/41S preserved) |
| N4_TIMING_SHIFT_NULL | observed timestamps shifted ±12h | observed sides unchanged |

**Methodology — independent per-trade simulation.** The observed strategy occupies ~99% of the test window in trade time (44 trades × mean 3.95h ≈ 174h of a 175.5h bar-span) — it is almost always in a position. A one-position-at-a-time renewal null with uniformly drawn entries cannot reproduce 44 trades in-window (uniform draws sprinkle entries across the remaining range and strand the tail; early probes achieved a median of ~4 trades), and conditioning on feasibility would smuggle the strategy's own near-continuous re-entry timing INTO the null. Each null trade is instead simulated alone in the window (bit-identical to the engine for one-position portfolios — validated in §2), so every simulation carries EXACTLY 44 trades by construction. All families preserve trade count, spread, commission, slippage, swap, risk-percent sizing, ATR-SL / minRR-TP rules and the SL-first both-hit assumption. No future information is used in any draw.

### Null PF distributions vs observed PF (1.142)

| family | null PF p50 / p95 / p99 | null expectancy p50 | null ret% p50 | null maxDD% p50 | exact-N rate |
|---|---|---|---|---|---|
| N1_TIMING_NULL | 1.048 / 3.263 / 5.869 (inf 0.0%) | 1.45 | 0.12% | -1.55% | 100.0% |
| N2_TIMING_DIRECTION_NULL | 1.061 / 3.272 / 5.908 (inf 0.0%) | 1.80 | 0.14% | -1.49% | 100.0% |
| N3_DIRECTION_NULL | 1.087 / 3.125 / 3.269 (inf 0.0%) | 2.68 | 0.21% | -1.48% | 100.0% |
| N4_TIMING_SHIFT_NULL | 1.177 / 3.441 / 6.223 (inf 0.0%) | 4.97 | 0.40% | -1.41% | 100.0% |

### Holding-time divergence (a first-class finding)

- Observed strategy mean holding: **31.8 bars (15-min)**.
- Null mean holdings: N1 TIMING NULL: 9 bars; N2 TIMING DIRECTION NULL: 9 bars; N3 DIRECTION NULL: 5 bars; N4 TIMING SHIFT NULL: 10 bars;
- Interpretation: the divergence (in whichever direction it falls) is itself evidence about entry-timing selection. It is NOT sufficient for an edge — the PF/expectancy p-values below decide that — but it is reported transparently because holding-time behaviour feeds back into cost exposure and swap.


### Empirical p-values (Davison–Hinkley)

| family | P(null PF ≥ obs) | P(null exp ≥ obs) | P(null return ≥ obs) | P(null Sharpe ≥ obs) | separated? |
|---|---|---|---|---|---|
| N1_TIMING_NULL | 0.4178 | 0.4115 | 0.4115 | 0.0022 | NO |
| N2_TIMING_DIRECTION_NULL | 0.4240 | 0.4187 | 0.4187 | 0.0030 | NO |
| N3_DIRECTION_NULL | 0.3693 | 0.3693 | 0.3693 | 0.0001 | NO |
| N4_TIMING_SHIFT_NULL | 0.5462 | 0.5376 | 0.5376 | 0.0042 | NO |

### §9 verdict: **EDGE_NOT_ESTABLISHED**

Rule: EDGE requires p_pf<0.05 AND p_expectancy<0.05 AND observed PF > null PF p95 in EVERY family — otherwise EDGE_NOT_ESTABLISHED (§9)

Interpretation: the observed PF does not separate from the trade-count-conditioned chance distribution. With 44 trades (LOW_STATISTICAL_POWER) and bootstrap PF CI95 covering values below 1, the null model CONFIRMS the Phase 66 classification:
**EDGE_NOT_ESTABLISHED** — not because the strategy is proven bad, but because the evidence cannot exclude chance.

## 5. §10 Bootstrap (10,000 resamples)

- PF CI95: 0.238 – 5.389 (median 1.141)
- Expectancy CI95: -34.72 – 54.70
- Total-return CI95: -277.75 – 437.57
- Drawdown distribution: p50 -1.45% / p95 -0.57% / p99 -0.43% / worst -4.25%
- **P(PF ≤ 1) = 0.3807**
- **P(expectancy ≤ 0) = 0.3807**
- Verdict: **EDGE_NOT_ESTABLISHED** — negative intervals are reported, never hidden.

## 6. §11 Cost sensitivity (identical signals, costs scaled)

| scenario | spread× | slippage× | trades | PF | expectancy | net | MaxDD% |
|---|---|---|---|---|---|---|---|
| BASE | 1.0 | 1.0 | 8 | 1.133 | 3.92 | 31.34 | -1.03 |
| 1.25x_spread | 1.25 | 1.0 | 8 | 1.128 | 3.77 | 30.14 | -1.04 |
| 1.5x_spread | 1.5 | 1.0 | 8 | 1.122 | 3.62 | 28.94 | -1.04 |
| 2x_spread | 2.0 | 1.0 | 8 | 1.111 | 3.32 | 26.54 | -1.05 |
| 3x_spread | 3.0 | 1.0 | 8 | 1.090 | 2.72 | 21.74 | -1.06 |
| 1.5x_slippage | 1.0 | 1.5 | 8 | 1.130 | 3.83 | 30.62 | -1.03 |
| 2x_slippage | 1.0 | 2.0 | 8 | 1.126 | 3.74 | 29.89 | -1.04 |
| 3x_slippage | 1.0 | 3.0 | 8 | 1.120 | 3.56 | 28.44 | -1.04 |

- Breakpoint: PF ≤ 1 at **spread ×> 3**, slippage ×> 3.
- Verdict: COST_ROBUST.

## 7. Reproduce

```
python scripts/phase67_null_model_audit.py [--config config_real.yaml] [--null-sims 10000]
```

Seeds are fixed → outputs are reproducible bit-for-bit.

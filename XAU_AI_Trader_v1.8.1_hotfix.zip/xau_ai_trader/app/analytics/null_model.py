"""PHASE 67 (§9) — NULL MODEL / RANDOMIZATION TEST ENGINE.

Investigates the Phase 66 finding ``random baseline p95 PF ≈ 3.15`` rigorously.

Why a proper null matters
-------------------------
The Phase 66 RANDOM baseline frequency-matched the ML gate (≈1.5 % of bars),
which produced a MEDIAN of only ~2 trades per seed. On 1–4 trades the profit
factor is a ratio of two coin-flip outcomes and is extremely heavy-tailed —
the 3.15 p95 was a small-sample artifact, not evidence that chance looks like
a 1.2-PF strategy. The null model below conditions on the ACTUAL strategy's
trade count and long/short mix, which is the comparison the directive demands.

Null families (all share the real strategy's exit machinery)
------------------------------------------------------------
N1 TIMING_NULL            entry timestamps drawn uniformly at random (renewal
                          sampling that never peeks into the future), side
                          multiset = exact permutation of the observed trades
                          (preserves long/short constraints).
N2 TIMING_DIRECTION_NULL  random timestamps, sides i.i.d. Bernoulli(0.5)
                          (relaxes the side mix to a pure coin flip).
N3 DIRECTION_NULL         OBSERVED entry timestamps, sides permuted across
                          trades (isolates directional selection from timing).

Every simulated trade preserves: number of trades (renewal/retry
conditioning), spread, commission, slippage, swap, risk-percent position
sizing, ATR-based SL, min-RR TP, one-position-at-a-time discipline, and the
conservative SL-first both-hit assumption — exits follow the SAME rules as
``app.backtest.engine.Backtester``.

Two implementations of the exit machinery live here:
  ``simulate``            — vectorised numpy (used for the 30,000 null sims)
  ``simulate_loop``       — bar-by-bar reference (used to cross-check)
Both are validated against the real engine (bit-level pnl comparison on the
observed signals) before any null is run.

NO FUTURE INFORMATION: timestamp draws depend only on the tradeable set
(bar timestamps with valid ATR), never on future prices or outcomes.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

NULL_MIN_SIMULATIONS = 10_000


# --------------------------------------------------------------------------
# single-trade simulator (mirrors app/backtest/engine.py exactly)
# --------------------------------------------------------------------------
@dataclass
class SimTrade:
    pnl: float
    fees: float
    swap: float
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp
    entry_price: float
    exit_price: float
    exit_reason: str
    signal_time: pd.Timestamp
    side: str
    volume: float

    @property
    def holding_seconds(self) -> float:
        return (self.exit_time - self.entry_time).total_seconds()


class SingleTradeSimulator:
    """Simulates ONE position at a time under the engine's exact rules.

    Engine semantics mirrored (app/backtest/engine.py):
      * signal on bar j fills at bar j+delay open ± half_spread ± slippage;
      * the entry bar itself is never checked for SL/TP (first check j+delay+1);
      * per bar: ``if hit_sl or force: exit at sl (or mark_close on force)`` /
        ``elif hit_tp: exit at tp`` — a TP touch on the final bar is ignored;
      * v1.8 fixes (three divergences found when the symmetric-label retrain
        changed the trade set — the old trade mix never exposed them):
          1. SL gap-fill: the engine fills at ``min(sl, bar_open − half_spread)``
             for BUY / ``max(sl, bar_open + half_spread)`` for SELL when a bar
             OPENS beyond the stop (weekend/news gap) — the simulator used to
             fill optimistically at the stop level itself;
          2. swap rollover hour: the engine charges at ``swap_hour_utc``
             (default 21:00 = 5pm ET), the simulator charged at MIDNIGHT;
          3. triple swap on the configured weekday and swap on the EXIT bar:
             the engine books the night's swap when a position is open AT the
             rollover instant — including the bar it exits on — and books 3×
             on Wednesday; the simulator excluded the exit bar and had no
             triple-swap day.
      * signals arriving while a position is open are skipped (one-position
        discipline); re-entry on the exit bar itself is allowed (>=).
    """

    def __init__(self, window: pd.DataFrame, *, delay: int, half_spread: np.ndarray,
                 slippage_price: float, tick_size: float, tick_value: float,
                 commission_per_lot: float, swap_long: float, swap_short: float,
                 both_hit_assumption: str = "sl_first",
                 swap_hour_utc: int = 21, triple_swap_weekday: int = 2) -> None:
        self.ts = window.index
        self.open_ = window["open"].to_numpy(float)
        self.high = window["high"].to_numpy(float)
        self.low = window["low"].to_numpy(float)
        self.close = window["close"].to_numpy(float)
        self.hours = np.array([t.hour for t in self.ts], dtype=np.int64)
        self.days = np.array([t.date() for t in self.ts])
        self.weekdays = np.array([t.weekday() for t in self.ts], dtype=np.int64)
        self.hs = np.asarray(half_spread, dtype=float)
        self.delay = max(1, int(delay))
        self.slip = float(slippage_price)
        self.tick_size = float(tick_size)
        self.tick_value = float(tick_value)
        self.commission = float(commission_per_lot)
        self.swap_long = float(swap_long)
        self.swap_short = float(swap_short)
        self.both_hit = both_hit_assumption
        self.swap_hour = int(swap_hour_utc)
        self.triple_swap_weekday = int(triple_swap_weekday)
        n = len(self.open_)
        self.n = n
        # side-adjusted mark arrays (precomputed once)
        self.buy_low = self.low - self.hs
        self.buy_high = self.high - self.hs
        self.buy_close = self.close - self.hs
        self.sell_low = self.low + self.hs
        self.sell_high = self.high + self.hs
        self.sell_close = self.close + self.hs
        # first index (>= start) where a boolean condition holds, -1 if none
        self._day_keys, self._day_idx = np.unique(self.days, return_index=True)

    # ------------------------------------------------------------ vector --
    def simulate(self, entry_j: int, side: str, lot: float, sl: float,
                 tp: float) -> SimTrade | None:
        n = self.n
        if entry_j < 0 or entry_j >= n:
            return None
        if lot <= 0 or not np.isfinite(sl) or not np.isfinite(tp):
            return None
        start = entry_j + 1
        if start >= n:
            return None
        buy = side == "BUY"
        dirn = 1.0 if buy else -1.0
        if buy:
            entry_price = self.open_[entry_j] + self.hs[entry_j] + self.slip
            # BUY: SL touched when spread-adjusted low <= sl; TP when high >= tp
            sl_hits = np.flatnonzero(self.buy_low[start:] <= sl)
            tp_hits = np.flatnonzero(self.buy_high[start:] >= tp)
        else:
            entry_price = self.open_[entry_j] - self.hs[entry_j] - self.slip
            # SELL: SL touched when spread-adjusted high >= sl; TP when low <= tp
            sl_hits = np.flatnonzero(self.sell_high[start:] >= sl)
            tp_hits = np.flatnonzero(self.sell_low[start:] <= tp)
        first_sl = start + int(sl_hits[0]) if len(sl_hits) else -1
        first_tp = start + int(tp_hits[0]) if len(tp_hits) else -1

        last = n - 1
        # v1.8: same-bar tie honours both_hit_assumption exactly like the
        # engine (``tp_first`` flips an SL+TP same-bar tie to TP)
        if first_sl != -1 and first_tp != -1 and first_sl == first_tp:
            if self.both_hit == "tp_first":
                first_sl = -1
            else:
                first_tp = -1
        cands: list[tuple[int, int, str]] = []
        if first_sl != -1:
            cands.append((first_sl, 0, "SL"))       # SL wins ties (engine order)
        if first_tp != -1:
            cands.append((first_tp, 1, "TP"))
        if cands:
            k0, _, reason = min(cands)
            if reason == "TP" and k0 == last:
                # engine force-close bar: TP touch is ignored → mark_close
                exit_k, exit_price, exit_reason = last, (
                    self.buy_close[last] if buy else self.sell_close[last]), "EOD"
            elif reason == "SL":
                exit_k = k0
                # v1.8: engine SL GAP-FILL — when the bar OPENS beyond the
                # stop (weekend/news gap) the fill is the worse open, not sl
                if buy:
                    exit_price = min(sl, self.open_[k0] - self.hs[k0])
                else:
                    exit_price = max(sl, self.open_[k0] + self.hs[k0])
                exit_reason = "SL"
            else:
                exit_k = k0
                exit_price = tp
                exit_reason = "TP"
        else:
            exit_k = last
            exit_price = (self.buy_close[last] if buy else self.sell_close[last])
            exit_reason = "EOD"

        # v1.8: swap at the ENGINE rollover hour (21:00 UTC default), once per
        # calendar day, 3x on the triple-swap weekday, and INCLUDING the exit
        # bar (the engine books the night's swap when the position is open at
        # the rollover instant, even on the bar it exits on).
        seg_days = self.days[start:exit_k + 1]
        seg_hours = self.hours[start:exit_k + 1]
        seg_wd = self.weekdays[start:exit_k + 1]
        rollover = seg_hours == self.swap_hour
        swap = 0.0
        seen_days: set = set()
        for d, w in zip(seg_days[rollover], seg_wd[rollover]):
            if d in seen_days:
                continue
            seen_days.add(d)
            mult = 3 if int(w) == self.triple_swap_weekday else 1
            swap += (self.swap_long if buy else self.swap_short) * lot * mult

        pnl = (exit_price - entry_price) * dirn / self.tick_size \
            * self.tick_value * lot
        return SimTrade(pnl=float(pnl), fees=self.commission * lot, swap=float(swap),
                        entry_time=self.ts[entry_j], exit_time=self.ts[exit_k],
                        entry_price=float(entry_price), exit_price=float(exit_price),
                        exit_reason=exit_reason,
                        signal_time=self.ts[entry_j - self.delay],
                        side=side, volume=float(lot))

    # -------------------------------------------------------- reference --
    def simulate_loop(self, entry_j: int, side: str, lot: float, sl: float,
                      tp: float) -> SimTrade | None:
        """Bar-by-bar reference implementation (slow; used for validation)."""
        n = self.n
        if entry_j < 0 or entry_j >= n:
            return None
        if lot <= 0 or not np.isfinite(sl) or not np.isfinite(tp):
            return None
        buy = side == "BUY"
        dirn = 1.0 if buy else -1.0
        if buy:
            entry_price = self.open_[entry_j] + self.hs[entry_j] + self.slip
        else:
            entry_price = self.open_[entry_j] - self.hs[entry_j] - self.slip

        swap_days: set = set()
        swap = 0.0
        exit_price = None
        exit_reason = ""
        exit_k = None
        for k in range(entry_j + 1, n):
            hs_k = self.hs[k]
            if buy:
                mark_high = self.high[k] - hs_k
                mark_low = self.low[k] - hs_k
                mark_close = self.close[k] - hs_k
                hit_sl = mark_low <= sl
                hit_tp = mark_high >= tp
            else:
                mark_high = self.high[k] + hs_k
                mark_low = self.low[k] + hs_k
                mark_close = self.close[k] + hs_k
                hit_sl = mark_high >= sl
                hit_tp = mark_low <= tp

            is_last = k == n - 1
            if hit_sl or is_last:
                if hit_sl:
                    # v1.8: engine SL gap-fill (bar opens beyond the stop →
                    # worse open fill, not the stop level)
                    if buy:
                        exit_price = min(sl, self.open_[k] - hs_k)
                    else:
                        exit_price = max(sl, self.open_[k] + hs_k)
                    exit_reason = "SL"
                    # v1.8: engine same-bar tie with tp_first → TP
                    if hit_tp and self.both_hit == "tp_first":
                        exit_price = tp
                        exit_reason = "TP"
                else:
                    exit_price = mark_close
                    exit_reason = "EOD"
                exit_k = k
            elif hit_tp:
                exit_price = tp
                exit_reason = "TP"
                exit_k = k

            # v1.8: swap charged on the rollover bar EVEN WHEN the trade exits
            # on it (engine order: update → swap → close), 3x on the
            # triple-swap weekday, once per calendar day.
            if self.hours[k] == self.swap_hour and self.days[k] not in swap_days:
                swap_days.add(self.days[k])
                mult = 3 if int(self.weekdays[k]) == self.triple_swap_weekday else 1
                swap += (self.swap_long if buy else self.swap_short) * lot * mult
            if exit_k is not None:
                break
        if exit_price is None:
            return None
        pnl = (exit_price - entry_price) * dirn / self.tick_size \
            * self.tick_value * lot
        return SimTrade(pnl=float(pnl), fees=self.commission * lot, swap=float(swap),
                        entry_time=self.ts[entry_j], exit_time=self.ts[exit_k],
                        entry_price=float(entry_price), exit_price=float(exit_price),
                        exit_reason=exit_reason,
                        signal_time=self.ts[entry_j - self.delay],
                        side=side, volume=float(lot))

    # -------------------------------------------------------------- run --
    def run_signals(self, signals: pd.DataFrame,
                    use_reference: bool = False) -> list[SimTrade]:
        """Engine-equivalent loop: signals indexed by signal-bar timestamp."""
        out: list[SimTrade] = []
        pos_of = {t: i for i, t in enumerate(self.ts)}
        busy_until = -1
        signals = signals.sort_index()
        fn = self.simulate_loop if use_reference else self.simulate
        for sig_ts, row in signals.iterrows():
            j = pos_of.get(sig_ts)
            if j is None:
                continue
            entry_j = j + self.delay
            # engine allows re-entry on the SAME bar a trade exits (>=)
            if entry_j < self.n and entry_j >= busy_until:
                tr = fn(entry_j, str(row["side"]), float(row["lot"]),
                        float(row["sl"]), float(row["tp"]))
                if tr is not None:
                    out.append(tr)
                    busy_until = self.ts.get_loc(tr.exit_time)
        return out


def validate_simulator(window: pd.DataFrame, signals: pd.DataFrame, *, delay: int,
                       assumed_spread: float, slippage_points: float, point: float,
                       tick_size: float, tick_value: float, commission_per_lot: float,
                       swap_long: float, swap_short: float, both_hit_assumption: str,
                       engine_trades: pd.DataFrame, tol: float = 1e-6,
                       swap_hour_utc: int = 21, triple_swap_weekday: int = 2) -> dict:
    """Validate BOTH simulator implementations against the real Backtester.

    Compares per-trade pnl and exit reasons on the SAME signals; raises
    AssertionError on any mismatch beyond ``tol`` — the null model may never
    rest on an unvalidated simulator. v1.8: the swap-hour / triple-swap
    parameters are explicit so the simulator always mirrors the engine's
    rollover configuration.
    """
    hs = np.full(len(window), assumed_spread / 2.0)
    kwargs = dict(delay=delay, half_spread=hs,
                  slippage_price=slippage_points * point, tick_size=tick_size,
                  tick_value=tick_value, commission_per_lot=commission_per_lot,
                  swap_long=swap_long, swap_short=swap_short,
                  both_hit_assumption=both_hit_assumption,
                  swap_hour_utc=swap_hour_utc,
                  triple_swap_weekday=triple_swap_weekday)
    results: dict = {}
    for name, use_ref in (("vectorised", False), ("reference_loop", True)):
        sim = SingleTradeSimulator(window, **kwargs)
        sim_trades = sim.run_signals(signals, use_reference=use_ref)
        sim_df = pd.DataFrame([t.__dict__ for t in sim_trades])
        if engine_trades.empty and sim_df.empty:
            results[name] = {"matched": 0, "max_abs_pnl_diff": 0.0,
                             "status": "BOTH_EMPTY"}
            continue
        if len(sim_df) != len(engine_trades):
            raise AssertionError(
                f"[{name}] simulator/engine trade-count mismatch: "
                f"sim={len(sim_df)} engine={len(engine_trades)}")
        e = engine_trades.reset_index(drop=True)
        s = sim_df.reset_index(drop=True)
        max_diff = float(np.abs(e["pnl"].to_numpy(float)
                                - s["pnl"].to_numpy(float)).max())
        if max_diff > tol:
            raise AssertionError(f"[{name}] simulator pnl mismatch "
                                 f"{max_diff} > tol {tol}")
        if (e["exit_reason"].to_numpy() != s["exit_reason"].to_numpy()).any():
            raise AssertionError(f"[{name}] simulator exit_reason mismatch")
        results[name] = {"matched": int(len(s)), "max_abs_pnl_diff": max_diff,
                         "status": "VALIDATED"}
    return results


# --------------------------------------------------------------------------
# metrics over a simulated trade list
# --------------------------------------------------------------------------
def sim_metrics(trades: list[SimTrade], initial_balance: float) -> dict:
    if not trades:
        return {"n_trades": 0, "pf": None, "expectancy": 0.0,
                "expectancy_net": 0.0, "total_return_pct": 0.0, "max_dd_pct": 0.0,
                "sharpe_trade": 0.0, "median_holding_min": 0.0}
    pnl = np.array([t.pnl for t in trades], dtype=float)
    net = pnl + np.array([t.swap - t.fees for t in trades])
    wins = pnl[pnl > 0].sum()
    losses = -pnl[pnl < 0].sum()
    pf = float("inf") if losses <= 0 and wins > 0 else (
        0.0 if losses <= 0 else float(wins / losses))
    eq = initial_balance + np.cumsum(pnl)
    peak = np.maximum.accumulate(np.concatenate(([initial_balance], eq)))
    eq_full = np.concatenate(([initial_balance], eq))
    dd = (eq_full - peak) / np.where(peak == 0, np.nan, peak)
    mdd = float(np.nanmin(dd) * 100.0)
    sd = pnl.std(ddof=0)
    holds = np.array([t.holding_seconds for t in trades]) / 60.0
    return {"n_trades": int(len(pnl)), "pf": pf, "expectancy": float(pnl.mean()),
            "expectancy_net": float(net.mean()),
            "total_return_pct": float(pnl.sum() / initial_balance * 100.0),
            "max_dd_pct": mdd,
            "sharpe_trade": float(pnl.mean() / sd) if sd > 0 else 0.0,
            "median_holding_min": float(np.median(holds))}


def empirical_p_value(null_values: np.ndarray, observed: float,
                      alternative: str = "greater") -> float:
    """Davison–Hinkley (1 + #{null beyond obs}) / (1 + N) — conservative."""
    null_values = np.asarray(null_values, dtype=float)
    if alternative == "greater":
        exceed = (null_values >= observed).sum()
    else:
        exceed = (null_values <= observed).sum()
    return float((1 + exceed) / (1 + len(null_values)))


def null_quantiles(null_values: np.ndarray) -> dict:
    v = np.asarray(null_values, dtype=float)
    finite = v[np.isfinite(v)]
    q: dict = {}
    if len(finite):
        q.update({f"p{p}": float(np.percentile(finite, p))
                  for p in (5, 25, 50, 75, 95, 99)})
    q["share_infinite"] = float(np.isinf(v).mean()) if len(v) else 0.0
    return q

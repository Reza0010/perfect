"""PHASE 65 (§9/§10) — Market-period and session performance analytics.

Periods: contiguous bars are grouped into labelled regimes using causal
quantiles of realised volatility plus a directional trend test. Labels:
BULL_TREND / BEAR_TREND / RANGE / HIGH_VOL / LOW_VOL — no period is
pre-assumed good or bad; the data decides (directive §10).

Sessions: ASIA / LONDON / NEW_YORK / LONDON_NEW_YORK_OVERLAP (UTC hours from
config). Trades are attributed to the session of their ENTRY time.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


# --------------------------------------------------------------- periods ---
def label_periods(close: pd.Series, atr_pct: pd.Series,
                  vol_quantiles: tuple[float, float] = (0.25, 0.85),
                  trend_window: int = 50,
                  trend_threshold: float = 0.004) -> pd.Series:
    """Return a per-bar period label series (causal — expanding windows only).

    v1.5 (ML-N7): the vol thresholds used to come from FULL-SAMPLE quantiles
    (look-ahead — early-bar labels depended on future volatility). Thresholds
    are now expanding-quantile shifted by one bar, so each bar's label uses
    only information available up to that bar.
    """
    vol = atr_pct.copy()
    n = len(vol)
    warm = max(50, trend_window // 2)
    lo_s = vol.expanding(min_periods=warm).quantile(vol_quantiles[0]).shift(1)
    hi_s = vol.expanding(min_periods=warm).quantile(vol_quantiles[1]).shift(1)
    lo = float(vol.iloc[:warm].quantile(vol_quantiles[0])) if n else 0.0
    hi = float(vol.iloc[:warm].quantile(vol_quantiles[1])) if n else 0.0
    lo = pd.Series(lo, index=vol.index).where(lo_s.isna(), lo_s)
    hi = pd.Series(hi, index=vol.index).where(hi_s.isna(), hi_s)
    ema = close.ewm(span=trend_window, min_periods=trend_window // 2).mean()
    slope = (ema - ema.shift(trend_window)) / ema.shift(trend_window)

    def _label(i: int) -> str:
        v = vol.iloc[i]
        s = slope.iloc[i]
        if np.isnan(v) or np.isnan(s):
            return "WARMUP"
        if v >= hi.iloc[i]:
            return "HIGH_VOL"
        if v <= lo.iloc[i]:
            return "LOW_VOL"
        if s > trend_threshold:
            return "BULL_TREND"
        if s < -trend_threshold:
            return "BEAR_TREND"
        return "RANGE"

    return pd.Series([_label(i) for i in range(len(close))], index=close.index, name="period")


def segment_summary(labels: pd.Series) -> dict:
    counts = labels.value_counts().to_dict()
    total = max(1, len(labels))
    return {k: {"bars": int(v), "share": round(v / total, 3)} for k, v in sorted(counts.items())}


# -------------------------------------------------------------- sessions ---
def session_of(ts: pd.Timestamp, cfg) -> str:
    """ASIA / LONDON / NEW_YORK / OVERLAP / OFF from UTC hour."""
    h = ts.hour if ts.tzinfo else ts.tz_localize("UTC").hour
    if cfg.ny_start <= h < min(cfg.london_end, cfg.ny_end):
        return "OVERLAP"
    if cfg.london_start <= h < cfg.london_end:
        return "LONDON"
    if cfg.ny_start <= h < cfg.ny_end:
        return "NEW_YORK"
    if cfg.asia_start <= h < cfg.asia_end:
        return "ASIA"
    return "OFF"


def session_breakdown(trades: pd.DataFrame, cfg) -> dict:
    """Per-session metrics from a trades DataFrame with entry_time + pnl."""
    if trades is None or trades.empty or "entry_time" not in trades.columns:
        return {}
    t = trades.copy()
    t["session"] = pd.to_datetime(t["entry_time"], utc=True,
                                  format="mixed").dt.tz_convert("UTC").map(lambda x: session_of(x, cfg))
    out: dict[str, dict] = {}
    for sess, g in t.groupby("session"):
        pnl = g["pnl"].astype(float)
        wins = pnl[pnl > 0]
        losses = pnl[pnl < 0]
        out[sess] = {
            "trades": int(len(g)),
            "win_rate": round(float((pnl > 0).mean()), 3) if len(g) else 0.0,
            "total_pnl": round(float(pnl.sum()), 2),
            "expectancy": round(float(pnl.mean()), 2) if len(g) else 0.0,
            "gross_profit": round(float(wins.sum()), 2),
            "gross_loss": round(float(losses.sum()), 2),
            "profit_factor": round(float(wins.sum() / abs(losses.sum())), 3)
            if losses.sum() < 0 else None,
        }
    return out


def period_breakdown(trades: pd.DataFrame, labels: pd.Series) -> dict:
    """Per-period metrics attributed by entry time."""
    if trades is None or trades.empty or "entry_time" not in trades.columns:
        return {}
    t = trades.copy()
    t["entry_time"] = pd.to_datetime(t["entry_time"], utc=True, format="mixed")
    t["period"] = t["entry_time"].map(
        lambda x: labels.asof(x) if len(labels) else "UNKNOWN")
    out: dict[str, dict] = {}
    for per, g in t.groupby("period"):
        pnl = g["pnl"].astype(float)
        wins = pnl[pnl > 0]
        losses = pnl[pnl < 0]
        out[str(per)] = {
            "trades": int(len(g)),
            "win_rate": round(float((pnl > 0).mean()), 3) if len(g) else 0.0,
            "total_pnl": round(float(pnl.sum()), 2),
            "expectancy": round(float(pnl.mean()), 2) if len(g) else 0.0,
            "profit_factor": round(float(wins.sum() / abs(losses.sum())), 3)
            if losses.sum() < 0 else None,
        }
    return out

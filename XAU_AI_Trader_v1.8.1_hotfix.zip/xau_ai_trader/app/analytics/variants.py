"""PHASE 66 (§7/§13/§17) — Strategy variant signal builder + unified runner.

Every variant (baselines A–G, ablations, cost/stability sweeps) is built by
THIS module and evaluated by THIS backtest wrapper, so all variants share
exactly the same test period, transaction costs, spread, slippage, execution
rules and risk constraints (§7: "No variant may receive special treatment").

Variants:
  BUY_HOLD       directional benchmark (handled by buy_hold_metrics())
  RANDOM         random-signal baseline with matched frequency (seeded)
  ML_ONLY        C
  ML_TECH        D  (ML + technical-alignment gate: EMA200 slope + ADX)
  ML_SMC         E
  ML_SMC_REGIME  F  (primary configuration)
  ML_SMC_REGIME_AI  G (gated real-AI calls; only when credentials exist)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from app.config.schema import Regime

# Relaxed evaluation gate — identical to the Phase 65 sensitivity grid so the
# numbers stay comparable. The PRIMARY (conservative) config produces 0 trades
# (WAIT-first); relaxed gates are for statistical evaluation only.
RELAX_GATE = {"min_ml_confidence": 0.40, "ml_conflict_margin": 0.08, "min_score": 0.40}


def classify_regime(features: pd.DataFrame, i: int, cfg) -> Regime:
    adx = features["adx"].iloc[i]
    if adx >= cfg.regime.adx_trend_min:
        return Regime.TRENDING_BULL if features["di_diff"].iloc[i] > 0 else Regime.TRENDING_BEAR
    if features["atr_pct"].iloc[i] >= cfg.regime.high_vol_atr_pct:
        return Regime.HIGH_VOLATILITY
    if features["atr_pct"].iloc[i] <= cfg.regime.low_vol_atr_pct:
        return Regime.LOW_VOLATILITY
    return Regime.RANGING


@dataclass
class VariantContext:
    cfg: object
    dataset: pd.DataFrame            # cleaned feature frame (index = signal ts)
    probs_all: np.ndarray            # bundle.average_proba over dataset rows
    features: pd.DataFrame           # raw feature frame (base-TF aligned)
    smc_bias: pd.Series              # SMC directional bias on base TF
    atr: pd.Series                   # ATR reindexed to dataset index
    close: pd.Series                 # close reindexed to dataset index
    base: pd.DataFrame               # base-TF OHLC frame
    info: object                     # SymbolInfo
    news_risk: object = None


def build_variant_signals(
    ctx: VariantContext,
    variant: str,
    test_ts: pd.DatetimeIndex,
    *,
    min_ml_conf: float | None = None,
    margin: float | None = None,
    min_score: float | None = None,
    atr_sl_mult: float | None = None,
    min_rr: float | None = None,
    rng: np.random.Generator | None = None,
    every_n: int = 5,
) -> pd.DataFrame:
    cfg = ctx.cfg
    mlc = RELAX_GATE["min_ml_confidence"] if min_ml_conf is None else min_ml_conf
    marg = RELAX_GATE["ml_conflict_margin"] if margin is None else margin
    msc = RELAX_GATE["min_score"] if min_score is None else min_score
    sl_mult = cfg.risk.atr_sl_mult if atr_sl_mult is None else atr_sl_mult
    rr = cfg.risk.min_rr if min_rr is None else min_rr

    from app.risk.sizing import calc_lot
    from app.signals.ensemble import SignalEnsemble

    if variant == "RANDOM":
        if rng is None:
            rng = np.random.default_rng(2026)
        idx, rows = [], []
        for ts in test_ts[::every_n]:
            if rng.random() < 0.985:           # frequency matched to ML gate pass-rate
                continue
            side = "BUY" if rng.random() < 0.5 else "SELL"
            a = ctx.atr.loc[ts] if ts in ctx.atr.index else np.nan
            if np.isnan(a) or a <= 0:
                continue
            entry = float(ctx.close.loc[ts])
            sgn = 1.0 if side == "BUY" else -1.0
            sl = entry - sgn * sl_mult * float(a)
            dist = abs(entry - sl)
            lot = calc_lot(cfg.backtest.initial_balance, cfg.risk.risk_percent, dist, ctx.info)
            if lot <= 0:
                continue
            idx.append(ts)
            rows.append({"side": side, "sl": float(sl),
                         "tp": float(entry + sgn * rr * dist), "lot": lot, "score": 0.5})
        return pd.DataFrame(rows, index=pd.DatetimeIndex(idx))

    weights = {"ML_ONLY": (1.0, 0.0, 0.0), "ML_TECH": (1.0, 0.0, 0.0),
               "ML_SMC": (0.70, 0.30, 0.0), "ML_SMC_REGIME": (0.70, 0.30, 0.0),
               "ML_SMC_REGIME_AI": (0.70, 0.30, 0.0)}.get(variant)
    if weights is None:
        raise ValueError(f"unknown variant: {variant}")

    ens_cfg = cfg.ensemble.model_copy(update={
        "ml": weights[0], "smc": weights[1], "ai": weights[2],
        "min_ml_confidence": mlc, "ml_conflict_margin": marg, "min_score": msc})
    ens = SignalEnsemble(ens_cfg)
    news_risk = ctx.news_risk
    idx, rows = [], []
    for ts in test_ts[::every_n]:
        if ts not in ctx.dataset.index:
            continue
        i = ctx.dataset.index.get_loc(ts)
        p = ctx.probs_all[i]
        pos = ctx.base.index.get_indexer([ts], method="nearest")[0]
        regime = classify_regime(ctx.features, pos, cfg)
        if variant in ("ML_SMC_REGIME", "ML_SMC_REGIME_AI") and regime in (
                Regime.HIGH_VOLATILITY, Regime.UNCERTAIN):
            continue
        if variant == "ML_TECH":
            # technical-alignment gate: EMA200 slope & ADX must agree with ML side
            try:
                slope = float(ctx.features["ema200_slope"].iloc[pos])
                adx = float(ctx.features["adx"].iloc[pos])
            except Exception:
                continue
            ml_dir = 1.0 if p[2] >= p[0] else -1.0
            if ml_dir * slope < 0 or adx < 20.0:
                continue
        bias = float(ctx.smc_bias.iloc[pos]) if pos < len(ctx.smc_bias) else 0.0
        d = ens.decide(ml_probs={"ens": np.array([p[0], p[1], p[2]])},
                       smc_bias=bias, regime=regime, news_risk=news_risk)
        if not d.is_actionable:
            continue
        a = ctx.atr.iloc[i]
        if np.isnan(a) or a <= 0:
            continue
        entry = float(ctx.close.iloc[i])
        sgn = 1.0 if d.side == "BUY" else -1.0
        sl = entry - sgn * sl_mult * float(a)
        dist = abs(entry - sl)
        if dist <= 0:
            continue
        lot = calc_lot(cfg.backtest.initial_balance, cfg.risk.risk_percent, dist, ctx.info)
        if lot <= 0:
            continue
        idx.append(ts)
        rows.append({"side": d.side, "sl": float(sl),
                     "tp": float(entry + sgn * rr * dist), "lot": lot,
                     "score": d.score})
    return pd.DataFrame(rows, index=pd.DatetimeIndex(idx))


def run_backtest(ctx: VariantContext, signals: pd.DataFrame, *,
                 spread_multiplier: float = 1.0, slippage_multiplier: float = 1.0,
                 bt_start: pd.Timestamp | None = None):
    """The ONLY backtest entry used by every variant — identical rules/costs."""
    from app.backtest.engine import Backtester

    cfg = ctx.cfg
    bt_start = bt_start or ctx.base.index[max(0, ctx.base.index.get_indexer(
        [ctx.dataset.index[0]], method="nearest")[0] - 100)]
    window = ctx.base[ctx.base.index >= bt_start]
    b = Backtester(cfg.backtest, ctx.info,
                   commission_per_lot=cfg.execution.commission_per_lot,
                   swap_long=cfg.execution.swap_long_per_lot,
                   swap_short=cfg.execution.swap_short_per_lot,
                   slippage_points=cfg.execution.slippage_points * slippage_multiplier,
                   assumed_spread=cfg.backtest.assumed_spread * spread_multiplier)
    return b, b.run(window, signals)


def buy_hold_metrics(ctx: VariantContext, bt_start: pd.Timestamp | None = None) -> dict:
    """Baseline A — Buy & Hold over exactly the same window with the same
    entry costs (spread + commission on one position, no SL/TP)."""
    cfg = ctx.cfg
    bt_start = bt_start or ctx.base.index[max(0, ctx.base.index.get_indexer(
        [ctx.dataset.index[0]], method="nearest")[0] - 100)]
    window = ctx.base[ctx.base.index >= bt_start]
    entry = float(window["open"].iloc[1]) + cfg.backtest.assumed_spread / 2.0
    exit_ = float(window["close"].iloc[-1]) - cfg.backtest.assumed_spread / 2.0
    # 1.0 lot position, same tick math as the engine
    info = ctx.info
    pnl = (exit_ - entry) / info.tick_size * info.tick_value * 1.0
    commission = cfg.execution.commission_per_lot
    net = pnl - commission
    eq = window["close"].iloc[1:].apply(
        lambda px: cfg.backtest.initial_balance
        + (px - entry) / info.tick_size * info.tick_value * 1.0)
    # margin reality: a fixed 1-lot position on a small account cannot draw
    # below zero equity — the broker would force-liquidate first. Truncate at
    # the first equity breach and flag it (§7 "where meaningful").
    breach = eq[eq <= 0]
    margin_note = None
    if len(breach):
        eq = eq.loc[:breach.index[0]]
        margin_note = ("equity path truncated at first margin-call breach "
                       f"({breach.index[0]}); a real account would be liquidated there")
    from app.analytics.statistics import (full_metrics, max_drawdown_from_pnl,
                                          sample_size_warning)
    m = full_metrics(pd.DataFrame({
        "pnl": [net], "fees": [commission], "swap": [0.0], "volume": [1.0],
        "entry_time": [window.index[1]], "exit_time": [window.index[-1]]}),
        eq, cfg.backtest.initial_balance)
    m["sample_warning"] = "NOT_APPLICABLE_SINGLE_POSITION"
    m["max_drawdown_pct"] = max_drawdown_from_pnl(np.diff(eq.values, prepend=eq.values[0]),
                                                  cfg.backtest.initial_balance)
    if margin_note:
        m["margin_note"] = margin_note
    return m


def random_baseline_distribution(ctx: VariantContext, test_ts: pd.DatetimeIndex,
                                 n_seeds: int = 200, bt_start: pd.Timestamp | None = None) -> dict:
    """Baseline B — random signals, SAME window/costs/risk; distribution of PF
    over seeds quantifies what pure chance delivers."""
    pfs, exps, trades = [], [], []
    for seed in range(n_seeds):
        rng = np.random.default_rng(10_000 + seed)
        sig = build_variant_signals(ctx, "RANDOM", test_ts, rng=rng)
        _, res = run_backtest(ctx, sig, bt_start=bt_start)
        tdf = res.trades_df()
        pnl = tdf["pnl"].values if not tdf.empty else np.array([])
        pf = _pf(pnl)
        pfs.append(pf if np.isfinite(pf) else 0.0)
        exps.append(float(pnl.mean()) if len(pnl) else 0.0)
        trades.append(len(pnl))
    pfs_a = np.array(pfs)
    return {
        "n_seeds": n_seeds,
        "pf_median": float(np.median(pfs_a)), "pf_p95": float(np.percentile(pfs_a, 95)),
        "pf_max": float(pfs_a.max()),
        "prob_random_pf_gt_1": float((pfs_a > 1.0).mean()),
        "expectancy_median": float(np.median(exps)),
        "trades_median": float(np.median(trades)),
        "note": "chance-level performance under identical costs — any claimed edge "
                "must clear the 95th percentile of this distribution",
    }


def _pf(pnl: np.ndarray) -> float:
    wins = pnl[pnl > 0].sum()
    losses = -pnl[pnl < 0].sum()
    if losses <= 0:
        return float("inf") if wins > 0 else 0.0
    return float(wins / losses)

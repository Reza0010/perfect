"""PHASE 66 (§8/§9/§10/§18) — Statistical audit engine.

Purpose: determine whether observed backtest results are statistically
defensible. This module NEVER manufactures an edge; it quantifies uncertainty
and refuses to certify profitability when the evidence does not support it.

Sections:
  §8  full_metrics()            — every metric required by the directive
  §9  bootstrap_analysis()      — >=10k resamples, 95% CIs, EDGE_NOT_ESTABLISHED
  §10 sample_size_warning()     — SAMPLE_TOO_SMALL .. ACCEPTABLE_FOR_PRELIMINARY
  §18 monte_carlo_sequences()   — >=10k trade-sequence simulations (downside)

NO PROFIT CLAIMS: all outputs are measurements with uncertainty attached.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

BOOTSTRAP_MIN_RESAMPLES = 10_000
MONTECARLO_MIN_RUNS = 10_000


# --------------------------------------------------------------------- §10 --
def sample_size_warning(n_trades: int) -> str:
    """Research warnings per §10. These are NOT guarantees of validity."""
    if n_trades < 30:
        return "SAMPLE_TOO_SMALL"
    if n_trades < 100:
        return "LOW_STATISTICAL_POWER"
    if n_trades < 300:
        return "MODERATE_SAMPLE"
    return "ACCEPTABLE_FOR_PRELIMINARY_ANALYSIS"


# ---------------------------------------------------------------------- §8 --
def _profit_factor(pnl: np.ndarray) -> float:
    wins = pnl[pnl > 0].sum()
    losses = -pnl[pnl < 0].sum()
    if losses <= 0:
        return float("inf") if wins > 0 else 0.0
    return float(wins / losses)


def max_drawdown_from_pnl(pnl: np.ndarray, initial_balance: float = 10_000.0) -> float:
    """Max drawdown (%) over the trade sequence (compounded on balance)."""
    eq = initial_balance + np.cumsum(pnl)
    if len(eq) == 0:
        return 0.0
    peak = np.maximum.accumulate(np.concatenate(([initial_balance], eq)))
    eq_full = np.concatenate(([initial_balance], eq))
    dd = (eq_full - peak) / np.where(peak == 0, np.nan, peak)
    return float(np.nanmin(dd) * 100.0)


def average_drawdown_from_pnl(pnl: np.ndarray, initial_balance: float = 10_000.0) -> float:
    """Mean of the individual drawdown episode depths (%)."""
    eq = initial_balance + np.cumsum(pnl)
    if len(eq) == 0:
        return 0.0
    eq_full = np.concatenate(([initial_balance], eq))
    peak = np.maximum.accumulate(eq_full)
    dd = (eq_full - peak) / np.where(peak == 0, np.nan, peak)
    # drawdown episodes: contiguous runs below 0
    in_dd = dd < 0
    episodes: list[float] = []
    run_min = np.inf
    for v, flag in zip(dd, in_dd):
        if flag:
            run_min = min(run_min, v)
        elif not np.isinf(run_min):
            episodes.append(run_min)
            run_min = np.inf
    if not np.isinf(run_min):
        episodes.append(run_min)
    return float(np.mean(episodes) * 100.0) if episodes else 0.0


def annualization_factor(index: pd.DatetimeIndex | None, bars_per_year: float) -> float:
    if index is not None and len(index) > 1:
        span_years = (index[-1] - index[0]).total_seconds() / (365.25 * 24 * 3600)
        return max(span_years, 1e-9)
    return 1.0 / bars_per_year


def full_metrics(
    trades: pd.DataFrame,
    equity_curve: pd.Series | None,
    initial_balance: float,
    *,
    total_volume_lots: float | None = None,
    spread_cost_estimate: float | None = None,
    slippage_cost_estimate: float | None = None,
) -> dict:
    """§8 — complete metric set. ``trades`` needs columns pnl, fees, swap,
    volume, entry_time, exit_time. Costs not directly observable in the
    trade ledger are reported as explicit estimates or 0-with-source note."""
    pnl = trades["pnl"].astype(float).values if not trades.empty and "pnl" in trades else np.array([])
    wins = pnl[pnl > 0]
    losses = pnl[pnl < 0]
    gross_profit = float(wins.sum()) if len(wins) else 0.0
    gross_loss = float(-losses.sum()) if len(losses) else 0.0
    pf = _profit_factor(pnl)

    if equity_curve is not None and len(equity_curve) > 1:
        daily_eq = equity_curve.resample("1D").last().dropna()
        daily_ret = daily_eq.pct_change().dropna()
        span_years = max((equity_curve.index[-1] - equity_curve.index[0]).total_seconds()
                         / (365.25 * 24 * 3600), 1e-9)
    else:
        daily_ret = pd.Series(dtype=float)
        span_years = 1.0

    rf = 0.0
    sharpe = float(daily_ret.mean() / daily_ret.std(ddof=0) * np.sqrt(365.25)) \
        if len(daily_ret) > 1 and daily_ret.std(ddof=0) > 0 else 0.0
    downside = daily_ret[daily_ret < 0]
    sortino = float(daily_ret.mean() / downside.std(ddof=0) * np.sqrt(365.25)) \
        if len(downside) > 1 and downside.std(ddof=0) > 0 else 0.0
    total_return_pct = float(pnl.sum() / initial_balance * 100.0) if len(pnl) else 0.0
    ann_return_pct = total_return_pct / span_years if span_years > 0 else 0.0
    mdd = max_drawdown_from_pnl(pnl, initial_balance)
    calmar = float(ann_return_pct / abs(mdd)) if mdd < 0 else 0.0

    hold = None
    exposure = 0.0
    if not trades.empty and {"entry_time", "exit_time"} <= set(trades.columns):
        hold = (pd.to_datetime(trades["exit_time"], utc=True)
                - pd.to_datetime(trades["entry_time"], utc=True)).dt.total_seconds()
        if equity_curve is not None and len(equity_curve) > 1:
            total_span = (equity_curve.index[-1] - equity_curve.index[0]).total_seconds()
            exposure = float(hold.sum() / total_span) if total_span > 0 else 0.0

    commission = float(trades["fees"].sum()) if "fees" in trades else 0.0
    swap = float(trades["swap"].sum()) if "swap" in trades else 0.0

    return {
        "n_trades": int(len(pnl)),
        "win_rate_pct": float((pnl > 0).mean() * 100.0) if len(pnl) else 0.0,
        "avg_win": float(wins.mean()) if len(wins) else 0.0,
        "avg_loss": float(losses.mean()) if len(losses) else 0.0,
        "expectancy": float(pnl.mean()) if len(pnl) else 0.0,
        "profit_factor": pf,
        "gross_profit": gross_profit,
        "gross_loss": gross_loss,
        "net_profit": float(pnl.sum()) if len(pnl) else 0.0,
        "max_drawdown_pct": mdd,
        "average_drawdown_pct": average_drawdown_from_pnl(pnl, initial_balance),
        "sharpe": sharpe,
        "sortino": sortino,
        "calmar": calmar,
        "payoff_ratio": float(abs(wins.mean() / losses.mean())) if len(wins) and len(losses) and losses.mean() != 0 else None,
        "exposure": exposure,
        "avg_holding_hours": float(hold.mean() / 3600.0) if hold is not None and len(hold) else 0.0,
        "median_holding_hours": float(hold.median() / 3600.0) if hold is not None and len(hold) else 0.0,
        "turnover_lots": float(trades["volume"].sum()) if "volume" in trades and not trades.empty else (total_volume_lots or 0.0),
        "commission": commission,
        "spread_cost_estimate": spread_cost_estimate,
        "slippage_cost_estimate": slippage_cost_estimate,
        "swap": swap,
        "span_years": span_years,
        "annualised_return_pct": ann_return_pct,
        "sample_warning": sample_size_warning(int(len(pnl))),
    }


# ---------------------------------------------------------------------- §9 --
@dataclass
class BootstrapResult:
    n_resamples: int
    pf_ci95: tuple[float | None, float | None]
    expectancy_ci95: tuple[float, float]
    total_return_ci95: tuple[float, float]
    maxdd_ci95: tuple[float, float]
    prob_loss: float
    prob_pf_le_1: float
    median_pf: float | None
    median_expectancy: float
    verdict: str  # EDGE_ESTABLISHED / EDGE_NOT_ESTABLISHED / INSUFFICIENT_DATA
    reasons: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "n_resamples": self.n_resamples,
            "pf_ci95": self.pf_ci95,
            "expectancy_ci95": self.expectancy_ci95,
            "total_return_ci95": self.total_return_ci95,
            "maxdd_ci95": self.maxdd_ci95,
            "prob_loss": self.prob_loss,
            "prob_pf_le_1": self.prob_pf_le_1,
            "median_pf": self.median_pf,
            "median_expectancy": self.median_expectancy,
            "verdict": self.verdict,
            "reasons": self.reasons,
        }


def bootstrap_analysis(
    pnl: np.ndarray,
    n_resamples: int = BOOTSTRAP_MIN_RESAMPLES,
    initial_balance: float = 10_000.0,
    seed: int = 2026,
) -> BootstrapResult:
    """§9 — percentile bootstrap over trade P&L (i.i.d. resampling with
    replacement). The sequence within each resample is the sampled order,
    so drawdown percentiles reflect ordering uncertainty as well."""
    pnl = np.asarray(pnl, dtype=float)
    if n_resamples < BOOTSTRAP_MIN_RESAMPLES:
        raise ValueError(f"directive requires >= {BOOTSTRAP_MIN_RESAMPLES} resamples")
    if len(pnl) == 0:
        return BootstrapResult(n_resamples, None, (0.0, 0.0), (0.0, 0.0), (0.0, 0.0),
                               0.0, 1.0, None, 0.0, "INSUFFICIENT_DATA",
                               ["no trades — nothing to certify"])
    rng = np.random.default_rng(seed)
    n = len(pnl)
    idx = rng.integers(0, n, size=(n_resamples, n))
    samples = pnl[idx]                                   # (R, n)

    with np.errstate(divide="ignore", invalid="ignore"):
        wins = np.where(samples > 0, samples, 0.0).sum(axis=1)
        loss = np.where(samples < 0, -samples, 0.0).sum(axis=1)
    pf = np.where(loss > 0, wins / np.where(loss == 0, 1.0, loss), np.inf)
    pf_finite = pf[np.isfinite(pf)]
    pf_ci = (float(np.percentile(pf_finite, 2.5)), float(np.percentile(pf_finite, 97.5))) \
        if len(pf_finite) else (None, None)

    exp = samples.mean(axis=1)
    tot = samples.sum(axis=1)

    # drawdown per resample: vectorised cumulative path
    eq = initial_balance + np.cumsum(samples, axis=1)
    eq = np.hstack([np.full((n_resamples, 1), initial_balance), eq])
    peak = np.maximum.accumulate(eq, axis=1)
    dd = (eq - peak) / np.where(peak == 0, np.nan, peak)
    mdd = np.nanmin(dd, axis=1) * 100.0

    prob_loss = float((exp < 0).mean())
    prob_pf_le_1 = float((pf <= 1.0).mean())
    reasons: list[str] = []
    expectancy_ci = (float(np.percentile(exp, 2.5)), float(np.percentile(exp, 97.5)))
    return_ci = (float(np.percentile(tot, 2.5)), float(np.percentile(tot, 97.5)))
    mdd_ci = (float(np.percentile(mdd, 2.5)), float(np.percentile(mdd, 97.5)))

    verdict = "EDGE_ESTABLISHED"
    if expectancy_ci[0] <= 0.0:
        verdict = "EDGE_NOT_ESTABLISHED"
        reasons.append("95% expectancy CI includes zero")
    if pf_ci[0] is None or pf_ci[0] <= 1.0:
        verdict = "EDGE_NOT_ESTABLISHED"
        reasons.append("95% PF CI lower bound <= 1")
    if n < 30:
        verdict = "EDGE_NOT_ESTABLISHED"
        reasons.append("SAMPLE_TOO_SMALL (<30 trades) — §10 override")
    if not reasons:
        reasons.append("expectancy CI excludes zero AND PF CI lower bound > 1 "
                       "AND n>=30 — statistical evidence supports a preliminary edge "
                       "(still not a guarantee; §10)")
    return BootstrapResult(
        n_resamples=n_resamples, pf_ci95=pf_ci, expectancy_ci95=expectancy_ci,
        total_return_ci95=return_ci, maxdd_ci95=mdd_ci,
        prob_loss=prob_loss, prob_pf_le_1=prob_pf_le_1,
        median_pf=float(np.median(pf_finite)) if len(pf_finite) else None,
        median_expectancy=float(np.median(exp)), verdict=verdict, reasons=reasons,
    )


# --------------------------------------------------------------------- §18 --
def monte_carlo_sequences(
    pnl: np.ndarray,
    n_runs: int = MONTECARLO_MIN_RUNS,
    initial_balance: float = 10_000.0,
    ruin_pct: float = 20.0,
    seed: int = 2027,
) -> dict:
    """§18 — randomised trade-sequence simulations. Distribution of trades is
    preserved (permutation of the observed P&L set). Used ONLY to understand
    downside uncertainty — never to manufacture profitability."""
    pnl = np.asarray(pnl, dtype=float)
    if n_runs < MONTECARLO_MIN_RUNS:
        raise ValueError(f"directive requires >= {MONTECARLO_MIN_RUNS} runs")
    if len(pnl) == 0:
        return {"n_runs": n_runs, "expected_return": 0.0, "worst_dd_pct": 0.0,
                "dd_p95_pct": 0.0, "dd_p99_pct": 0.0, "max_losing_streak": 0,
                "risk_of_ruin_pct": 0.0, "note": "no trades"}
    rng = np.random.default_rng(seed)
    n = len(pnl)
    sims = np.tile(pnl, (n_runs, 1))
    rng_perm = rng.permuted(sims, axis=1)                # shuffle each row

    eq = initial_balance + np.cumsum(rng_perm, axis=1)
    eq = np.hstack([np.full((n_runs, 1), initial_balance), eq])
    peak = np.maximum.accumulate(eq, axis=1)
    dd = (eq - peak) / np.where(peak == 0, np.nan, peak)
    mdd = np.nanmin(dd, axis=1) * 100.0

    losing = rng_perm < 0
    # losing streak per run
    streaks = np.zeros(n_runs, dtype=int)
    run = np.zeros(n_runs, dtype=int)
    for j in range(n):
        run = np.where(losing[:, j], run + 1, 0)
        streaks = np.maximum(streaks, run)

    ruin = (eq.min(axis=1) <= initial_balance * (1 - ruin_pct / 100.0)).mean() * 100.0
    return {
        "n_runs": n_runs,
        "expected_return": float(rng_perm.mean()),
        "worst_dd_pct": float(mdd.min()),
        "dd_p95_pct": float(np.percentile(mdd, 5)),      # 95th percentile of |DD|
        "dd_p99_pct": float(np.percentile(mdd, 1)),      # 99th percentile of |DD|
        "max_losing_streak": int(streaks.max()),
        "p95_losing_streak": int(np.percentile(streaks, 95)),
        "risk_of_ruin_pct": float(ruin),
        "ruin_definition": f"equity touches -{ruin_pct}% of initial balance at any point",
        "purpose": "downside uncertainty only — NOT used to manufacture profitability (§18)",
    }

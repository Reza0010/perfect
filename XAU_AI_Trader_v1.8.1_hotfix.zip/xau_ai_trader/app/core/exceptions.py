"""Exception hierarchy for the trading system.

Every subsystem raises a subclass of TradingSystemError so the top-level
orchestrator can handle failures deterministically without bare excepts.
"""


class TradingSystemError(Exception):
    """Base class for all trading-system errors."""


# --- Configuration -------------------------------------------------------
class ConfigError(TradingSystemError):
    """Invalid or inconsistent configuration."""


# --- Data layer ----------------------------------------------------------
class DataError(TradingSystemError):
    """Generic data-layer failure."""


class ProviderConnectionError(DataError):
    """Market-data provider (e.g. MT5) connection failure."""


class SymbolNotFoundError(DataError):
    """Requested symbol could not be resolved via discovery."""


class DataQualityError(DataError):
    """Data quality below the configured threshold."""


class StorageError(DataError):
    """Persistence failure (database / parquet)."""


# --- Features / models ---------------------------------------------------
class FeatureError(TradingSystemError):
    """Feature-engineering failure."""


class ModelError(TradingSystemError):
    """Base ML-model error."""


class ModelNotTrainedError(ModelError):
    """Model requested before training / registration."""


class LeakageError(ModelError):
    """A data-leakage audit check failed — training/inference must stop."""


class CalibrationError(ModelError):
    """Probability calibration failure."""


# --- AI layer ------------------------------------------------------------
class AIProviderError(TradingSystemError):
    """Base AI-provider error."""


class AITimeoutError(AIProviderError):
    """Provider timed out."""


class AIRateLimitError(AIProviderError):
    """Provider returned HTTP 429."""


class AIServerError(AIProviderError):
    """Provider returned 5xx / transport error."""


class AIInvalidResponseError(AIProviderError):
    """Provider returned malformed / schema-invalid output."""


class AIUnavailableError(AIProviderError):
    """All providers exhausted — gateway enters SAFE MODE."""


# --- Risk / execution ----------------------------------------------------
class RiskLimitError(TradingSystemError):
    """Risk engine rejected the trade (reason codes attached)."""


class KillSwitchActive(TradingSystemError):
    """Kill switch is engaged — trading disabled."""


class ExecutionError(TradingSystemError):
    """Order execution failure."""


class OrderRejectedError(ExecutionError):
    """Broker rejected the order (retcode attached)."""


class AmbiguousOrderError(ExecutionError):
    """Order outcome UNKNOWN (timeout / connection lost mid-request).

    The order MAY exist broker-side. Callers must reconcile orders/deals/
    positions before sending anything else — blind retry duplicates risk.
    """


class InsufficientMarginError(ExecutionError):
    """Not enough free margin for the order."""


# --- Journal / notifications ---------------------------------------------
class JournalError(TradingSystemError):
    """Trade-journal persistence failure."""


class NotificationError(TradingSystemError):
    """Notification delivery failure (never fatal to the trading loop)."""

"""Core cross-cutting concerns: logging, exceptions, security helpers."""

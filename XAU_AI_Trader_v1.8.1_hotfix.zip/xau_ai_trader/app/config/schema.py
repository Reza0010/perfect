"""Pydantic v2 configuration schema.

Every important parameter is configurable (PHASE 62 — no magic numbers).
Secrets are NEVER stored here — only the *names* of environment variables.
"""

from __future__ import annotations

from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------- enums ---
class TradingMode(str, Enum):
    BACKTEST = "backtest"
    PAPER = "paper"
    LIVE = "live"


class Timeframe(str, Enum):
    M1 = "M1"
    M5 = "M5"
    M15 = "M15"
    M30 = "M30"
    H1 = "H1"
    H4 = "H4"
    D1 = "D1"

    @property
    def minutes(self) -> int:
        return _TF_MINUTES[self.value]


_TF_MINUTES = {"M1": 1, "M5": 5, "M15": 15, "M30": 30, "H1": 60, "H4": 240, "D1": 1440}

# MetaTrader5 timeframe constants (kept here so the MT5 package is optional)
MT5_TF_CODE = {"M1": 1, "M5": 5, "M15": 15, "M30": 30, "H1": 16385, "H4": 16388, "D1": 16408}


class SLMethod(str, Enum):
    ATR = "ATR"
    STRUCTURE = "STRUCTURE"
    SWING = "SWING"
    ORDER_BLOCK = "ORDER_BLOCK"
    FIXED = "FIXED"


class TPMethod(str, Enum):
    RR = "RR"
    ATR = "ATR"
    LIQUIDITY = "LIQUIDITY"
    STRUCTURE = "STRUCTURE"


class NewsRisk(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    UNKNOWN = "UNKNOWN"


class Regime(str, Enum):
    TRENDING_BULL = "TRENDING_BULL"
    TRENDING_BEAR = "TRENDING_BEAR"
    RANGING = "RANGING"
    HIGH_VOLATILITY = "HIGH_VOLATILITY"
    LOW_VOLATILITY = "LOW_VOLATILITY"
    UNCERTAIN = "UNCERTAIN"


class HealthStatus(str, Enum):
    NORMAL = "NORMAL"
    WARNING = "WARNING"
    SAFE_MODE = "SAFE_MODE"
    DISABLED = "DISABLED"


# ------------------------------------------------------------- sections ---
class LoggingConfig(BaseModel):
    level: str = "INFO"
    json_mode: bool = False


class PathsConfig(BaseModel):
    data_dir: str = "data"
    models_dir: str = "models"
    reports_dir: str = "reports"
    logs_dir: str = "logs"


class SymbolConfig(BaseModel):
    primary: str = "XAUUSD"
    aliases: list[str] = Field(
        default_factory=lambda: ["XAUUSDm", "XAUUSD.", "GOLD", "GOLDm", "XAUUSD.a", "XAUUSD#"]
    )
    fallback_symbol_info: "SymbolInfoDefaults" = Field(default_factory=lambda: SymbolInfoDefaults())


class SymbolInfoDefaults(BaseModel):
    """Deterministic defaults used only when a provider cannot supply them."""

    digits: int = 2
    point: float = 0.01
    tick_size: float = 0.01
    tick_value: float = 1.0
    contract_size: float = 100.0
    volume_min: float = 0.01
    volume_max: float = 100.0
    volume_step: float = 0.01
    leverage: int = 100


class MT5Config(BaseModel):
    login_env: str = "MT5_LOGIN"
    password_env: str = "MT5_PASSWORD"
    server: str | None = None
    terminal_path: str | None = None
    server_utc_offset_hours: float = 0.0
    timeout_seconds: int = 60
    retry_attempts: int = 3
    retry_backoff_seconds: float = 2.0
    # v1.4: deviation in points for market orders. None => spread-aware
    # (max(10, 2x current spread)). Explicit config wins when set.
    deviation_points: int | None = None


class ProviderConfig(BaseModel):
    """Which market-data provider to use when MT5 is unavailable.

    v1.7 ``public``: REAL live prices from free public sources (Yahoo Finance
    COMEX GC=F + gold-api spot) — no MT5 and no API keys required."""

    kind: Literal["mt5", "simulated", "replay", "public"] = "simulated"
    simulated_days: int = 150
    simulated_seed: int = 42
    simulated_start_price: float = 2350.0
    simulated_annual_vol: float = 0.16
    # --- v1.7 live public provider ---
    public_symbol: str = "GC=F"          # Yahoo symbol (COMEX gold futures)
    public_refresh_seconds: float = 30.0  # background refresh cadence
    public_spread_points: float = 30.0    # DOCUMENTED ASSUMPTION (30 pt = $0.30)
    public_timeout_seconds: float = 15.0  # per-HTTP-request timeout
    # --- v1.7.1 broker alignment ---
    # public_price_offset ($, added to EVERY public price: candles + ticks) aligns
    # the free COMEX proxy with the user's broker price level. Set manually or via
    # the panel "Calibrate from broker" button. 0.0 = raw proxy, fully honest.
    public_price_offset: float = 0.0
    # Panel feed priority: "auto" = broker tick when MT5 reachable, else public;
    # "broker" = broker only (public fallback labelled); "public" = never touch MT5.
    price_source_mode: Literal["auto", "broker", "public"] = "auto"


class MultiTimeframeConfig(BaseModel):
    base: Timeframe = Timeframe.M5
    execution: Timeframe = Timeframe.M1
    structure: Timeframe = Timeframe.H1
    macro: Timeframe = Timeframe.H4
    setup: Timeframe = Timeframe.M15
    enabled: list[Timeframe] = Field(
        default_factory=lambda: [
            Timeframe.M1, Timeframe.M5, Timeframe.M15, Timeframe.M30, Timeframe.H1, Timeframe.H4, Timeframe.D1,
        ]
    )
    bars: dict[str, int] = Field(
        default_factory=lambda: {"M1": 2000, "M5": 4000, "M15": 3000, "M30": 2000, "H1": 2000, "H4": 1500, "D1": 500}
    )


class DataQualityConfig(BaseModel):
    min_score: float = Field(default=70.0, ge=0, le=100)
    max_gap_factor: float = 3.0
    spread_anomaly_z: float = 6.0
    max_spread_points: float = 60.0  # in points (point = symbol point)
    stale_after_bars: int = 3
    fail_streak_limit: int = 5


class SessionsConfig(BaseModel):
    asia_start: int = 0
    asia_end: int = 8
    london_start: int = 7
    london_end: int = 16
    ny_start: int = 12
    ny_end: int = 21
    allowed_sessions: list[str] = Field(default_factory=lambda: ["asia", "london", "newyork", "overlap"])


class IndicatorConfig(BaseModel):
    ema_periods: list[int] = Field(default_factory=lambda: [9, 20, 50, 100, 200])
    sma_period: int = 50
    rsi_period: int = 14
    macd_fast: int = 12
    macd_slow: int = 26
    macd_signal: int = 9
    atr_period: int = 14
    bollinger_period: int = 20
    bollinger_std: float = 2.0
    stochastic_k: int = 14
    stochastic_d: int = 3
    adx_period: int = 14
    roc_period: int = 10
    realized_vol_windows: list[int] = Field(default_factory=lambda: [20, 60])


class FeatureConfig(BaseModel):
    version_tag: str = "v1"
    momentum_windows: list[int] = Field(default_factory=lambda: [1, 5, 10])
    swing_lookback: int = 3
    structure_recent_bars: int = 24
    event_recent_bars: int = 20


class SMCConfig(BaseModel):
    swing_left: int = 3
    swing_right: int = 3
    equal_levels_atr_tolerance: float = 0.10
    fvg_min_atr: float = 0.25
    ob_max_lookback: int = 10
    displacement_body_atr: float = 1.2
    displacement_range_atr: float = 1.6
    sweep_recent_bars: int = 12
    premium_discount_lookback: int = 120
    min_event_strength: float = 0.05


class LabelConfig(BaseModel):
    method: Literal["triple_barrier"] = "triple_barrier"
    horizon_bars: int = 48
    tp_atr_mult: float = 2.0
    sl_atr_mult: float = 1.0
    ambiguous: Literal["zero", "sl_first"] = "zero"


class LGBMParams(BaseModel):
    n_estimators: int = 400
    learning_rate: float = 0.03
    num_leaves: int = 31
    max_depth: int = -1
    min_child_samples: int = 40
    subsample: float = 0.8
    colsample_bytree: float = 0.8
    reg_lambda: float = 1.0
    early_stopping_rounds: int = 50


class XGBParams(BaseModel):
    n_estimators: int = 400
    learning_rate: float = 0.03
    max_depth: int = 5
    min_child_weight: int = 5
    subsample: float = 0.8
    colsample_bytree: float = 0.8
    reg_lambda: float = 1.0
    early_stopping_rounds: int = 50


class RegimeConfig(BaseModel):
    adx_trend_min: float = 22.0
    high_vol_atr_pct: float = 0.0035
    low_vol_atr_pct: float = 0.0008
    use_hmm: bool = True
    hmm_override_conf: float = 0.8


class HMMConfig(BaseModel):
    enabled: bool = True
    n_states: int = 4
    n_iter: int = 200
    random_state: int = 7
    min_bars_to_train: int = 2000


class CalibrationConfig(BaseModel):
    method: Literal["isotonic", "platt"] = "isotonic"
    min_validation_samples: int = 150


class ValidationConfig(BaseModel):
    n_splits: int = 5
    purge_bars: int = 64
    embargo_bars: int = 64
    train_ratio: float = 0.70
    val_ratio: float = 0.15
    walk_forward_train_bars: int = 12000
    walk_forward_val_bars: int = 2000
    walk_forward_test_bars: int = 2000
    walk_forward_step_bars: int = 2000
    # v1.5 (Mission 8/30): minimum acceptable out-of-sample fold count for a
    # walk-forward run to be considered evidence; runs with fewer folds fail.
    min_oos_folds: int = 3  # raised to 8 by release criteria when data allows
    # v1.5 (Mission 6): executable-fill labeling cost model (PRICE units)
    label_spread_price: float = 0.30
    label_slippage_price: float = 0.05
    label_commission_price: float = 0.0


class DatasetConfig(BaseModel):
    min_rows: int = 3000
    scaler: Literal["standard", "robust", "none"] = "robust"


class EnsembleWeights(BaseModel):
    ml: float = 0.45
    smc: float = 0.25
    ai: float = 0.30
    min_score: float = 0.55
    min_ml_confidence: float = 0.55
    ml_conflict_margin: float = 0.15
    smc_conflict_margin: float = 0.30


class AIProviderSettings(BaseModel):
    name: str
    enabled: bool = True
    api_key_env: str
    base_url: str | None = None
    model: str | None = None
    timeout_seconds: float = 30.0
    temperature: float = 0.1
    max_tokens: int = 512
    max_requests_per_day: int = 300
    extra_headers_env: str | None = None
    """Name of an env var holding a JSON object of EXTRA HTTP headers
    (e.g. gateway tokens). Secrets stay in the environment — never in code
    or config files (PHASE 65 §12)."""


class RateLimitConfig(BaseModel):
    """PHASE 67 §14 — AI rate limiting (opt-in; None = legacy behaviour).

    v1.7: ``rate_limit_cooldown_s`` — after a 429/timeout/5xx the provider is
    parked for this long WITHOUT any HTTP call (the gateway skips it), so a
    rate-limited provider is no longer hammered every poll cycle and each
    cooldown skip is not counted as a fresh AI failure by the kill switch."""
    enabled: bool = True
    max_retries: int = 2
    backoff_base_s: float = 0.2
    backoff_cap_s: float = 2.0
    min_interval_s: float = 0.0
    circuit_failure_threshold: int = 5
    circuit_reset_timeout_s: float = 60.0
    rate_limit_cooldown_s: float = 120.0
    journal_path: str | None = None


class AIConfig(BaseModel):
    enabled: bool = True
    require_ai_for_trade: bool = True
    providers: list[AIProviderSettings] = Field(default_factory=list)
    failover_order: list[str] = Field(default_factory=list)
    cache_ttl_seconds: int = 300
    cache_min_state_change: float = 0.0
    max_context_chars: int = 6000
    cost_daily_limit_usd: float = 5.0
    estimated_cost_per_1k_tokens: float = 0.003
    on_all_fail: Literal["WAIT", "PROCEED_WITHOUT_AI"] = "WAIT"
    rate_limit: RateLimitConfig | None = None
    """PHASE 67 §14 — when set, the gateway applies exponential backoff,
    request pacing, retry limits, a per-provider circuit breaker and an
    append-only AI request journal. All providers failing still → WAIT."""


class RiskConfig(BaseModel):
    risk_percent: float = 0.5
    max_risk_percent: float = 1.0
    max_lot: float = 5.0
    max_daily_loss_percent: float = 2.0
    max_drawdown_percent: float = 10.0
    max_spread_points: float = 60.0
    max_open_positions: int = 1
    max_open_risk_percent: float = 1.0
    # v1.4 §0: explicit AI-proofing flags. The AI layer is an analyst only —
    # these default False everywhere and the risk engine never accepts risk
    # parameters from AI output (see app/ai/gateway + trader.py).
    ai_can_change_risk: bool = False
    ai_can_change_lot: bool = False
    ai_can_change_sl: bool = False
    ai_can_change_tp: bool = False
    ai_can_override_risk: bool = False
    sl_method: SLMethod = SLMethod.ATR
    tp_method: TPMethod = TPMethod.RR
    atr_sl_mult: float = 1.5
    structure_sl_buffer_atr: float = 0.2
    fixed_sl_points: float = 300.0
    min_rr: float = 2.0
    max_sl_atr_distance: float = 4.0
    min_ml_confidence: float = 0.55
    min_ai_confidence: float = 0.55
    allowed_regimes: list[Regime] = Field(
        default_factory=lambda: [
            Regime.TRENDING_BULL, Regime.TRENDING_BEAR, Regime.RANGING,
        ]
    )
    block_on_high_news: bool = True
    block_on_low_data_quality: bool = True
    min_data_quality: float = 70.0
    margin_usage_max_pct: float = 50.0


class KillSwitchConfig(BaseModel):
    enabled: bool = True
    max_daily_loss_percent: float = 2.0
    max_drawdown_percent: float = 10.0
    max_consecutive_execution_failures: int = 3
    max_consecutive_data_errors: int = 5
    max_consecutive_ai_failures: int = 12
    abnormal_move_atr: float = 6.0
    abnormal_spread_points: float = 200.0
    auto_reset_after_minutes: int | None = None
    state_file: str = "logs/kill_switch_state.json"


class ExecutionConfig(BaseModel):
    mode: TradingMode = TradingMode.PAPER
    live_trading_enabled: bool = False
    live_confirm_env: str = "LIVE_CONFIRM"
    # v1.4 §24: demo order_send only after BOTH an explicit CLI --send flag
    # AND this config flag are set, AND the account verifies as DEMO.
    demo_send_enabled: bool = False
    slippage_points: float = 5.0
    commission_per_lot: float = 7.0
    swap_long_per_lot: float = -8.0
    swap_short_per_lot: float = -2.0
    swap_hour_utc: int = 21
    magic_number: int = 20260101
    comment: str = "xau-ai-trader"
    poll_interval_seconds: float = 30.0
    max_order_retries: int = 3
    retry_delay_seconds: float = 1.0


class BacktestConfig(BaseModel):
    initial_balance: float = 10_000.0
    execution_delay_bars: int = 1
    both_hit_assumption: Literal["sl_first", "tp_first"] = "sl_first"
    daily_loss_stop_percent: float | None = None
    enable_ai: bool = False
    assumed_spread: float = 0.0
    """PHASE 65 §26: spread used when the dataset has no broker spread column.
    Must be documented in the report as an ASSUMPTION, never as observed data."""
    ai_max_calls_per_run: int = 200
    ai_min_smc_alignment: float = 0.0


class OptimizeConfig(BaseModel):
    n_trials: int = 40
    objective: Literal["expectancy", "profit_factor", "sharpe"] = "expectancy"
    min_trades: int = 30
    overfit_penalty: float = 0.5
    search_space: dict[str, list[float]] = Field(
        default_factory=lambda: {
            "sl_atr_mult": [1.0, 1.25, 1.5, 2.0, 2.5],
            "tp_rr": [1.5, 2.0, 2.5, 3.0],
            "min_ml_confidence": [0.5, 0.55, 0.6, 0.65],
            "min_score": [0.5, 0.55, 0.6, 0.65],
        }
    )


class NewsConfig(BaseModel):
    provider: Literal["static_csv", "mock", "http", "none"] = "static_csv"
    csv_path: str = "data/news_calendar.csv"
    http_url: str | None = None
    http_timeout_seconds: float = 10.0
    currencies: list[str] = Field(default_factory=lambda: ["USD"])
    high_before_minutes: int = 30
    high_after_minutes: int = 15
    medium_before_minutes: int = 15
    medium_after_minutes: int = 5
    on_unavailable: Literal["WAIT", "PROCEED"] = "WAIT"


class NotificationsConfig(BaseModel):
    telegram_enabled: bool = True
    telegram_token_env: str = "TELEGRAM_BOT_TOKEN"
    telegram_chat_id_env: str = "TELEGRAM_CHAT_ID"
    language: Literal["fa", "en"] = "fa"
    events: list[str] = Field(
        default_factory=lambda: [
            "BUY", "SELL", "WAIT", "TRADE_OPEN", "TRADE_CLOSE", "SL", "TP",
            "DAILY_LOSS", "KILL_SWITCH", "MT5_DISCONNECT", "AI_FAILURE",
        ]
    )


class DashboardConfig(BaseModel):
    language: Literal["fa", "en"] = "fa"
    refresh_seconds: float = 5.0
    web_port: int = 8501


class RealDataConfig(BaseModel):
    """PHASE 65 — real-dataset validation settings (data/raw parquet+meta)."""
    raw_dir: str = "data/raw"
    symbol: str = "GC"                    # dataset file prefix, e.g. GC_M15.parquet
    timeframes: list[str] = Field(default_factory=lambda: ["M15", "H1", "D1"])
    assumed_spread: float = 0.30          # documented cost assumption when spread absent
    registry_tag: str = "main"            # model registry family matching this dataset's feature set
    volume_kind_note: str = "COMEX futures contract volume"


class DriftConfig(BaseModel):
    psi_warn: float = 0.10
    psi_action: float = 0.25
    feature_drift_ratio_warn: float = 0.20
    perf_window_trades: int = 30
    perf_winrate_min: float = 0.30
    check_interval_loops: int = 20


class AIModelRefs(BaseModel):
    lgbm_model_id: str | None = None
    xgb_model_id: str | None = None
    hmm_model_id: str | None = None


# ----------------------------------------------------------------- root ---
class AppConfig(BaseModel):
    app_name: str = "xau-ai-trader"
    timezone: str = "UTC"
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    paths: PathsConfig = Field(default_factory=PathsConfig)
    symbol: SymbolConfig = Field(default_factory=SymbolConfig)
    mt5: MT5Config = Field(default_factory=MT5Config)
    provider: ProviderConfig = Field(default_factory=ProviderConfig)
    timeframes: MultiTimeframeConfig = Field(default_factory=MultiTimeframeConfig)
    quality: DataQualityConfig = Field(default_factory=DataQualityConfig)
    sessions: SessionsConfig = Field(default_factory=SessionsConfig)
    indicators: IndicatorConfig = Field(default_factory=IndicatorConfig)
    features: FeatureConfig = Field(default_factory=FeatureConfig)
    smc: SMCConfig = Field(default_factory=SMCConfig)
    labels: LabelConfig = Field(default_factory=LabelConfig)
    lgbm: LGBMParams = Field(default_factory=LGBMParams)
    xgb: XGBParams = Field(default_factory=XGBParams)
    hmm: HMMConfig = Field(default_factory=HMMConfig)
    regime: RegimeConfig = Field(default_factory=RegimeConfig)
    calibration: CalibrationConfig = Field(default_factory=CalibrationConfig)
    validation: ValidationConfig = Field(default_factory=ValidationConfig)
    dataset: DatasetConfig = Field(default_factory=DatasetConfig)
    ensemble: EnsembleWeights = Field(default_factory=EnsembleWeights)
    ai: AIConfig = Field(default_factory=AIConfig)
    risk: RiskConfig = Field(default_factory=RiskConfig)
    kill_switch: KillSwitchConfig = Field(default_factory=KillSwitchConfig)
    execution: ExecutionConfig = Field(default_factory=ExecutionConfig)
    backtest: BacktestConfig = Field(default_factory=BacktestConfig)
    optimize: OptimizeConfig = Field(default_factory=OptimizeConfig)
    news: NewsConfig = Field(default_factory=NewsConfig)
    notifications: NotificationsConfig = Field(default_factory=NotificationsConfig)
    dashboard: DashboardConfig = Field(default_factory=DashboardConfig)
    drift: DriftConfig = Field(default_factory=DriftConfig)
    real_data: RealDataConfig = Field(default_factory=RealDataConfig)
    models: AIModelRefs = Field(default_factory=AIModelRefs)

    @field_validator("risk")
    @classmethod
    def _validate_risk(cls, v: RiskConfig) -> RiskConfig:
        if v.risk_percent > v.max_risk_percent:
            raise ValueError("risk_percent cannot exceed max_risk_percent")
        if v.min_rr < 1.0:
            raise ValueError("min_rr below 1.0 is not acceptable")
        return v

    @field_validator("ensemble")
    @classmethod
    def _validate_weights(cls, v: EnsembleWeights) -> EnsembleWeights:
        total = v.ml + v.smc + v.ai
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"ensemble weights must sum to 1.0 (got {total})")
        return v

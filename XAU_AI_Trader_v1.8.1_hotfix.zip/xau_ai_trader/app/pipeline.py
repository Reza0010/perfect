"""Shared analysis pipeline (used by trader, backtest and healthcheck).

data → quality → features → SMC → ML → regime → news → market_state
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from app.ai.schemas import AIOutput
from app.config.schema import AppConfig, NewsRisk, Regime, Timeframe
from app.data.market.base import MarketDataProvider
from app.data.multi_tf import MarketData, MultiTimeframeEngine
from app.features.builder import FeatureBuilder
from app.models.bundle import ModelBundle
from app.news.engine import NewsAssessment, NewsEngine
from app.regime.engine import RegimeEngine, RegimeResult
from app.smc.engine import SMCEngine, SMCResult

logger = logging.getLogger(__name__)


@dataclass
class AnalysisResult:
    symbol: str
    market_data: MarketData
    features: pd.DataFrame
    feature_names: list[str]
    smc: SMCResult
    ml_probs: dict | None = None
    regime: RegimeResult | None = None
    news: NewsAssessment | None = None
    market_state: dict = field(default_factory=dict)
    wait_reasons: list[str] = field(default_factory=list)

    @property
    def last_row(self) -> pd.Series:
        return self.features.iloc[-1]

    @property
    def price(self) -> float:
        df = self.market_data.frames.get("M5")
        if df is None or df.empty:
            base_tf = sorted(self.market_data.frames)[-1]
            df = self.market_data.frames[base_tf]
        return float(df["close"].iloc[-1])


class AnalysisPipeline:
    def __init__(
        self,
        cfg: AppConfig,
        provider: MarketDataProvider,
        feature_builder: FeatureBuilder,
        regime_engine: RegimeEngine,
        news_engine: NewsEngine,
        bundle: ModelBundle | None = None,
        hmm_model=None,
    ) -> None:
        self.cfg = cfg
        self.mtf = MultiTimeframeEngine(provider, cfg.timeframes, cfg.quality)
        self.features = feature_builder
        self.regime_engine = regime_engine
        self.news_engine = news_engine
        self.bundle = bundle
        self.hmm_model = hmm_model

    def fetch(self, symbol: str, end_time: pd.Timestamp | None = None) -> MarketData:
        return self.mtf.fetch(symbol, end_time=end_time)

    def analyze(
        self,
        market_data: MarketData | None = None,
        include_ml: bool = True,
        include_state: bool = True,
        news_now=None,
    ) -> AnalysisResult:
        cfg = self.cfg
        md = market_data or self.fetch(cfg.symbol.primary)
        wait_reasons: list[str] = []

        # quality gate
        worst = md.worst_score()
        for tf, q in md.quality.items():
            if q.score < cfg.quality.min_score:
                wait_reasons.append(f"DATA_QUALITY_{tf}_{q.score:.0f}")

        features, feature_names = self.features.build(md.frames, cfg.timeframes.base)

        # SMC on setup timeframe + base
        # v1.5 fix: reuse the builder's cached SMC result when it was computed
        # for this exact data window (same engine instance). Recomputing here
        # with a second engine created a stale-features/fresh-bias split
        # within one decision when the rolling window slid.
        smc_engine = self.features.smc_engine or SMCEngine(cfg.smc)
        base_key = cfg.timeframes.base.value
        cached_smc = getattr(self.features, "_smc_cache", {}).get(base_key)
        if cached_smc is not None and self.features.smc_engine is smc_engine \
                and cached_smc.features is not None \
                and len(cached_smc.features) == len(md.frames[base_key]):
            smc_result = cached_smc
        else:
            smc_result = smc_engine.analyze(md.frames[base_key], base_key)

        # align SMC feature columns into features (already merged by builder)
        # ML predictions --------------------------------------------------
        ml_probs = None
        if include_ml and self.bundle is not None:
            row = features.iloc[-1]
            nan_cols = [c for c in self.bundle.feature_names
                        if c in row.index and pd.isna(row[c])]
            if nan_cols:
                # v1.5 fix (N2): a NaN inference row used to be silently
                # zero-filled — after robust scaling a 0.0 is an extreme
                # tail value, i.e. live distribution shift by construction.
                # Fail closed with an explicit reason instead.
                # v1.7.2: reason codes pass sanitize_reason_codes() (drops
                # ':'/',' and truncates at 48 chars) — the old
                # "FEATURES_NAN:a,b,c" came out garbled in the journal
                # ("FEATURES_NANab…"). Underscore-joined short code survives.
                _n = sorted(nan_cols)
                wait_reasons.append(
                    "FEATURES_NAN_" + "_".join(_n[:2]) + (f"_plus{len(_n) - 2}" if len(_n) > 2 else ""))
                logger.warning("ML inference row has NaN features: %s", nan_cols[:8])
            else:
                try:
                    row_df = features.iloc[[-1]]
                    ml_probs = self.bundle.predict(row_df)
                    ml_probs = {k: v[0] for k, v in ml_probs.items()}
                except Exception as e:
                    logger.warning("ML prediction failed: %s", e)
                    wait_reasons.append("ML_PREDICTION_FAILED")

        # HMM --------------------------------------------------------------
        hmm_label, hmm_conf = None, 0.0
        if self.hmm_model is not None:
            try:
                # v1.5 fix (N2/audit-ML): the HMM input MUST be built by the
                # shared hmm_feature_matrix helper (3 specific columns with
                # rsi normalized), not the full ~90-column feature frame.
                # Previously the dimension mismatch raised inside the try and
                # was swallowed at DEBUG level → HMM silently dead forever.
                from app.models.hmm_model import hmm_feature_matrix
                X = hmm_feature_matrix(features.iloc[-2000:])
                hmm_label, hmm_conf = self.hmm_model.predict_last(X)
            except Exception as e:
                # fail-closed: surface the failure, never hide it
                logger.warning("HMM prediction failed: %s", e)
                if self.cfg.regime.use_hmm:
                    wait_reasons.append("HMM_PREDICTION_FAILED")

        regime = self.regime_engine.classify(features.iloc[-1], None, hmm_label, hmm_conf)

        news = news_now or self.news_engine.assess()
        if news.risk == NewsRisk.UNKNOWN and cfg.news.on_unavailable == "WAIT":
            # v1.8.1 (hotfix F28): keep the precise cause (provider missing vs
            # calendar out of range) so the journal/panel tell the user WHAT to
            # fix instead of a generic NEWS_UNAVAILABLE.
            wait_reasons.append(news.reasons[0] if news.reasons else "NEWS_UNAVAILABLE")

        market_state: dict = {}
        if include_state:
            market_state = self._build_state(md, features, smc_result, ml_probs,
                                             regime, news, feature_names)

        return AnalysisResult(
            symbol=cfg.symbol.primary,
            market_data=md,
            features=features,
            feature_names=feature_names,
            smc=smc_result,
            ml_probs=ml_probs,
            regime=regime,
            news=news,
            market_state=market_state,
            wait_reasons=wait_reasons,
        )

    # ------------------------------------------------------------- state ---
    def _build_state(self, md, features, smc, ml_probs, regime, news, feature_names) -> dict:
        cfg = self.cfg
        base = md.frames.get(cfg.timeframes.base.value)
        last = features.iloc[-1]
        price = float(base["close"].iloc[-1])
        spread = float(base["spread"].iloc[-1]) if "spread" in base else 0.0
        tick = None
        try:
            tick_df = base.iloc[-1]
            spread = float(tick_df.get("spread", 0.0))
        except Exception:
            pass

        h1 = md.frames.get("H1")
        h4 = md.frames.get("H4")
        trend = {}
        for name, df in (("h1", h1), ("h4", h4)):
            if df is not None and len(df) > 60:
                ema20 = df["close"].ewm(span=20).mean().iloc[-1]
                trend[name] = round(float(df["close"].iloc[-1] / ema20 - 1.0), 5)

        recent_events = sorted(smc.events, key=lambda e: e.timestamp)[-6:]
        smc_state = {
            "bias": round(smc.directional_bias()[0], 3),
            "recent_events": [
                {"type": e.type.value, "dir": e.direction.value,
                 "strength": round(e.strength, 2), "time": str(e.timestamp)}
                for e in recent_events
            ],
        }
        indicators = {
            "rsi": round(float(last.get("rsi", 50.0)), 1),
            "adx": round(float(last.get("adx", 0.0)), 1),
            "atr_pct": round(float(last.get("atr_pct", 0.0)), 5),
            "macd_hist": round(float(last.get("macd_hist", 0.0)), 6),
        }
        volatility = {
            "bb_width": round(float(last.get("bb_width", 0.0)), 5),
            "range_expansion": round(float(last.get("range_expansion", 1.0)), 3),
        }
        structure = {
            "struct_trend": int(last.get("struct_trend", 0)),
            "premium_discount": round(float(last.get("premium_discount", 0.5)), 3),
        }
        ml_state = {}
        if ml_probs:
            for name, probs in ml_probs.items():
                arr = np.asarray(probs, dtype=float)
                if arr.ndim == 1:
                    ml_state[name] = {"SELL": round(float(arr[0]), 3),
                                      "NO_EDGE": round(float(arr[1]), 3),
                                      "BUY": round(float(arr[2]), 3)}
        from app.features.sessions import current_session_name

        state = {
            "symbol": md.symbol,
            "price": round(price, 2),
            "spread": round(spread, 4),
            "timeframes": {tf: {"bars": len(df)} for tf, df in md.frames.items()},
            "trend": trend,
            "structure": structure,
            "smc": smc_state,
            "indicators": indicators,
            "volatility": volatility,
            "session": {"current": current_session_name(base.index[-1], cfg.sessions)},
            "news": news.to_market_state(),
            "ml": ml_state,
            "regime": {"value": regime.regime.value, "confidence": regime.confidence,
                       "source": regime.source},
        }
        return state

"""PHASE 40/41 — Terminal dashboard rendering (rich-based, FA/EN fallback)."""

from __future__ import annotations

import json
from pathlib import Path

_LABELS = {
    "fa": {
        "title": "داشبورد معاملات هوشمند XAUUSD",
        "price": "قیمت", "spread": "اسپرد", "regime": "رژیم بازار",
        "news": "ریسک خبری", "quality": "کیفیت داده", "mode": "حالت",
        "balance": "موجودی", "equity": "اکوییتی", "daily_pnl": "سود/زیان روز",
        "open_positions": "پوزیشن‌های باز", "kill_switch": "کیل سوئیچ",
        "health": "سلامت اجزا", "component": "اجزا", "status": "وضعیت",
        "win_rate": "نرخ برد", "profit_factor": "ضریب سود",
        "note_rtl": "(فارسی — راست‌به‌چپ)",
    },
    "en": {
        "title": "XAUUSD AI Trading Dashboard",
        "price": "Price", "spread": "Spread", "regime": "Regime",
        "news": "News Risk", "quality": "Data Quality", "mode": "Mode",
        "balance": "Balance", "equity": "Equity", "daily_pnl": "Daily P/L",
        "open_positions": "Open Positions", "kill_switch": "Kill Switch",
        "health": "Component Health", "component": "Component", "status": "Status",
        "win_rate": "Win Rate", "profit_factor": "Profit Factor",
        "note_rtl": "",
    },
}


def load_state(logs_dir: str | Path) -> dict:
    path = Path(logs_dir) / "state.json"
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def render_terminal(cfg, journal=None) -> None:
    lang = cfg.dashboard.language
    L = _LABELS[lang] if lang in _LABELS else _LABELS["en"]
    state = load_state(cfg.paths.logs_dir)

    try:
        from rich.console import Console
        from rich.table import Table

        console = Console()
        console.print(f"\n[bold cyan]{L['title']}[/bold cyan] {L['note_rtl']}")
        t = Table(show_header=True, header_style="bold")
        t.add_column(L["component"])
        t.add_column(L["status"])
        for h in state.get("health", []):
            t.add_row(h["name"], h["status"])
        if t.rows:
            console.print(t)
        acc = state.get("account", {})
        if acc:
            t2 = Table(show_header=True, header_style="bold")
            t2.add_column(L["balance"])
            t2.add_column(L["equity"])
            t2.add_column(L["daily_pnl"])
            t2.add_column(L["open_positions"])
            t2.add_column(L["kill_switch"])
            t2.add_row(str(acc.get("balance")), str(acc.get("equity")),
                       str(state.get("daily_pnl")), str(state.get("open_positions")),
                       "ACTIVE" if state.get("kill_switch", {}).get("active") else "OK")
            console.print(t2)
    except ImportError:
        print(f"\n{L['title']}")
        for h in state.get("health", []):
            print(f"  {h['name']:<22} {h['status']}")
        acc = state.get("account", {})
        if acc:
            print(f"  Balance: {acc.get('balance')}  Equity: {acc.get('equity')}"
                  f"  DailyP/L: {state.get('daily_pnl')}")

    if journal is not None:
        try:
            stats = journal.closed_trade_stats()
            print(f"\n{L['win_rate']}: {stats['win_rate_pct']:.1f}%  "
                  f"{L['profit_factor']}: {stats['profit_factor']}")
            for s in journal.recent_signals(5):
                print(f"  [{s['ts']}] {s['decision']:<5} score={s['score']} "
                      f"{str(s['reasons'])[:60]}")
        except Exception:
            pass

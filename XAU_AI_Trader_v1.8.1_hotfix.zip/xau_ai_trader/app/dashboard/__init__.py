from app.dashboard.terminal import render_terminal

__all__ = ["render_terminal"]

"""PHASE 66 (§25) — NO AUTO-RETRAINING guard.

Retraining must ALWAYS require: human approval, a new dataset, a new
validation run, a new walk-forward, and a new leakage audit. This module is
the machine-enforceable statement of that policy:

  * ``assert_no_auto_retrain(cfg)`` raises if any automatic retraining path
    is enabled in configuration.
  * ``RETRAINING_REQUIREMENTS`` documents the mandatory human checklist.

There is intentionally NO scheduler, NO cron, NO "drift → retrain" hook
anywhere in this codebase. Drift detection (app/monitoring/drift.py) reports
to a human; it never triggers training.
"""

from __future__ import annotations

RETRAINING_REQUIREMENTS = [
    "1. HUMAN APPROVAL — a named person explicitly signs off",
    "2. NEW DATASET — genuinely new market data, downloaded and quality-checked",
    "3. NEW VALIDATION — full train/validation/test protocol re-run",
    "4. NEW WALK-FORWARD — rolling OOS validation re-run, results reviewed",
    "5. NEW LEAKAGE AUDIT — LEAKAGE_AUDIT = PASS on the new pipeline",
]


class AutoRetrainForbidden(Exception):
    pass


def assert_no_auto_retrain(cfg) -> None:
    """Raise if configuration enables any automatic retraining path.

    Checks every known retraining-related switch. Unknown config keys fail
    safe (an explicitly-enabled auto-retrain flag can never hide).
    """
    offenders: list[str] = []
    for section in ("dataset", "validation", "drift", "backtest"):
        sub = getattr(cfg, section, None)
        if sub is None:
            continue
        for key in ("auto_retrain", "auto_retrain_enabled", "retrain_on_drift",
                    "periodic_retrain", "continuous_learning"):
            if getattr(sub, key, False):
                offenders.append(f"{section}.{key}=true")
    if getattr(getattr(cfg, "trader", None), "auto_retrain", False):
        offenders.append("trader.auto_retrain=true")
    if offenders:
        raise AutoRetrainForbidden(
            "PHASE 66 §25 violation — automatic retraining is FORBIDDEN: "
            + ", ".join(offenders)
            + ". Required instead: " + " | ".join(RETRAINING_REQUIREMENTS))
    return None

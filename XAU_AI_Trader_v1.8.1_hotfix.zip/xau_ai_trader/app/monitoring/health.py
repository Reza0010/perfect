"""PHASE 57 — Health registry: every component reports NORMAL/WARNING/SAFE_MODE/DISABLED."""

from __future__ import annotations

import threading
from dataclasses import asdict, dataclass
from datetime import datetime, timezone

from app.config.schema import HealthStatus


@dataclass
class ComponentHealth:
    name: str
    status: str = HealthStatus.NORMAL.value
    detail: str = ""
    updated: str = ""


class HealthRegistry:
    def __init__(self) -> None:
        self._components: dict[str, ComponentHealth] = {}
        self._lock = threading.Lock()

    def update(self, name: str, status: str, detail: str = "") -> None:
        with self._lock:
            self._components[name] = ComponentHealth(
                name=name, status=status, detail=detail,
                updated=datetime.now(timezone.utc).isoformat(timespec="seconds"),
            )

    def get(self, name: str) -> ComponentHealth | None:
        return self._components.get(name)

    def summary(self) -> list[dict]:
        with self._lock:
            return [asdict(c) for c in self._components.values()]

    def worst(self) -> str:
        # v1.5 (health-N11): operational severity — SAFE_MODE (system active
        # but refusing risk) is WORSE than DISABLED (component intentionally
        # off). The old ranking inverted the semantics.
        order = {HealthStatus.NORMAL.value: 0, HealthStatus.DISABLED.value: 1,
                 HealthStatus.WARNING.value: 2, HealthStatus.SAFE_MODE.value: 3}
        if not self._components:
            return HealthStatus.DISABLED.value
        return max((c.status for c in self._components.values()), key=lambda s: order.get(s, 0))

    def mark(self, name: str, ok: bool, warning_detail: str = "", error_detail: str = "") -> None:
        if ok:
            self.update(name, HealthStatus.NORMAL.value, warning_detail or "ok")
        else:
            self.update(name, HealthStatus.WARNING.value, error_detail or warning_detail)

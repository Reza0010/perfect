"""PHASE 37 — Drift detection (PSI + KS + performance drift)."""

from __future__ import annotations

import numpy as np
import pandas as pd


def psi(expected: np.ndarray, actual: np.ndarray, bins: int = 10) -> float:
    """Population Stability Index between reference and current distributions."""
    e = np.asarray(expected, dtype=float)
    a = np.asarray(actual, dtype=float)
    e, a = e[np.isfinite(e)], a[np.isfinite(a)]
    if len(e) < 30 or len(a) < 30:
        return 0.0
    edges = np.quantile(e, np.linspace(0, 1, bins + 1))
    edges = np.unique(edges)
    if len(edges) < 3:
        return 0.0
    e_hist = np.histogram(e, bins=edges)[0] / len(e)
    a_hist = np.histogram(a, bins=edges)[0] / len(a)
    eps = 1e-6
    e_hist = np.clip(e_hist, eps, None)
    a_hist = np.clip(a_hist, eps, None)
    return float(np.sum((a_hist - e_hist) * np.log(a_hist / e_hist)))


def ks_statistic(expected: np.ndarray, actual: np.ndarray) -> float:
    e = np.sort(np.asarray(expected, dtype=float))
    a = np.sort(np.asarray(actual, dtype=float))
    if len(e) < 30 or len(a) < 30:
        return 0.0
    all_vals = np.concatenate([e, a])
    cdf_e = np.searchsorted(e, all_vals, side="right") / len(e)
    cdf_a = np.searchsorted(a, all_vals, side="right") / len(a)
    return float(np.max(np.abs(cdf_e - cdf_a)))


class FeatureDriftMonitor:
    """Compares live feature windows against the training reference."""

    def __init__(self, reference: pd.DataFrame, psi_warn: float = 0.10,
                 psi_action: float = 0.25, feature_ratio_warn: float = 0.20) -> None:
        self.reference = reference.select_dtypes(include=[np.number])
        self.psi_warn = psi_warn
        self.psi_action = psi_action
        self.feature_ratio_warn = feature_ratio_warn

    def report(self, current: pd.DataFrame) -> dict:
        cur = current.select_dtypes(include=[np.number])
        common = [c for c in self.reference.columns if c in cur.columns]
        per_feature = []
        for c in common[:60]:
            score = psi(self.reference[c].values, cur[c].values)
            per_feature.append({"feature": c, "psi": round(score, 4),
                                "level": "OK" if score < self.psi_warn
                                else ("WARN" if score < self.psi_action else "ACTION")})
        n_action = sum(1 for f in per_feature if f["level"] == "ACTION")
        ratio = n_action / len(per_feature) if per_feature else 0.0
        verdict = "NORMAL" if ratio < self.feature_ratio_warn else (
            "WARNING" if ratio < 2 * self.feature_ratio_warn else "SAFE_MODE")
        return {"verdict": verdict, "drift_ratio": round(ratio, 3),
                "features": sorted(per_feature, key=lambda f: -f["psi"])[:15]}


class PerformanceDriftMonitor:
    """Rolling win-rate / expectancy degradation check."""

    def __init__(self, window: int = 30, min_winrate: float = 0.30) -> None:
        self.window = window
        self.min_winrate = min_winrate

    def check(self, pnls: list[float]) -> dict:
        recent = [p for p in pnls[-self.window:] if p is not None]
        if len(recent) < self.window:
            return {"verdict": "INSUFFICIENT_DATA", "n": len(recent)}
        wr = sum(1 for p in recent if p > 0) / len(recent)
        exp = sum(recent) / len(recent)
        verdict = "NORMAL" if wr >= self.min_winrate else "WARNING"
        if wr < self.min_winrate / 2:
            verdict = "SAFE_MODE"
        return {"verdict": verdict, "win_rate": round(wr, 3), "expectancy": round(exp, 2)}

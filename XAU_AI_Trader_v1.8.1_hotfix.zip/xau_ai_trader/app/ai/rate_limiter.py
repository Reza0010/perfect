"""PHASE 67 (§14) — AI RATE LIMITING: backoff, pacing, retry, circuit breaker,
caching hand-off and request journal.

Phase 66 evidence: the AI gateway experienced provider 429 rate limits and
70/100 calls were rate-limited in the repeatability run. The directive
requires that this is handled openly, never hidden:

    exponential backoff · request pacing · retry limit · timeout ·
    circuit breaker · caching · per-call journaling · WAIT when unavailable

Design:
  * ``RateLimitConfig`` (app/config/schema.py) is OPT-IN on ``AIConfig`` —
    gateways built without it behave exactly as before (backwards compatible,
    existing failover tests unchanged).
  * Retryable failures: AIRateLimitError (429), AITimeoutError, AIServerError.
    AIInvalidResponseError is NOT retried (same payload → same result);
    it failovers immediately.
  * ``RequestPacer`` enforces a minimum interval between request starts.
  * ``CircuitBreaker`` (per provider) opens after N consecutive failures and
    half-opens after a reset timeout — a saturated provider is not hammered.
  * ``AIRequestJournal`` appends one JSON line per attempt chain:
    request hash, provider, latency, status code, retry count, final action.
  * When everything fails the gateway still returns SAFE_MODE (WAIT) —
    the system never depends on AI availability for safety.
"""

from __future__ import annotations

import asyncio
import json
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from app.core import exceptions as exc
from app.core.security import mask_secrets

RETRYABLE_EXCEPTIONS = (exc.AITimeoutError, exc.AIRateLimitError, exc.AIServerError)
NON_RETRYABLE = (exc.AIInvalidResponseError, exc.AIProviderError)

STATUS_FROM_EXC = {
    exc.AITimeoutError: "TIMEOUT",
    exc.AIRateLimitError: "429",
    exc.AIServerError: "5XX",
    exc.AIInvalidResponseError: "INVALID_RESPONSE",
    exc.AIProviderError: "PROVIDER_ERROR",
}


def backoff_delay(attempt: int, base_s: float, cap_s: float,
                  jitter: bool = True) -> float:
    """Exponential backoff: base * 2^attempt capped at cap_s, ±jitter."""
    d = min(cap_s, base_s * (2 ** max(0, attempt)))
    if jitter:
        d *= random.uniform(0.5, 1.5)
    return max(0.0, d)


class RequestPacer:
    """Enforces a minimum interval between request starts (async-safe)."""

    def __init__(self, min_interval_s: float = 0.0) -> None:
        self.min_interval_s = float(min_interval_s)
        self._last_start = 0.0
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        if self.min_interval_s <= 0:
            return
        async with self._lock:
            now = time.monotonic()
            wait = self._last_start + self.min_interval_s - now
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_start = time.monotonic()


class CircuitBreaker:
    """CLOSED → (N consecutive failures) → OPEN → (reset timeout) → HALF_OPEN
    → (probe success) → CLOSED.  Per provider."""

    def __init__(self, name: str, failure_threshold: int = 5,
                 reset_timeout_s: float = 60.0) -> None:
        self.name = name
        self.failure_threshold = int(failure_threshold)
        self.reset_timeout_s = float(reset_timeout_s)
        self.state = "CLOSED"
        self.failures = 0
        self.opened_at = 0.0

    def allow(self) -> bool:
        if self.state == "OPEN":
            if time.monotonic() - self.opened_at >= self.reset_timeout_s:
                self.state = "HALF_OPEN"
                return True
            return False
        return True

    def record_success(self) -> None:
        self.state = "CLOSED"
        self.failures = 0

    def record_failure(self) -> None:
        self.failures += 1
        if self.state == "HALF_OPEN" or self.failures >= self.failure_threshold:
            self.state = "OPEN"
            self.opened_at = time.monotonic()


class AIRequestJournal:
    """Append-only JSONL journal of every AI call chain (§14 record fields)."""

    def __init__(self, path: str | Path | None) -> None:
        self.path = Path(path) if path else None
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)

    def record(self, entry: dict) -> None:
        if not self.path:
            return
        try:
            clean = {k: (mask_secrets(str(v)) if isinstance(v, str) and k == "error"
                         else v) for k, v in entry.items()}
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(clean, default=str) + "\n")
        except Exception:  # journaling must never break trading
            pass


@dataclass
class LimiterCallResult:
    output: object
    usage: dict | None
    latency_ms: int
    retries: int
    status: str = "OK"


class RateLimiter:
    """Facade used by AIGateway when ``cfg.rate_limit`` is configured."""

    def __init__(self, cfg) -> None:  # cfg: RateLimitConfig
        self.cfg = cfg
        self.pacer = RequestPacer(cfg.min_interval_s)
        self.breakers: dict[str, CircuitBreaker] = {}
        self.journal = AIRequestJournal(cfg.journal_path)
        self.stats = {"calls": 0, "retries": 0, "circuit_open_skips": 0,
                      "final_ok": 0, "final_failover": 0}

    def breaker(self, name: str) -> CircuitBreaker:
        if name not in self.breakers:
            self.breakers[name] = CircuitBreaker(
                name, self.cfg.circuit_failure_threshold,
                self.cfg.circuit_reset_timeout_s)
        return self.breakers[name]

    async def execute(self, provider_name: str, call_fn, request_hash: str,
                      model: str = "") -> LimiterCallResult:
        """Run one provider call chain with pacing, retries and breaker.

        ``call_fn()`` is an async callable returning ``(output, usage)`` and
        raising AI exceptions. Raises the last exception after retries are
        exhausted so the gateway can failover to the next provider.
        """
        br = self.breaker(provider_name)
        self.stats["calls"] += 1
        if not br.allow():
            self.stats["circuit_open_skips"] += 1
            self._journal(provider_name, model, request_hash, 0, "CIRCUIT_OPEN",
                          0, "CIRCUIT_OPEN", error="circuit open")
            raise exc.AIProviderError(f"{provider_name}: circuit open")

        await self.pacer.acquire()
        started = time.perf_counter()
        retries = 0
        last_exc: Exception | None = None
        for attempt in range(self.cfg.max_retries + 1):
            try:
                output, usage = await call_fn()
                latency = int((time.perf_counter() - started) * 1000)
                br.record_success()
                self.stats["final_ok"] += 1
                self.stats["retries"] += retries
                self._journal(provider_name, model, request_hash, latency, "OK",
                              retries, "OK")
                return LimiterCallResult(output=output, usage=usage,
                                         latency_ms=latency, retries=retries)
            except RETRYABLE_EXCEPTIONS as e:
                last_exc = e
                status = STATUS_FROM_EXC.get(type(e), "ERROR")
                br.record_failure()
                if attempt < self.cfg.max_retries:
                    retries += 1
                    delay = backoff_delay(attempt, self.cfg.backoff_base_s,
                                          self.cfg.backoff_cap_s)
                    self._journal(provider_name, model, request_hash,
                                  int((time.perf_counter() - started) * 1000),
                                  status, retries, "RETRY", error=str(e))
                    await asyncio.sleep(delay)
                    continue
                break
            except NON_RETRYABLE:
                br.record_failure()
                raise

        latency = int((time.perf_counter() - started) * 1000)
        status = STATUS_FROM_EXC.get(type(last_exc), "ERROR") if last_exc else "ERROR"
        self.stats["final_failover"] += 1
        self.stats["retries"] += retries
        self._journal(provider_name, model, request_hash, latency, status,
                      retries, "FAILOVER", error=str(last_exc))
        assert last_exc is not None
        raise last_exc

    def _journal(self, provider: str, model: str, request_hash: str,
                 latency_ms: int, status: str, retries: int, final_action: str,
                 error: str = "") -> None:
        self.journal.record({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "provider": provider, "model": model,
            "request_hash": request_hash, "latency_ms": latency_ms,
            "status": status, "retry_count": retries,
            "final_action": final_action,
            "error": mask_secrets(error) if error else "",
        })

"""PHASE 12 — Abstract AI provider + shared OpenAI-compatible implementation."""

from __future__ import annotations

import abc
import asyncio
import time

import httpx

from app.ai.schemas import AIOutput, parse_ai_output
from app.ai.prompts import SYSTEM_PROMPT, build_user_prompt
from app.core import exceptions as exc


class AIProvider(abc.ABC):
    name = "base"

    def __init__(
        self,
        api_key: str,
        model: str,
        base_url: str,
        timeout_seconds: float = 30.0,
        temperature: float = 0.1,
        max_tokens: int = 512,
        extra_headers: dict | None = None,
    ) -> None:
        self.api_key = api_key
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout_seconds
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.extra_headers = dict(extra_headers or {})
        self._last_usage: dict | None = None
        self._client: httpx.AsyncClient | None = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=httpx.Timeout(self.timeout))
        return self._client

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def analyze(self, market_state: dict, news_texts: list[str] | None = None) -> AIOutput:
        user_prompt = build_user_prompt(market_state, news_texts)
        result = await self._complete(SYSTEM_PROMPT, user_prompt)
        if isinstance(result, tuple):
            raw, usage = result
        else:
            raw, usage = result, None
        # PHASE 65 §12 fix: keep usage so the gateway cost ledger records real
        # token counts (previously discarded → tokens always logged as None)
        self._last_usage = usage
        try:
            return parse_ai_output(raw)
        except Exception as e:
            raise exc.AIInvalidResponseError(f"{self.name}: invalid AI output: {e}") from e

    @abc.abstractmethod
    async def _complete(self, system: str, user: str) -> tuple[str, dict | None]:
        """Return (text, usage) — usage may be None."""


class OpenAICompatibleProvider(AIProvider):
    """Z.ai / Groq / OpenRouter all expose /chat/completions."""

    async def _complete(self, system: str, user: str) -> tuple[str, dict | None]:
        url = f"{self.base_url}/chat/completions"
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            # v1.5 (Mission 23): request structured JSON output at the provider
            # instead of parsing prose for braces. Providers that ignore the
            # field simply return text — the strict parser remains the gate.
            "response_format": {"type": "json_object"},
        }
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        if self.extra_headers:
            headers.update(self.extra_headers)  # gateway-specific headers from env only
        started = time.perf_counter()
        try:
            resp = await self.client.post(url, json=payload, headers=headers)
        except httpx.TimeoutException as e:
            raise exc.AITimeoutError(f"{self.name}: timeout after {self.timeout}s") from e
        except httpx.HTTPError as e:
            raise exc.AIServerError(f"{self.name}: transport error: {e}") from e
        finally:
            self.last_latency_ms = int((time.perf_counter() - started) * 1000)
        if resp.status_code == 429:
            raise exc.AIRateLimitError(f"{self.name}: rate limited (429)")
        if resp.status_code >= 500:
            raise exc.AIServerError(f"{self.name}: server error {resp.status_code}")
        if resp.status_code >= 400:
            raise exc.AIProviderError(f"{self.name}: HTTP {resp.status_code}")
        try:
            data = resp.json()
        except Exception as e:
            raise exc.AIInvalidResponseError(f"{self.name}: non-JSON HTTP body") from e
        usage = data.get("usage") or {}
        try:
            text = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as e:
            raise exc.AIInvalidResponseError(f"{self.name}: unexpected response shape") from e
        return text, {"input_tokens": usage.get("prompt_tokens"), "output_tokens": usage.get("completion_tokens")}

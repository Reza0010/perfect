"""PHASE 21 — AI Consensus: independent provider outputs → one verdict.

Not a plain majority vote: conflicts (BUY vs SELL) force WAIT; confidence is
weighted by agreement ratio; WAIT votes dilute confidence instead of voting.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from app.ai.schemas import AIOutput


@dataclass
class ConsensusResult:
    decision: str  # BUY | SELL | WAIT
    confidence: float
    agreement: float
    votes: dict = field(default_factory=dict)
    conflict: bool = False
    reasons: list[str] = field(default_factory=list)


class AIConsensus:
    def combine(self, results: list[tuple[str, AIOutput]]) -> ConsensusResult:
        if not results:
            return ConsensusResult(decision="WAIT", confidence=0.0, agreement=0.0,
                                   reasons=["NO_AI_VOTES"], conflict=False)
        votes: dict[str, list[tuple[str, float]]] = {"BUY": [], "SELL": [], "WAIT": []}
        for provider, out in results:
            votes.setdefault(out.decision, []).append((provider, float(out.confidence)))
        buys, sells = votes["BUY"], votes["SELL"]
        conflict = bool(buys) and bool(sells)
        if conflict:
            return ConsensusResult(
                decision="WAIT", confidence=0.0,
                agreement=0.0, votes={k: [(p, c) for p, c in v] for k, v in votes.items()},
                conflict=True, reasons=["AI_CONFLICT_BUY_SELL"],
            )
        if buys:
            direction, voters = "BUY", buys
        elif sells:
            direction, voters = "SELL", sells
        else:
            return ConsensusResult(
                decision="WAIT",
                confidence=0.0,
                agreement=0.0,
                votes={k: [(p, c) for p, c in v] for k, v in votes.items()},
                conflict=False, reasons=["AI_ALL_WAIT"],
            )
        n_total = len(results)
        agreement = len(voters) / n_total
        conf = sum(c for _, c in voters) / len(voters) * agreement
        return ConsensusResult(
            decision=direction, confidence=round(float(conf), 4), agreement=round(float(agreement), 3),
            votes={k: [(p, round(c, 3)) for p, c in v] for k, v in votes.items()},
            conflict=False, reasons=[f"AI_{p}_{direction}_{round(c, 2)}" for p, c in voters],
        )

"""PHASE 65 (§12/§14) — Real-market-state factory for AI testing.

Builds genuine pipeline states (data → quality → features → SMC → ML →
regime → compressed market_state) from a ReplayProvider at HISTORICAL
timestamps, so AI provider/consistency tests exercise exactly the same state
representation the live trader would produce.

News is injected as an explicit NEUTRAL assumption (real news provider is NOT
IMPLEMENTED — §11) so tests are reproducible and never rely on mock data
being mistaken for real news.
"""

from __future__ import annotations

import logging

import numpy as np
import pandas as pd

from app.config.schema import AppConfig, NewsRisk
from app.data.market.replay import ReplayProvider
from app.data.multi_tf import MultiTimeframeEngine
from app.models.train_service import make_feature_builder
from app.news.engine import NewsAssessment
from app.pipeline import AnalysisPipeline
from app.regime.engine import RegimeEngine

logger = logging.getLogger(__name__)


def build_state_at_time(
    cfg: AppConfig,
    provider: ReplayProvider,
    bundle,
    ts: pd.Timestamp,
    mtf: MultiTimeframeEngine | None = None,
    feature_builder=None,
) -> dict | None:
    """Full pipeline state for the market as it looked at ``ts`` (inclusive)."""
    try:
        mtf = mtf or MultiTimeframeEngine(provider, cfg.timeframes, cfg.quality)
        md = mtf.fetch(cfg.real_data.symbol, end_time=ts)
        if not md.frames:
            return None
        fb = feature_builder or make_feature_builder(cfg)
        news = NewsAssessment(risk=NewsRisk.LOW,
                              reasons=["NEWS_NEUTRAL_TEST_ASSUMPTION"])
        result = AnalysisPipeline(
            cfg, provider, fb, RegimeEngine(cfg.regime), None, bundle, None,
        )
        # NewsEngine is None → pass explicit assessment
        res = result.analyze(market_data=md, include_state=True, news_now=news)
        if not res.market_state:
            return None
        res.market_state["state_time"] = str(ts)
        return res.market_state
    except Exception as e:
        logger.debug("state build failed at %s: %s", ts, e)
        return None


def sample_state_timestamps(provider: ReplayProvider, cfg: AppConfig,
                            count: int, min_gap_bars: int = 12) -> list[pd.Timestamp]:
    """Evenly spaced M15 timestamps with warmup history available."""
    base_tf = cfg.timeframes.base.value
    frame = provider.full_range(base_tf)
    warmup = 250
    usable = frame.index[warmup:-cfg.labels.horizon_bars]
    if len(usable) == 0:
        return []
    step = max(min_gap_bars, len(usable) // max(1, count))
    picks = list(usable[::step])[:count]
    while len(picks) < count:                       # not enough spread → resample with wrap
        extra = list(usable[::max(1, step // 2)])[:count * 2]
        picks = list(dict.fromkeys(extra))[:count]
        break
    return picks


def ml_side_from_state(bundle, state: dict) -> str:
    """Extract the ML side stored in the compressed state (for consistency checks)."""
    ml = state.get("ml") or {}
    if not ml:
        return "UNKNOWN"
    name = next(iter(ml))
    probs = ml[name]
    sides = [("SELL", probs.get("SELL", 0)), ("NO_EDGE", probs.get("NO_EDGE", 0)),
             ("BUY", probs.get("BUY", 0))]
    return max(sides, key=lambda t: t[1])[0]

"""PHASE 20 — Mandatory AI output schema (pydantic, strict).

Every AI response must validate against AIOutput; anything invalid is
treated as provider failure → next provider / WAIT.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator

from app.core.security import sanitize_reason_codes


class AIOutput(BaseModel):
    # v1.5 (Mission 23 / finding 8): unknown keys are FORBIDDEN — the old
    # silent-Ignore contract could hide provider drift (new fields changing
    # semantics) and prompt-injection payloads smuggled in extra fields.
    model_config = {"extra": "forbid"}

    decision: Literal["BUY", "SELL", "WAIT"]
    confidence: float = Field(ge=0.0, le=1.0)
    setup_quality: Literal["A", "B", "C", "NONE"] = "NONE"
    regime: str = Field(default="", max_length=32)
    news_risk: Literal["LOW", "MEDIUM", "HIGH", "UNKNOWN"] = "UNKNOWN"
    reason_codes: list[str] = Field(default_factory=list, max_length=10)
    invalidation: str = Field(default="", max_length=200)
    confirmation_required: bool = False

    @field_validator("reason_codes", mode="before")
    @classmethod
    def _clean_reasons(cls, v):
        if not isinstance(v, list):
            return []
        return sanitize_reason_codes([str(x) for x in v])

    @field_validator("regime", "invalidation", mode="before")
    @classmethod
    def _clean_text(cls, v):
        from app.core.security import sanitize_untrusted_text

        return sanitize_untrusted_text(str(v), max_length=64)


SAFE_MODE_OUTPUT = AIOutput(
    decision="WAIT",
    confidence=0.0,
    setup_quality="NONE",
    regime="",
    news_risk="UNKNOWN",
    reason_codes=["AI_UNAVAILABLE_SAFE_MODE"],
    invalidation="",
    confirmation_required=True,
)


def parse_ai_output(text: str) -> AIOutput:
    """Extract a JSON object from a response and validate strictly.

    v1.5 (Mission 23): the brace-slice fallback is a LAST RESORT — a response
    consisting of prose with braces is rejected as invalid (failover), not
    silently salvaged. When the response is not clean JSON, the salvage
    attempt is logged at WARNING so parser churn is visible.
    """
    import json
    import logging

    logger = logging.getLogger(__name__)
    text = (text or "").strip()
    if text.startswith("```") or "```json" in text[:12].lower():
        # strip a markdown code fence if the provider added one
        inner = text.split("```", 2)
        for chunk in inner:
            chunk = chunk.strip()
            if chunk.lower().startswith("json"):
                chunk = chunk[4:].strip()
            if chunk.startswith("{"):
                text = chunk
                break
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start == -1 or end <= start:
            raise ValueError("no JSON object found in AI response")
        logger.warning("AI response was not clean JSON — salvaging the brace-slice "
                       "(structured output should be enabled at the provider)")
        payload = json.loads(text[start: end + 1])
    return AIOutput(**payload)

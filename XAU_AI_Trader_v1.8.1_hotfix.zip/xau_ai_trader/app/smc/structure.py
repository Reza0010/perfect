"""Market structure: swing detection, BOS and CHoCH (deterministic)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.smc.types import Direction, SMCEvent, SMCEventType


def find_swings(df: pd.DataFrame, left: int = 3, right: int = 3) -> pd.DataFrame:
    """Flag confirmed swing highs/lows.

    A swing at bar i is confirmed only `right` bars later — the returned
    boolean columns are shifted so that bar i+right carries the signal,
    guaranteeing causality (no future access at bar i).
    """
    high, low = df["high"], df["low"]
    is_sh = pd.Series(True, index=df.index)
    is_sl = pd.Series(True, index=df.index)
    for k in range(1, left + 1):
        is_sh &= high > high.shift(k)
        is_sl &= low < low.shift(k)
    for k in range(1, right + 1):
        is_sh &= high >= high.shift(-k)
        is_sl &= low <= low.shift(-k)
    # shift confirmation into the future bar where it becomes known.
    # fill_value=False keeps the bool dtype (shift() alone would upcast to
    # object because it inserts NaN, and fillna(False) on object dtype
    # triggers a pandas FutureWarning about silent downcasting).
    swing_high = is_sh.shift(right, fill_value=False)
    swing_low = is_sl.shift(right, fill_value=False)
    return pd.DataFrame({"swing_high": swing_high, "swing_low": swing_low}, index=df.index)


def detect_structure(
    df: pd.DataFrame,
    swings: pd.DataFrame,
    atr: pd.Series,
    timeframe: str,
    min_strength: float = 0.05,
) -> list[SMCEvent]:
    """BOS = close beyond last swing in trend direction; CHoCH = close beyond
    the opposing swing, flipping trend. Events are emitted on the bar where
    the close confirms the break (causal)."""
    events: list[SMCEvent] = []
    trend = 0  # +1 bull, -1 bear, 0 undefined
    last_sh_price: float | None = None
    last_sl_price: float | None = None
    last_sh_time: pd.Timestamp | None = None
    last_sl_time: pd.Timestamp | None = None

    close = df["close"].values
    atr_v = atr.values

    for i, ts in enumerate(df.index):
        if bool(swings["swing_high"].iloc[i]):
            last_sh_price = float(df["high"].iloc[i])
            last_sh_time = ts
        if bool(swings["swing_low"].iloc[i]):
            last_sl_price = float(df["low"].iloc[i])
            last_sl_time = ts

        c = close[i]
        a = atr_v[i] if i < len(atr_v) and not np.isnan(atr_v[i]) else np.nan
        if np.isnan(a) or a <= 0:
            continue

        if last_sh_price is not None and c > last_sh_price:
            etype = SMCEventType.BOS if trend >= 0 else SMCEventType.CHOCH
            strength = float(min(1.0, (c - last_sh_price) / a * 0.5))
            if strength >= min_strength:
                events.append(SMCEvent(
                    type=etype, direction=Direction.BULLISH, timeframe=timeframe,
                    price=float(last_sh_price), strength=strength, timestamp=ts,
                    invalidation=last_sl_price,
                    meta={"break_close": float(c), "swing_time": str(last_sh_time)},
                ))
            trend = 1
            last_sh_price = None  # consumed
        elif last_sl_price is not None and c < last_sl_price:
            etype = SMCEventType.BOS if trend <= 0 else SMCEventType.CHOCH
            strength = float(min(1.0, (last_sl_price - c) / a * 0.5))
            if strength >= min_strength:
                events.append(SMCEvent(
                    type=etype, direction=Direction.BEARISH, timeframe=timeframe,
                    price=float(last_sl_price), strength=strength, timestamp=ts,
                    invalidation=last_sh_price,
                    meta={"break_close": float(c), "swing_time": str(last_sl_time)},
                ))
            trend = -1
            last_sl_price = None

    return events


def structure_state_series(df: pd.DataFrame, swings: pd.DataFrame) -> pd.DataFrame:
    """Per-bar causal structure state (used as ML features)."""
    n = len(df)
    trend = np.zeros(n)
    dist_sh = np.full(n, np.nan)
    dist_sl = np.full(n, np.nan)
    t = 0
    last_sh = np.nan
    last_sl = np.nan
    high = df["high"].values
    low = df["low"].values
    close = df["close"].values
    for i in range(n):
        if bool(swings["swing_high"].iloc[i]):
            last_sh = high[i]
        if bool(swings["swing_low"].iloc[i]):
            last_sl = low[i]
        if not np.isnan(last_sh) and close[i] > last_sh:
            t = 1
            last_sh = np.nan
        elif not np.isnan(last_sl) and close[i] < last_sl:
            t = -1
            last_sl = np.nan
        trend[i] = t
        dist_sh[i] = last_sh
        dist_sl[i] = last_sl
    out = pd.DataFrame({"struct_trend": trend,
                        "dist_swing_high": dist_sh - close,
                        "dist_swing_low": dist_sl - close}, index=df.index)
    # "no active swing reference" is a valid state, not missing data:
    # carry the last known distance forward, neutral-fill the remainder
    out[["dist_swing_high", "dist_swing_low"]] = \
        out[["dist_swing_high", "dist_swing_low"]].ffill().fillna(0.0)
    return out

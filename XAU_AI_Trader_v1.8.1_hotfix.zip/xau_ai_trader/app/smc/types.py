"""SMC event types (PHASE 5). Every event is deterministic and auditable."""

from __future__ import annotations

from enum import Enum
from typing import Any

import pandas as pd
from pydantic import BaseModel, Field


class Direction(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"


class SMCEventType(str, Enum):
    SWING_HIGH = "SWING_HIGH"
    SWING_LOW = "SWING_LOW"
    BOS = "BOS"
    CHOCH = "CHOCH"
    LIQ_SWEEP = "LIQ_SWEEP"
    EQH = "EQH"
    EQL = "EQL"
    FVG_BULL = "FVG_BULL"
    FVG_BEAR = "FVG_BEAR"
    ORDER_BLOCK_BULL = "ORDER_BLOCK_BULL"
    ORDER_BLOCK_BEAR = "ORDER_BLOCK_BEAR"
    BREAKER_BULL = "BREAKER_BULL"
    BREAKER_BEAR = "BREAKER_BEAR"
    DISPLACEMENT_BULL = "DISPLACEMENT_BULL"
    DISPLACEMENT_BEAR = "DISPLACEMENT_BEAR"


class SMCEvent(BaseModel):
    type: SMCEventType
    direction: Direction
    timeframe: str
    price: float
    strength: float = Field(ge=0.0, le=1.0)
    timestamp: pd.Timestamp
    invalidation: float | None = None
    meta: dict[str, Any] = Field(default_factory=dict)

    model_config = {"arbitrary_types_allowed": True}

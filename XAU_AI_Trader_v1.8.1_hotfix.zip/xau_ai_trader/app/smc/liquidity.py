"""Liquidity: equal highs/lows, previous day/week levels, session extremes,
liquidity sweeps."""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.smc.types import Direction, SMCEvent, SMCEventType


def equal_high_lows(df: pd.DataFrame, swings: pd.DataFrame, atr: pd.Series,
                    tolerance_atr: float, timeframe: str) -> list[SMCEvent]:
    """Cluster confirmed swing highs/lows within tolerance → EQH/EQL events.

    Vectorised clustering: swings are sorted by price once; groups are grown
    from each unclustered anchor with an early break (sorted order), so the
    cost is O(S log S) instead of O(bars × swings).
    """
    events: list[SMCEvent] = []
    a = atr.values

    def _cluster(side: str, kind: SMCEventType) -> None:
        mask = swings[f"swing_{side}"].values
        pos = np.where(mask)[0]
        if len(pos) < 2:
            return
        prices = df["high"].values[pos] if side == "high" else df["low"].values[pos]
        order = pos[np.argsort(prices, kind="stable")]
        used = np.zeros(len(pos), dtype=bool)
        price_by_pos = dict(zip(pos.tolist(), prices.tolist()))
        for ai, anchor in enumerate(order):
            if used[ai]:
                continue
            av = a[anchor]
            tol = av * tolerance_atr if not np.isnan(av) else abs(price_by_pos[anchor]) * 0.001
            group = [anchor]
            used[ai] = True
            for bi in range(ai + 1, len(order)):
                cand = order[bi]
                if used[bi]:
                    continue
                if price_by_pos[cand] - price_by_pos[anchor] > tol:
                    break  # sorted by price — nothing further can match
                used[bi] = True
                group.append(cand)
            if len(group) >= 2:
                level = float(np.mean([price_by_pos[g] for g in group]))
                events.append(SMCEvent(
                    type=kind, direction=Direction.NEUTRAL, timeframe=timeframe,
                    price=level, strength=min(1.0, 0.3 + 0.1 * len(group)),
                    timestamp=df.index[max(group)],
                    meta={"cluster_size": len(group), "tolerance": float(tol)},
                ))

    _cluster("high", SMCEventType.EQH)
    _cluster("low", SMCEventType.EQL)
    return events


def previous_day_week_levels(df: pd.DataFrame) -> pd.DataFrame:
    """Previous day high/low and previous week high/low, shifted to be causal
    (value known only after the period completes)."""
    d = df.resample("1D", label="left", closed="left").agg(
        {"high": "max", "low": "min"}).dropna()
    prev_day = d.shift(1)
    w = df.resample("W-FRI", label="left", closed="left").agg(
        {"high": "max", "low": "min"}).dropna()
    prev_week = w.shift(1)
    out = pd.DataFrame(index=df.index)
    out["pdh"] = prev_day["high"].reindex(df.index, method="ffill")
    out["pdl"] = prev_day["low"].reindex(df.index, method="ffill")
    out["pwh"] = prev_week["high"].reindex(df.index, method="ffill")
    out["pwl"] = prev_week["low"].reindex(df.index, method="ffill")
    return out


def detect_sweeps(df: pd.DataFrame, swings: pd.DataFrame, atr: pd.Series,
                  timeframe: str, recent_bars: int = 12) -> list[SMCEvent]:
    """Liquidity sweep: wick beyond a confirmed swing level while the close
    retreats back. direction = implied trade direction (a buyside sweep of
    highs implies BEARISH reaction, and vice versa).

    Only the most recent swing levels are checked per bar (bounded window),
    keeping the scan O(bars × window) instead of O(bars × swings).
    """
    events: list[SMCEvent] = []
    high = df["high"].values
    low = df["low"].values
    close = df["close"].values
    a = atr.values
    window = max(20, recent_bars * 6)
    sh_prices: list[tuple[int, float]] = []   # bounded rolling history
    sl_prices: list[tuple[int, float]] = []
    cooldown = 3
    last_sweep = -10**9
    for i in range(len(df)):
        if bool(swings["swing_high"].iloc[i]):
            sh_prices.append((i, high[i]))
        if bool(swings["swing_low"].iloc[i]):
            sl_prices.append((i, low[i]))
        if i - last_sweep < cooldown:
            continue
        av = a[i] if i < len(a) and not np.isnan(a[i]) else np.nan
        if np.isnan(av) or av <= 0:
            continue
        recent_sh = [(j, p) for j, p in sh_prices[-window:] if 0 < i - j <= recent_bars * 6]
        recent_sl = [(j, p) for j, p in sl_prices[-window:] if 0 < i - j <= recent_bars * 6]
        if recent_sh:
            j, p = max(recent_sh, key=lambda x: x[1])
            if high[i] > p and close[i] < p:
                strength = float(min(1.0, (high[i] - p) / av * 0.6))
                events.append(SMCEvent(
                    type=SMCEventType.LIQ_SWEEP, direction=Direction.BEARISH, timeframe=timeframe,
                    price=float(p), strength=strength, timestamp=df.index[i],
                    invalidation=float(high[i]),
                    meta={"liquidity_side": "buyside", "sweep_high": float(high[i])},
                ))
                last_sweep = i
                continue
        if recent_sl:
            j, p = min(recent_sl, key=lambda x: x[1])
            if low[i] < p and close[i] > p:
                strength = float(min(1.0, (p - low[i]) / av * 0.6))
                events.append(SMCEvent(
                    type=SMCEventType.LIQ_SWEEP, direction=Direction.BULLISH, timeframe=timeframe,
                    price=float(p), strength=strength, timestamp=df.index[i],
                    invalidation=float(low[i]),
                    meta={"liquidity_side": "sellside", "sweep_low": float(low[i])},
                ))
                last_sweep = i
    return events


def sweep_flags(df: pd.DataFrame, sweeps: list[SMCEvent], recent_bars: int) -> pd.DataFrame:
    """Per-bar flags that are 1.0 for `recent_bars` bars after a sweep (causal)."""
    out = pd.DataFrame(index=df.index)
    n = len(df)
    for col, direction in (("sweep_bull_recent", Direction.BULLISH), ("sweep_bear_recent", Direction.BEARISH)):
        flag = np.zeros(n, dtype=float)
        for e in sweeps:
            if e.direction != direction:
                continue
            p0 = df.index.searchsorted(e.timestamp)
            if p0 < n:
                flag[p0:p0 + recent_bars + 1] = 1.0
        out[col] = flag
    return out

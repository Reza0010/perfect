"""Displacement candles → Order Blocks and Breaker Blocks."""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.smc.types import Direction, SMCEvent, SMCEventType


def detect_displacement(df: pd.DataFrame, atr: pd.Series, timeframe: str,
                        body_atr: float = 1.2, range_atr: float = 1.6) -> list[SMCEvent]:
    events: list[SMCEvent] = []
    body = (df["close"] - df["open"]).abs().values
    rng = (df["high"] - df["low"]).values
    a = atr.values
    for i in range(len(df)):
        av = a[i] if not np.isnan(a[i]) else np.nan
        if np.isnan(av) or av <= 0:
            continue
        if body[i] >= body_atr * av and rng[i] >= range_atr * av:
            bull = df["close"].iloc[i] > df["open"].iloc[i]
            events.append(SMCEvent(
                type=SMCEventType.DISPLACEMENT_BULL if bull else SMCEventType.DISPLACEMENT_BEAR,
                direction=Direction.BULLISH if bull else Direction.BEARISH,
                timeframe=timeframe, price=float(df["close"].iloc[i]),
                strength=float(min(1.0, body[i] / av * 0.5)), timestamp=df.index[i],
                invalidation=float(df["low"].iloc[i] if bull else df["high"].iloc[i]),
                meta={"body_atr": float(body[i] / av), "range_atr": float(rng[i] / av)},
            ))
    return events


def detect_order_blocks(df: pd.DataFrame, atr: pd.Series, timeframe: str,
                        displacement_events: list[SMCEvent],
                        max_lookback: int = 10) -> list[SMCEvent]:
    """Bull OB = last opposite-colour candle before a bullish displacement;
    Breaker = OB whose zone has since been violated by a close-through."""
    events: list[SMCEvent] = []
    open_ = df["open"].values
    close = df["close"].values
    high = df["high"].values
    low = df["low"].values
    for disp in displacement_events:
        i = df.index.searchsorted(disp.timestamp)
        if i >= len(df) or df.index[i] != disp.timestamp:
            i = min(i, len(df) - 1)
        bull_disp = disp.direction == Direction.BULLISH
        found = -1
        for j in range(i - 1, max(-1, i - 1 - max_lookback), -1):
            is_opposite = close[j] < open_[j] if bull_disp else close[j] > open_[j]
            if is_opposite:
                found = j
                break
        if found < 0:
            continue
        zone_top = float(high[found]) if bull_disp else float(max(open_[found], close[found]))
        zone_bottom = float(min(open_[found], close[found])) if bull_disp else float(low[found])
        etype = SMCEventType.ORDER_BLOCK_BULL if bull_disp else SMCEventType.ORDER_BLOCK_BEAR
        events.append(SMCEvent(
            type=etype, direction=disp.direction, timeframe=timeframe,
            price=float((zone_top + zone_bottom) / 2.0),
            strength=float(disp.strength), timestamp=disp.timestamp,
            invalidation=float(zone_bottom) if bull_disp else float(zone_top),
            meta={"zone_top": zone_top, "zone_bottom": zone_bottom,
                  "ob_time": str(df.index[found]), "breaker": False},
        ))
    # breaker upgrade: zone violated by opposite close
    for ev in events:
        i0 = df.index.searchsorted(ev.timestamp)
        zt = ev.meta["zone_top"]
        zb = ev.meta["zone_bottom"]
        if ev.direction == Direction.BULLISH:
            violated = close[i0:] < zb
        else:
            violated = close[i0:] > zt
        if violated.any() and i0 + int(np.argmax(violated)) < len(df):
            ev.meta["breaker"] = True
            ev.type = SMCEventType.BREAKER_BULL if ev.direction == Direction.BULLISH else SMCEventType.BREAKER_BEAR
    return events


def order_block_features(df: pd.DataFrame, obs: list[SMCEvent]) -> pd.DataFrame:
    """Causal distance to the nearest recent OB/breaker zone of each side."""
    out = pd.DataFrame(index=df.index)
    close = df["close"].values
    n = len(df)
    for col, d in (("dist_ob_bull", Direction.BULLISH), ("dist_ob_bear", Direction.BEARISH)):
        res = np.full(n, np.nan)
        evs = sorted([e for e in obs if e.direction == d], key=lambda e: e.timestamp)
        ei = 0
        active: list[tuple[int, float]] = []
        for i in range(n):
            while ei < len(evs) and evs[ei].timestamp <= df.index[i]:
                active.append((i, evs[ei].price))
                ei += 1
            active = active[-5:]
            if active:
                res[i] = min(abs(close[i] - p) for _, p in active)
        out[col] = res
    return out

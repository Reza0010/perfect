"""PHASE 11 — News providers (pluggable) + risk assessment engine.

Providers:
- static CSV (default, offline calendar file)
- mock (deterministic, for tests/demo)
- HTTP (strict-schema JSON endpoint; response treated as untrusted data)

The engine never invents events: if a provider fails, risk becomes UNKNOWN
and config decides (WAIT by default).
"""

from __future__ import annotations

import abc
import csv
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx

from app.config.schema import NewsConfig
from app.core.security import sanitize_untrusted_text
from app.news.models import NewsEvent

logger = logging.getLogger(__name__)


class NewsProvider(abc.ABC):
    name: str = "base"

    @abc.abstractmethod
    def get_events(self, start: datetime, end: datetime) -> list[NewsEvent]: ...

    def healthy(self) -> bool:
        return True

    # v1.5 (Mission 21 / finding 19): freshness contract. A provider that
    # cannot prove WHEN its data was last updated can never claim freshness —
    # the engine treats a stale/unknown last_update as UNKNOWN risk (WAIT).
    def last_update(self) -> datetime | None:
        return None

    def coverage(self) -> tuple[datetime, datetime] | None:
        """(first_event_time, last_event_time) the provider can speak about."""
        return None

    def is_fresh(self, max_age_seconds: float = 24 * 3600.0,
                 now: datetime | None = None) -> bool:
        last = self.last_update()
        if last is None:
            return False
        now = now or datetime.now(timezone.utc)
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        return (now - last).total_seconds() <= max_age_seconds


class StaticCSVNewsProvider(NewsProvider):
    name = "static_csv"

    def __init__(self, csv_path: str) -> None:
        self.csv_path = Path(csv_path)
        self._events: list[NewsEvent] | None = None
        self._loaded_at: datetime | None = None

    def _load(self) -> list[NewsEvent]:
        if self._events is not None:
            return self._events
        events: list[NewsEvent] = []
        if not self.csv_path.exists():
            logger.warning("news calendar file missing: %s", self.csv_path)
            self._events = []
            return self._events
        with self.csv_path.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                try:
                    events.append(NewsEvent(
                        event=sanitize_untrusted_text(row.get("event", "")),
                        country=sanitize_untrusted_text(row.get("country", ""), 8),
                        currency=sanitize_untrusted_text(row.get("currency", "USD"), 8),
                        importance=row.get("importance", "MEDIUM").upper(),
                        time=datetime.fromisoformat(row["time"]),
                        previous=row.get("previous", ""), forecast=row.get("forecast", ""),
                        actual=row.get("actual", ""), source="static_csv",
                    ))
                except Exception as e:
                    logger.debug("skipping malformed news row: %s", e)
        self._events = events
        self._loaded_at = datetime.now(timezone.utc)
        return self._events

    def get_events(self, start: datetime, end: datetime) -> list[NewsEvent]:
        return [e for e in self._load() if start <= e.time <= end]

    def healthy(self) -> bool:
        return self.csv_path.exists()

    def last_update(self) -> datetime | None:
        # File mtime is the honest provenance signal (when the file was
        # written) — but see is_fresh(): it must NOT gate trading by itself.
        if not self.csv_path.exists():
            return None
        try:
            return datetime.fromtimestamp(self.csv_path.stat().st_mtime, tz=timezone.utc)
        except Exception:
            return None

    def coverage(self) -> tuple[datetime, datetime] | None:
        events = self._load()
        if not events:
            return None
        return (min(e.time for e in events), max(e.time for e in events))

    def is_fresh(self, max_age_seconds: float = 24 * 3600.0,
                 now: datetime | None = None) -> bool:
        """v1.8.1 (hotfix F28): COVERAGE-based freshness for a static calendar.

        The previous implementation used file mtime with a 24h window — but a
        calendar shipped inside a ZIP preserves its BUILD timestamp, so every
        user's copy became "stale" 24h after packaging and the system waited
        on NEWS_UNAVAILABLE forever, even while the calendar's events covered
        months AROUND the current date.

        For a schedule of KNOWN-FUTURE economic releases, the honest question
        is not "when was the file written?" but "does it speak about NOW?":
        fresh ⟺ the event coverage window spans the current instant. mtime
        stays available via last_update() for display/provenance only.
        """
        now = now or datetime.now(timezone.utc)
        cov = self.coverage()
        if cov is None:
            return False
        first, last = cov
        if first.tzinfo is None:
            first = first.replace(tzinfo=timezone.utc)
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        return first <= now <= last


class MockNewsProvider(StaticCSVNewsProvider):
    """Deterministic weekly schedule: NFP (first Fri 13:30 UTC, HIGH) +
    CPI (10th 13:30 UTC, HIGH) + FOMC (20th 19:00 UTC, HIGH)."""

    name = "mock"

    def get_events(self, start: datetime, end: datetime) -> list[NewsEvent]:
        events: list[NewsEvent] = []
        day = start.date() - timedelta(days=1)
        while day <= end.date() + timedelta(days=1):
            dt = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
            if day.weekday() == 4:  # Friday
                events.append(NewsEvent(event="Non-Farm Payrolls", country="US", currency="USD",
                                        importance="HIGH", time=dt + timedelta(hours=13, minutes=30),
                                        source="mock"))
            if day.day == 10:
                events.append(NewsEvent(event="US CPI y/y", country="US", currency="USD",
                                        importance="HIGH", time=dt + timedelta(hours=13, minutes=30),
                                        source="mock"))
            if day.day == 20:
                events.append(NewsEvent(event="FOMC Rate Decision", country="US", currency="USD",
                                        importance="HIGH", time=dt + timedelta(hours=19), source="mock"))
            day += timedelta(days=1)
        return [e for e in events if start <= e.time <= end]

    def is_fresh(self, max_age_seconds: float = 24 * 3600.0,
                 now: datetime | None = None) -> bool:
        # v1.8.1: the mock generates events ON the requested window by
        # construction — it is always coverage-fresh (it never reads the CSV).
        return True


class HTTPNewsProvider(NewsProvider):
    """Generic JSON calendar endpoint: expects a list of NewsEvent-shaped dicts.

    ⚠ Response is UNTRUSTED DATA: schema-validated and sanitised; arbitrary
    fields are dropped. Real economic-calendar APIs differ — adapt here.

    v1.5 (finding 20): the HTTP call is moved OFF the caller's thread via
    ``asyncio.to_thread`` in :meth:`get_events_async` — the trading loop must
    never block on network I/O (Mission 40).
    """

    name = "http"

    def __init__(self, url: str, timeout: float = 10.0) -> None:
        self.url = url
        self.timeout = timeout
        self._last_ok = False
        self._last_success_at: datetime | None = None

    def healthy(self) -> bool:
        return self._last_ok

    def last_update(self) -> datetime | None:
        return self._last_success_at

    def get_events(self, start: datetime, end: datetime) -> list[NewsEvent]:
        params = {"from": start.isoformat(), "to": end.isoformat()}
        try:
            resp = httpx.get(self.url, params=params, timeout=self.timeout,
                             headers={"User-Agent": "xau-ai-trader/0.1"})
            resp.raise_for_status()
            payload = resp.json()
            self._last_ok = True
            self._last_success_at = datetime.now(timezone.utc)
        except Exception as e:
            logger.warning("news HTTP provider failed: %s", e)
            self._last_ok = False
            return []
        events: list[NewsEvent] = []
        if isinstance(payload, list):
            for item in payload[:500]:
                try:
                    events.append(NewsEvent(**item))
                except Exception:
                    continue
        return events

    async def get_events_async(self, start: datetime, end: datetime) -> list[NewsEvent]:
        """Non-blocking variant for the async trading loop (Mission 40)."""
        import asyncio

        return await asyncio.to_thread(self.get_events, start, end)


def build_news_provider(cfg: NewsConfig) -> NewsProvider:
    """PHASE 65 §11 STATUS:

    - static_csv : IMPLEMENTED (shipped sample calendar — NOT a live feed)
    - mock       : IMPLEMENTED (unit tests / demo ONLY — forbidden in real reports)
    - http       : GENERIC TRANSPORT IMPLEMENTED; a concrete REAL provider
                   (ForexFactory / Investing / broker calendar API) is
                   NOT IMPLEMENTED — plug one in by subclassing NewsProvider.
    - none       : v1.5 — explicit NO provider. Returns NullNewsProvider:
                   healthy()=False → risk UNKNOWN → WAIT (config_real.yaml
                   documented this contract but the factory fell through to
                   the static CSV, silently going news-neutral).
    Live behaviour with no real provider: assessment UNKNOWN/LOW → the risk
    engine keeps the system in WAIT/news-neutral instead of guessing.
    """
    if cfg.provider == "none":
        return NullNewsProvider()
    if cfg.provider == "mock":
        return MockNewsProvider(cfg.csv_path)
    if cfg.provider == "http" and cfg.http_url:
        return HTTPNewsProvider(cfg.http_url, cfg.http_timeout_seconds)
    return StaticCSVNewsProvider(cfg.csv_path)


class NullNewsProvider(NewsProvider):
    """Explicit 'no news provider' — permanently unhealthy by contract so
    live mode fails closed (UNKNOWN → WAIT)."""

    name = "none"

    def get_events(self, start: datetime, end: datetime) -> list[NewsEvent]:
        return []

    def healthy(self) -> bool:
        return False

"""News data models. All text from providers is UNTRUSTED — sanitise on ingest."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator

from app.core.security import sanitize_untrusted_text


class NewsEvent(BaseModel):
    event: str = Field(max_length=120)
    country: str = Field(max_length=8, default="")
    currency: str = Field(max_length=8, default="USD")
    importance: Literal["LOW", "MEDIUM", "HIGH"] = "MEDIUM"
    time: datetime
    previous: str = Field(max_length=32, default="")
    forecast: str = Field(max_length=32, default="")
    actual: str = Field(max_length=32, default="")
    source: str = Field(max_length=64, default="unknown")

    @field_validator("event", "previous", "forecast", "actual", "country", "source")
    @classmethod
    def _sanitize(cls, v: str) -> str:
        return sanitize_untrusted_text(v, max_length=120)

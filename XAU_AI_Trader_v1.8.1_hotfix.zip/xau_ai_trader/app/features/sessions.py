"""Session classification (UTC based, configurable)."""

from __future__ import annotations

import pandas as pd

from app.config.schema import SessionsConfig


def session_flags(index: pd.DatetimeIndex, cfg: SessionsConfig) -> pd.DataFrame:
    """Return boolean session columns for each timestamp (UTC)."""
    h = index.hour
    overlap = (h >= cfg.ny_start) & (h < min(cfg.london_end, cfg.ny_end))
    return pd.DataFrame(
        {
            "session_asia": (h >= cfg.asia_start) & (h < cfg.asia_end),
            "session_london": (h >= cfg.london_start) & (h < cfg.london_end),
            "session_newyork": (h >= cfg.ny_start) & (h < cfg.ny_end),
            "session_overlap": overlap,
        },
        index=index,
    ).astype(float)


def current_session_name(ts: pd.Timestamp, cfg: SessionsConfig) -> str:
    # v1.5 fix: convert tz-aware timestamps to UTC (a non-UTC tz-aware input
    # previously used its local wall hour and misclassified the session).
    ts = ts.tz_convert("UTC") if ts.tzinfo is not None else ts.tz_localize("UTC")
    h = ts.hour
    if cfg.ny_start <= h < min(cfg.london_end, cfg.ny_end):
        return "overlap"
    if cfg.london_start <= h < cfg.london_end:
        return "london"
    if cfg.ny_start <= h < cfg.ny_end:
        return "newyork"
    if cfg.asia_start <= h < cfg.asia_end:
        return "asia"
    return "off"

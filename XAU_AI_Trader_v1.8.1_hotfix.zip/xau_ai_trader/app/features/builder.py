"""PHASE 4 — Feature engineering.

Builds a causal feature matrix on the base timeframe:
- price action, trend, momentum, volatility indicators (base TF)
- higher-TF indicators aligned by BAR COMPLETION TIME (v1.5: time-based
  shift instead of positional shift — a HTF bar stamped at open time T
  becomes available at T + tf_duration, expressed on the time axis itself)
- SMC structure/liquidity features
- session & time features

Leakage policy: a higher-TF bar stamped at open-time T is only available at
T + tf_minutes. v1.5 implements this directly on the index (index + duration,
then backward as-of join) which is equivalent to the old positional shift(1)
on a regular grid but remains correct when HTF bars are missing or irregular
and is self-documenting (see tests/test_features.py).
"""

from __future__ import annotations

import hashlib
import json

import numpy as np
import pandas as pd

from app.config.schema import FeatureConfig, IndicatorConfig, SessionsConfig, Timeframe
from app.features.sessions import session_flags
from app.indicators import ta
from app.smc.engine import SMCEngine, SMCResult


def align_higher_tf(base_index: pd.DatetimeIndex, htf: pd.DataFrame,
                    tf_minutes: int | None = None) -> pd.DataFrame:
    """Make HTF features available at their true completion time.

    v1.5 (Mission 5): instead of a positional ``shift(1)`` — which is only
    correct on a perfectly regular HTF grid — each HTF bar's availability
    timestamp is set to ``bar_open_time + timeframe_duration`` (its actual
    completion time) and the result is backward as-of joined onto the base
    index (equivalent to merge_asof(direction='backward')).

    ``tf_minutes`` is inferred from the median index spacing when not given.
    """
    h = htf.copy()
    if tf_minutes is None:
        if len(h) >= 2:
            diffs = pd.Series(h.index).diff().dropna()
            tf_minutes = int(max(1, round(diffs.dt.total_seconds().median() / 60.0)))
        else:
            tf_minutes = 1
    h.index = h.index + pd.Timedelta(minutes=tf_minutes)
    return h.reindex(base_index, method="ffill")


class FeatureBuilder:
    def __init__(
        self,
        fcfg: FeatureConfig,
        icfg: IndicatorConfig,
        scfg: SessionsConfig,
        smc_cfg=None,
    ) -> None:
        self.fcfg = fcfg
        self.icfg = icfg
        self.scfg = scfg
        self.smc_engine = SMCEngine(smc_cfg) if smc_cfg is not None else None
        self._smc_cache: dict[str, SMCResult] = {}

    # ------------------------------------------------------------ base TF --
    def _base_features(self, df: pd.DataFrame) -> pd.DataFrame:
        ic = self.icfg
        close, high, low, open_ = df["close"], df["high"], df["low"], df["open"]
        f = pd.DataFrame(index=df.index)

        f["log_return"] = np.log(close / close.shift(1))
        for w in self.fcfg.momentum_windows:
            f[f"ret_{w}"] = close.pct_change(w)
        body = (close - open_).abs()
        rng = (high - low).replace(0.0, np.nan)
        f["body_ratio"] = body / rng
        upper_wick = high - pd.concat([open_, close], axis=1).max(axis=1)
        lower_wick = pd.concat([open_, close], axis=1).min(axis=1) - low
        f["wick_ratio"] = (upper_wick + lower_wick) / rng
        f["range"] = rng
        atr = ta.atr(high, low, close, ic.atr_period)
        f["atr"] = atr
        f["atr_pct"] = atr / close
        f["atr_norm_range"] = rng / atr.replace(0.0, np.nan)
        for w in self.fcfg.momentum_windows:
            f[f"momentum_{w}"] = close.diff(w)

        for p in ic.ema_periods:
            e = ta.ema(close, p)
            f[f"ema{p}_dist"] = close / e - 1.0
            f[f"ema{p}_slope"] = e.diff(3) / e.shift(3)
        s = ta.sma(close, ic.sma_period)
        f["sma_dist"] = close / s - 1.0

        adx_df = ta.adx(high, low, close, ic.adx_period)
        f["adx"] = adx_df["adx"]
        f["di_diff"] = adx_df["di_plus"] - adx_df["di_minus"]

        f["rsi"] = ta.rsi(close, ic.rsi_period)
        f["rsi_delta"] = f["rsi"].diff(3)
        macd_df = ta.macd(close, ic.macd_fast, ic.macd_slow, ic.macd_signal)
        f["macd"] = macd_df["macd"] / close
        f["macd_hist"] = macd_df["macd_hist"] / close
        stoch_df = ta.stochastic(high, low, close, ic.stochastic_k, ic.stochastic_d)
        f["stoch_k"] = stoch_df["stoch_k"]
        f["stoch_d"] = stoch_df["stoch_d"]
        f["roc"] = ta.roc(close, ic.roc_period)

        bb = ta.bollinger(close, ic.bollinger_period, ic.bollinger_std)
        f["bb_pos"] = bb["bb_pos"].fillna(0.5)
        f["bb_width"] = bb["bb_width"]
        for w in ic.realized_vol_windows:
            f[f"realized_vol_{w}"] = ta.realized_vol(close, w)
        f["range_expansion"] = rng / rng.rolling(20, min_periods=20).mean()
        return f

    # ----------------------------------------------------------- sessions --
    def _time_features(self, index: pd.DatetimeIndex) -> pd.DataFrame:
        f = session_flags(index, self.scfg)
        hour = index.hour.values
        dow = index.dayofweek.values
        f["hour_sin"] = np.sin(2 * np.pi * hour / 24.0)
        f["hour_cos"] = np.cos(2 * np.pi * hour / 24.0)
        f["day_of_week"] = dow.astype(float)
        f["minute_of_hour"] = index.minute.values.astype(float)
        return f

    # --------------------------------------------------------------- main --
    def build(self, frames: dict[str, pd.DataFrame], base_tf: Timeframe = Timeframe.M5) -> tuple[pd.DataFrame, list[str]]:
        base_key = base_tf.value
        if base_key not in frames:
            raise KeyError(f"base timeframe {base_key} missing from frames")
        base = frames[base_key]
        feats = self._base_features(base)
        feats = feats.join(self._time_features(base.index), how="left")

        for tf in frames:
            if tf == base_key:
                continue
            htf = frames[tf]
            htf_feats = self._compact_htf_features(htf, tf)
            tf_minutes = Timeframe(tf).minutes if tf in Timeframe.__members__ else None
            aligned = align_higher_tf(base.index, htf_feats, tf_minutes)
            feats = feats.join(aligned, how="left", rsuffix=f"_{tf}")

        if self.smc_engine is not None:
            base_key_used = base_key
            # v1.5 fix (Mission 5): the SMC cache must key on the DATA WINDOW
            # identity, not just its length. A fixed-size rolling live window
            # keeps len() constant while sliding — the old check silently
            # served stale SMC features (NaN joins / old zones) to the model.
            fingerprint = _window_fingerprint(base, self.smc_engine)
            cached = self._smc_cache.get(base_key_used)
            if cached is None or cached.fingerprint != fingerprint:
                self._smc_cache = {
                    base_key_used: self.smc_engine.analyze(base, base_key_used).attach_fingerprint(fingerprint)
                }
            smc = self._smc_cache[base_key_used]
            smc_feats = smc.features.copy()
            # distance features: "no active reference zone" is a state, not
            # missing data — carry forward then neutral-fill BEFORE normalising
            dist_cols = [c for c in smc_feats.columns if c.startswith("dist_")]
            if dist_cols:
                smc_feats[dist_cols] = smc_feats[dist_cols].ffill().fillna(0.0)
            # ATR-normalise distance features (relative distance from close)
            for col in dist_cols:
                smc_feats[f"{col}_norm"] = (smc_feats[col]) / base["close"]
                smc_feats = smc_feats.drop(columns=[col])
            for col in ("pdh", "pdl", "pwh", "pwl"):
                if col in smc_feats.columns:
                    smc_feats[f"{col}_norm"] = (smc_feats[col] - base["close"]) / base["close"]
                    smc_feats = smc_feats.drop(columns=[col])
            feats = feats.join(smc_feats, how="left")

        feats = feats.replace([np.inf, -np.inf], np.nan)
        feature_names = list(feats.columns)
        return feats, feature_names

    def _compact_htf_features(self, df: pd.DataFrame, tf: str) -> pd.DataFrame:
        ic = self.icfg
        close, high, low = df["close"], df["high"], df["low"]
        f = pd.DataFrame(index=df.index)
        prefix = tf.lower()
        # relaxed min_periods: higher timeframes accumulate slowly; requiring the
        # full window would make e.g. D1 features all-NaN for short histories
        e_fast = close.ewm(span=20, min_periods=5, adjust=False).mean()
        e_slow = close.ewm(span=50, min_periods=5, adjust=False).mean()
        f[f"{prefix}_trend"] = (e_fast / e_slow - 1.0).clip(-0.2, 0.2)
        f[f"{prefix}_slope"] = e_fast.diff(3) / e_slow.shift(3)
        f[f"{prefix}_rsi"] = ta.rsi(close, min(ic.rsi_period, 14))
        a = ta.true_range(high, low, close).ewm(
            alpha=1 / ic.atr_period, min_periods=3, adjust=False).mean()
        f[f"{prefix}_atr_pct"] = a / close
        adx_df = ta.adx(high, low, close, ic.adx_period)
        f[f"{prefix}_adx"] = adx_df["adx"]
        f[f"{prefix}_di_diff"] = adx_df["di_plus"] - adx_df["di_minus"]
        f[f"{prefix}_ret"] = close.pct_change(5).clip(-0.1, 0.1)
        return f

    # ------------------------------------------------------------ version --
    @staticmethod
    def feature_version(
        feature_names: list[str],
        cfg_tag: str = "v1",
        indicator_cfg=None,
        feature_cfg=None,
        sessions_cfg=None,
        smc_cfg=None,
        label_spec: dict | None = None,
        scaler_kind: str | None = None,
        builder_rev: str = "v15",
    ) -> str:
        """Hash the FULL feature contract (v1.5, Mission 5/28).

        The old version hashed only the sorted feature-name list — changing
        e.g. rsi_period 14→21 kept the same 'version' while the feature
        distribution shifted, silently invalidating every registered model
        and drift baseline. The hash now covers: feature names, indicator
        parameters, feature/session/SMC configuration, the label spec,
        the scaler kind and the builder revision.
        """
        def _dump(obj) -> dict:
            if obj is None:
                return {}
            if hasattr(obj, "model_dump"):
                return obj.model_dump()
            return {k: str(v) for k, v in sorted(vars(obj).items())} if hasattr(obj, "__dict__") else {"cfg": str(obj)}

        payload = {
            "names": sorted(feature_names),
            "tag": cfg_tag,
            "indicators": _dump(indicator_cfg),
            "features": _dump(feature_cfg),
            "sessions": _dump(sessions_cfg),
            "smc": _dump(smc_cfg),
            "label_spec": label_spec or {},
            "scaler": scaler_kind or "",
            "builder_rev": builder_rev,
        }
        canonical = json.dumps(payload, sort_keys=True, default=str)
        return hashlib.sha256(canonical.encode()).hexdigest()[:12]


def _window_fingerprint(base: pd.DataFrame, smc_engine) -> str:
    """Content fingerprint of a rolling candle window for cache identity.

    Covers first/last timestamps, length, last close and the SMC config so
    ANY change of window content or analysis parameters invalidates the cache.
    """
    smc_cfg_part = ""
    if getattr(smc_engine, "cfg", None) is not None:
        try:
            smc_cfg_part = json.dumps(smc_engine.cfg.model_dump(), sort_keys=True, default=str)
        except Exception:
            smc_cfg_part = str(smc_engine.cfg)
    head = (str(base.index[0]), str(base.index[-1]), int(len(base)),
            float(base["close"].iloc[-1]), float(base["high"].iloc[-1]), float(base["low"].iloc[-1]))
    return hashlib.sha256((repr(head) + smc_cfg_part).encode()).hexdigest()[:16]

"""PHASE 33 — Event-driven backtester with realistic cost modelling.

Costs modelled: spread, slippage, commission per lot, swap per night.
Execution delay: signals evaluated on bar t fill at bar t+delay open.
Conservative fills: if SL and TP both inside one bar → SL first.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from app.backtest import metrics as btmetrics
from app.config.schema import BacktestConfig, SymbolInfoDefaults
from app.data.market.models import SymbolInfo

logger = logging.getLogger(__name__)


@dataclass
class Trade:
    ticket: int
    side: str
    volume: float
    entry_time: pd.Timestamp
    entry_price: float
    sl: float
    tp: float
    exit_time: pd.Timestamp | None = None
    exit_price: float | None = None
    pnl: float = 0.0
    fees: float = 0.0
    swap: float = 0.0
    mfe: float = 0.0
    mae: float = 0.0
    exit_reason: str = ""
    signal_score: float = 0.0
    # PHASE 65 §26 — three-stage execution timing
    signal_time: pd.Timestamp | None = None   # bar close where the signal fired
    order_time: pd.Timestamp | None = None    # next bar open where the order was submitted
    fill_time: pd.Timestamp | None = None     # assumed immediate market fill at order_time

    def as_dict(self) -> dict:
        d = self.__dict__.copy()
        for k in ("entry_time", "exit_time", "signal_time", "order_time", "fill_time"):
            if d.get(k) is not None:
                d[k] = pd.Timestamp(d[k]).isoformat()
        return d


@dataclass
class BacktestResult:
    trades: list[Trade] = field(default_factory=list)
    equity_curve: pd.Series | None = None
    summary: dict = field(default_factory=dict)
    monthly: pd.DataFrame | None = None
    daily: pd.DataFrame | None = None

    def trades_df(self) -> pd.DataFrame:
        if not self.trades:
            return pd.DataFrame()
        return pd.DataFrame([t.as_dict() for t in self.trades])


class Backtester:
    def __init__(
        self,
        cfg: BacktestConfig,
        symbol_info: SymbolInfo,
        commission_per_lot: float = 7.0,
        swap_long: float = -8.0,
        swap_short: float = -2.0,
        slippage_points: float = 5.0,
        daily_loss_stop_percent: float | None = None,
        assumed_spread: float | None = None,
        spread_units: str = "PRICE",
        swap_hour_utc: int = 21,
        triple_swap_weekday: int = 2,
    ) -> None:
        self.cfg = cfg
        self.symbol = symbol_info
        self.commission = commission_per_lot
        self.swap_long = swap_long
        self.swap_short = swap_short
        self.slippage = slippage_points * symbol_info.point
        self.daily_loss_stop = daily_loss_stop_percent
        # PHASE 65 §26: spread source priority = dataset column > assumed_spread.
        # When neither exists a conservative 2-point spread is applied and the
        # report MUST disclose it as an assumption.
        self.assumed_spread = assumed_spread
        self.spread_source = "dataset_column"
        # v1.5 (Mission 19 / finding 4): spread units are EXPLICIT. MT5 broker
        # datasets store spread in POINTS (e.g. 13–50 for XAUUSD); using those
        # values as absolute price would model a $13–50 spread on gold.
        if spread_units not in ("PRICE", "POINTS"):
            raise ValueError(f"spread_units must be PRICE or POINTS, got {spread_units!r}")
        self.spread_units = spread_units
        self.swap_hour_utc = int(swap_hour_utc)
        self.triple_swap_weekday = int(triple_swap_weekday)  # 0=Mon..2=Wed (3x swap day)

    # --------------------------------------------------------------- run ---
    def run(
        self,
        df: pd.DataFrame,
        signals: pd.DataFrame,
        initial_balance: float | None = None,
    ) -> BacktestResult:
        """signals: DataFrame indexed like df with columns
        [side (BUY/SELL/), sl, tp, lot, score] — already risk-approved.
        Signals on bar t are executed at bar t+delay open."""
        initial_balance = initial_balance or self.cfg.initial_balance
        delay = max(1, self.cfg.execution_delay_bars)
        if "spread" in df.columns and df["spread"].astype(float).abs().sum() > 0:
            spread = df["spread"].astype(float)
            # v1.5 (Mission 19): convert POINTS → PRICE at the boundary; a NaN
            # in the spread column must not poison mark prices (ML-N8).
            if self.spread_units == "POINTS":
                spread = spread * float(self.symbol.point)
            self.spread_source = f"dataset_column ({self.spread_units})"
        elif self.assumed_spread and self.assumed_spread > 0:
            spread = pd.Series(float(self.assumed_spread), index=df.index)
            self.spread_source = f"assumed_spread={self.assumed_spread} (PRICE)"
        else:
            spread = pd.Series(2.0 * self.symbol.point, index=df.index)
            self.spread_source = "fallback_2_points (PRICE)"
        spread = spread.ffill().fillna(0.0)

        balance = initial_balance
        equity_hist: list[tuple[pd.Timestamp, float]] = []
        trades: list[Trade] = []
        open_trade: Trade | None = None
        ticket = 0
        peak = initial_balance

        sig_by_time = {t: row for t, row in signals.iterrows()} if not signals.empty else {}

        index = df.index
        for i in range(delay, len(index)):
            ts = index[i]
            bar = df.iloc[i]
            mid_open = float(bar["open"])
            half_spread = float(spread.iloc[i]) / 2.0

            # ---- manage open trade ---------------------------------------
            if open_trade is not None:
                self._update_trade(open_trade, bar, half_spread, ts)
                swap_applied = self._apply_swap(open_trade, ts)
                if open_trade.exit_reason:
                    balance += open_trade.pnl - open_trade.fees + open_trade.swap
                    trades.append(open_trade)
                    open_trade = None
                # daily loss stop
                if self.daily_loss_stop is not None and open_trade is None and trades:
                    day_pnl = sum(t.pnl - t.fees + t.swap for t in trades
                                  if t.exit_time.date() == ts.date())
                    if day_pnl < 0 and abs(day_pnl) / initial_balance * 100 >= self.daily_loss_stop:
                        equity_hist.append((ts, balance))
                        continue  # stop trading for the day

            # ---- equity mark ------------------------------------------------
            floating = 0.0
            if open_trade is not None:
                mark = float(bar["close"])
                d = 1.0 if open_trade.side == "BUY" else -1.0
                floating = (mark - open_trade.entry_price) * d / self.symbol.tick_size \
                           * self.symbol.tick_value * open_trade.volume
            equity = balance + floating
            equity_hist.append((ts, equity))
            peak = max(peak, equity)

            # ---- entry ---------------------------------------------------------
            if open_trade is None:
                sig_time = index[i - delay]
                sig = sig_by_time.get(sig_time)
                if sig is not None and sig["side"] in ("BUY", "SELL"):
                    fill = mid_open + half_spread + self.slippage if sig["side"] == "BUY" \
                        else mid_open - half_spread - self.slippage
                    ticket += 1
                    open_trade = Trade(
                        ticket=ticket, side=str(sig["side"]), volume=float(sig["lot"]),
                        entry_time=ts, entry_price=float(fill),
                        sl=float(sig["sl"]), tp=float(sig["tp"]),
                        signal_score=float(sig.get("score", 0.0)),
                        fees=self.commission * float(sig["lot"]),
                        signal_time=index[i - delay],      # signal bar close
                        order_time=ts,                     # order submitted at next bar open
                        fill_time=ts,                      # market fill assumed same instant
                    )

        # force-close at end
        if open_trade is not None:
            last_bar = df.iloc[-1]
            ts = index[-1]
            self._update_trade(open_trade, last_bar, float(spread.iloc[-1]) / 2.0, ts, force=True)
            balance += open_trade.pnl - open_trade.fees + open_trade.swap
            trades.append(open_trade)
            open_trade = None
            equity_hist.append((ts, balance))

        result = BacktestResult()
        result.trades = trades
        eq = pd.Series({t: v for t, v in equity_hist}, dtype=float)
        result.equity_curve = eq
        tdf = result.trades_df()
        result.summary = btmetrics.summarize(tdf, eq, initial_balance)
        result.monthly = btmetrics.monthly_pl(tdf)
        result.daily = btmetrics.daily_pl(tdf)
        return result

    # ------------------------------------------------------------ internals --
    def _update_trade(self, trade: Trade, bar: pd.Series, half_spread: float,
                      ts: pd.Timestamp, force: bool = False) -> None:
        direction = 1.0 if trade.side == "BUY" else -1.0
        if trade.side == "BUY":
            mark_high = float(bar["high"]) - half_spread
            mark_low = float(bar["low"]) - half_spread
            mark_close = float(bar["close"]) - half_spread
        else:
            mark_high = float(bar["high"]) + half_spread
            mark_low = float(bar["low"]) + half_spread
            mark_close = float(bar["close"]) + half_spread

        profit_at = lambda price: (price - trade.entry_price) * direction / self.symbol.tick_size \
            * self.symbol.tick_value * trade.volume  # noqa: E731

        trade.mfe = max(trade.mfe, profit_at(mark_high) if direction > 0 else profit_at(mark_low))
        trade.mae = min(trade.mae, profit_at(mark_low) if direction > 0 else profit_at(mark_high))

        if direction > 0:
            hit_sl = mark_low <= trade.sl
            hit_tp = mark_high >= trade.tp
        else:
            hit_sl = mark_high >= trade.sl
            hit_tp = mark_low <= trade.tp

        if hit_sl or force:
            # v1.5 (Mission 18 / N-gap): if the bar OPENS beyond the stop
            # (weekend/news gap on XAUUSD), the fill is at the open — the
            # worst-case price — not at the stop level. The old model
            # always filled at SL, which is optimistic on gaps.
            if hit_sl:
                if direction > 0:
                    gap_fill = min(trade.sl, float(bar["open"]) - half_spread)
                else:
                    gap_fill = max(trade.sl, float(bar["open"]) + half_spread)
                exit_price = gap_fill
            else:
                exit_price = mark_close
            if hit_sl and hit_tp and self.cfg.both_hit_assumption == "tp_first":
                # v1.5: honour the config instead of silently ignoring it —
                # but the DEFAULT remains SL-first (conservative), and the
                # assumption is recorded on the trade.
                exit_price = trade.tp
                trade.exit_reason = "TP"
            else:
                trade.exit_reason = "SL" if hit_sl else "EOD"
            trade.exit_price = float(exit_price)
            trade.exit_time = ts
            trade.pnl = profit_at(float(exit_price))
            if hit_sl and hit_tp:
                trade.exit_reason = (trade.exit_reason + "_same_bar").lstrip("_")
        elif hit_tp:
            trade.exit_price = float(trade.tp)
            trade.exit_time = ts
            trade.pnl = profit_at(trade.tp)
            trade.exit_reason = "TP"

    def _apply_swap(self, trade: Trade, ts: pd.Timestamp) -> None:
        """Broker-style swap at the configured rollover hour (v1.5, Mission 20).

        - charged when a position is OPEN AT the rollover instant
          (swap_hour_utc, default 21:00 UTC = 5pm ET), not at midnight;
        - Wednesday rollover books 3× swap (the classic triple-swap day,
          compensating the weekend);
        - closing at/after the rollover bar still books that night's swap
          (the position existed at the rollover instant — conservative)."""
        if not self._is_rollover_hour(ts):
            return
        day = ts.date().isoformat()
        key = f"{trade.ticket}:{day}"
        if getattr(trade, "_last_swap_day", "") == day:
            return
        rate = self.swap_long if trade.side == "BUY" else self.swap_short
        mult = 3 if ts.weekday() == self.triple_swap_weekday else 1
        trade.swap += rate * trade.volume * mult
        trade._last_swap_day = day

    def _is_rollover_hour(self, ts: pd.Timestamp) -> bool:
        return ts.hour == self.swap_hour_utc and ts.minute == 0

"""Trading performance metrics (PHASE 8/33).

NO PROFIT CLAIMS: these functions report computed history only.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def profit_factor(pnl: np.ndarray) -> float:
    wins = pnl[pnl > 0].sum()
    losses = -pnl[pnl < 0].sum()
    if losses <= 0:
        return float("inf") if wins > 0 else 0.0
    return float(wins / losses)


def expectancy(pnl: np.ndarray) -> float:
    return float(np.mean(pnl)) if len(pnl) else 0.0


def win_rate(pnl: np.ndarray) -> float:
    return float((pnl > 0).mean() * 100.0) if len(pnl) else 0.0


def max_drawdown(equity: pd.Series | np.ndarray) -> float:
    eq = pd.Series(equity, dtype=float)
    peak = eq.cummax()
    dd = (eq - peak) / peak.replace(0.0, np.nan)
    return float(dd.min() * 100.0) if len(dd) else 0.0


def sharpe(returns: pd.Series | np.ndarray, periods_per_year: int = 252) -> float:
    r = pd.Series(returns, dtype=float).dropna()
    if len(r) < 2 or r.std(ddof=0) == 0:
        return 0.0
    return float(r.mean() / r.std(ddof=0) * np.sqrt(periods_per_year))


def sortino(returns: pd.Series | np.ndarray, periods_per_year: int = 252) -> float:
    r = pd.Series(returns, dtype=float).dropna()
    downside = r[r < 0]
    if len(r) < 2 or len(downside) == 0:
        return 0.0
    dd = downside.std(ddof=0)
    if dd == 0:
        return 0.0
    return float(r.mean() / dd * np.sqrt(periods_per_year))


def monthly_pl(trades: pd.DataFrame) -> pd.DataFrame:
    """trades must have exit_time (tz-aware) and pnl columns."""
    if trades.empty:
        return pd.DataFrame(columns=["month", "pnl", "trades"])
    t = trades.copy()
    t["month"] = pd.to_datetime(t["exit_time"], utc=True).dt.strftime("%Y-%m")
    out = t.groupby("month").agg(pnl=("pnl", "sum"), trades=("pnl", "count")).reset_index()
    return out


def daily_pl(trades: pd.DataFrame) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame(columns=["day", "pnl", "trades"])
    t = trades.copy()
    t["day"] = pd.to_datetime(t["exit_time"], utc=True).dt.date.astype(str)
    out = t.groupby("day").agg(pnl=("pnl", "sum"), trades=("pnl", "count")).reset_index()
    return out


def summarize(trades: pd.DataFrame, equity_curve: pd.Series, initial_balance: float) -> dict:
    """Headline metrics are NET of costs (v1.5, ML-N5).

    ``pnl`` in the trade rows is the gross price P&L; the engine separately
    tracks ``fees`` (commission) and ``swap``. Headline PF/expectancy now use
    ``pnl_net = pnl - fees + swap`` (the balance-equivalent series) so a
    strategy that is only gross-profitable can never pass as net-profitable.
    Gross values are kept under *_gross keys for comparison.
    """
    if trades.empty:
        pnl = np.array([])
        pnl_net = np.array([])
    else:
        pnl = trades["pnl"].values.astype(float)
        fees = trades["fees"].values.astype(float) if "fees" in trades.columns else 0.0
        swap = trades["swap"].values.astype(float) if "swap" in trades.columns else 0.0
        pnl_net = pnl - np.asarray(fees) + np.asarray(swap)
    daily_eq = equity_curve.resample("1D").last().dropna() if len(equity_curve) else pd.Series(dtype=float)
    daily_ret = daily_eq.pct_change().dropna() if len(daily_eq) > 1 else pd.Series(dtype=float)
    wins = pnl_net[pnl_net > 0]
    losses = pnl_net[pnl_net < 0]
    return {
        "n_trades": int(len(pnl)),
        "net_pl": float(pnl_net.sum()) if len(pnl_net) else 0.0,
        "gross_pl": float(pnl.sum()) if len(pnl) else 0.0,
        "profit_factor": profit_factor(pnl_net),
        "profit_factor_gross": profit_factor(pnl),
        "expectancy": expectancy(pnl_net),
        "expectancy_gross": expectancy(pnl),
        "win_rate_pct": win_rate(pnl_net),
        "avg_win": float(wins.mean()) if len(wins) else 0.0,
        "avg_loss": float(losses.mean()) if len(losses) else 0.0,
        "max_drawdown_pct": max_drawdown(equity_curve.values if len(equity_curve) else [initial_balance]),
        "sharpe": sharpe(daily_ret) if len(daily_ret) else 0.0,
        "sortino": sortino(daily_ret) if len(daily_ret) else 0.0,
        "final_balance": float(equity_curve.iloc[-1]) if len(equity_curve) else initial_balance,
        "return_pct": float((equity_curve.iloc[-1] / initial_balance - 1) * 100) if len(equity_curve) else 0.0,
    }

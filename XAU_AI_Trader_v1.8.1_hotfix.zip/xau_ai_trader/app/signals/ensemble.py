"""Signal Ensemble Engine (PHASE 21 fusion part).

Combines calibrated ML probabilities, SMC bias, regime gating, news risk
and AI consensus into a single ensemble decision. WAIT is the default when
evidence is insufficient or conflicting.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from app.config.schema import EnsembleWeights, NewsRisk, Regime


@dataclass
class EnsembleDecision:
    side: str  # BUY | SELL | WAIT
    score: float = 0.0
    confidence: float = 0.0
    reasons: list[str] = field(default_factory=list)
    components: dict = field(default_factory=dict)
    requires_confirmation: bool = False

    @property
    def is_actionable(self) -> bool:
        return self.side in ("BUY", "SELL")


class SignalEnsemble:
    def __init__(self, cfg: EnsembleWeights) -> None:
        self.cfg = cfg

    def decide(
        self,
        ml_probs: dict[str, np.ndarray] | None,   # {"lgbm": (3,), "xgb": (3,)} last row
        smc_bias: float,
        regime: Regime,
        news_risk: NewsRisk,
        ai_decision: str | None = None,
        ai_confidence: float | None = None,
        ai_conflict: bool = False,
        model_quality: dict[str, float] | None = None,
        expected_value: float | None = None,
    ) -> EnsembleDecision:
        """Fuse evidence into a decision.

        v1.5 (Mission 12 / findings 8+9):
        - ``model_quality``: optional {model_name: OOS log-loss}; models are
          weighted inverse-log-loss instead of a naive average.
        - ``expected_value``: EV-after-costs from the EV layer (Mission 13);
          when provided, a non-positive EV vetoes the trade regardless of
          the composite score.
        - P(NO_EDGE) is now a FIRST-CLASS veto: a high NO_EDGE probability
          means the market offers no tradable edge even if BUY > SELL.
        """
        cfg = self.cfg
        reasons: list[str] = []
        components: dict = {}

        # ---- news hard gate ----------------------------------------------
        if news_risk == NewsRisk.HIGH:
            return EnsembleDecision("WAIT", 0.0, 0.0, ["NEWS_RISK_HIGH_WAIT"], components)
        if news_risk == NewsRisk.UNKNOWN:
            return EnsembleDecision("WAIT", 0.0, 0.0, ["NEWS_UNKNOWN_WAIT"], components)

        # ---- ML consensus (quality-weighted, NO_EDGE-aware) ----------------
        if not ml_probs:
            return EnsembleDecision("WAIT", 0.0, 0.0, ["ML_UNAVAILABLE"], components)
        mq = model_quality or {}
        usable = {k: np.asarray(p, dtype=float) for k, p in ml_probs.items()
                  if k not in mq or (mq[k] is not None and np.isfinite(mq[k]))}
        if not usable:
            usable = {k: np.asarray(p, dtype=float) for k, p in ml_probs.items()}
        if len(usable) > 1 and mq:
            # inverse-log-loss weights (bounded to avoid one model dominating)
            losses = {k: min(max(float(mq[k]), 1e-4), 10.0) for k in usable}
            inv = {k: 1.0 / l for k, l in losses.items()}
            tot = sum(inv.values())
            weights = {k: v / tot for k, v in inv.items()}
        else:
            weights = {k: 1.0 / len(usable) for k in usable}
        avg = np.zeros(3)
        for k, p in usable.items():
            avg += weights[k] * p
        p_sell, p_no_edge, p_buy = float(avg[0]), float(avg[1]), float(avg[2])
        components["ml_weights"] = {k: round(w, 3) for k, w in weights.items()}
        # v1.5 (finding 8): P(NO_EDGE) as a hard veto. A BUY=0.56 / NO_EDGE=0.40
        # situation is NOT the same as BUY=0.56 / NO_EDGE=0.10 — the former has
        # no tradable edge. On a valid simplex a NO_EDGE mass ≥ the veto
        # threshold caps any directional mass, so the trade is refused even
        # when BUY is the argmax. Threshold sits just above the uniform 1/3.
        no_edge_veto = max(0.34, cfg.min_ml_confidence - 0.15)
        if p_no_edge >= no_edge_veto:
            return EnsembleDecision(
                "WAIT", 0.0, p_no_edge,
                [f"ML_NO_EDGE_DOMINANT_{p_no_edge:.2f}"],
                {"ml_buy": p_buy, "ml_sell": p_sell, "ml_no_edge": p_no_edge},
            )
        best_p = max(p_buy, p_sell)
        ml_side = "BUY" if p_buy >= p_sell else "SELL"
        margin = abs(p_buy - p_sell)
        if margin < cfg.ml_conflict_margin:
            return EnsembleDecision(
                "WAIT", 0.0, best_p,
                [f"ML_AMBIGUOUS_MARGIN_{margin:.2f}"],
                {"ml_buy": p_buy, "ml_sell": p_sell, "ml_no_edge": p_no_edge},
            )
        if best_p < cfg.min_ml_confidence:
            return EnsembleDecision(
                "WAIT", 0.0, best_p,
                [f"ML_CONF_LOW_{best_p:.2f}"],
                {"ml_buy": p_buy, "ml_sell": p_sell, "ml_no_edge": p_no_edge},
            )
        reasons.append(f"ML_{ml_side}_{best_p:.2f}")
        components.update({"ml_buy": round(p_buy, 3), "ml_sell": round(p_sell, 3),
                           "ml_no_edge": round(p_no_edge, 3)})

        # ---- SMC agreement -----------------------------------------------------
        smc_side = "BUY" if smc_bias > cfg.smc_conflict_margin else ("SELL" if smc_bias < -cfg.smc_conflict_margin else "NEUTRAL")
        if smc_side != "NEUTRAL" and smc_side != ml_side:
            return EnsembleDecision(
                "WAIT", 0.0, best_p,
                [f"SMC_CONFLICTS_{smc_side}", f"SMC_BIAS_{smc_bias:.2f}"],
                components,
            )
        if smc_side == ml_side:
            reasons.append(f"SMC_AGREES_{smc_side}")
        components["smc_bias"] = round(float(smc_bias), 3)

        # ---- AI layer -----------------------------------------------------------
        ai_score = 0.0
        if ai_decision is not None:
            if ai_conflict:
                return EnsembleDecision("WAIT", 0.0, best_p, ["AI_CONFLICT_WAIT"], components)
            if ai_decision == "WAIT":
                if cfg.ai > 0:
                    return EnsembleDecision(
                        "WAIT", 0.0, best_p, ["AI_SAYS_WAIT"], components,
                        requires_confirmation=True,
                    )
            elif ai_decision == ml_side:
                ai_score = float(ai_confidence or 0.0)
                reasons.append(f"AI_AGREES_{ai_decision}_{ai_score:.2f}")
            else:  # AI disagrees with ML direction
                return EnsembleDecision(
                    "WAIT", 0.0, best_p, [f"AI_DISAGREES_{ai_decision}"], components,
                )
        components["ai"] = round(float(ai_score), 3)

        # ---- regime alignment ----------------------------------------------------
        regime_penalty = 0.0
        if regime in (Regime.RANGING,) and ml_side == "BUY" and (components.get("smc_bias", 0) or 0) < 0:
            regime_penalty = 0.1
        if regime in (Regime.HIGH_VOLATILITY, Regime.UNCERTAIN):
            reasons.append(f"REGIME_CAUTION_{regime.value}")
            regime_penalty += 0.15
        elif regime.value.endswith("BULL") and ml_side == "BUY":
            reasons.append("REGIME_ALIGNED_BULL")
        elif regime.value.endswith("BEAR") and ml_side == "SELL":
            reasons.append("REGIME_ALIGNED_BEAR")
        components["regime"] = regime.value

        # ---- weighted fusion (real Edge Score) ------------------------------
        # v1.5 (Mission 12): edge score = direction confidence × net-risk-unit
        # expectancy when an EV estimate is available, else the weighted
        # opinion mix. EV after costs > 0 is required when provided.
        ml_score = best_p
        smc_aligned = max(0.0, smc_bias if ml_side == "BUY" else -smc_bias)
        raw_score = cfg.ml * ml_score + cfg.smc * smc_aligned + cfg.ai * ai_score
        if expected_value is not None:
            edge_score = float(np.sign(expected_value) * min(abs(expected_value) / 100.0, 1.0) * 0.5 + raw_score * 0.5)
            if expected_value <= 0:
                return EnsembleDecision(
                    "WAIT", 0.0, best_p,
                    reasons + [f"EV_NOT_POSITIVE_{expected_value:.2f}"], components,
                )
        else:
            edge_score = raw_score
        score = float(np.clip(edge_score - regime_penalty, 0.0, 1.0))
        if score < cfg.min_score:
            return EnsembleDecision(
                "WAIT", score, best_p, reasons + [f"SCORE_BELOW_MIN_{score:.2f}"], components,
            )
        return EnsembleDecision(ml_side, score, best_p, reasons, components)

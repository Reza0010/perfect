"""Execution abstraction: PaperExecutor (simulated fills) + MT5Executor (live).

Every order carries magic number + comment; results include retcode.
"""

from __future__ import annotations

import abc

from app.data.market.models import OrderResult, Position


class Executor(abc.ABC):
    mode: str = "base"

    @abc.abstractmethod
    def open_market(self, symbol: str, side: str, volume: float, sl: float, tp: float,
                    comment: str = "", magic: int = 0) -> OrderResult: ...

    @abc.abstractmethod
    def close_position(self, ticket: int, reason: str = "") -> OrderResult: ...

    @abc.abstractmethod
    def modify_position(self, ticket: int, sl: float, tp: float) -> OrderResult: ...

    @abc.abstractmethod
    def positions(self) -> list[Position]: ...

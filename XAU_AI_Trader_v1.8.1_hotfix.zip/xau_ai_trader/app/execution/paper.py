"""PHASE 31 — Paper trading executor.

Simulates realistic fills:
- BUY at ask, SELL at bid (spread paid)
- slippage added against the trader
- commission per round-turn lot
- swap per night at the configured rollover hour
- SL/TP monitored on price updates (conservative: SL first)
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from app.config.schema import ExecutionConfig
from app.core import exceptions as exc
from app.execution import mt5_retcodes as rc
from app.data.market.base import MarketDataProvider
from app.data.market.models import OrderResult, Position, SymbolInfo
from app.execution.base import Executor

logger = logging.getLogger(__name__)


class PaperExecutor(Executor):
    mode = "paper"

    def __init__(self, provider: MarketDataProvider, symbol_info: SymbolInfo, cfg: ExecutionConfig) -> None:
        self.provider = provider
        self.symbol_info = symbol_info
        self.cfg = cfg
        self._positions: dict[int, Position] = {}
        self._next_ticket = 500_000_000
        self._last_swap_day: dict[int, str] = {}
        # v1.5: realized balance tracking (starts at 0 offset from the
        # configured initial balance the caller passes to account())
        self._realized_balance = 0.0
        self._closed_tickets: set[int] = set()

    # ---------------------------------------------------------------- utils --
    def _tick(self):
        return self.provider.get_tick(self.symbol_info.name)

    def _fill_price(self, side: str, reference: float) -> float:
        slip = self.cfg.slippage_points * self.symbol_info.point
        return reference + slip if side == "BUY" else reference - slip

    def _maybe_apply_swap(self, pos: Position) -> None:
        """v1.5 (Mission 20 / finding 11-12): broker-style swap semantics.

        - charge only when the position is open AT the rollover instant
          (swap_hour_utc), not at any hour ≥ it on the same calendar day;
        - a position opened AFTER the rollover hour is not charged the same
          evening (it never crossed a rollover — the old code charged it);
        - Wednesday rollover books 3× (triple-swap convention).
        """
        now = datetime.now(timezone.utc)
        day = now.date().isoformat()
        if now.hour != self.cfg.swap_hour_utc or now.minute >= 5:
            return  # only in a window after the rollover instant
        if self._last_swap_day.get(pos.ticket) == day:
            return
        open_day = pos.open_time.date().isoformat() if pos.open_time.tzinfo else \
            pos.open_time.replace(tzinfo=timezone.utc).date().isoformat()
        if open_day == day and pos.open_time.hour >= self.cfg.swap_hour_utc:
            self._last_swap_day[pos.ticket] = day
            return  # opened after today's rollover — nothing crossed yet
        swap = self.cfg.swap_long_per_lot if pos.side == "BUY" else self.cfg.swap_short_per_lot
        mult = 3 if now.weekday() == 2 else 1  # triple swap Wednesday
        pos.swap += swap * pos.volume * mult
        self._last_swap_day[pos.ticket] = day

    # ------------------------------------------------------------- orders --
    def open_market(self, symbol: str, side: str, volume: float, sl: float, tp: float,
                    comment: str = "", magic: int = 0) -> OrderResult:
        if symbol != self.symbol_info.name:
            self.symbol_info = SymbolInfo(**{**self.symbol_info.model_dump(), "name": symbol})
        tick = self._tick()
        ref = tick.ask if side == "BUY" else tick.bid
        price = self._fill_price(side, ref)
        # validate stops distance
        min_dist = 10 * self.symbol_info.point
        if sl:
            if (side == "BUY" and sl >= price - min_dist) or (side == "SELL" and sl <= price + min_dist):
                raise exc.OrderRejectedError(f"SL too close to fill price ({sl} vs {price})")
        if tp:
            if (side == "BUY" and tp <= price + min_dist) or (side == "SELL" and tp >= price - min_dist):
                raise exc.OrderRejectedError(f"TP too close to fill price ({tp} vs {price})")
        self._next_ticket += 1
        pos = Position(
            ticket=self._next_ticket, symbol=symbol, side=side, volume=volume,
            open_price=price, sl=sl, tp=tp,
            open_time=datetime.now(timezone.utc),
            comment=comment, magic=magic,
            commission=self.cfg.commission_per_lot * volume,
        )
        self._positions[pos.ticket] = pos
        self._last_swap_day[pos.ticket] = ""
        logger.info("PAPER OPEN %s %s %.2f lots @ %.2f SL %.2f TP %.2f",
                    side, symbol, volume, price, sl, tp)
        return OrderResult(success=True, retcode=rc.RETCODE_DONE, ticket=pos.ticket,
                           price=price, volume=volume, comment=comment)

    def close_position(self, ticket: int, reason: str = "") -> OrderResult:
        pos = self._positions.pop(ticket, None)
        if pos is None:
            raise exc.ExecutionError(f"paper position {ticket} not found")
        tick = self._tick()
        exit_price = tick.bid if pos.side == "BUY" else tick.ask
        exit_price = self._fill_price("SELL" if pos.side == "BUY" else "BUY", exit_price)
        pos.profit = self.unrealized_pnl(pos, exit_price)
        # v1.5 (exec-N5): accumulate REALIZED P&L so paper equity/drawdown
        # reflect trading history instead of a synthetic flat balance.
        self._realized_balance += pos.profit - pos.commission + pos.swap
        self._closed_tickets.add(ticket)
        logger.info("PAPER CLOSE ticket=%d @ %.2f pnl=%.2f reason=%s realized_balance=%.2f",
                    ticket, exit_price, pos.profit, reason, self._realized_balance)
        return OrderResult(success=True, retcode=rc.RETCODE_DONE, ticket=ticket,
                           price=exit_price, volume=pos.volume,
                           comment=f"close:{reason}")

    def modify_position(self, ticket: int, sl: float, tp: float) -> OrderResult:
        pos = self._positions.get(ticket)
        if pos is None:
            raise exc.ExecutionError(f"paper position {ticket} not found")
        pos.sl, pos.tp = sl, tp
        return OrderResult(success=True, retcode=rc.RETCODE_DONE, ticket=ticket)

    # --------------------------------------------------------- management --
    def unrealized_pnl(self, pos: Position, mark_price: float) -> float:
        direction = 1.0 if pos.side == "BUY" else -1.0
        ticks = (mark_price - pos.open_price) * direction / self.symbol_info.tick_size
        return ticks * self.symbol_info.tick_value * pos.volume

    def update(self) -> list[tuple[Position, str]]:
        """Check SL/TP on every open paper position. Returns closed (pos, reason)."""
        closed: list[tuple[Position, str]] = []
        if not self._positions:
            return closed
        tick = self._tick()
        for ticket, pos in list(self._positions.items()):
            self._maybe_apply_swap(pos)
            if pos.side == "BUY":
                hit_sl = pos.sl and tick.bid <= pos.sl
                hit_tp = pos.tp and tick.bid >= pos.tp
            else:
                hit_sl = pos.sl and tick.ask >= pos.sl
                hit_tp = pos.tp and tick.ask <= pos.tp
            if hit_sl:  # conservative: SL has priority
                reason = "SL"
            elif hit_tp:
                reason = "TP"
            else:
                pos.profit = self.unrealized_pnl(pos, tick.bid if pos.side == "BUY" else tick.ask)
                continue
            res = self.close_position(ticket, reason)
            closed.append((pos, reason))
        return closed

    def positions(self) -> list[Position]:
        return list(self._positions.values())

    def account(self, balance: float) -> "AccountInfo-like":
        from app.data.market.models import AccountInfo

        # v1.5 (exec-N5): equity includes REALIZED history, not just floating.
        base = balance + self._realized_balance
        floating = sum(self.unrealized_pnl(p, self._tick().bid if p.side == "BUY" else self._tick().ask)
                       for p in self._positions.values())
        equity = base + floating
        return AccountInfo(balance=base, equity=equity, margin=0.0,
                           free_margin=equity, margin_level=0.0)

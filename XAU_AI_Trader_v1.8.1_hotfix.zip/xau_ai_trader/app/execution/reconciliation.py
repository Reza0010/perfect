"""PHASE 66 (§21) — Broker reconciliation.

Compares the internal journal/executor state against the live MT5 account
state, position by position. Any mismatch is CRITICAL and the trading policy
requires WAIT/HALT until a human resolves it.

Detects: orphan positions (broker has, internal doesn't), missing positions
(internal has, broker doesn't), volume / price / SL / TP / profit / swap /
commission mismatches, and stale internal state.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ReconciliationReport:
    ok: bool
    compared: int
    orphans: list[dict] = field(default_factory=list)          # broker-only
    missing: list[dict] = field(default_factory=list)          # internal-only
    mismatches: list[dict] = field(default_factory=list)       # field-level
    stale_internal: list[dict] = field(default_factory=list)
    policy: str = "any CRITICAL finding → WAIT / HALT (no new trades until resolved)"

    def as_dict(self) -> dict:
        return {
            "ok": self.ok, "compared": self.compared,
            "orphans": self.orphans, "missing": self.missing,
            "mismatches": self.mismatches, "stale_internal": self.stale_internal,
            "policy": self.policy,
        }


_FIELDS = ("volume", "entry", "sl", "tp", "side")
_FLOAT_TOLERANCE = {
    # relative tolerances; profit/swap/commission drift while a position is open
    "volume": 1e-9, "entry": 1e-6, "sl": 1e-6, "tp": 1e-6,
    "profit": 0.02, "swap": 0.02, "commission": 0.02,
}


def _close(a: float | None, b: float | None, rel: float) -> bool:
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    if a == b:
        return True
    denom = max(abs(a), abs(b), 1e-12)
    return abs(a - b) / denom <= rel


def reconcile_positions(
    internal: list[dict],
    broker: list[dict],
    max_stale_seconds: float = 120.0,
    now_ts: float | None = None,
) -> ReconciliationReport:
    """Both sides: list of dicts with keys
    ticket, symbol, side, volume, entry, sl, tp, profit, swap, commission
    (and optionally last_sync_ts / updated_ts epoch seconds for staleness)."""
    rep = ReconciliationReport(ok=True, compared=0)
    by_ticket_int = {str(p.get("ticket")): p for p in internal}
    by_ticket_bro = {str(p.get("ticket")): p for p in broker}

    for ticket, b in by_ticket_bro.items():
        i = by_ticket_int.get(ticket)
        if i is None:
            rep.ok = False
            rep.orphans.append({"ticket": ticket, "symbol": b.get("symbol"),
                                "side": b.get("side"), "volume": b.get("volume")})
            continue
        rep.compared += 1
        for f in _FIELDS:
            rel = _FLOAT_TOLERANCE.get(f, 1e-6)
            a_val, b_val = i.get(f), b.get(f)
            if isinstance(a_val, (int, float)) and isinstance(b_val, (int, float)):
                if not _close(float(a_val), float(b_val), rel):
                    rep.ok = False
                    rep.mismatches.append({"ticket": ticket, "field": f,
                                           "internal": a_val, "broker": b_val})
            elif str(a_val or "").upper() != str(b_val or "").upper():
                rep.ok = False
                rep.mismatches.append({"ticket": ticket, "field": f,
                                       "internal": a_val, "broker": b_val})
        for f in ("profit", "swap", "commission"):
            if not _close(i.get(f), b.get(f), _FLOAT_TOLERANCE[f]):
                # profit/swap drift on open positions is informational,
                # not a blocker — recorded but not fatal
                rep.mismatches.append({"ticket": ticket, "field": f,
                                       "internal": i.get(f), "broker": b.get(f),
                                       "severity": "informational"})

    for ticket, i in by_ticket_int.items():
        if ticket not in by_ticket_bro:
            rep.ok = False
            rep.missing.append({"ticket": ticket, "symbol": i.get("symbol"),
                                "side": i.get("side"), "volume": i.get("volume")})
        elif now_ts is not None:
            ts = i.get("last_sync_ts") or i.get("updated_ts")
            if ts is not None and (now_ts - float(ts)) > max_stale_seconds:
                rep.stale_internal.append({"ticket": ticket,
                                           "age_seconds": now_ts - float(ts)})
    if rep.stale_internal:
        rep.ok = False
    return rep

"""PHASE 30/32 — Live MT5 execution (guarded by explicit configuration).

Safety gates (all must pass before any real order):
1. config.execution.mode == LIVE
2. config.execution.live_trading_enabled is True
3. env <live_confirm_env> == "YES"

v1.5 (Mission 2/16 — Order State Machine):
  INTENT → PRECHECK → ORDER_CHECK → SEND → ACK → RECONCILE → FILLED /
  REJECTED / UNKNOWN.
- Rejections and AMBIGUOUS outcomes are NEVER retried here. The provider
  already implements the only legal bounded retry loop (RETRYABLE retcodes
  with price refresh + re-check). An ambiguous outcome (TIMEOUT/CONNECTION/
  send-returned-None) may have reached the broker: re-sending risks a
  duplicate position. Instead the executor BLOCKS further trading, journals
  the event and demands reconciliation.
"""

from __future__ import annotations

import logging
import os
import uuid

from app.config.schema import ExecutionConfig
from app.core import exceptions as exc
from app.data.market.models import OrderResult, Position
from app.execution.base import Executor

logger = logging.getLogger(__name__)


class MT5Executor(Executor):
    mode = "live"

    def __init__(self, provider, cfg: ExecutionConfig, journal=None) -> None:
        self.provider = provider
        self.cfg = cfg
        self.journal = journal
        # v1.5 order state machine: trading is blocked until an UNKNOWN
        # outcome is reconciled (reconciliation result clears it).
        self._unknown_outcome_pending = False
        self._assert_live_allowed()

    def _assert_live_allowed(self) -> None:
        from app.config.schema import TradingMode

        if self.cfg.mode != TradingMode.LIVE:
            raise exc.ConfigError("live executor requires execution.mode=LIVE")
        if not self.cfg.live_trading_enabled:
            raise exc.ConfigError(
                "LIVE TRADING DISABLED: set execution.live_trading_enabled=true to enable"
            )
        confirm = os.environ.get(self.cfg.live_confirm_env, "")
        if confirm != "YES":
            raise exc.ConfigError(
                f"live trading requires environment {self.cfg.live_confirm_env}=YES "
                "(explicit human confirmation)"
            )
        if not getattr(self.provider, "supports_real_execution", False):
            raise exc.ConfigError("provider does not support real execution")

    # ------------------------------------------------- order state machine --
    def open_market(self, symbol: str, side: str, volume: float, sl: float, tp: float,
                    comment: str = "", magic: int = 0) -> OrderResult:
        """Single-send contract: NO blind retries at this layer.

        Idempotency: every intent carries a unique client order id (in the
        broker comment) so deals/orders can be reconciled after ambiguity.
        """
        if self._unknown_outcome_pending:
            raise exc.AmbiguousOrderError(
                "previous order outcome UNKNOWN — reconcile positions/orders/deals "
                "before any new order (trading blocked)")
        intent_id = uuid.uuid4().hex[:8]
        full_comment = f"{comment or self.cfg.comment}|{intent_id}"[:31]
        eff_magic = magic or self.cfg.magic_number
        # INTENT journal (before send) — reconstructability for Mission 39
        if self.journal is not None:
            try:
                self.journal.log_event({
                    "kind": "ORDER_INTENT", "symbol": symbol, "side": side,
                    "volume": volume, "sl": sl, "tp": tp,
                    "comment": full_comment, "magic": eff_magic,
                    "intent_id": intent_id,
                })
            except Exception as e:  # journal failure must not silently vanish
                logger.error("ORDER_INTENT journaling failed: %s", e)
        try:
            # PRECHECK + ORDER_CHECK + SEND happen inside the provider; the
            # provider implements the ONLY legal retry loop (RETRYABLE
            # retcodes with price refresh AND re-check) and raises
            # AmbiguousOrderError for anything whose outcome is unknown.
            result = self.provider.send_market_order(
                symbol, side, volume, sl, tp, full_comment, eff_magic,
            )
        except exc.AmbiguousOrderError as e:
            # ACK never arrived — outcome UNKNOWN: block trading, reconcile.
            self._unknown_outcome_pending = True
            self._journal_event_safe("ORDER_UNKNOWN", {
                "symbol": symbol, "side": side, "comment": full_comment,
                "magic": eff_magic, "intent_id": intent_id, "error": str(e),
            })
            raise
        except (exc.OrderRejectedError, exc.ExecutionError) as e:
            # Deterministic rejection (NO_MONEY, INVALID_STOPS, ...) — never
            # retried blindly; the broker told us NO and re-sending the same
            # request cannot change its mind.
            self._journal_event_safe("ORDER_REJECTED", {
                "symbol": symbol, "side": side, "comment": full_comment,
                "magic": eff_magic, "intent_id": intent_id, "error": str(e),
            })
            raise
        self._journal_event_safe("ORDER_ACK", {
            "ticket": result.ticket, "price": result.price,
            "comment": full_comment, "intent_id": intent_id,
        })
        return result

    def _journal_event_safe(self, kind: str, payload: dict) -> None:
        if self.journal is None:
            return
        try:
            self.journal.log_event({"kind": kind, **payload})
        except Exception as e:
            logger.error("%s journaling failed: %s", kind, e)

    def reconcile_unknown(self) -> bool:
        """Reconcile an UNKNOWN outcome (Mission 2/16).

        Compares broker positions (orders/deals are implicitly included —
        any fill materialises as a position) against the internal journal
        using the PHASE 66 reconciliation contract. The trade block is
        lifted ONLY when the state is consistent.
        """
        if not self._unknown_outcome_pending:
            return True
        from app.execution.reconciliation import reconcile_positions

        broker_positions = self.provider.get_open_positions(magic=self.cfg.magic_number)
        broker_rows = [{
            "ticket": p.ticket, "symbol": p.symbol, "side": p.side,
            "volume": p.volume, "entry": p.open_price, "sl": p.sl, "tp": p.tp,
        } for p in broker_positions]
        internal_rows = []
        if self.journal is not None:
            try:
                internal_rows = [
                    {"ticket": t["ticket"], "symbol": t["symbol"], "side": t["side"],
                     "volume": t.get("lot", 0.0), "entry": t.get("entry_price", 0.0),
                     "sl": t.get("sl", 0.0), "tp": t.get("tp", 0.0)}
                    for t in self.journal.open_trades()
                ]
            except Exception as e:
                logger.error("reconciliation could not read journal: %s", e)
                # cannot verify internal state → stay blocked (fail-closed)
                return False
        report = reconcile_positions(internal_rows, broker_rows)
        self._journal_event_safe("RECONCILIATION_RESULT", report.as_dict())
        if report.ok:
            self._unknown_outcome_pending = False
        return report.ok

    @property
    def unknown_outcome_pending(self) -> bool:
        return self._unknown_outcome_pending

    def close_position(self, ticket: int, reason: str = "") -> OrderResult:
        return self.provider.close_position(ticket)

    def modify_position(self, ticket: int, sl: float, tp: float) -> OrderResult:
        return self.provider.modify_position(ticket, sl, tp)

    def positions(self) -> list[Position]:
        return self.provider.get_open_positions(magic=self.cfg.magic_number)

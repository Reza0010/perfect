"""PHASE 24/25 — Stop-loss and take-profit calculation (deterministic)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.config.schema import SLMethod, TPMethod
from app.risk.sizing import round_price


def _nearest_swing_low(df: pd.DataFrame, lookback: int = 40) -> float | None:
    window = df["low"].iloc[-lookback:]
    return float(window.min()) if len(window) else None


def _nearest_swing_high(df: pd.DataFrame, lookback: int = 40) -> float | None:
    window = df["high"].iloc[-lookback:]
    return float(window.max()) if len(window) else None


def compute_stop_loss(
    side: str,
    entry: float,
    df: pd.DataFrame,
    atr: float,
    method: SLMethod,
    cfg,
    smc_events: list | None = None,
) -> float | None:
    """Return SL price or None if it cannot be computed."""
    if side == "BUY":
        sign = 1.0
    else:
        sign = -1.0
    if method == SLMethod.ATR:
        sl = entry - sign * cfg.atr_sl_mult * atr
    elif method in (SLMethod.STRUCTURE, SLMethod.SWING):
        if side == "BUY":
            swing = _nearest_swing_low(df)
            sl = swing - cfg.structure_sl_buffer_atr * atr if swing else entry - cfg.atr_sl_mult * atr
        else:
            swing = _nearest_swing_high(df)
            sl = swing + cfg.structure_sl_buffer_atr * atr if swing else entry + cfg.atr_sl_mult * atr
    elif method == SLMethod.ORDER_BLOCK:
        ob = _nearest_ob_zone(smc_events, side)
        if ob is None:
            sl = entry - sign * cfg.atr_sl_mult * atr
        else:
            # v1.5 fix (finding 9 / exec-#2): the old expression was
            #   sl = ob + sign*buf*atr*-1 if False else ob
            # which parses as (…if False else ob) → ALWAYS sl = ob: the
            # configured structure buffer was silently ignored and the SL
            # sat exactly on the zone edge (first wick through the OB
            # stopped the trade). Correct placement: BELOW the bull zone
            # bottom (BUY) / ABOVE the bear zone top (SELL).
            sl = ob - sign * cfg.structure_sl_buffer_atr * atr
    elif method == SLMethod.FIXED:
        # v1.5 fix (SMC-N4): the point size must come from the SYMBOL, not a
        # hard-coded df.attrs default that nobody sets (a point=0.10 symbol
        # got a 10× too tight stop). Callers pass symbol_info via attrs["point"]
        # (wired in trader.py); fall back to ATR method when absent.
        point = float(df.attrs.get("point", 0.0)) if hasattr(df, "attrs") else 0.0
        if point <= 0:
            sl = entry - sign * cfg.atr_sl_mult * atr
        else:
            points = cfg.fixed_sl_points * point
            sl = entry - sign * (points if points > 0 else cfg.atr_sl_mult * atr)
    else:
        return None
    # sanity: SL must be on the correct side and within max distance
    if side == "BUY" and sl >= entry:
        sl = entry - cfg.atr_sl_mult * atr
    if side == "SELL" and sl <= entry:
        sl = entry + cfg.atr_sl_mult * atr
    dist = abs(entry - sl)
    if dist <= 0 or dist > cfg.max_sl_atr_distance * atr * 10:
        return None
    return float(sl)


def _nearest_ob_zone(events: list | None, side: str) -> float | None:
    """Nearest recent OB zone boundary on the protective side."""
    if not events:
        return None
    from app.smc.types import Direction, SMCEventType

    wanted = {"ORDER_BLOCK_BULL", "BREAKER_BULL"} if side == "BUY" else {"ORDER_BLOCK_BEAR", "BREAKER_BEAR"}
    zones = [e for e in events if e.type.value in wanted]
    if not zones:
        return None
    ev = max(zones, key=lambda e: e.timestamp)
    if side == "BUY":
        return float(ev.meta.get("zone_bottom", ev.invalidation))
    return float(ev.meta.get("zone_top", ev.invalidation))


def compute_take_profit(
    side: str,
    entry: float,
    sl: float,
    df: pd.DataFrame,
    atr: float,
    method: TPMethod,
    cfg,
    liquidity_levels: dict | None = None,
) -> tuple[float | None, float]:
    """Return (TP price, achieved RR). Falls back to RR method."""
    sl_dist = abs(entry - sl)
    if sl_dist <= 0:
        return None, 0.0
    sign = 1.0 if side == "BUY" else -1.0

    def _rr_target() -> float:
        return entry + sign * max(cfg.min_rr, 2.0) * sl_dist

    tp = None
    if method == TPMethod.RR:
        tp = entry + sign * cfg.min_rr * sl_dist
    elif method == TPMethod.ATR:
        tp = entry + sign * max(1.5, cfg.min_rr) * atr
        if abs(tp - entry) / sl_dist < cfg.min_rr:
            tp = entry + sign * cfg.min_rr * sl_dist
    elif method == TPMethod.LIQUIDITY and liquidity_levels:
        # v1.5 fix (finding 10 / exec-#3): the mapping was INVERTED —
        # BUY targeted the previous-day LOW (below price) and SELL the HIGH.
        # SMC doctrine: buy-side liquidity rests ABOVE old highs, sell-side
        # liquidity BELOW old lows. BUY → pdh/pwh (pools above),
        # SELL → pdl/pwl (pools below). The direction guard keeps the
        # RR fallback for the pathological case where price is already
        # beyond the level.
        target = liquidity_levels.get("pdh" if side == "BUY" else "pdl")
        if target is None:
            target = liquidity_levels.get("pwh" if side == "BUY" else "pwl")
        if target is not None:
            rr = abs(target - entry) / sl_dist
            if rr >= cfg.min_rr and ((side == "BUY" and target > entry) or (side == "SELL" and target < entry)):
                tp = float(target)
                return tp, rr
        tp = entry + sign * cfg.min_rr * sl_dist
    elif method == TPMethod.STRUCTURE:
        swing = _nearest_swing_high(df) if side == "BUY" else _nearest_swing_low(df)
        if swing is not None:
            rr = abs(swing - entry) / sl_dist
            if rr >= cfg.min_rr and ((side == "BUY" and swing > entry) or (side == "SELL" and swing < entry)):
                return float(swing), rr
        tp = entry + sign * cfg.min_rr * sl_dist
    else:
        tp = _rr_target()
    achieved_rr = abs(tp - entry) / sl_dist if tp else 0.0
    if tp is None or achieved_rr < cfg.min_rr * 0.999:
        tp = entry + sign * cfg.min_rr * sl_dist
        achieved_rr = abs(tp - entry) / sl_dist
    return float(tp), float(achieved_rr)

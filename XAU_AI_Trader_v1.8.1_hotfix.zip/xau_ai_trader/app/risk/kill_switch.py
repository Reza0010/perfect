"""PHASE 29 (v1.4 fail-closed revision) — Independent Kill Switch.

Triggers: excessive loss, drawdown, abnormal spread, execution failures,
data corruption streak, AI failure streak, abnormal price movement,
MT5 disconnect — plus unreadable/corrupt state persistence itself.

v1.4 safety contract (fail-closed everywhere):
  * unreadable / corrupt state file  -> KILL SWITCH ENGAGED (STATE_CORRUPT),
    NOT "starting clean". Trading stays blocked until a human resolves it.
  * state persistence is atomic (temp file + os.replace); if persistence
    fails the switch reports active (trading blocked) — the system never
    claims a protected state it failed to store.
  * check() collects ALL simultaneously-fired triggers, not just the first.
  * auto-reset defaults to OFF (auto_reset_after_minutes: null); a corrupt
    state is never auto-reset regardless of configuration.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

TRIGGERS = [
    "DAILY_LOSS_LIMIT",
    "MAX_DRAWDOWN",
    "ABNORMAL_SPREAD",
    "EXECUTION_FAILURES",
    "DATA_CORRUPTION",
    "AI_FAILURES",
    "ABNORMAL_PRICE_MOVE",
    "MT5_DISCONNECT",
    "STATE_CORRUPT",
]


@dataclass
class KillSwitchState:
    active: bool = False
    trigger: str = ""
    detail: str = ""
    tripped_at: str = ""
    triggers: list = field(default_factory=list)  # all simultaneous triggers


class KillSwitch:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.state = KillSwitchState()
        self.state_path = Path(cfg.state_file)
        self._persist_failed = False
        self._load()

    # -------------------------------------------------------------- state --
    def _load(self) -> None:
        if not self.state_path.exists():
            return
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            state = KillSwitchState(**data)
        except Exception:
            # FAIL-CLOSED: an unreadable protected state must never be
            # silently discarded ("starting clean") — engage instead.
            logger.critical(
                "kill switch state file unreadable — FAIL CLOSED "
                "(STATE_CORRUPT; manual reset required)", exc_info=True)
            self.state = KillSwitchState(
                active=True, trigger="STATE_CORRUPT",
                detail=f"state file unreadable: {self.state_path}",
                tripped_at=datetime.now(timezone.utc).isoformat(),
                triggers=["STATE_CORRUPT"],
            )
            self._persist()
            return
        self.state = state
        if self.state.active:
            if self.state.trigger == "STATE_CORRUPT":
                return  # never auto-reset a corrupted state
            if self.cfg.auto_reset_after_minutes is not None:
                try:
                    tripped = datetime.fromisoformat(self.state.tripped_at)
                    if datetime.now(timezone.utc) - tripped > timedelta(
                            minutes=self.cfg.auto_reset_after_minutes):
                        logger.info("kill switch auto-reset after cooldown")
                        self.reset()
                except Exception:
                    logger.warning("auto-reset evaluation failed; "
                                   "kill switch stays engaged", exc_info=True)

    def _persist(self) -> bool:
        """Atomic persistence (temp file + os.replace).

        Returns True on success. On failure the switch flags itself
        persist-failed: trading stays blocked rather than proceeding on an
        unprotected state.
        """
        tmp = self.state_path.with_suffix(self.state_path.suffix + ".tmp")
        try:
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_text(json.dumps(asdict(self.state), indent=2),
                           encoding="utf-8")
            os.replace(tmp, self.state_path)
            self._persist_failed = False
            return True
        except Exception:
            self._persist_failed = True
            logger.critical(
                "cannot persist kill switch state — trading BLOCKED "
                "(fail-closed)", exc_info=True)
            return False

    # ------------------------------------------------------------ actions --
    def trip(self, trigger: str, detail: str = "",
             all_triggers: list | None = None) -> None:
        if trigger not in TRIGGERS:
            trigger = "DATA_CORRUPTION"
        if not self.state.active:
            logger.critical("KILL SWITCH ENGAGED: %s — %s", trigger, detail)
        self.state = KillSwitchState(
            active=True, trigger=trigger, detail=detail,
            tripped_at=self.state.tripped_at or
            datetime.now(timezone.utc).isoformat(),
            triggers=all_triggers or [trigger],
        )
        self._persist()

    def reset(self) -> None:
        self.state = KillSwitchState()
        ok = self._persist()
        if ok:
            logger.warning("kill switch RESET — trading may resume")
        else:
            logger.critical("kill switch RESET attempted but persistence "
                            "failed — trading stays BLOCKED (fail-closed)")

    @property
    def is_active(self) -> bool:
        return bool(self.state.active) or self._persist_failed

    @property
    def blocked_reason(self) -> str:
        if self._persist_failed:
            return "KILL_SWITCH_STATE_PERSIST_FAILED"
        return self.state.trigger

    def check(
        self,
        daily_loss_percent: float = 0.0,
        drawdown_percent: float = 0.0,
        spread_points: float = 0.0,
        consecutive_execution_failures: int = 0,
        consecutive_data_errors: int = 0,
        consecutive_ai_failures: int = 0,
        last_move_atr: float = 0.0,
        mt5_connected: bool = True,
    ) -> KillSwitchState:
        """Evaluate ALL triggers; engage if any fires (fail-closed).

        Unlike the pre-v1.4 elif chain, every simultaneously-triggered
        condition is collected and recorded in state.triggers.
        """
        if not self.cfg.enabled:
            return self.state
        if self.state.active:
            return self.state
        if self._persist_failed:
            return self.state  # already blocked via is_active

        fired: list[tuple[str, str]] = []
        if daily_loss_percent >= self.cfg.max_daily_loss_percent:
            fired.append(("DAILY_LOSS_LIMIT",
                          f"daily loss {daily_loss_percent:.2f}%"))
        if drawdown_percent >= self.cfg.max_drawdown_percent:
            fired.append(("MAX_DRAWDOWN",
                          f"drawdown {drawdown_percent:.2f}%"))
        if spread_points >= self.cfg.abnormal_spread_points:
            fired.append(("ABNORMAL_SPREAD",
                          f"spread {spread_points:.0f} points"))
        if consecutive_execution_failures >= self.cfg.max_consecutive_execution_failures:
            fired.append(("EXECUTION_FAILURES",
                          f"{consecutive_execution_failures} consecutive failures"))
        if consecutive_data_errors >= self.cfg.max_consecutive_data_errors:
            fired.append(("DATA_CORRUPTION",
                          f"{consecutive_data_errors} consecutive data errors"))
        if consecutive_ai_failures >= self.cfg.max_consecutive_ai_failures:
            fired.append(("AI_FAILURES",
                          f"{consecutive_ai_failures} consecutive AI failures"))
        if last_move_atr >= self.cfg.abnormal_move_atr:
            fired.append(("ABNORMAL_PRICE_MOVE",
                          f"move {last_move_atr:.1f} ATR"))
        if not mt5_connected:
            fired.append(("MT5_DISCONNECT", "provider connection lost"))

        if fired:
            names = [t for t, _ in fired]
            self.trip(names[0], "; ".join(f"{t}: {d}" for t, d in fired),
                      all_triggers=names)
        return self.state

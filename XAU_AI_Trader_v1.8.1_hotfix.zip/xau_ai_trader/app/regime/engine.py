"""PHASE 10 — Regime Engine.

Combines rule-based classification (ADX/trend/volatility percentiles) with
optional HMM state, then applies strategy gating. HIGH_VOLATILITY regimes are
tradeable only if explicitly allowed by config.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from app.config.schema import Regime
from app.core.exceptions import FeatureError


@dataclass
class RegimeResult:
    regime: Regime
    confidence: float
    source: str  # "rules" | "hmm" | "rules+hmm"
    reasons: list[str] = field(default_factory=list)


class RegimeEngine:
    def __init__(self, cfg) -> None:
        self.cfg = cfg  # regime section: adx thresholds & vol percentiles
        self._atr_hist: list[float] = []

    def classify(
        self,
        base_row: pd.Series,
        h4_row: pd.Series | None = None,
        hmm_label: str | None = None,
        hmm_conf: float = 0.0,
    ) -> RegimeResult:
        reasons: list[str] = []
        adx = float(base_row.get("adx", 25.0) or 25.0)
        di_diff = float(base_row.get("di_diff", 0.0) or 0.0)
        atr_pct = float(base_row.get("atr_pct", 0.0) or 0.0)
        ema20_slope = float(base_row.get("ema20_slope", 0.0) or 0.0)
        ema50_dist = float(base_row.get("ema50_dist", 0.0) or 0.0)

        trending = adx >= self.cfg.adx_trend_min
        vol = "normal"
        if atr_pct >= self.cfg.high_vol_atr_pct:
            vol = "high"
        elif atr_pct <= self.cfg.low_vol_atr_pct:
            vol = "low"

        if vol == "high":
            regime = Regime.HIGH_VOLATILITY
            reasons.append(f"ATR% {atr_pct:.4f} >= {self.cfg.high_vol_atr_pct}")
        elif trending and di_diff > 0 and ema50_dist > 0:
            regime = Regime.TRENDING_BULL
            reasons.append(f"ADX {adx:.1f}+ DI+ dominant, price above EMA50")
        elif trending and di_diff < 0 and ema50_dist < 0:
            regime = Regime.TRENDING_BEAR
            reasons.append(f"ADX {adx:.1f}+ DI- dominant, price below EMA50")
        elif vol == "low":
            regime = Regime.LOW_VOLATILITY
            reasons.append(f"ATR% {atr_pct:.4f} <= {self.cfg.low_vol_atr_pct}")
        else:
            regime = Regime.RANGING
            reasons.append(f"ADX {adx:.1f} below trend threshold, normal volatility")

        source = "rules"
        confidence = min(1.0, 0.4 + adx / 100.0)

        if hmm_label and self.cfg.use_hmm:
            source = "rules+hmm"
            # disagreement → UNCERTAIN with reduced confidence
            try:
                hmm_regime = Regime(hmm_label)
            except ValueError:
                hmm_regime = Regime.UNCERTAIN
            if hmm_regime != regime and hmm_regime != Regime.UNCERTAIN:
                strong_disagree = {
                    (Regime.TRENDING_BULL, Regime.TRENDING_BEAR),
                    (Regime.TRENDING_BEAR, Regime.TRENDING_BULL),
                }
                if (regime, hmm_regime) in strong_disagree or hmm_conf >= self.cfg.hmm_override_conf:
                    regime = Regime.UNCERTAIN if hmm_conf < self.cfg.hmm_override_conf else hmm_regime
                    reasons.append(f"HMM disagrees ({hmm_label}, conf={hmm_conf:.2f})")
                else:
                    reasons.append(f"HMM alternative view: {hmm_label} (conf={hmm_conf:.2f})")
            else:
                confidence = min(1.0, confidence * 0.5 + hmm_conf * 0.5)
                reasons.append(f"HMM agrees: {hmm_label}")

        return RegimeResult(regime=regime, confidence=round(float(confidence), 3),
                            source=source, reasons=reasons)

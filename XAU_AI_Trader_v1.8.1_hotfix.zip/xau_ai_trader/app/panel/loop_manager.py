"""v1.6 — Trading loop manager: start/stop the TradingSystem inside the panel.

The trader runs in a dedicated background thread with its own asyncio loop
(the system is async). `main.py` semantics are preserved:
  - paper / mt5-readonly modes only (mt5-live stays HARD REFUSED)
  - no-auto-retrain policy asserted at startup
  - state.json + journal.db updated by the trader itself → the panel reads
    them live (single source of truth, no duplicate state)
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class LoopStatus:
    state: str = "stopped"           # stopped | starting | running | stopping | error
    mode: str = ""
    started_at: float | None = None
    stopped_at: float | None = None
    iterations: int = 0
    last_error: str = ""
    last_error_trace: str = ""
    config_path: str = ""
    notes: list[str] = field(default_factory=list)


class TradingLoopManager:
    def __init__(self, project_root: Path) -> None:
        self.root = Path(project_root).resolve()
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self.status = LoopStatus()

    # ------------------------------------------------------------- status --
    def snapshot(self) -> dict:
        s = self.status
        out = {
            "state": s.state,
            "mode": s.mode,
            "uptime_seconds": int(time.time() - s.started_at) if s.started_at and s.state == "running" else 0,
            "iterations": s.iterations,
            "last_error": s.last_error,
            "config_path": s.config_path,
            "notes": s.notes[-8:],
        }
        return out

    def _note(self, msg: str) -> None:
        logger.info("[panel-loop] %s", msg)
        self.status.notes.append(f"{time.strftime('%H:%M:%S')} {msg}")

    # -------------------------------------------------------------- start --
    def start(self, mode: str = "paper", config_path: str | None = None,
              registry_tag: str | None = None) -> dict:
        with self._lock:
            if self.status.state in ("running", "starting"):
                return {"ok": False, "error": f"loop already {self.status.state} — stop it first"}
            if mode not in ("paper", "mt5-readonly", "auto"):
                return {"ok": False, "error":
                        "panel allows 'paper', 'mt5-readonly' or 'auto' (mt5-live is HARD "
                        "REFUSED by design; use scripts/mt5_demo_execution_test.py "
                        "on a DEMO account for demo execution)"}
            self._stop_event.clear()
            self.status = LoopStatus(state="starting", mode=mode, config_path=config_path or "config.yaml")
            self._thread = threading.Thread(
                target=self._run_trader, name="panel-trading-loop",
                args=(mode, config_path, registry_tag), daemon=True)
            self._thread.start()
            return {"ok": True, "state": "starting", "mode": mode}

    @staticmethod
    def _resolve_mode(mode: str, provider_kind: str) -> tuple[str, str | None]:
        """v1.7 — resolve the requested panel mode against the configured provider.

        Returns (effective_mode, note). Previously a mode/provider mismatch raised
        RuntimeError and CRASHED the loop thread (user-visible as 'panel trading
        loop crashed'). Now it degrades honestly:
          - mt5-readonly + provider≠mt5  → falls back to paper with a note
          - auto                          → mt5-readonly when provider is mt5, else paper
        """
        if mode == "auto":
            mode = "mt5-readonly" if provider_kind == "mt5" else "paper"
        if mode == "mt5-readonly" and provider_kind != "mt5":
            note = (f"mt5-readonly needs provider.kind=mt5 (got {provider_kind!r}) — "
                    f"fell back to paper; set provider.kind=mt5 + MT5 creds in config "
                    f"to validate the real broker feed read-only")
            return "paper", note
        return mode, None

    # --------------------------------------------------------------- stop --
    def stop(self, timeout: float = 20.0) -> dict:
        with self._lock:
            if self.status.state not in ("running", "starting", "error"):
                return {"ok": True, "state": self.status.state}
            self.status.state = "stopping"
        self._stop_event.set()
        # trader.stop() is invoked inside the thread; wait for a clean exit
        t0 = time.time()
        while self._thread and self._thread.is_alive() and (time.time() - t0) < timeout:
            time.sleep(0.2)
        alive = bool(self._thread and self._thread.is_alive())
        if alive:
            self.status.last_error = "thread did not stop cleanly within timeout"
            self.status.state = "error"
            return {"ok": False, "error": self.status.last_error}
        self.status.state = "stopped"
        self.status.stopped_at = time.time()
        return {"ok": True, "state": "stopped"}

    # ------------------------------------------------------------- worker --
    def _run_trader(self, mode: str, config_path: str | None, registry_tag: str | None) -> None:
        """Own event loop; mirrors main.py build/run/teardown semantics."""
        import sys

        if str(self.root) not in sys.path:
            sys.path.insert(0, str(self.root))
        try:
            from app.config.loader import load_config
            from app.config.schema import TradingMode
            from app.core.logging import setup_logging
            from app.monitoring.no_retrain import assert_no_auto_retrain

            cfg = load_config(config_path, project_root=self.root)
            setup_logging(cfg.logging.level, cfg.logging.json_mode)
            assert_no_auto_retrain(cfg)  # v1.5 Mission 26/27 policy

            # panel addition: tee trader logs to logs/trader.log so the panel's
            # Logs tab shows the real loop output (secret-masked, same as stdout)
            from app.core.logging import SecretMaskingFilter

            log_path = Path(cfg.paths.logs_dir) / "trader.log"
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(logging.Formatter(
                "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"))
            fh.addFilter(SecretMaskingFilter())
            root_logger = logging.getLogger()
            root_logger.addHandler(fh)

            from main import build_system  # reuse the exact production builder

            # v1.7 — resolve mode against the actual provider config instead
            # of crashing the thread on a mismatch (graceful, visible note).
            mode, note = self._resolve_mode(mode, cfg.provider.kind)
            if note:
                self._note(note)
                logger.warning("[panel-loop] %s", note)

            cfg.execution.mode = TradingMode.PAPER
            tag = registry_tag or getattr(cfg.real_data, "registry_tag", "main") or "main"
            system = build_system(cfg, registry_tag=tag)

            self.status.state = "running"
            self.status.started_at = time.time()
            self._note(f"trading loop started (mode={mode}, registry_tag={tag})")

            async def _drive() -> None:
                # TradingSystem.run() has no external stop hook in this build
                # (stop() only flips _running, checked between iterations), so
                # the panel drives iteration-by-iteration with once=True and
                # checks the stop event between loops — identical semantics to
                # main.py (same iterate() path), with responsive panel Stop.
                poll = max(1.0, getattr(cfg.execution, "poll_interval_seconds", 30) or 30)
                while not self._stop_event.is_set():
                    t0 = time.perf_counter()
                    await system.run(once=True)
                    with self._lock:
                        self.status.iterations += 1
                    wait = max(1.0, poll - (time.perf_counter() - t0))
                    # interruptible sleep
                    deadline = time.perf_counter() + wait
                    while not self._stop_event.is_set() and time.perf_counter() < deadline:
                        await asyncio.sleep(0.5)

            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(_drive())
            finally:
                try:
                    loop.run_until_complete(system.gateway.aclose())
                except Exception:
                    pass
                system.journal.close()
                loop.close()
                # detach the panel's file handler (clean restarts)
                try:
                    root_logger.removeHandler(fh)
                    fh.close()
                except Exception:
                    pass
            system.stop()
            if self._stop_event.is_set():
                self.status.state = "stopped"
                self.status.stopped_at = time.time()
                self._note("trading loop stopped by panel request")
            else:
                self.status.state = "stopped"
                self.status.stopped_at = time.time()
        except Exception as e:  # noqa: BLE001
            self.status.state = "error"
            self.status.last_error = f"{type(e).__name__}: {e}"
            self.status.last_error_trace = traceback.format_exc(limit=6)
            self._note(f"loop error: {self.status.last_error}")
            logger.exception("panel trading loop crashed")

"""v1.6 — Control Panel: single-command web panel for the whole system.

Zero new dependencies: built on the Python standard library
(http.server ThreadingHTTPServer). See run_panel.py for the launcher.
"""

"""v1.6 — Panel HTTP server (stdlib only: ThreadingHTTPServer + json).

Endpoints (all JSON unless /):
  GET  /                                → panel UI (single-file HTML)
  GET  /api/overview                    → header snapshot (version/mode/health/ks)
  GET  /api/state                       → live trader state.json
  GET  /api/config                      → effective config (secrets masked)
  GET  /api/data                        → datasets + quality report (sha verified)
  GET  /api/models                      → registry scan + manifest hashes
  GET  /api/reports                     → reports dir + RELEASE_MANIFEST
  GET  /api/signals?limit=              → journal signals
  GET  /api/trades?limit=               → journal trades + stats
  GET  /api/ai                          → AI settings + key presence + call stats
  GET  /api/ai/calls?limit=             → AI call ledger
  POST /api/ai/settings                 → persist AI settings (config.yaml + .env)
  POST /api/ai/key                      → set/remove ONE api key in .env
  POST /api/ai/test                     → REAL provider ping (key never returned)
  GET  /api/risk                        → risk + kill-switch config/state
  POST /api/killswitch/reset            → reset kill switch (audit-logged)
  GET  /api/news                        → news calendar upcoming
  GET  /api/logs                        → log file list
  GET  /api/logs/tail?name=&lines=      → log tail
  GET  /api/system                      → platform/packages/env summary
  GET  /api/loop                        → trading loop status
  POST /api/loop/start {mode}           → start paper/mt5-readonly loop
  POST /api/loop/stop                   → stop loop

Security defaults: bind 127.0.0.1; write endpoints require the panel token
when one is configured (PANEL_TOKEN env or --token). Keys are write-only.

v1.8: when the panel is bound to a non-localhost host WITH a token, READ
endpoints are token-gated as well (``X-Panel-Token`` header or ``?token=``
query parameter — the UI forwards it automatically). Token comparison is
constant-time. Without a token the panel stays local-only and warns.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from app.panel.collector import PanelCollector
from app.panel.loop_manager import TradingLoopManager
from app.panel.market_feed import LiveMarketFeed
from app.panel.settings_store import AISettingsStore, SettingsStoreError

logger = logging.getLogger("panel")

STATIC_DIR = Path(__file__).parent / "static"


class PanelServer:
    def __init__(self, project_root: Path, host: str, port: int,
                 config_path: str | None = None, token: str | None = None) -> None:
        self.root = Path(project_root).resolve()
        self.host = host
        self.port = port
        self.token = token
        self.collector = PanelCollector(self.root, config_path)
        self.store = AISettingsStore(self.root, config_path)
        self.loop_mgr = TradingLoopManager(self.root)
        self.feed = LiveMarketFeed(self.root, config_path)
        self.collector.feed = self.feed   # overview price fallback (real live price)
        # v1.8 (P13): non-localhost binding WITH a token gates READS too —
        # previously every GET (logs, config, AI call ledger) was LAN-readable
        # while only writes were protected.
        self.read_auth_required = bool(token) and host not in (
            "127.0.0.1", "localhost", "::1")

    def start_feed(self) -> None:
        """Start the live market feed daemon (real prices even with no loop)."""
        self.feed.start()

    # ---------------------------------------------------------- dispatch --
    def dispatch(self, method: str, path: str, qs: dict, body: dict | None,
                 token_ok: bool) -> tuple[int, dict]:
        routes_get = {
            "/api/overview": lambda: self.collector.overview(),
            "/api/state": lambda: {"ok": True, "state": self.collector.state()},
            "/api/config": lambda: self.collector.config_sanitized(),
            "/api/data": lambda: self.collector.datasets(),
            "/api/models": lambda: self.collector.models(),
            "/api/reports": lambda: self.collector.reports(),
            "/api/signals": lambda: self.collector.signals(int(qs.get("limit", ["50"])[0])),
            "/api/trades": lambda: self.collector.trades(int(qs.get("limit", ["50"])[0])),
            "/api/ai": lambda: self._ai_view(),
            "/api/ai/calls": lambda: self.collector.ai_calls(int(qs.get("limit", ["50"])[0])),
            "/api/risk": lambda: self.collector.risk(),
            "/api/news": lambda: self.collector.news_calendar(),
            "/api/logs": lambda: self.collector.logs(),
            "/api/system": lambda: self.collector.system(),
            "/api/loop": lambda: {"ok": True, **self.loop_mgr.snapshot()},
            "/api/events": lambda: self.collector.events(int(qs.get("limit", ["50"])[0])),
            "/api/market": lambda: self._market_view(qs),
        }
        routes_get_param = {
            "/api/logs/tail": lambda: self.collector.log_tail(
                qs.get("name", [""])[0], int(qs.get("lines", ["150"])[0])),
        }
        routes_post = {
            "/api/ai/settings": self._post_ai_settings,
            "/api/ai/key": self._post_ai_key,
            "/api/ai/test": self._post_ai_test,
            "/api/loop/start": self._post_loop_start,
            "/api/loop/stop": lambda b: self.loop_mgr.stop(),
            "/api/killswitch/reset": self._post_ks_reset,
            "/api/provider/settings": self._post_provider_settings,
            "/api/market/calibrate": self._post_market_calibrate,
        }

        if method == "GET":
            if path in routes_get:
                return self._safe(routes_get[path])
            if path in routes_get_param:
                return self._safe(routes_get_param[path])
            return 404, {"ok": False, "error": f"unknown endpoint {path}"}

        if method == "POST":
            if path in routes_post:
                # all POST routes are write endpoints → token gate
                if self.token and not token_ok:
                    return 401, {"ok": False, "error":
                                 "write endpoint requires panel token (X-Panel-Token header)"}
                return self._safe(lambda: routes_post[path](body or {}))
            return 404, {"ok": False, "error": f"unknown endpoint {path}"}
        return 405, {"ok": False, "error": "method not allowed"}

    @staticmethod
    def _safe(fn):
        t0 = time.perf_counter()
        try:
            data = fn()
            out = data if isinstance(data, tuple) else (200, data)
            return out[0], {**out[1], "_ms": int((time.perf_counter() - t0) * 1000)}
        except Exception as e:  # noqa: BLE001
            logger.exception("endpoint error")
            return 500, {"ok": False, "error": f"{type(e).__name__}: {e}"}

    # ------------------------------------------------------------- views --
    def _ai_view(self) -> dict:
        view = self.store.current()
        journal_stats = self.collector.ai_calls(limit=200)
        view["call_stats"] = journal_stats.get("stats", [])
        view["recent_calls"] = (journal_stats.get("calls") or [])[:15]
        loop = self.loop_mgr.snapshot()
        view["loop_state"] = loop.get("state")
        view["apply_note"] = ("پس از ذخیره، حلقه معامله‌گری را Restart کنید تا Gateway با "
                              "تنظیمات جدید ساخته شود / Restart the loop to rebuild the gateway")
        return view

    def _post_ai_settings(self, body: dict) -> dict:
        result = self.store.save_ai_settings(body)
        self.collector._cfg_cache = None  # invalidate config cache
        return result

    def _post_ai_key(self, body: dict) -> dict:
        env_name = str(body.get("env_var", "")).strip()
        api_key = str(body.get("api_key", ""))
        if not env_name:
            raise SettingsStoreError("env_var is required")
        return self.store.save_api_key(env_name, api_key)

    def _post_ai_test(self, body: dict) -> dict:
        from app.panel.ai_tester import test_provider

        name = str(body.get("name", "")).strip().lower()
        base_url = str(body.get("base_url", "")).strip()
        model = str(body.get("model", "")).strip()
        env_var = str(body.get("env_var", "")).strip()
        timeout = float(body.get("timeout_seconds", 20) or 20)
        # key source: running env first, then .env file — never the browser
        import os
        api_key = os.environ.get(env_var) if env_var else None
        if not api_key:
            api_key = self.store._dotenv().get(env_var)
        if body.get("provider_key_direct"):  # only used by in-panel quick test after save
            api_key = api_key or None
        result = test_provider(name, base_url, model, api_key or "", timeout)
        return result

    def _post_loop_start(self, body: dict) -> dict:
        mode = str(body.get("mode", "paper")).strip().lower()
        config_path = body.get("config_path") or self.collector.config_path
        registry_tag = body.get("registry_tag")
        return self.loop_mgr.start(mode=mode, config_path=config_path, registry_tag=registry_tag)

    # ------------------------------------------------------------ market --
    def _market_view(self, qs: dict) -> dict:
        """Real live market data for the panel (price/bid/ask/spot/status)."""
        snap = self.feed.snapshot()
        tf = str(qs.get("tf", [""])[0] or "").strip().upper()
        if tf in ("M1", "M5", "M15", "M30", "H1", "H4", "D1"):
            count = min(1500, int(qs.get("count", ["300"])[0] or 300))
            snap["candles"] = self.feed.candles(tf, count)
        return snap

    def _post_provider_settings(self, body: dict) -> dict:
        """v1.7 — persist market-data provider settings into config.yaml."""
        result = self.store.save_provider_settings(body)
        self.collector._cfg_cache = None  # invalidate config cache
        return result

    def _post_market_calibrate(self, body: dict) -> dict:
        """v1.7.1 — measure broker-vs-public price basis NOW and store it as
        provider.public_price_offset so every panel/loop price aligns with the
        user's broker. Honest 200-with-ok=False when MT5 is unreachable."""
        measured = self.feed.measure_offset_now()
        if not measured.get("ok"):
            return {**measured, "hint": "MT5 terminal must be running and logged "
                                        "in; then press Calibrate again"}
        offset = float(measured["offset"])
        cfg = self.collector.cfg()
        kind = "public"
        if cfg is not None and not isinstance(cfg, dict):
            kind = str(getattr(cfg.provider, "kind", "public"))
        result = self.store.save_provider_settings({
            "kind": kind,
            "public_price_offset": offset,
        })
        self.collector._cfg_cache = None
        # restart the feed so the provider rebuilds with the new offset
        try:
            self.feed.stop()
        except Exception:  # noqa: BLE001
            pass
        self.feed.start()
        return {"ok": True, "calibrated": True, "offset": offset,
                "broker_mid": measured.get("broker_mid"),
                "broker_symbol": measured.get("broker_symbol"),
                "raw_public_mid": measured.get("raw_public_mid"),
                "config": result.get("written"),
                "note": "panel feed restarted with the new offset; restart the "
                        "trading loop so paper fills use the aligned levels too"}

    def _post_ks_reset(self, body: dict) -> dict:
        """Reset kill switch via the production KillSwitch class (exact state
        schema + atomic persist + fail-closed semantics) + audit-log."""
        cfg = self.collector.cfg()
        if isinstance(cfg, dict):
            return {"ok": False, "error": "config unavailable"}
        from app.risk.kill_switch import KillSwitch

        ks_path = Path(cfg.kill_switch.state_file)
        prev = {}
        if ks_path.exists():
            try:
                prev = json.loads(ks_path.read_text(encoding="utf-8"))
            except Exception:
                prev = {}
        ks = KillSwitch(cfg.kill_switch)   # loads current state (fail-closed)
        ks.reset()                          # exact schema + atomic write
        try:
            from app.journal.journal import Journal
            j = Journal(self.collector._cfg_paths()["logs"] / "journal.db")
            j.log_event({"kind": "KILL_SWITCH_RESET", "via": "panel",
                         "previous_trigger": prev.get("trigger", "")})
            j.close()
        except Exception:
            pass
        return {"ok": True, "reset": True,
                "previous_trigger": prev.get("trigger", ""),
                "state_file": str(ks_path)}


def make_handler(server: PanelServer):
    class Handler(BaseHTTPRequestHandler):
        server_version = "XAUPanel/1.8"

        def log_message(self, fmt, *args):  # quiet default logging
            logger.debug("%s %s", self.address_string(), fmt % args)

        # ---------------------------------------------------------- send --
        def _send_json(self, status: int, payload: dict) -> None:
            body = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _send_html(self, html: bytes) -> None:
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(html)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(html)

        def _token_ok(self, qs: dict | None = None) -> bool:
            if not server.token:
                return True
            # v1.8 (P13): constant-time comparison (was ``==``) and support
            # for the ``?token=`` query parameter so the browser UI can
            # authenticate read-gated endpoints on LAN bindings.
            supplied = self.headers.get("X-Panel-Token", "")
            if not supplied and qs:
                supplied = (qs.get("token", [""])[0]) or ""
            import hmac
            return hmac.compare_digest(str(supplied), str(server.token))

        # --------------------------------------------------------- verbs --
        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path in ("/", "/index.html"):
                index = STATIC_DIR / "index.html"
                if index.exists():
                    self._send_html(index.read_bytes())
                else:
                    self._send_json(500, {"ok": False, "error": "panel UI missing"})
                return
            qs = parse_qs(parsed.query)
            # v1.8: read-auth on LAN bindings with a token
            if server.read_auth_required and not self._token_ok(qs):
                self._send_json(401, {"ok": False,
                                      "error": "read endpoints require the panel "
                                               "token (X-Panel-Token or ?token=)"})
                return
            status, payload = server.dispatch("GET", parsed.path, qs, None, self._token_ok())
            self._send_json(status, payload)

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            length = int(self.headers.get("Content-Length", 0) or 0)
            body: dict = {}
            if length:
                try:
                    body = json.loads(self.rfile.read(min(length, 1 << 20)) or b"{}")
                except Exception:
                    self._send_json(400, {"ok": False, "error": "invalid JSON body"})
                    return
            qs = parse_qs(parsed.query)
            status, payload = server.dispatch("POST", parsed.path, qs, body, self._token_ok(qs))
            self._send_json(status, payload)

    return Handler


def serve(project_root: Path, host: str, port: int, config_path: str | None,
          token: str | None, open_browser: bool,
          start_loop: bool = False) -> tuple[ThreadingHTTPServer, str]:
    srv = PanelServer(project_root, host, port, config_path, token)
    srv.start_feed()   # v1.7 — real live market prices for the panel
    if start_loop:
        # v1.8 fix (P11): --with-trader used to build a SECOND PanelServer in
        # run_panel.py whose loop manager was invisible to the served panel
        # (the UI showed the loop as stopped and Stop did nothing). The loop
        # is now started on the SAME server instance that serves the UI.
        r = srv.loop_mgr.start(mode="paper")
        print(("▶ trading loop: " + r.get("state", "?")) if r.get("ok")
              else ("✖ loop start refused: " + r.get("error", "?")))
    httpd = ThreadingHTTPServer((host, port), make_handler(srv))
    httpd.daemon_threads = True
    httpd.panel_server = srv        # v1.8: teardown access for the launcher
    url = f"http://{'127.0.0.1' if host in ('0.0.0.0',) else host}:{port}/"
    print("=" * 64)
    print(f"  XAU AI Trader — Control Panel v1.8.1 (forensic audit + hotfix release)")
    print(f"  URL:      {url}")
    print(f"  Root:     {srv.root}")
    print(f"  Config:   {config_path or 'config.yaml'}")
    print(f"  Feed:     LIVE gold prices (broker MT5 tick when available, else "
          f"Yahoo GC=F + gold-api spot)")
    if token:
        scope = "read+write" if srv.read_auth_required else "write endpoints"
        print(f"  Token:    enabled ({scope} need X-Panel-Token)")
    else:
        print("  Token:    disabled (bind 127.0.0.1 keeps the panel local)")
    print("  Ctrl+C to stop.")
    print("=" * 64)
    if open_browser:
        threading_timer = __import__("threading").Timer(1.0, lambda: webbrowser.open(url))
        threading_timer.daemon = True
        threading_timer.start()
    return httpd, url


def main() -> int:
    parser = argparse.ArgumentParser(description="XAU AI Trader control panel")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8788)
    parser.add_argument("--config", default=None)
    parser.add_argument("--token", default=None,
                        help="require this token on write endpoints (or set PANEL_TOKEN env)")
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    root = Path(__file__).resolve().parents[2]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    import os

    token = args.token or os.environ.get("PANEL_TOKEN")
    httpd, _ = serve(root, args.host, args.port, args.config, token,
                     open_browser=not args.no_browser)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\npanel stopped.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

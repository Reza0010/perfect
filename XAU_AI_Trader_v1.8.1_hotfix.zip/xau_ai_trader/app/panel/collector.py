"""v1.6 — Panel data collector: aggregates REAL system data for the panel.

Every value shown in the panel comes from real project artifacts:
  - logs/state.json            → live trader snapshot (written by the trader loop)
  - logs/journal.db            → signals / trades / AI calls (SQLite journal)
  - config.yaml (+ .env)       → effective configuration (secrets masked)
  - data/raw/*.meta.json       → dataset metadata (bars, range, broker)
  - data/raw/*.parquet         → row counts + freshness (pyarrow if present)
  - data/data_quality_report.json
  - models/registry/**         → model registry entries
  - RELEASE_MANIFEST.json      → release provenance, dataset/model hashes
  - reports/*.md|*.json        → audit & validation reports
  - logs/kill_switch_state.json→ kill-switch state
  - data/news_calendar.csv     → upcoming high-impact news
  - .env                       → which API keys are present (values NEVER exposed)

Degradation rule: every collector returns {"ok": bool, "error": str, ...} and
NEVER raises — a missing artifact renders as "not available", never fabricated.
This mirrors the project's PHASE 65 honesty contract (no fake data in UI).
"""

from __future__ import annotations

import csv
import json
import os
import platform
import sqlite3
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT_MARKER = "config.yaml"


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _mask(value: str | None, keep: int = 4) -> str:
    """Mask a secret, keeping only a short tail for recognition."""
    if not value:
        return ""
    if len(value) <= keep:
        return "*" * len(value)
    return "*" * 8 + value[-keep:]


def _fmt_dt(v: Any) -> str:
    return str(v) if v is not None else ""


class PanelCollector:
    """Collects real data snapshots. One instance per server; methods are
    read-only over project files (plus the SQLite WAL-safe reader)."""

    def __init__(self, project_root: Path, config_path: str | None = None) -> None:
        self.root = Path(project_root).resolve()
        self.config_path = config_path
        self._cfg_cache: Any = None
        self._cfg_cache_ts: float = 0.0
        self.started_at = time.time()

    # ------------------------------------------------------------- config --
    def cfg(self):
        """Load + cache AppConfig (invalidated when config.yaml mtime changes)."""
        import yaml  # project dependency, always present
        from app.config.loader import load_config

        path = Path(self.config_path) if self.config_path else self.root / "config.yaml"
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0.0
        if self._cfg_cache is None or mtime != self._cfg_cache_ts:
            try:
                self._cfg_cache = load_config(str(path) if path.exists() else None,
                                              project_root=self.root)
                self._cfg_cache_ts = mtime
            except Exception as e:  # broken config must not kill the panel
                self._cfg_cache = {"__config_error__": str(e)}
        return self._cfg_cache

    def _cfg_paths(self) -> dict:
        cfg = self.cfg()
        if isinstance(cfg, dict):  # config error sentinel
            return {"data": self.root / "data", "logs": self.root / "logs",
                    "models": self.root / "models", "reports": self.root / "reports"}
        p = cfg.paths
        return {"data": Path(p.data_dir), "logs": Path(p.logs_dir),
                "models": Path(p.models_dir), "reports": Path(p.reports_dir)}

    # ----------------------------------------------------------- overview --
    def overview(self) -> dict:
        cfg = self.cfg()
        paths = self._cfg_paths()
        state = self.state()
        manifest = _read_json(self.root / "RELEASE_MANIFEST.json") or {}
        kill = self.kill_switch()
        error = cfg.get("__config_error__") if isinstance(cfg, dict) else None

        comp = {}
        if error:
            comp["config"] = {"status": "ERROR", "detail": error}
        else:
            comp["config"] = {"status": "OK", "detail": str(self.config_path or "config.yaml")}

        mode = ""
        provider_kind = ""
        symbol = ""
        ai_enabled = False
        if not isinstance(cfg, dict):
            mode_raw = getattr(cfg.execution, "mode", "")
            mode = str(getattr(mode_raw, "value", mode_raw))  # enum → value
            provider_kind = str(getattr(cfg.provider, "kind", ""))
            symbol = str(getattr(cfg.symbol, "primary", ""))
            ai_enabled = bool(getattr(cfg.ai, "enabled", False))

        env_status = self.env_status()
        ai_keys_set = [k for k, v in env_status.get("vars", {}).items()
                       if v.get("set") and k.endswith("_API_KEY")]

        # v1.7 — REAL live price for the panel even when the trading loop is
        # stopped: trader state.json is authoritative when fresh, otherwise
        # the live public market feed takes over (source labelled honestly).
        feed_snap = {}
        price, price_source = state.get("price"), "trader"
        state_age = self._state_age(state)
        state_stale = state_age is None or state_age > 120
        feed = getattr(self, "feed", None)
        if feed is not None:
            try:
                feed_snap = feed.snapshot() or {}
            except Exception:
                feed_snap = {"ok": False, "error": "feed snapshot failed"}
            if feed_snap.get("ok") and feed_snap.get("price") is not None:
                if price is None or state_stale:
                    price = feed_snap.get("price")
                    # v1.7.1 — honest source: broker tick vs calibrated public
                    price_source = feed_snap.get("price_source", "public_feed")

        calib = feed_snap.get("calibration") or {}
        state_provider_kind = str(state.get("provider_kind") or provider_kind or "")
        return {
            "ok": not bool(error),
            "app_name": "XAU AI Trader",
            "release_version": manifest.get("release_version", "1.8.0-forensic-audit"),
            "manifest_generated": manifest.get("generated_at"),
            "now": _utcnow(),
            "server_uptime_seconds": int(time.time() - self.started_at),
            "symbol": symbol,
            "mode": mode,
            "provider_kind": state_provider_kind or provider_kind,
            "provider_is_broker": bool(state.get("provider_is_broker")),
            "model_validated": state.get("model_validated"),
            "model_quality_warnings": state.get("model_quality_warnings") or [],
            "ai_enabled": ai_enabled,
            "ai_keys_present": ai_keys_set,
            "live": {"price": price,
                     "price_source": price_source,
                     "market_open": feed_snap.get("market_open"),
                     "spot": feed_snap.get("spot"),
                     "bid": feed_snap.get("bid"),
                     "ask": feed_snap.get("ask"),
                     "bid_ask_source": feed_snap.get("bid_ask_source"),
                     "public_price": feed_snap.get("public_price"),
                     "feed_source": feed_snap.get("source"),
                     "feed_error": feed_snap.get("error"),
                     "calibration": calib,
                     "mt5_connected": state.get("mt5_connected"),
                     "regime": state.get("current_regime")},
            "health": state.get("health", []),
            "worst_health": state.get("worst_health", ""),
            "kill_switch": kill,
            "trader_state_age_seconds": self._state_age(state),
            "config_status": comp["config"],
        }

    # -------------------------------------------------------------- state --
    def _state_age(self, state: dict) -> float | None:
        upd = state.get("updated")
        if not upd:
            return None
        try:
            t = datetime.fromisoformat(str(upd))
            if t.tzinfo is None:
                t = t.replace(tzinfo=timezone.utc)
            return max(0.0, (datetime.now(timezone.utc) - t).total_seconds())
        except Exception:
            return None

    def state(self) -> dict:
        path = self._cfg_paths()["logs"] / "state.json"
        data = _read_json(path)
        return data or {}

    # ------------------------------------------------------- kill switch --
    def kill_switch(self) -> dict:
        cfg = self.cfg()
        ks_path = None
        if not isinstance(cfg, dict):
            ks_path = Path(getattr(cfg.kill_switch, "state_file", ""))
        if not ks_path:
            ks_path = self.root / "logs" / "kill_switch_state.json"
        data = _read_json(ks_path) or {}
        return {
            "active": bool(data.get("active", data.get("tripped", False))),
            "raw": data,
            "state_file": str(ks_path),
        }

    # ------------------------------------------------------------- config --
    def config_sanitized(self) -> dict:
        """Full effective config with secret VALUES masked (env var NAMES kept)."""
        cfg = self.cfg()
        if isinstance(cfg, dict):
            return {"ok": False, "error": cfg.get("__config_error__", "config error")}
        try:
            raw = cfg.model_dump()
        except Exception as e:
            return {"ok": False, "error": f"config dump failed: {e}"}

        def _scrub(obj):
            if isinstance(obj, dict):
                return {k: _scrub(v) for k, v in obj.items()}
            if isinstance(obj, list):
                return [_scrub(v) for v in obj]
            return obj

        raw = _scrub(raw)
        # resolve real absolute paths for display
        try:
            raw["paths_resolved"] = {
                "project_root": str(self.root),
                "data_dir": str(self._cfg_paths()["data"]),
                "logs_dir": str(self._cfg_paths()["logs"]),
                "models_dir": str(self._cfg_paths()["models"]),
                "reports_dir": str(self._cfg_paths()["reports"]),
            }
        except Exception:
            pass
        raw["env"] = self.env_status().get("vars", {})
        return {"ok": True, "config": raw}

    # ---------------------------------------------------------- env/keys --
    ENV_VARS_OF_INTEREST = [
        "ZAI_API_KEY", "GEMINI_API_KEY", "GROQ_API_KEY", "OPENROUTER_API_KEY",
        "OPENAI_API_KEY", "DEEPSEEK_API_KEY", "ANTHROPIC_API_KEY",
        "MT5_LOGIN", "MT5_PASSWORD", "MT5_SERVER",
        "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID", "LIVE_CONFIRM", "XAI_API_KEY",
    ]

    def env_status(self) -> dict:
        """Which secrets are SET (never their values)."""
        dotenv_vals: dict[str, str] = {}
        env_file = self.root / ".env"
        if env_file.exists():
            try:
                for line in env_file.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, _, v = line.partition("=")
                    dotenv_vals[k.strip()] = v.strip().strip('"').strip("'")
            except Exception:
                pass
        vars_out = {}
        for name in self.ENV_VARS_OF_INTEREST:
            in_file = name in dotenv_vals and bool(dotenv_vals[name])
            in_proc = bool(os.environ.get(name))
            vars_out[name] = {
                "set": bool(in_file or in_proc),
                "source": "env+file" if (in_file and in_proc) else ("env" if in_proc else ("file" if in_file else "none")),
                "preview": _mask(dotenv_vals.get(name) or os.environ.get(name)),
            }
        return {"ok": True, "vars": vars_out, "env_file": str(env_file),
                "env_file_exists": env_file.exists()}

    # --------------------------------------------------------------- data --
    def datasets(self) -> dict:
        raw_dir = self._cfg_paths()["data"] / "raw"
        out = []
        if raw_dir.exists():
            for meta_file in sorted(raw_dir.glob("*.meta.json")):
                stem = meta_file.name[: -len(".meta.json")]
                meta = _read_json(meta_file) or {}
                pq = raw_dir / f"{stem}.parquet"
                entry = {
                    "file": stem,
                    "symbol": meta.get("symbol"),
                    "timeframe": meta.get("timeframe"),
                    "source": meta.get("source"),
                    "data_kind": meta.get("data_kind"),
                    "bar_count": meta.get("bar_count"),
                    "start": meta.get("start"),
                    "end": meta.get("end"),
                    "download_date": meta.get("download_date"),
                    "spread_available": meta.get("spread_available"),
                    "volume_kind": meta.get("volume_kind"),
                    "broker": (meta.get("extra") or {}).get("broker_company") or meta.get("broker"),
                    "parquet_exists": pq.exists(),
                    "parquet_bytes": pq.stat().st_size if pq.exists() else 0,
                    "sha256": None,
                    "rows_actual": None,
                    "freshness_hours": None,
                }
                # real file verification: sha + row count via pyarrow
                if pq.exists():
                    try:
                        import hashlib
                        h = hashlib.sha256()
                        with open(pq, "rb") as f:
                            for chunk in iter(lambda: f.read(1 << 20), b""):
                                h.update(chunk)
                        entry["sha256"] = h.hexdigest()
                    except Exception:
                        pass
                    try:
                        import pyarrow.parquet as pqmod  # noqa: N813
                        tbl = pqmod.read_table(str(pq))
                        entry["rows_actual"] = tbl.num_rows
                        cols = tbl.column_names
                        for tcol in ("time", "timestamp", "close_time", "index"):
                            if tcol in cols:
                                last = tbl.column(tcol)[-1].as_py()
                                if last is not None:
                                    try:
                                        t = datetime.fromisoformat(str(last).replace("Z", "+00:00"))
                                        if t.tzinfo is None:
                                            t = t.replace(tzinfo=timezone.utc)
                                        entry["freshness_hours"] = round(
                                            (datetime.now(timezone.utc) - t).total_seconds() / 3600.0, 1)
                                    except Exception:
                                        pass
                                break
                        if entry["freshness_hours"] is None and "close" in cols:
                            # approximate freshness from meta end
                            end = meta.get("end")
                            if end:
                                try:
                                    t = datetime.fromisoformat(str(end))
                                    if t.tzinfo is None:
                                        t = t.replace(tzinfo=timezone.utc)
                                    entry["freshness_hours"] = round(
                                        (datetime.now(timezone.utc) - t).total_seconds() / 3600.0, 1)
                                except Exception:
                                    pass
                    except Exception:
                        pass
                out.append(entry)
        dq = _read_json(self._cfg_paths()["data"] / "data_quality_report.json") or {}
        return {"ok": True, "datasets": out, "quality_report": dq,
                "quality_report_path": str(self._cfg_paths()["data"] / "data_quality_report.json")}

    # ------------------------------------------------------------- models --
    def models(self) -> dict:
        models_dir = self._cfg_paths()["models"]
        entries = []
        reg_root = models_dir / "registry"
        manifest = _read_json(self.root / "RELEASE_MANIFEST.json") or {}
        mh = manifest.get("model_hashes", {})
        if reg_root.exists():
            for fam in sorted(p for p in reg_root.iterdir() if p.is_dir()):
                files = sorted(f for f in fam.iterdir() if f.is_file() and f.name != ".gitkeep")
                if not files:
                    continue
                fam_info = mh.get(fam.name, {})
                meta_files = {}
                for name in ("params.json", "feature_names.json", "calibrator.json"):
                    j = _read_json(fam / name)
                    if j is not None:
                        # keep payloads small for the UI
                        meta_files[name] = j if name != "feature_names.json" else {
                            "n_features": len(j) if isinstance(j, list) else None}
                entries.append({
                    "family": fam.name,
                    "path": str(fam.relative_to(self.root)),
                    "n_files": len(files),
                    "files": [{"name": f.name, "bytes": f.stat().st_size} for f in files],
                    "artifact": next((f.name for f in files if f.name.startswith("model")), files[0].name),
                    "manifest_version": fam_info.get("version"),
                    "manifest_sha256": (fam_info.get("sha256") or "")[:16],
                    "provenance_complete": fam_info.get("provenance_complete"),
                    "meta": meta_files,
                })
        return {"ok": True, "registry": entries,
                "manifest_model_hashes": mh,
                "manifest_label_contract": manifest.get("label_contract", {})}

    # ------------------------------------------------------------ reports --
    def reports(self) -> dict:
        rep_dir = self._cfg_paths()["reports"]
        files = []
        if rep_dir.exists():
            for p in sorted(rep_dir.glob("*")):
                if p.is_file() and p.name != ".gitkeep":
                    files.append({"name": p.name, "bytes": p.stat().st_size,
                                  "modified": datetime.fromtimestamp(
                                      p.stat().st_mtime, tz=timezone.utc).isoformat(timespec="seconds")})
        manifest = _read_json(self.root / "RELEASE_MANIFEST.json") or {}
        return {"ok": True, "reports": files, "manifest": manifest}

    # ------------------------------------------------------------ journal --
    def _journal_conn(self) -> sqlite3.Connection | None:
        db = self._cfg_paths()["logs"] / "journal.db"
        if not db.exists():
            return None
        try:
            conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True, check_same_thread=False,
                                   timeout=3.0)
            conn.row_factory = sqlite3.Row
            return conn
        except Exception:
            return None

    def _q(self, conn, sql: str, params: tuple = ()) -> list[dict]:
        try:
            return [dict(r) for r in conn.execute(sql, params).fetchall()]
        except Exception:
            return []

    def signals(self, limit: int = 50) -> dict:
        conn = self._journal_conn()
        if not conn:
            return {"ok": True, "signals": [], "note": "journal.db not created yet (no trading loop has run)"}
        rows = self._q(conn, "SELECT * FROM signals ORDER BY id DESC LIMIT ?", (int(limit),))
        conn.close()
        return {"ok": True, "signals": rows}

    def trades(self, limit: int = 50) -> dict:
        conn = self._journal_conn()
        if not conn:
            return {"ok": True, "trades": [], "stats": {}, "note": "journal.db not created yet"}
        rows = self._q(conn, "SELECT * FROM trades ORDER BY entry_time DESC LIMIT ?", (int(limit),))
        stats_rows = self._q(conn, "SELECT pnl FROM trades WHERE exit_time IS NOT NULL ORDER BY exit_time DESC LIMIT 500")
        conn.close()
        pnls = [r["pnl"] or 0.0 for r in stats_rows]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p < 0]
        # v1.8 fix (P9): with ZERO closed trades the old defaults showed a
        # 0% win rate and $0 expectancy — fabricated-looking statistics. No
        # trades → null (the UI renders "—"), and the trade count is the
        # honest headline until a real sample exists.
        stats = {
            "n_closed": len(pnls),
            "win_rate_pct": round(len(wins) / len(pnls) * 100.0, 2) if pnls else None,
            "profit_factor": round(sum(wins) / abs(sum(losses)), 3) if losses and sum(wins) > 0 else (None if not wins else "inf"),
            "expectancy": round(sum(pnls) / len(pnls), 4) if pnls else None,
            "net_pnl": round(sum(pnls), 4),
        }
        return {"ok": True, "trades": rows, "stats": stats}

    def ai_calls(self, limit: int = 50) -> dict:
        conn = self._journal_conn()
        if not conn:
            return {"ok": True, "calls": [], "stats": {}, "note": "journal.db not created yet"}
        rows = self._q(conn, "SELECT * FROM ai_calls ORDER BY id DESC LIMIT ?", (int(limit),))
        agg = self._q(conn, "SELECT provider, model, COUNT(*) calls, "
                            "SUM(CASE WHEN status='OK' THEN 1 ELSE 0 END) ok, "
                            "AVG(latency_ms) avg_latency, "
                            "SUM(COALESCE(input_tokens,0)+COALESCE(output_tokens,0)) tokens "
                            "FROM ai_calls GROUP BY provider, model")
        conn.close()
        return {"ok": True, "calls": rows, "stats": agg}

    def events(self, limit: int = 50) -> dict:
        conn = self._journal_conn()
        if not conn:
            return {"ok": True, "events": []}
        try:
            rows = self._q(conn, "SELECT * FROM events ORDER BY id DESC LIMIT ?", (int(limit),))
        finally:
            conn.close()
        return {"ok": True, "events": rows}

    # --------------------------------------------------------------- news --
    def news_calendar(self) -> dict:
        cfg = self.cfg()
        csv_path = None
        if not isinstance(cfg, dict):
            csv_path = Path(cfg.news.csv_path)
        if not csv_path:
            csv_path = self._cfg_paths()["data"] / "news_calendar.csv"
        if not csv_path.exists():
            return {"ok": True, "upcoming": [], "past": [], "path": str(csv_path), "exists": False}
        rows = []
        try:
            with open(csv_path, newline="", encoding="utf-8") as f:
                for r in csv.DictReader(f):
                    rows.append(r)
        except Exception as e:
            return {"ok": False, "error": str(e), "path": str(csv_path)}
        now = datetime.now(timezone.utc)

        def _parse(v):
            for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S"):
                try:
                    return datetime.strptime(v, fmt).replace(tzinfo=timezone.utc)
                except Exception:
                    continue
            return None

        upcoming, past = [], []
        for r in rows[:5000]:
            dt = _parse(r.get("datetime", "") or r.get("date", ""))
            item = dict(r)
            item["parsed"] = dt.isoformat() if dt else None
            if dt is None:
                upcoming.append(item)
                continue
            (upcoming if dt >= now else past).append(item)
        upcoming.sort(key=lambda x: x.get("parsed") or "")
        return {"ok": True, "exists": True, "path": str(csv_path),
                "upcoming": upcoming[:30], "past_count": len(past),
                "total": len(rows)}

    # --------------------------------------------------------------- logs --
    def logs(self) -> dict:
        logs_dir = self._cfg_paths()["logs"]
        files = []
        if logs_dir.exists():
            for p in sorted(logs_dir.glob("*.log")) + sorted(logs_dir.glob("*.log.*")):
                files.append({"name": p.name, "bytes": p.stat().st_size,
                              "modified": datetime.fromtimestamp(
                                  p.stat().st_mtime, tz=timezone.utc).isoformat(timespec="seconds")})
        return {"ok": True, "logs_dir": str(logs_dir), "files": files}

    def log_tail(self, name: str, lines: int = 120) -> dict:
        logs_dir = self._cfg_paths()["logs"]
        safe = Path(name).name  # prevent traversal
        p = logs_dir / safe
        if not p.exists() or p.parent != logs_dir:
            return {"ok": False, "error": "log file not found", "name": safe}
        try:
            with open(p, "rb") as f:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                f.seek(max(0, size - 400_000))
                data = f.read().decode("utf-8", errors="replace")
            tail = data.splitlines()[-int(lines):]
            return {"ok": True, "name": safe, "lines": tail, "truncated": size > 400_000}
        except Exception as e:
            return {"ok": False, "error": str(e), "name": safe}

    # ------------------------------------------------------------- system --
    def system(self) -> dict:
        pkgs = {}
        for mod in ("numpy", "pandas", "yaml", "pydantic", "httpx", "sklearn",
                    "lightgbm", "xgboost", "hmmlearn", "pyarrow", "rich",
                    "MetaTrader5", "dotenv", "optuna"):
            try:
                m = __import__(mod)
                pkgs[mod] = getattr(m, "__version__", "installed")
            except Exception:
                pkgs[mod] = "NOT INSTALLED"
        mt5_ok = pkgs.get("MetaTrader5") != "NOT INSTALLED"
        return {
            "ok": True,
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "machine": platform.machine(),
            "pid": os.getpid(),
            "now_local": datetime.now().astimezone().isoformat(timespec="seconds"),
            "now_utc": _utcnow(),
            "tz": str(getattr(sys.modules["time"], "tzname", ("", ""))),
            "packages": pkgs,
            "mt5_available": mt5_ok,
            "project_root": str(self.root),
        }

    # ------------------------------------------------------- risk snapshot --
    def risk(self) -> dict:
        cfg = self.cfg()
        if isinstance(cfg, dict):
            return {"ok": False, "error": "config unavailable"}
        r = cfg.risk.model_dump()
        k = cfg.kill_switch.model_dump()
        k["state_file"] = str(k.get("state_file", ""))
        ks = self.kill_switch()
        return {"ok": True, "risk": r, "kill_switch_config": k, "kill_switch_state": ks}

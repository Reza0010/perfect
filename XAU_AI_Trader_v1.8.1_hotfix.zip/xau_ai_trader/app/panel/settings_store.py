"""v1.6 — AI settings store: panel-side persistence for AI provider settings.

Design (follows the project's security contract — SECURITY.md):
  - API keys are SECRETS → written ONLY to `.env` (never YAML, never JSON logs).
  - Non-secret provider settings (model, base_url, temperature, limits, order)
    → written to the `ai:` section of config.yaml via a safe YAML round-trip
    that preserves comments where possible (ruamel if available, else PyYAML
    with a timestamped backup of the original file).
  - Every write creates a backup file (config.yaml.bak-<ts> / .env.bak-<ts>).
  - The panel NEVER returns key values back to the browser — masked previews only.

Provider catalogue: the 4 built-in failover providers (zai, gemini, groq,
openrouter) plus common OpenAI-compatible additions (openai, deepseek,
anthropic, xai, custom) — custom providers are routed through the
OpenAICompatibleProvider path in the gateway.
"""

from __future__ import annotations

import os
import shutil
import time
from pathlib import Path

import yaml

BUILTIN_PROVIDERS = ["zai", "gemini", "groq", "openrouter"]

# OpenAI-compatible providers (chat/completions path) usable without new code
OPENAI_COMPATIBLE = {
    "zai":       {"default_url": "https://api.z.ai/api/paas/v4",                "default_model": "glm-4.6",              "key_env": "ZAI_API_KEY"},
    "gemini":    {"default_url": "https://generativelanguage.googleapis.com/v1beta", "default_model": "gemini-2.0-flash", "key_env": "GEMINI_API_KEY"},
    "groq":      {"default_url": "https://api.groq.com/openai/v1",              "default_model": "llama-3.3-70b-versatile", "key_env": "GROQ_API_KEY"},
    "openrouter":{"default_url": "https://openrouter.ai/api/v1",                "default_model": "openai/gpt-4o-mini",  "key_env": "OPENROUTER_API_KEY"},
    "openai":    {"default_url": "https://api.openai.com/v1",                   "default_model": "gpt-4o-mini",         "key_env": "OPENAI_API_KEY"},
    "deepseek":  {"default_url": "https://api.deepseek.com/v1",                 "default_model": "deepseek-chat",       "key_env": "DEEPSEEK_API_KEY"},
    "xai":       {"default_url": "https://api.x.ai/v1",                         "default_model": "grok-3-mini",         "key_env": "XAI_API_KEY"},
    "anthropic": {"default_url": "https://api.anthropic.com/v1",                "default_model": "claude-sonnet-4-20250514", "key_env": "ANTHROPIC_API_KEY"},
    "custom":    {"default_url": "",                                            "default_model": "",                    "key_env": "CUSTOM_AI_API_KEY"},
}

KEY_ENV_BY_NAME = {k: v["key_env"] for k, v in OPENAI_COMPATIBLE.items()}

VALID_SETTINGS_FIELDS = {"name", "enabled", "api_key_env", "base_url", "model",
                         "timeout_seconds", "temperature", "max_tokens",
                         "max_requests_per_day", "extra_headers_env"}


class SettingsStoreError(Exception):
    pass


def _backup(path: Path) -> Path:
    if path.exists():
        bak = path.with_name(f"{path.name}.bak-{time.strftime('%Y%m%d-%H%M%S')}")
        shutil.copy2(path, bak)
        # keep at most 10 backups per file
        baks = sorted(path.parent.glob(f"{path.name}.bak-*"))
        for old in baks[:-10]:
            try:
                old.unlink()
            except OSError:
                pass
        return bak
    return path


class AISettingsStore:
    def __init__(self, project_root: Path, config_path: str | None = None) -> None:
        self.root = Path(project_root).resolve()
        self.config_path = Path(config_path) if config_path else self.root / "config.yaml"
        self.env_path = self.root / ".env"

    # ------------------------------------------------------------- read --
    def current(self) -> dict:
        """Current AI settings from config.yaml + key presence from .env/env."""
        data = {}
        if self.config_path.exists():
            try:
                data = yaml.safe_load(self.config_path.read_text(encoding="utf-8")) or {}
            except yaml.YAMLError as e:
                raise SettingsStoreError(f"config.yaml is not valid YAML: {e}") from e
        ai = data.get("ai", {}) or {}
        providers = []
        for p in ai.get("providers", []) or []:
            name = str(p.get("name", ""))
            key_env = str(p.get("api_key_env", KEY_ENV_BY_NAME.get(name, f"{name.upper()}_API_KEY")))
            providers.append({
                "name": name,
                "enabled": bool(p.get("enabled", True)),
                "api_key_env": key_env,
                "base_url": p.get("base_url") or OPENAI_COMPATIBLE.get(name, {}).get("default_url") or "",
                "model": p.get("model") or OPENAI_COMPATIBLE.get(name, {}).get("default_model") or "",
                "timeout_seconds": p.get("timeout_seconds", 30),
                "temperature": p.get("temperature", 0.1),
                "max_tokens": p.get("max_tokens", 512),
                "max_requests_per_day": p.get("max_requests_per_day", 300),
                "extra_headers_env": p.get("extra_headers_env"),
                "key_set": self._key_present(key_env),
                "key_preview": self._key_preview(key_env),
                "builtin": name in OPENAI_COMPATIBLE,
            })
        return {
            "ok": True,
            "ai": {
                "enabled": bool(ai.get("enabled", True)),
                "require_ai_for_trade": bool(ai.get("require_ai_for_trade", True)),
                "on_all_fail": ai.get("on_all_fail", "WAIT"),
                "cache_ttl_seconds": ai.get("cache_ttl_seconds", 300),
                "cost_daily_limit_usd": ai.get("cost_daily_limit_usd", 5.0),
                "estimated_cost_per_1k_tokens": ai.get("estimated_cost_per_1k_tokens", 0.003),
                "max_context_chars": ai.get("max_context_chars", 6000),
                "failover_order": ai.get("failover_order", []),
            },
            "providers": providers,
            "catalogue": OPENAI_COMPATIBLE,
            "config_path": str(self.config_path),
            "env_path": str(self.env_path),
        }

    def _dotenv(self) -> dict[str, str]:
        vals: dict[str, str] = {}
        if self.env_path.exists():
            for line in self.env_path.read_text(encoding="utf-8").splitlines():
                s = line.strip()
                if not s or s.startswith("#") or "=" not in s:
                    continue
                k, _, v = s.partition("=")
                vals[k.strip()] = v.strip().strip('"').strip("'")
        return vals

    def _key_present(self, env_name: str) -> bool:
        if os.environ.get(env_name):
            return True
        return bool(self._dotenv().get(env_name))

    def _key_preview(self, env_name: str) -> str:
        v = os.environ.get(env_name) or self._dotenv().get(env_name) or ""
        if not v:
            return ""
        return "*" * 8 + v[-4:] if len(v) > 4 else "*" * len(v)

    # ------------------------------------------------------------ write --
    def save_api_key(self, env_name: str, api_key: str) -> dict:
        """Write/replace ONE key line in .env (atomic + backup). Empty key → remove line."""
        env_name = env_name.strip()
        if not env_name.replace("_", "").isalnum():
            raise SettingsStoreError(f"invalid env var name: {env_name!r}")
        api_key = api_key.strip()
        _backup(self.env_path)
        lines: list[str] = []
        if self.env_path.exists():
            lines = self.env_path.read_text(encoding="utf-8").splitlines()
        out, replaced = [], False
        for line in lines:
            s = line.strip()
            if s and not s.startswith("#") and s.split("=", 1)[0].strip() == env_name:
                if api_key:  # replace
                    out.append(f"{env_name}={api_key}")
                # empty key → drop the line
                replaced = True
            else:
                out.append(line)
        if not replaced and api_key:
            if out and out[-1].strip():
                out.append("")
            out.append(f"# added by control panel at {time.strftime('%Y-%m-%d %H:%M:%S')}")
            out.append(f"{env_name}={api_key}")
        self.env_path.write_text("\n".join(out).rstrip() + "\n", encoding="utf-8")
        try:
            os.chmod(self.env_path, 0o600)
        except OSError:
            pass
        return {"ok": True, "env_var": env_name, "set": bool(api_key),
                "note": "key stored in .env — never exposed via the panel API"}

    def save_ai_settings(self, payload: dict) -> dict:
        """Persist the ai: section (providers + globals) into config.yaml.

        payload shape:
        {
          "ai": {enabled, require_ai_for_trade, on_all_fail, cache_ttl_seconds,
                 cost_daily_limit_usd, estimated_cost_per_1k_tokens, max_context_chars,
                 failover_order: [...]},
          "providers": [{name, enabled, api_key_env, base_url, model,
                         timeout_seconds, temperature, max_tokens,
                         max_requests_per_day, extra_headers_env?}, ...]
        }
        """
        if not isinstance(payload, dict):
            raise SettingsStoreError("payload must be a JSON object")
        providers_in = payload.get("providers")
        ai_in = payload.get("ai")
        if not isinstance(providers_in, list) or not providers_in:
            raise SettingsStoreError("at least one provider definition is required")
        if not isinstance(ai_in, dict):
            raise SettingsStoreError("ai globals object is required")

        _backup(self.config_path)
        data: dict = {}
        if self.config_path.exists():
            try:
                data = yaml.safe_load(self.config_path.read_text(encoding="utf-8")) or {}
            except yaml.YAMLError as e:
                raise SettingsStoreError(f"config.yaml is not valid YAML: {e}") from e

        clean_providers = []
        seen_names = set()
        for p in providers_in:
            name = str(p.get("name", "")).strip().lower()
            if not name or not name.replace("_", "").replace("-", "").isalnum():
                raise SettingsStoreError(f"invalid provider name: {name!r}")
            if name in seen_names:
                raise SettingsStoreError(f"duplicate provider name: {name}")
            seen_names.add(name)
            api_key_env = str(p.get("api_key_env") or KEY_ENV_BY_NAME.get(name) or f"{name.upper()}_API_KEY").strip()
            rec = {
                "name": name,
                "enabled": bool(p.get("enabled", True)),
                "api_key_env": api_key_env,
                "base_url": (str(p.get("base_url") or "").strip() or None),
                "model": (str(p.get("model") or "").strip() or None),
                "timeout_seconds": float(p.get("timeout_seconds", 30) or 30),
                "temperature": float(p.get("temperature", 0.1) or 0.0),
                "max_tokens": int(p.get("max_tokens", 512) or 512),
                "max_requests_per_day": int(p.get("max_requests_per_day", 300) or 300),
            }
            if p.get("extra_headers_env"):
                rec["extra_headers_env"] = str(p["extra_headers_env"]).strip()
            clean_providers.append(rec)

        failover = [str(n).strip().lower() for n in (ai_in.get("failover_order") or [])]
        if failover:
            unknown = [n for n in failover if n not in seen_names]
            if unknown:
                raise SettingsStoreError(f"failover_order references unknown providers: {unknown}")

        ai_section = {
            "enabled": bool(ai_in.get("enabled", True)),
            "require_ai_for_trade": bool(ai_in.get("require_ai_for_trade", True)),
            "on_all_fail": str(ai_in.get("on_all_fail", "WAIT")).upper()
                            if str(ai_in.get("on_all_fail", "WAIT")).upper()
                            in ("WAIT", "PROCEED_WITHOUT_AI") else "WAIT",
            "cache_ttl_seconds": int(ai_in.get("cache_ttl_seconds", 300) or 300),
            "max_context_chars": int(ai_in.get("max_context_chars", 6000) or 6000),
            "cost_daily_limit_usd": float(ai_in.get("cost_daily_limit_usd", 5.0) or 5.0),
            "estimated_cost_per_1k_tokens": float(ai_in.get("estimated_cost_per_1k_tokens", 0.003) or 0.003),
            "providers": clean_providers,
        }
        if failover:
            ai_section["failover_order"] = failover
        # v1.7 — preserve sections the panel does not edit (rate limiting)
        old_ai = data.get("ai", {}) or {}
        if isinstance(old_ai.get("rate_limit"), dict):
            ai_section["rate_limit"] = old_ai["rate_limit"]

        data["ai"] = ai_section
        # PyYAML round-trip: comments are lost, that is why we keep a .bak —
        # documented in the panel UI.
        try:
            text = yaml.safe_dump(data, sort_keys=False, allow_unicode=True, default_flow_style=False)
        except yaml.YAMLError as e:
            raise SettingsStoreError(f"serializing config failed: {e}") from e
        self.config_path.write_text(text, encoding="utf-8")
        return {"ok": True, "written": str(self.config_path),
                "providers": [p["name"] for p in clean_providers],
                "note": "backup created; restart the trading loop (or main.py) to apply"}

    # ----------------------------------------------- provider (v1.7) --
    VALID_KINDS = ("public", "simulated", "mt5", "replay")
    VALID_SOURCE_MODES = ("auto", "broker", "public")

    def save_provider_settings(self, payload: dict) -> dict:
        """Persist the ``provider:`` section (market data source) into config.yaml.

        payload: {kind, public_symbol?, public_refresh_seconds?,
                  public_spread_points?, public_timeout_seconds?,
                  public_price_offset?,          # v1.7.1 broker calibration ($)
                  price_source_mode?}            # v1.7.1 auto|broker|public
        """
        if not isinstance(payload, dict):
            raise SettingsStoreError("payload must be a JSON object")
        kind = str(payload.get("kind", "")).strip().lower()
        if kind not in self.VALID_KINDS:
            raise SettingsStoreError(
                f"kind must be one of {self.VALID_KINDS} (got {kind!r})")
        mode = str(payload.get("price_source_mode", "")).strip().lower() or None
        if mode is not None and mode not in self.VALID_SOURCE_MODES:
            raise SettingsStoreError(
                f"price_source_mode must be one of {self.VALID_SOURCE_MODES} (got {mode!r})")

        _backup(self.config_path)
        data: dict = {}
        if self.config_path.exists():
            try:
                data = yaml.safe_load(self.config_path.read_text(encoding="utf-8")) or {}
            except yaml.YAMLError as e:
                raise SettingsStoreError(f"config.yaml is not valid YAML: {e}") from e

        old = data.get("provider", {}) or {}
        offset = float(payload.get("public_price_offset",
                                   old.get("public_price_offset", 0.0)) or 0.0)
        if not -1000.0 <= offset <= 1000.0:
            raise SettingsStoreError(
                f"public_price_offset out of sane range (±1000): {offset}")
        section = {
            "kind": kind,
            "public_symbol": str(payload.get("public_symbol") or old.get("public_symbol") or "GC=F").strip(),
            "public_refresh_seconds": max(15.0, float(payload.get("public_refresh_seconds", old.get("public_refresh_seconds", 30)) or 30)),
            "public_spread_points": max(1.0, float(payload.get("public_spread_points", old.get("public_spread_points", 30)) or 30)),
            "public_timeout_seconds": max(3.0, float(payload.get("public_timeout_seconds", old.get("public_timeout_seconds", 15)) or 15)),
            "public_price_offset": round(offset, 2),
            "price_source_mode": mode or str(old.get("price_source_mode", "auto")),
            "simulated_days": int(old.get("simulated_days", 90)),
            "simulated_seed": int(old.get("simulated_seed", 42)),
            "simulated_start_price": float(old.get("simulated_start_price", 2350.0)),
            "simulated_annual_vol": float(old.get("simulated_annual_vol", 0.16)),
        }
        data["provider"] = section
        try:
            text = yaml.safe_dump(data, sort_keys=False, allow_unicode=True, default_flow_style=False)
        except yaml.YAMLError as e:
            raise SettingsStoreError(f"serializing config failed: {e}") from e
        self.config_path.write_text(text, encoding="utf-8")
        return {"ok": True, "written": str(self.config_path), "kind": kind,
                "public_price_offset": section["public_price_offset"],
                "price_source_mode": section["price_source_mode"],
                "note": "backup created; restart the trading loop to apply "
                        "(the panel price feed switches to public automatically)"}

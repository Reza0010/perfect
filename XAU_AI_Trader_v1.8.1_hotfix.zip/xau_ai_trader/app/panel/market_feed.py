"""v1.7.1 — Panel LIVE MARKET FEED: broker-aligned real-time gold prices.

Priority logic (provider.price_source_mode):
  auto    → broker MT5 tick when the terminal is reachable (EXACT match with
            what the user sees in their trading platform), otherwise the
            public feed (Yahoo COMEX GC=F + gold-api) with the configured
            calibration offset applied.
  broker  → broker tick only; public shown as fallback with an honest label.
  public  → never touch MT5 (public feed only).

The feed ALSO measures the live residual basis between the broker tick and
the calibrated public price (EMA-smoothed) and persists it to
``logs/price_basis.json`` so the panel can tell the user when the offset in
config.yaml is drifting and needs a re-calibration.

A small daemon around :class:`LivePublicProvider` that keeps REAL market data
flowing to the panel EVEN WHEN the trading loop is stopped.

- own LivePublicProvider instance (independent of the loop's provider —
  the loop may be restarted/reconfigured without interrupting the feed)
- thread-safe snapshot + intraday candle series for the price chart
- never raises: on total failure ``ok=False`` with the error string
"""

from __future__ import annotations

import logging
import threading
import time
from pathlib import Path

logger = logging.getLogger(__name__)

BROKER_TICK_FRESH_S = 120.0     # broker tick older than this → use public
BASIS_EMA_ALPHA = 0.25          # EMA smoothing of residual basis samples
BASIS_PERSIST_EVERY = 10        # persist at most every N measured cycles


class LiveMarketFeed:
    def __init__(self, project_root: Path, config_path: str | None = None) -> None:
        self.root = Path(project_root).resolve()
        self.config_path = config_path
        self._provider = None
        self._reader = None                 # BrokerTickReader (may be None)
        self._mode = "auto"
        self._offset = 0.0
        self._basis_path = self.root / "logs" / "price_basis.json"
        # broker state (lock-guarded)
        self._broker_tick: dict | None = None
        self._basis_samples: list[float] = []
        self._basis_ema: float | None = None
        self._basis_cycles = 0
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._started_at: float | None = None
        self._last_error = ""
        self._last_ok: float | None = None

    # ------------------------------------------------------------- build --
    def _build(self):
        from app.config.loader import load_config
        from app.data.market.live_public import LivePublicProvider

        cfg = load_config(self.config_path, project_root=self.root)
        provider = LivePublicProvider(
            symbol=cfg.provider.public_symbol,
            refresh_seconds=cfg.provider.public_refresh_seconds,
            spread_points=cfg.provider.public_spread_points,
            timeout_seconds=cfg.provider.public_timeout_seconds,
            defaults=cfg.symbol.fallback_symbol_info,
            initial_balance=cfg.backtest.initial_balance,
            display_symbol=cfg.symbol.primary,
            price_offset=getattr(cfg.provider, "public_price_offset", 0.0),
        )
        self._mode = getattr(cfg.provider, "price_source_mode", "auto") or "auto"
        self._offset = float(getattr(cfg.provider, "public_price_offset", 0.0) or 0.0)
        reader = None
        if self._mode in ("auto", "broker"):
            from app.data.mt5.tick_reader import BrokerTickReader, load_persisted_basis

            aliases = [cfg.symbol.primary] + list(cfg.symbol.aliases or [])
            reader = BrokerTickReader(aliases)
            if not reader.available:
                logger.info("[market-feed] MT5 package unavailable — "
                            "panel price falls back to the public feed")
                reader = None
            else:
                persisted = load_persisted_basis(self._basis_path)
                if persisted:
                    with self._lock:
                        self._basis_ema = persisted.get("residual_ema")
        return provider, reader

    def start(self) -> None:
        # v1.8 fix (P12): the old order was (1) clear the stop event, (2) check
        # thread alive → return. After stop() the old thread could still be
        # inside its 30s wait; clearing the event let it keep running forever
        # while start() returned as if a fresh feed had been created — the
        # panel then showed stale prices with a "restarted" success message.
        # Correct order: join any stopping thread FIRST, then clear + start.
        if self._thread and self._thread.is_alive():
            # a still-running thread is only acceptable when it was NOT asked
            # to stop; otherwise wait (bounded) for it to honour the event.
            if self._stop.is_set():
                self._thread.join(timeout=12.0)
            if self._thread.is_alive():
                logger.warning("[market-feed] previous feed thread did not stop "
                               "within 12s — new feed NOT started (avoiding two)")
                return
        self._stop.clear()

        def _run() -> None:
            try:
                provider, reader = self._build()
            except Exception as e:  # noqa: BLE001 — config broken → honest error
                self._last_error = f"feed init failed: {type(e).__name__}: {e}"
                logger.warning("[market-feed] %s", self._last_error)
                return
            with self._lock:
                self._provider = provider
                self._reader = reader
            self._started_at = time.time()
            while not self._stop.is_set():
                try:
                    provider.connect()          # idempotent; seeds on first call
                    self._last_ok = time.time()
                    self._last_error = ""
                except Exception as e:  # noqa: BLE001
                    self._last_error = f"{type(e).__name__}: {e}"
                    logger.debug("[market-feed] connect failed: %s", self._last_error)
                    self._measure_broker(reader, provider, allow_no_public=True)
                    self._stop.wait(30.0)
                    continue
                self._measure_broker(reader, provider)
                self._stop.wait(max(15.0, provider._refresh_seconds))

        self._thread = threading.Thread(target=_run, name="panel-market-feed",
                                        daemon=True)
        self._thread.start()

    # ----------------------------------------------------- broker sample --
    def _measure_broker(self, reader, provider, allow_no_public: bool = False) -> None:
        """One broker tick sample + residual-basis update (never raises)."""
        if reader is None:
            return
        tick = reader.read()
        if tick is None:
            with self._lock:
                self._broker_tick = None
            return
        public_mid = None
        if not allow_no_public:
            try:
                public_mid = provider.get_tick("XAUUSD").last
            except Exception:  # noqa: BLE001 — public side may be down
                public_mid = None
        with self._lock:
            self._broker_tick = tick
            if public_mid:
                residual = float(tick["mid"]) - float(public_mid)
                self._basis_samples.append(residual)
                del self._basis_samples[:-60]          # keep last 60 samples
                if self._basis_ema is None:
                    self._basis_ema = residual
                else:
                    self._basis_ema += BASIS_EMA_ALPHA * (residual - self._basis_ema)
                self._basis_cycles += 1
                if self._basis_cycles % BASIS_PERSIST_EVERY == 0:
                    from app.data.mt5.tick_reader import persist_basis

                    persist_basis(self._basis_path, self._basis_ema, self._offset,
                                  len(self._basis_samples), tick.get("symbol"))

    def stop(self) -> None:
        self._stop.set()
        # v1.8: JOIN the feed thread (bounded) so a subsequent start() can
        # never observe a half-stopped thread. The old stop() only set the
        # event and returned immediately.
        t = self._thread
        if t is not None and t.is_alive():
            t.join(timeout=10.0)
        with self._lock:
            if self._provider is not None:
                try:
                    self._provider.disconnect()
                except Exception:
                    pass
            if self._reader is not None:
                try:
                    self._reader.shutdown()
                except Exception:
                    pass
            self._provider = None
            self._reader = None

    # ---------------------------------------------------------- snapshot --
    def _pick_price(self, snap: dict, tick: dict | None,
                    reader_available: bool = True) -> dict:
        """Broker-first price selection per price_source_mode."""
        broker_fresh = bool(tick) and (
            time.time() - float(tick.get("received_at", 0))) < BROKER_TICK_FRESH_S
        pub_price = snap.get("price")
        pub_bid, pub_ask = snap.get("bid"), snap.get("ask")
        if self._mode == "public":
            return {"price": pub_price, "bid": pub_bid, "ask": pub_ask,
                    "source": "public", "source_label": snap.get("source"),
                    "bid_ask_source": "public_assumed"}
        if broker_fresh:
            label = f"MT5 broker ({tick['symbol']})"
            if self._mode == "broker":
                return {"price": tick.get("mid"), "bid": tick.get("bid"),
                        "ask": tick.get("ask"), "source": "broker",
                        "source_label": label, "bid_ask_source": "broker"}
            # auto — broker wins when it has a real two-sided quote
            if tick.get("bid") and tick.get("ask"):
                return {"price": tick.get("mid"), "bid": tick.get("bid"),
                        "ask": tick.get("ask"), "source": "broker",
                        "source_label": label, "bid_ask_source": "broker"}
        if self._mode == "broker" and pub_price is None:
            return {"price": None, "bid": None, "ask": None,
                    "source": "broker_unavailable", "source_label": None,
                    "bid_ask_source": None}
        # reader present but tick stale/absent → honest fallback label;
        # no MT5 support on this machine at all → plain public source
        src = "public_fallback" if reader_available else "public"
        return {"price": pub_price, "bid": pub_bid, "ask": pub_ask,
                "source": src, "source_label": snap.get("source"),
                "bid_ask_source": "public_assumed"}

    def snapshot(self) -> dict:
        with self._lock:
            provider = self._provider
            reader = self._reader
            tick = dict(self._broker_tick) if self._broker_tick else None
            basis_ema = self._basis_ema
            n_samples = len(self._basis_samples)
        if provider is None:
            return {"ok": False, "error": self._last_error or "feed not initialized",
                    "available": False}
        try:
            snap = provider.snapshot()
            pub_tick = provider.get_tick("XAUUSD") if snap.get("price") else None
            if pub_tick is not None and snap.get("bid") is None:
                # provider snapshot lacks bid/ask — enrich from its tick
                snap["bid"], snap["ask"] = pub_tick.bid, pub_tick.ask
            spot = provider.spot_reference()
            sel = self._pick_price(snap, tick, reader_available=reader is not None)
            basis_info = None
            if reader is not None:
                basis_info = {
                    "mode": self._mode,
                    "offset": self._offset,
                    "residual_ema": round(basis_ema, 3) if basis_ema is not None else None,
                    "samples": n_samples,
                    "broker_available": tick is not None,
                    "broker_symbol": (tick or {}).get("symbol"),
                    "broker_age_seconds": reader.last_tick_age(),
                    "broker_error": reader.last_error or None,
                    "needs_recalibration": bool(
                        basis_ema is not None and abs(basis_ema) > 2.0),
                }
            # v1.8 fix (P4): market_open was FORCED to True for the broker and
            # public_fallback sources — the badge claimed an open market on
            # weekends. Honest evaluation now:
            #   * broker source → the broker tick's own EVENT time must be
            #     fresh (a terminal returns the last tick with a stale event
            #     time when the market is closed)
            #   * public/public_fallback → the public source's own honest
            #     market_open() evaluation (Yahoo freshness)
            market_open: bool | None = snap.get("market_open")
            if sel["source"] == "broker" and tick:
                tick_epoch = tick.get("tick_epoch") or 0
                if tick_epoch:
                    market_open = (time.time() - float(tick_epoch)) < 900.0
                # no event time available → leave the public evaluation as-is
                # (never claim OPEN without evidence)
            return {
                "ok": True,
                "available": True,
                "symbol": "XAUUSD",
                "remote_symbol": snap.get("remote_symbol"),
                "source": sel["source_label"],
                "price_source": sel["source"],
                "price": sel["price"],
                "bid": sel["bid"],
                "ask": sel["ask"],
                "public_price": snap.get("price"),
                # v1.8 (P7): does the shown bid/ask come from the broker or is
                # it mid ± assumed spread? The UI labels the assumption.
                "bid_ask_source": sel.get("bid_ask_source"),
                "spread_points": snap.get("spread_points"),
                "spread_is_assumed": True,
                "price_time_utc": snap.get("price_time_utc"),
                "market_open": market_open,
                "tick_age_seconds": snap.get("tick_age_seconds"),
                "spot": spot.get("price") if spot else snap.get("spot"),
                "spot_updated": spot.get("updated") if spot else None,
                "spot_source": spot.get("source") if spot else snap.get("spot_source"),
                "calibration": basis_info,
                "degraded": snap.get("degraded"),
                "error": snap.get("error") or self._last_error,
                "frames": snap.get("frames", {}),
                "feed_uptime_seconds": int(time.time() - self._started_at) if self._started_at else 0,
            }
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "available": False, "error": f"{type(e).__name__}: {e}"}

    def candles(self, timeframe: str = "M5", count: int = 300) -> dict:
        """Candle series for the panel chart (list, oldest→newest)."""
        with self._lock:
            provider = self._provider
        if provider is None:
            return {"ok": False, "error": "feed not initialized", "candles": []}
        try:
            df = provider.get_candles("XAUUSD", timeframe, int(count))
            out = [{"t": str(ts), "o": float(r.open), "h": float(r.high),
                    "l": float(r.low), "c": float(r.close)}
                   for ts, r in df.tail(int(count)).iterrows()]
            return {"ok": True, "timeframe": timeframe, "candles": out,
                    "source": provider.source_label,
                    "price_offset": provider.price_offset}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": f"{type(e).__name__}: {e}", "candles": []}

    # -------------------------------------------------------- calibrate --
    def measure_offset_now(self) -> dict:
        """Sample broker vs RAW public price once → recommended offset ($).

        Used by POST /api/market/calibrate. Honest result either way:
        ``ok=False`` carries the exact reason (no MT5, no public data...).
        """
        with self._lock:
            reader = self._reader
            provider = self._provider
        if provider is None:
            return {"ok": False, "reason": "feed not initialized"}
        if reader is None:
            return {"ok": False,
                    "reason": "MT5 broker tick not available on this machine "
                              "(terminal closed or MetaTrader5 package missing)"}
        tick = reader.read()
        if tick is None:
            return {"ok": False, "reason": f"broker tick failed: {reader.last_error}"}
        try:
            provider.connect()
            # RAW public mid = provider tick (with offset) − configured offset
            pub = provider.get_tick("XAUUSD").last
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "reason": f"public feed failed: {type(e).__name__}: {e}"}
        raw_public = float(pub) - self._offset
        if raw_public <= 0:
            return {"ok": False, "reason": "public feed returned no usable price"}
        offset = round(float(tick["mid"]) - raw_public, 2)
        return {
            "ok": True,
            "offset": offset,
            "broker_mid": tick["mid"],
            "broker_symbol": tick["symbol"],
            "raw_public_mid": round(raw_public, 2),
            "current_offset": self._offset,
            "note": "offset = broker_mid − raw COMEX mid; stored in "
                    "config.yaml as provider.public_price_offset",
        }

"""Parquet-based candle storage (with graceful fallback if pyarrow missing)."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from app.core.exceptions import StorageError


class ParquetStore:
    def __init__(self, base_dir: str | Path) -> None:
        self.base = Path(base_dir)
        self.base.mkdir(parents=True, exist_ok=True)

    def _path(self, symbol: str, timeframe: str) -> Path:
        safe = symbol.replace(".", "_").replace("#", "_")
        return self.base / f"{safe}_{timeframe}.parquet"

    def save(self, df: pd.DataFrame, symbol: str, timeframe: str) -> Path:
        path = self._path(symbol, timeframe)
        try:
            df.to_parquet(path)
        except Exception as e:  # pragma: no cover
            raise StorageError(f"Failed writing {path}: {e}") from e
        return path

    def load(self, symbol: str, timeframe: str) -> pd.DataFrame | None:
        path = self._path(symbol, timeframe)
        if not path.exists():
            return None
        try:
            df = pd.read_parquet(path)
            if not isinstance(df.index, pd.DatetimeIndex):
                df.index = pd.DatetimeIndex(df.index)
            if df.index.tz is None:
                df.index = df.index.tz_localize("UTC")
            return df
        except Exception as e:  # pragma: no cover
            raise StorageError(f"Failed reading {path}: {e}") from e

    def exists(self, symbol: str, timeframe: str) -> bool:
        return self._path(symbol, timeframe).exists()

"""v1.8 — SINGLE shared market-data provider builder.

FORENSIC FIX (user finding C-1): ``train.py`` hard-coded ``SimulatedProvider``
while its console output claimed "MT5 data", and ``walkforward.py``,
``optimize.py`` and ``backtest.py`` did the same — every default training /
validation / backtest run was silently synthetic while the deployed loop read
public data. All entry points now build the provider THROUGH THIS MODULE from
``cfg.provider.kind`` so the executed data source is the configured data
source, and every caller reports the provider that actually ran.

The builder is config-driven and explicit:
  kind=mt5       → MT5DataProvider (real broker; read-only by default)
  kind=public    → LivePublicProvider (real Yahoo COMEX GC=F proxy)
  kind=replay    → ReplayProvider (saved parquet history)
  kind=simulated → SimulatedProvider (SYNTHETIC — engineering only)

``explicit_simulated()`` is the only sanctioned way to force the synthetic
provider, and it stamps the instance (``provider.synthetic_forced = True``)
so logs/registries can never mistake it for real data.
"""

from __future__ import annotations

import logging

from app.config.schema import AppConfig

logger = logging.getLogger(__name__)


def build_data_provider(cfg: AppConfig, allow_live_execution: bool = False):
    """Build the CONFIGURED provider (same semantics as main.py's build_provider).

    ``allow_live_execution`` is deliberately default-False: no provider built
    here can send broker orders unless the caller explicitly opts in (the
    runtime loop never does; the demo script does, on a DEMO account).
    """
    if cfg.provider.kind == "public":
        from app.data.market.live_public import LivePublicProvider

        return LivePublicProvider(
            symbol=cfg.provider.public_symbol,
            refresh_seconds=cfg.provider.public_refresh_seconds,
            spread_points=cfg.provider.public_spread_points,
            timeout_seconds=cfg.provider.public_timeout_seconds,
            defaults=cfg.symbol.fallback_symbol_info,
            initial_balance=cfg.backtest.initial_balance,
            display_symbol=cfg.symbol.primary,
            price_offset=getattr(cfg.provider, "public_price_offset", 0.0),
        )
    if cfg.provider.kind == "replay":
        from app.data.market.models import SymbolInfo
        from app.data.market.replay import ReplayProvider

        # explicit config-declared fallback specs (documented assumption, §6)
        info = SymbolInfo(name=cfg.real_data.symbol,
                          **cfg.symbol.fallback_symbol_info.model_dump())
        return ReplayProvider.from_raw_dir(
            cfg.real_data.raw_dir, cfg.real_data.symbol, cfg.real_data.timeframes,
            symbol_info=info)
    if cfg.provider.kind == "mt5":
        from app.data.mt5.provider import MT5DataProvider

        return MT5DataProvider(
            login_env=cfg.mt5.login_env, password_env=cfg.mt5.password_env,
            server=cfg.mt5.server, terminal_path=cfg.mt5.terminal_path,
            server_utc_offset_hours=cfg.mt5.server_utc_offset_hours,
            timeout_seconds=cfg.mt5.timeout_seconds,
            retry_attempts=cfg.mt5.retry_attempts,
            retry_backoff_seconds=cfg.mt5.retry_backoff_seconds,
            # execution capability stays OFF at the provider level —
            # the runtime loop never sends broker orders; the demo script owns
            # the only gated order_send path.
            allow_live_execution=allow_live_execution,
            deviation_points=getattr(cfg.mt5, "deviation_points", None),
        )
    # kind == "simulated"
    from app.data.market.simulated import SimulatedProvider

    provider = SimulatedProvider(
        days=cfg.provider.simulated_days, seed=cfg.provider.simulated_seed,
        start_price=cfg.provider.simulated_start_price,
        annual_vol=cfg.provider.simulated_annual_vol,
        initial_balance=cfg.backtest.initial_balance,
    )
    logger.warning("provider.kind=simulated — SYNTHETIC data: results say "
                   "nothing about real-market performance")
    return provider


def explicit_simulated(cfg: AppConfig, days: int | None = None):
    """Force the SYNTHETIC provider (training/tests only).

    The returned instance is stamped ``synthetic_forced=True`` so that
    ``provider_data_source()`` always reports it as synthetic.
    """
    from app.data.market.simulated import SimulatedProvider

    provider = SimulatedProvider(
        days=days or cfg.provider.simulated_days,
        seed=cfg.provider.simulated_seed,
        start_price=cfg.provider.simulated_start_price,
        annual_vol=cfg.provider.simulated_annual_vol,
        initial_balance=cfg.backtest.initial_balance,
    )
    provider.synthetic_forced = True
    return provider


def provider_data_source(provider) -> dict:
    """Honest provenance descriptor for any provider instance.

    Used by train/backtest/walkforward reports and the model registry so a
    trained model can never be mistaken for real-data-trained again.
    """
    from app.data.market.simulated import SimulatedProvider
    from app.data.mt5.provider import MT5DataProvider

    forced = bool(getattr(provider, "synthetic_forced", False))
    if isinstance(provider, MT5DataProvider):
        return {"kind": "mt5", "name": "mt5", "real_market": True,
                "label": "MT5 broker (real broker data)"}
    if isinstance(provider, SimulatedProvider):
        return {"kind": "simulated", "name": "simulated", "real_market": False,
                "label": ("SIMULATED (synthetic random-walk"
                          + (", explicitly forced" if forced else "")
                          + ")")}
    cls = type(provider).__name__
    if cls == "LivePublicProvider":
        return {"kind": "public", "name": "public-live", "real_market": True,
                "label": (f"Yahoo Finance {getattr(provider, '_remote', 'GC=F')} "
                          "(COMEX futures proxy — NOT broker XAUUSD spot)")}
    if cls == "ReplayProvider":
        return {"kind": "replay", "name": "replay", "real_market": True,
                "label": "replayed stored dataset (parquet history)"}
    return {"kind": "unknown", "name": cls.lower(), "real_market": False,
            "label": cls}

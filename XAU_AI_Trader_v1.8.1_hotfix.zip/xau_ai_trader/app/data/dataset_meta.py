"""PHASE 65 (§4) — Dataset source metadata.

Every real dataset stored under ``data/raw`` carries a sidecar
``<name>.meta.json`` describing exactly where the data came from so that any
later backtest can state precisely which data it was evaluated on.

The metadata explicitly separates:
- REAL market data (broker MT5, public exchanges / data vendors)
- SYNTHETIC data (unit tests only — never valid for performance reporting)
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, Field


class DatasetMetadata(BaseModel):
    """Provenance record for one dataset file (parquet/csv)."""

    symbol: str
    timeframe: str                       # M1..D1
    source: str                          # mt5_broker | yahoo_finance | stooq | ...
    data_kind: str = "real"              # real | synthetic  (validated downstream)
    instrument: str = ""                 # e.g. XAUUSD spot, COMEX GC futures
    broker: str | None = None            # broker server name when source=mt5_broker
    timezone: str = "UTC"                # timezone of the stored index
    start: str | None = None
    end: str | None = None
    download_date: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    bar_count: int = 0
    spread_available: bool = False
    spread_units: str = "PRICE"          # PRICE | POINTS — explicit unit contract (v1.5)
    volume_kind: str = "none"            # none | tick | real | contract
    columns: list[str] = Field(default_factory=list)
    notes: str = ""
    extra: dict = Field(default_factory=dict)   # broker spec fields (digits, point, ...)

    @property
    def is_real(self) -> bool:
        return self.data_kind == "real"

    def filename(self) -> str:
        return f"{self.symbol}_{self.timeframe}.meta.json"


def save_metadata(meta: DatasetMetadata, data_file: Path) -> Path:
    sidecar = data_file.parent / f"{data_file.stem}.meta.json"
    sidecar.write_text(json.dumps(meta.model_dump(), indent=2), encoding="utf-8")
    return sidecar


def load_metadata(data_file: Path) -> DatasetMetadata:
    sidecar = data_file.parent / f"{data_file.stem}.meta.json"
    if not sidecar.exists():
        raise FileNotFoundError(
            f"metadata sidecar missing for {data_file.name} — a dataset without "
            "provenance metadata must never be used for validation (PHASE 65 §4)"
        )
    return DatasetMetadata(**json.loads(sidecar.read_text(encoding="utf-8")))


def enrich_with_range(meta: DatasetMetadata, index) -> DatasetMetadata:
    """Fill start/end/bar_count from the actual stored frame."""
    meta.bar_count = int(len(index))
    if len(index):
        meta.start = str(index[0])
        meta.end = str(index[-1])
    return meta

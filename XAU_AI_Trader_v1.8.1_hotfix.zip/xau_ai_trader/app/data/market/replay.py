"""PHASE 65 (§2) — Real Data Adapter (CSV / Parquet).

``ReplayProvider`` implements the standard ``MarketDataProvider`` interface on
top of *real* historical datasets stored under ``data/raw`` as parquet or CSV:

    timestamp, open, high, low, close, volume [, tick_volume, spread]

It is a READ-ONLY provider:
- ``get_candles`` returns the window of stored real bars up to ``end_time``
  (replay semantics — the pipeline can therefore run unmodified over history).
- execution methods raise a clear error: replayed data cannot be traded.

Synthetic datasets are refused: a sidecar ``<name>.meta.json`` must exist and
declare ``data_kind="real"`` (PHASE 65 §30/§31 — never pass fake data off as
real market data).
"""

from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

from app.config.schema import MT5_TF_CODE
from app.core import exceptions as exc
from app.data.dataset_meta import DatasetMetadata, load_metadata
from app.data.market.base import MarketDataProvider
from app.data.market.models import AccountInfo, OrderResult, Position, SymbolInfo, Tick

logger = logging.getLogger(__name__)

REQUIRED_COLUMNS = {"open", "high", "low", "close"}
TIMESTAMP_ALIASES = ("timestamp", "time", "date", "datetime")
VOLUME_ALIASES = ("volume", "vol", "tick_volume")


def load_price_file(path: Path) -> pd.DataFrame:
    """Load one real dataset file into the canonical provider frame format.

    Canonical frame (same contract as MT5DataProvider.get_candles):
        index: tz-aware UTC DatetimeIndex named 'time'
        columns: open, high, low, close, tick_volume, real_volume, spread
    """
    path = Path(path)
    if path.suffix.lower() in (".parquet", ".pq"):
        df = pd.read_parquet(path)
    elif path.suffix.lower() in (".csv", ".txt"):
        df = pd.read_csv(path)
    else:
        raise exc.DataError(f"unsupported dataset format: {path.name}")

    df.columns = [str(c).strip().lower() for c in df.columns]

    # --- timestamp column -------------------------------------------------
    ts_col = next((c for c in TIMESTAMP_ALIASES if c in df.columns), None)
    if ts_col is None and not isinstance(df.index, pd.DatetimeIndex):
        raise exc.DataError(
            f"{path.name}: no timestamp column ({TIMESTAMP_ALIASES}) and index is not DatetimeIndex"
        )
    if ts_col is not None:
        idx = pd.to_datetime(df[ts_col], utc=True, errors="coerce", format="mixed")
        if idx.isna().any():
            raise exc.DataError(f"{path.name}: {int(idx.isna().sum())} unparseable timestamps")
        df = df.drop(columns=[ts_col])
        df.index = pd.DatetimeIndex(idx, name="time")
    else:
        idx = pd.DatetimeIndex(pd.to_datetime(df.index, utc=True, format="mixed"), name="time")
        df.index = idx
    if df.index.tz is None:
        raise exc.DataError(f"{path.name}: timestamps are tz-naive — timezone must be declared (PHASE 65 §5)")

    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise exc.DataError(f"{path.name}: missing required columns {sorted(missing)}")

    # --- volume / spread columns -------------------------------------------
    if "real_volume" not in df.columns:
        vol_col = next((c for c in VOLUME_ALIASES if c in df.columns), None)
        df["real_volume"] = df[vol_col] if vol_col else 0.0
    if "tick_volume" not in df.columns:
        df["tick_volume"] = 0.0
    if "spread" not in df.columns:
        df["spread"] = 0.0            # absent → backtester must use assumed_spread

    out = df[["open", "high", "low", "close", "tick_volume", "real_volume", "spread"]].astype(float)
    out = out[~out.index.duplicated(keep="first")].sort_index()
    return out


class ReplayProvider(MarketDataProvider):
    """Read-only provider over real historical datasets (CSV/parquet)."""

    name = "replay"

    def __init__(
        self,
        files: dict[str, Path | str],
        symbol: str = "XAUUSD",
        symbol_info: SymbolInfo | None = None,
        source_label: str = "real_dataset",
    ) -> None:
        self._files = {tf: Path(p) for tf, p in files.items()}
        self._symbol = symbol
        self._frames: dict[str, pd.DataFrame] = {}
        self._meta: dict[str, DatasetMetadata] = {}
        self._connected = False
        self._info = symbol_info
        self.source_label = source_label
        for tf, path in self._files.items():
            frame = load_price_file(path)
            meta = load_metadata(path)
            if not meta.is_real:
                raise exc.DataError(
                    f"{path.name}: data_kind={meta.data_kind!r} — synthetic datasets are "
                    "refused by ReplayProvider (PHASE 65 §30)"
                )
            if meta.bar_count and abs(meta.bar_count - len(frame)) > max(10, meta.bar_count * 0.05):
                logger.warning("%s: metadata bar_count=%d vs file rows=%d",
                               path.name, meta.bar_count, len(frame))
            self._frames[tf] = frame
            self._meta[tf] = meta
            logger.info("replay loaded %s %s: %d real bars (%s → %s)",
                        meta.symbol, tf, len(frame), meta.start, meta.end)

    # ------------------------------------------------------------- factory --
    @classmethod
    def from_raw_dir(cls, raw_dir: Path | str, symbol: str, timeframes: list[str],
                     symbol_info: SymbolInfo | None = None) -> "ReplayProvider":
        raw_dir = Path(raw_dir)
        files: dict[str, Path] = {}
        for tf in timeframes:
            for ext in (".parquet", ".csv"):
                p = raw_dir / f"{symbol}_{tf}{ext}"
                if p.exists():
                    files[tf] = p
                    break
            else:
                raise FileNotFoundError(
                    f"data/raw has no {symbol}_{tf}.parquet/.csv — run "
                    "scripts/download_mt5_data.py (Windows/MT5) or scripts/fetch_public_data.py"
                )
        return cls(files, symbol=symbol, symbol_info=symbol_info)

    # ----------------------------------------------------------- interface --
    def connect(self) -> bool:
        self._connected = True
        return True

    def disconnect(self) -> None:
        self._connected = False

    def is_connected(self) -> bool:
        return self._connected

    @property
    def data_kind(self) -> str:
        return "real"

    @property
    def timeframes(self) -> list[str]:
        return sorted(self._frames)

    def discover_symbols(self, aliases: list[str]) -> list[SymbolInfo]:
        return [self.get_symbol_info(self._symbol)]

    def get_symbol_info(self, symbol: str) -> SymbolInfo:
        if self._info is not None:
            return self._info
        raise exc.SymbolNotFoundError(
            "replay provider has no broker SymbolInfo — broker specs (digits/point/"
            "tick value/lots) can only be read from MT5 (PHASE 65 §6). Configure "
            "symbol.fallback_symbol_info explicitly if you accept documented defaults."
        )

    def get_account_info(self) -> AccountInfo:
        raise exc.ProviderConnectionError(
            "replay provider has no account — account state in replay mode is "
            "maintained by the paper/backtest executors"
        )

    def get_candles(self, symbol: str, timeframe: str, count: int,
                    end_time: pd.Timestamp | None = None) -> pd.DataFrame:
        if timeframe not in self._frames:
            raise exc.DataError(
                f"replay has no {timeframe} dataset (available: {self.timeframes})"
            )
        df = self._frames[timeframe]
        if end_time is not None:
            end_time = pd.Timestamp(end_time)
            if end_time.tzinfo is None:
                end_time = end_time.tz_localize("UTC")
            df = df[df.index <= end_time]
        if df.empty:
            raise exc.DataError(f"no {timeframe} bars at or before {end_time}")
        window = df.tail(max(1, int(count)))
        if len(window) < count:
            logger.debug("replay %s: requested %d bars, only %d available",
                         timeframe, count, len(window))
        return window.copy()

    def get_tick(self, symbol: str) -> Tick:
        raise exc.DataError(
            "replay provider has no live tick — use get_candles(); live ticks require "
            "an MT5 terminal (Windows)"
        )

    # --------------------------------------------------- execution: refused --
    @property
    def supports_real_execution(self) -> bool:
        return False

    def get_open_positions(self, symbol=None, magic=None) -> list[Position]:
        return []

    def send_market_order(self, *a, **kw) -> OrderResult:
        raise exc.ExecutionError(
            "REPLAY_PROVIDER_READ_ONLY — historical real data cannot be traded; "
            "use PAPER mode with MT5 (Windows) for live paper trading"
        )

    def close_position(self, ticket: int) -> OrderResult:
        raise exc.ExecutionError("REPLAY_PROVIDER_READ_ONLY")

    def modify_position(self, ticket: int, sl: float, tp: float) -> OrderResult:
        raise exc.ExecutionError("REPLAY_PROVIDER_READ_ONLY")

    # -------------------------------------------------------------- helpers --
    def full_range(self, timeframe: str) -> pd.DataFrame:
        return self._frames[timeframe]

    def metadata(self, timeframe: str) -> DatasetMetadata:
        return self._meta[timeframe]

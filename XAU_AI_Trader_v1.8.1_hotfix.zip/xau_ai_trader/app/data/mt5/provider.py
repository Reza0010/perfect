"""PHASE 1 — Real MetaTrader 5 provider.

The ``MetaTrader5`` python package is Windows-only. This module guards the
import: on non-Windows systems (or when the package is missing) construction
raises a clear, actionable ProviderConnectionError instead of an import crash.

Full symbol metadata (tick size/value, contract size, lots, margins) and
account info are read from the terminal — nothing hard-coded.
"""

from __future__ import annotations

import logging
import platform
import time
from datetime import datetime, timezone

import pandas as pd

from app.config.schema import MT5_TF_CODE, _TF_MINUTES
from app.core import exceptions as exc
from app.data.market.base import MarketDataProvider
from app.data.market.models import AccountInfo, OrderResult, Position, SymbolInfo, Tick
from app.data.mt5.symbol_map import SymbolResolver
from app.execution import mt5_retcodes as rc

logger = logging.getLogger(__name__)


def _import_mt5():
    try:
        import MetaTrader5 as mt5  # type: ignore

        return mt5
    except Exception as e:  # pragma: no cover - depends on platform
        raise exc.ProviderConnectionError(
            "MetaTrader5 package is unavailable on this platform "
            f"(platform={platform.system()}). Install it on Windows with "
            "`pip install MetaTrader5`, or use provider.kind=simulated on Linux. "
            f"Original error: {e}"
        ) from e


class MT5DataProvider(MarketDataProvider):
    name = "mt5"

    def __init__(
        self,
        login_env: str = "MT5_LOGIN",
        password_env: str = "MT5_PASSWORD",
        server: str | None = None,
        terminal_path: str | None = None,
        server_utc_offset_hours: float = 0.0,
        timeout_seconds: int = 60,
        retry_attempts: int = 3,
        retry_backoff_seconds: float = 2.0,
        allow_live_execution: bool = False,
        deviation_points: int | None = None,
    ) -> None:
        self._login_env = login_env
        self._password_env = password_env
        self._server = server
        self._terminal_path = terminal_path
        self._utc_offset = server_utc_offset_hours
        self._timeout = timeout_seconds
        self._retries = retry_attempts
        self._backoff = retry_backoff_seconds
        self._mt5 = _import_mt5()
        self._resolver = SymbolResolver()
        self._connected = False
        self._symbol_cache: dict[str, SymbolInfo] = {}
        self._available: list[SymbolInfo] = []
        self._selected: set[str] = set()
        # v1.8.1 (hotfix F27): lazy connect / reconnect state. Previously
        # ``connect()`` was the ONLY place ``_available`` got populated, but
        # ``main.build_system()`` calls ``get_symbol_info()`` BEFORE the trading
        # system ever connects → guaranteed ``SymbolNotFoundError`` with an
        # empty available-list for provider.kind=mt5 (panel loop crash).
        self._last_connect_attempt: float | None = None
        self._last_connect_error: str = ""
        # one full retry cycle per cooldown window; never hammer the terminal
        self._reconnect_cooldown = max(30.0, self._backoff * (self._retries + 1))
        # v1.4 §12: real execution is a CAPABILITY, not a constant. The
        # provider only ever reports execution capability when the caller
        # (main.py) has explicitly wired the global live/demo-send policy.
        self._allow_live_execution = bool(allow_live_execution)
        self._deviation_points = deviation_points  # None => spread-aware

    # ---------------------------------------------------------- time base --
    def server_to_utc(self, ts: pd.Timestamp | datetime) -> pd.Timestamp:
        """Convert a broker-server-wall-clock timestamp to UTC.

        Contract (v1.5 data-correctness fix): server = UTC + offset, therefore
        utc = server - offset.  Single conversion point for candles, ticks and
        position times so no mixed timebases can exist between execution
        records and the candle timeline.
        """
        t = pd.Timestamp(ts)
        if t.tzinfo is None:
            t = t.tz_localize("UTC")
        return t - pd.Timedelta(hours=self._utc_offset)

    # ------------------------------------------------------------ session --
    def connect(self) -> bool:
        if self.is_connected():
            return True   # v1.8.1: idempotent fast-path
        mt5 = self._mt5
        kwargs = {"timeout": self._timeout * 1000}
        if self._terminal_path:
            kwargs["path"] = self._terminal_path
        import os

        login = os.environ.get(self._login_env)
        password = os.environ.get(self._password_env)
        if login and password and self._server:
            kwargs.update(login=int(login), password=password, server=self._server)
        self._last_connect_attempt = time.monotonic()
        for attempt in range(1, self._retries + 1):
            if mt5.initialize(**kwargs):
                self._connected = True
                self._last_connect_error = ""
                self._refresh_symbols()
                logger.info("MT5 connected (attempt %d)", attempt)
                return True
            err = mt5.last_error()
            self._last_connect_error = str(err)
            logger.warning("MT5 initialize failed (attempt %d): %s", attempt, err)
            if attempt < self._retries:
                time.sleep(self._backoff * attempt)
        raise exc.ProviderConnectionError(
            f"MT5 initialize failed after {self._retries} attempts: {mt5.last_error()} "
            f"— start the MT5 terminal (logged in) or switch provider.kind to "
            f"'public' in the panel Settings")

    def _ensure_connected(self) -> None:
        """v1.8.1 (hotfix F27): lazy connect with a bounded reconnect cadence.

        Called at the top of every data method so an unconnected provider is
        never asked for data it cannot have. When the terminal is unreachable
        this raises a CLEAR ProviderConnectionError (actionable message) —
        not a misleading ``SymbolNotFoundError ... Available: []``.
        """
        if self.is_connected():
            return
        now = time.monotonic()
        if self._last_connect_attempt is not None \
                and (now - self._last_connect_attempt) < self._reconnect_cooldown:
            raise exc.ProviderConnectionError(
                f"MT5 terminal not reachable (last error: "
                f"{self._last_connect_error or 'initialize failed'}). The loop "
                f"retries every ~{int(self._reconnect_cooldown)}s — start the "
                f"terminal / fix credentials, or switch provider.kind to "
                f"'public' in the panel Settings.")
        try:
            self.connect()
        except exc.ProviderConnectionError:
            raise

    def _ensure_selected(self, name: str) -> None:
        """Ensure a symbol is visible in Market Watch (idempotent, once per name).

        symbol_info()/symbol_info_tick()/copy_rates_*() only return data for
        symbols that have been selected in Market Watch; symbols_get() does not
        require selection. There is no wildcard select in the MT5 API — each
        symbol must be selected by exact name.
        """
        if name in self._selected:
            return
        if self._mt5.symbol_select(name, True):
            self._selected.add(name)
        else:
            logger.warning("symbol_select(%s) failed — symbol may be unavailable", name)

    def _refresh_symbols(self) -> None:
        mt5 = self._mt5
        infos = mt5.symbols_get()
        if infos:
            # NOTE: symbols_get() lists every server symbol without Market Watch
            # selection; selection is enforced lazily via _ensure_selected().
            # v1.5: tick_value provenance is tracked — a heuristic fallback
            # (contract_size*point) must fail-closed in LIVE risk paths.
            self._available = [
                SymbolInfo(
                    name=s.name,
                    digits=s.digits,
                    point=s.point,
                    tick_size=s.trade_tick_size or s.point,
                    tick_value=s.trade_tick_value or (s.trade_contract_size * s.point),
                    tick_value_is_fallback=not bool(s.trade_tick_value),
                    contract_size=s.trade_contract_size,
                    volume_min=s.volume_min,
                    volume_max=s.volume_max,
                    volume_step=s.volume_step,
                    spread_points=float(s.spread),
                    description=getattr(s, "description", "") or "",
                )
                for s in infos
                if any(k in s.name.upper() for k in ("XAU", "GOLD"))
            ]

    def disconnect(self) -> None:
        try:
            self._mt5.shutdown()
        finally:
            self._connected = False

    def is_connected(self) -> bool:
        return self._connected and self._mt5.terminal_info() is not None

    # ------------------------------------------------------------- symbols --
    def discover_symbols(self, aliases: list[str]) -> list[SymbolInfo]:
        return list(self._available)

    def resolve(self, symbol: str) -> str:
        self._ensure_connected()   # v1.8.1 (F27): data requires a live terminal
        if symbol in self._symbol_cache:
            return self._symbol_cache[symbol].name
        info = self._resolver.resolve(symbol, self._available)
        self._symbol_cache[info.name] = info
        return info.name

    def get_symbol_info(self, symbol: str) -> SymbolInfo:
        name = self.resolve(symbol)
        if name in self._symbol_cache:
            return self._symbol_cache[name]
        self._ensure_selected(name)
        s = self._mt5.symbol_info(name)
        if s is None:
            raise exc.SymbolNotFoundError(f"symbol_info({name}) returned None")
        info = SymbolInfo(
            name=s.name, digits=s.digits, point=s.point,
            tick_size=s.trade_tick_size or s.point,
            tick_value=s.trade_tick_value or s.trade_contract_size * s.point,
            tick_value_is_fallback=not bool(s.trade_tick_value),
            contract_size=s.trade_contract_size,
            volume_min=s.volume_min, volume_max=s.volume_max, volume_step=s.volume_step,
            spread_points=float(s.spread),
        )
        self._symbol_cache[name] = info
        return info

    # ------------------------------------------------------------ account ---
    def get_account_info(self) -> AccountInfo:
        a = self._mt5.account_info()
        if a is None:
            raise exc.ProviderConnectionError("MT5 account_info() returned None (disconnected?)")
        return AccountInfo(
            login=str(a.login), balance=a.balance, equity=a.equity, margin=a.margin,
            free_margin=a.margin_free, margin_level=a.margin_level,
            currency=a.currency, leverage=a.leverage,
        )

    # ------------------------------------------------------------- candles --
    def get_candles(self, symbol: str, timeframe: str, count: int,
                    end_time: pd.Timestamp | None = None) -> pd.DataFrame:
        """Return ``count`` CLOSED candles, newest-last, tz-aware UTC index.

        v1.5 data-correctness contract (Mission 3):
        * the current/forming bar is NEVER returned — a bar is only complete
          once ``bar_open + timeframe_duration <= cutoff``;
        * ``end_time`` is enforced: bars opening after (end_time - duration)
          are excluded, so callers can request a historical window and never
          silently receive a newer one;
        * ``count+8`` raw bars are requested so that after dropping the
          forming bar and any post-end_time bars the caller still receives
          the requested number of closed bars (best effort).
        """
        name = self.resolve(symbol)
        tf_code = MT5_TF_CODE[timeframe]
        self._ensure_selected(name)
        cutoff = pd.Timestamp(end_time) if end_time is not None else pd.Timestamp.now(tz="UTC")
        if cutoff.tzinfo is None:
            cutoff = cutoff.tz_localize("UTC")
        rows = None
        for attempt in range(3):
            rows = self._mt5.copy_rates_from_pos(name, tf_code, 0, int(count) + 8)
            if rows is not None and len(rows) > 0:
                break
            time.sleep(0.5 * (attempt + 1))
        if rows is None or len(rows) == 0:
            raise exc.DataError(f"MT5 copy_rates returned no data for {name} {timeframe}")
        df = pd.DataFrame(rows)
        df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
        df["time"] = self.server_to_utc(df["time"])
        df = df.set_index("time").rename(
            columns={"tick_volume": "tick_volume", "real_volume": "real_volume", "spread": "spread"}
        )
        df = df[["open", "high", "low", "close", "tick_volume", "real_volume", "spread"]].astype(float)
        df.index.name = "time"
        # --- closed-bar + end_time enforcement (single chokepoint) ---------
        duration = pd.Timedelta(minutes=_TF_MINUTES[timeframe])
        complete_cutoff = cutoff - duration  # a bar is complete when open+duration <= cutoff
        df = df[df.index <= complete_cutoff]
        if df.empty:
            raise exc.DataError(
                f"no CLOSED bars available for {name} {timeframe} "
                f"(cutoff={cutoff.isoformat()}, duration={duration})")
        if len(df) > count:
            df = df.iloc[-int(count):]
        return df

    def get_tick(self, symbol: str) -> Tick:
        name = self.resolve(symbol)
        self._ensure_selected(name)
        t = self._mt5.symbol_info_tick(name)
        if t is None:
            raise exc.DataError(f"symbol_info_tick({name}) returned None")
        return Tick(
            time=self.server_to_utc(datetime.fromtimestamp(t.time, tz=timezone.utc)).to_pydatetime(),
            bid=t.bid, ask=t.ask, last=t.last, volume=t.volume,
        )

    # ----------------------------------------------------------- positions --
    def get_open_positions(self, symbol: str | None = None, magic: int | None = None) -> list[Position]:
        poses = self._mt5.positions_get(symbol=self.resolve(symbol)) if symbol else self._mt5.positions_get()
        if poses is None:
            return []
        out = []
        for p in poses:
            if magic is not None and p.magic != magic:
                continue
            out.append(Position(
                ticket=p.ticket, symbol=p.symbol,
                side="BUY" if p.type == 0 else "SELL",
                volume=p.volume, open_price=p.price_open, sl=p.sl, tp=p.tp,
                open_time=self.server_to_utc(datetime.fromtimestamp(p.time, tz=timezone.utc)).to_pydatetime(),
                comment=p.comment, magic=p.magic, profit=p.profit, swap=p.swap,
            ))
        return out

    # ----------------------------------------------------------- execution --
    @property
    def supports_real_execution(self) -> bool:
        """v1.4 §12 — dynamic, fail-closed capability check.

        True only when ALL of the following hold:
          * running on Windows with the MetaTrader5 package (constructor),
          * the terminal is currently connected,
          * autotrading is enabled in the terminal,
          * the account allows expert trading,
          * the caller explicitly wired allow_live_execution=True (global
            live/demo-send policy — default False).

        Paper/demo safety never depends on this being False; the executor
        layer gates sends independently.
        """
        if not self._allow_live_execution:
            return False
        if not (self._connected and self.is_connected()):
            return False
        try:
            term = self._mt5.terminal_info()
            acc = self._mt5.account_info()
        except Exception:
            return False
        if term is None or acc is None:
            return False
        if not getattr(term, "trade_allowed", False):
            return False
        if not getattr(acc, "trade_expert", False):
            return False
        return True

    # -- broker-native math (v1.4 §14) -------------------------------------
    def order_calc_profit(self, side: str, symbol: str, volume: float,
                          price_open: float, price_close: float) -> float | None:
        """Broker-native profit/loss for a hypothetical close. None if the
        terminal cannot calculate (caller must WAIT, not approximate)."""
        name = self.resolve(symbol)
        order_type = rc.ORDER_TYPE_BUY if side.upper() == "BUY" else rc.ORDER_TYPE_SELL
        try:
            v = self._mt5.order_calc_profit(order_type, name, float(volume),
                                            float(price_open), float(price_close))
        except Exception:
            return None
        return None if v is None else float(v)

    def order_calc_margin(self, side: str, symbol: str, volume: float,
                          price: float) -> float | None:
        """Broker-native margin requirement. None if unavailable."""
        name = self.resolve(symbol)
        order_type = rc.ORDER_TYPE_BUY if side.upper() == "BUY" else rc.ORDER_TYPE_SELL
        try:
            v = self._mt5.order_calc_margin(order_type, name, float(volume),
                                            float(price))
        except Exception:
            return None
        return None if v is None else float(v)

    # -- request building (v1.4 §19) ----------------------------------------
    def _execution_filling(self, name: str) -> int:
        info = self._mt5.symbol_info(name)
        raw = int(getattr(info, "filling_mode", 0) or 0) if info else 0
        return rc.choose_filling_mode(raw)

    def _deviation(self, symbol: str) -> int:
        if self._deviation_points is not None:
            return int(self._deviation_points)
        # spread-aware fallback: 2x current spread, floor 10 points
        try:
            t = self._mt5.symbol_info_tick(self.resolve(symbol))
            info = self._mt5.symbol_info(self.resolve(symbol))
            if t and info and info.point > 0:
                spread_pts = (t.ask - t.bid) / info.point
                return max(10, int(2 * spread_pts))
        except Exception:
            pass
        return 20

    def _check_request(self, request: dict) -> None:
        """v1.4 §20 — mandatory mt5.order_check() gate before order_send.

        order_check OK does not guarantee execution; it catches structurally
        invalid requests (stops, volume, money, permissions) cheaply.
        """
        check = self._mt5.order_check(request)
        if check is None:
            raise exc.OrderRejectedError(
                f"order_check returned None: {self._mt5.last_error()}")
        policy = rc.classify(getattr(check, "retcode", None))
        if policy not in (rc.RetcodePolicy.SUCCESS, rc.RetcodePolicy.SUCCESS_PARTIAL):
            comment = getattr(check, "comment", "") or ""
            raise exc.OrderRejectedError(
                f"order_check rejected request: "
                f"{rc.describe(getattr(check, 'retcode', None))} "
                f"({policy.value}) {comment}".strip())

    def _send_with_policy(self, request: dict, label: str) -> "OrderResult":
        """order_send under the central retcode policy.

        RETRYABLE  -> refresh price & retry (bounded, deterministic backoff)
        AMBIGUOUS  -> raise AmbiguousOrderError — NEVER retried blindly;
                      reconciliation must run first (duplicate risk)
        FATAL      -> raise OrderRejectedError
        SUCCESS    -> return OrderResult
        """
        mt5 = self._mt5
        last_err = ""
        for attempt in range(3):
            result = mt5.order_send(request)
            if result is None:
                raise exc.AmbiguousOrderError(
                    f"{label}: order_send returned None — broker-side outcome "
                    f"UNKNOWN ({mt5.last_error()}). Reconcile before retrying.")
            policy = rc.classify(result.retcode)
            if policy in (rc.RetcodePolicy.SUCCESS, rc.RetcodePolicy.SUCCESS_PARTIAL):
                return OrderResult(
                    success=True, retcode=int(result.retcode),
                    ticket=int(result.order), price=float(result.price),
                    volume=float(getattr(result, "volume", 0.0) or 0.0),
                    comment=str(request.get("comment", "")))
            last_err = f"{rc.describe(result.retcode)} ({policy.value})"
            if policy is rc.RetcodePolicy.AMBIGUOUS:
                # v1.5 fix (Mission 2/16): ambiguous outcomes (TIMEOUT,
                # CONNECTION errors, unknown state) must NEVER be retried —
                # the first send may have reached the broker. Surface the
                # ambiguity so the executor blocks trading and reconciles.
                raise exc.AmbiguousOrderError(
                    f"{label}: ambiguous broker outcome {last_err} — "
                    f"reconciliation required before any retry")
            if policy is rc.RetcodePolicy.RETRYABLE:
                logger.warning("%s retryable failure (attempt %d): %s",
                               label, attempt + 1, last_err)
                time.sleep(0.5 * (attempt + 1))
                # refresh the price so requote/price-off retries are valid
                if "symbol" in request and request.get("action") == rc.TRADE_ACTION_DEAL:
                    t = mt5.symbol_info_tick(request["symbol"])
                    if t is not None:
                        request["price"] = float(t.ask if request["type"] == rc.ORDER_TYPE_BUY
                                                 else t.bid)
                    else:
                        # cannot refresh price on a retryable rejection:
                        # re-sending with a stale price is a blind send.
                        raise exc.AmbiguousOrderError(
                            f"{label}: retryable failure but tick unavailable "
                            f"to refresh price — outcome unknown")
                # v1.5 fix (Mission 17): re-run order_check against the
                # REFRESHED price/SL/TP — never 'old check + new price'.
                self._check_request(request)
                continue
            raise exc.OrderRejectedError(f"{label}: {last_err}")
        raise exc.OrderRejectedError(f"{label}: exhausted retries — {last_err}")

    def send_market_order(self, symbol: str, side: str, volume: float, sl: float, tp: float,
                          comment: str, magic: int) -> OrderResult:
        name = self.resolve(symbol)
        self._ensure_selected(name)
        info = self._mt5.symbol_info(name)
        tick = self._mt5.symbol_info_tick(name)
        if info is None or tick is None:
            raise exc.DataError(f"symbol_info/tick unavailable for {name}")
        is_buy = side.upper() == "BUY"
        price = float(tick.ask if is_buy else tick.bid)
        request = {
            "action": rc.TRADE_ACTION_DEAL,
            "symbol": name,
            "volume": float(volume),
            "type": rc.ORDER_TYPE_BUY if is_buy else rc.ORDER_TYPE_SELL,
            "price": price,
            "sl": float(sl) if sl else 0.0,
            "tp": float(tp) if tp else 0.0,
            "deviation": self._deviation(symbol),
            "magic": int(magic),
            "comment": (comment or "")[:31],
            "type_time": 0,  # ORDER_TIME_GTC
            "type_filling": self._execution_filling(name),
        }
        self._check_request(request)
        return self._send_with_policy(request, f"market {side} {name}")

    def close_position(self, ticket: int) -> OrderResult:
        poses = self._mt5.positions_get(ticket=ticket)
        if not poses:
            raise exc.ExecutionError(f"position {ticket} not found")
        p = poses[0]
        self._ensure_selected(p.symbol)
        is_buy = p.type == 0
        closing_type = rc.ORDER_TYPE_SELL if is_buy else rc.ORDER_TYPE_BUY
        tick = self._mt5.symbol_info_tick(p.symbol)
        if tick is None:
            raise exc.DataError(f"tick unavailable for {p.symbol}")
        price = float(tick.bid if is_buy else tick.ask)  # close BUY at bid
        request = {
            "action": rc.TRADE_ACTION_DEAL, "symbol": p.symbol,
            "volume": float(p.volume), "type": closing_type,
            "position": int(ticket), "price": price,
            "deviation": self._deviation(p.symbol), "magic": int(p.magic),
            "comment": "close", "type_time": 0,
            "type_filling": self._execution_filling(p.symbol),
        }
        self._check_request(request)
        return self._send_with_policy(request, f"close #{ticket}")

    def modify_position(self, ticket: int, sl: float, tp: float) -> OrderResult:
        poses = self._mt5.positions_get(ticket=ticket)
        if not poses:
            raise exc.ExecutionError(f"position {ticket} not found")
        p = poses[0]
        request = {"action": rc.TRADE_ACTION_SLTP, "position": int(ticket),
                   "symbol": p.symbol, "sl": float(sl), "tp": float(tp)}
        result = self._mt5.order_send(request)
        policy = rc.classify(getattr(result, "retcode", None)) if result else None
        if result is None or policy not in (rc.RetcodePolicy.SUCCESS,
                                            rc.RetcodePolicy.SUCCESS_PARTIAL):
            detail = rc.describe(getattr(result, "retcode", None))
            raise exc.ExecutionError(f"modify failed for {ticket}: {detail}")
        return OrderResult(success=True, retcode=int(result.retcode), ticket=ticket)

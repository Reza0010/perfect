"""v1.7.1 — Lightweight BROKER TICK READER for the control panel.

Purpose: the panel's live price must match what the user actually sees in
their broker terminal. This reader attaches to the *already running, already
logged-in* MT5 terminal (no credentials, no trading — read-only ticks) and
returns the broker's own bid/ask for XAUUSD (or any configured alias).

Design contracts:
  - NEVER raises: every failure returns ``None`` (feed falls back to the
    public source and labels it honestly).
  - Attaches with ``initialize()`` only — never logs in, never sends orders.
  - Alias resolution reuses :class:`SymbolResolver` (XAUUSDm, GOLD, ...);
    the first alias that yields a valid tick is cached.
  - Thread-safe: the market feed is the only caller, but we lock anyway.
  - On non-Windows / missing package: ``available()`` is False forever.
"""

from __future__ import annotations

import logging
import platform
import threading
import time
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

TICK_STALE_SECONDS = 120.0


def _import_mt5():
    try:
        import MetaTrader5 as mt5  # type: ignore

        return mt5
    except Exception as e:  # pragma: no cover — depends on platform
        logger.debug("MetaTrader5 unavailable (%s): %s", platform.system(), e)
        return None


class BrokerTickReader:
    """Read-only broker tick source attached to a running MT5 terminal."""

    name = "mt5-broker-tick"

    def __init__(self, aliases: list[str], timeout_ms: int = 5000) -> None:
        self._aliases = [a for a in (aliases or []) if a]
        self._timeout_ms = int(timeout_ms)
        self._mt5 = _import_mt5()
        self._lock = threading.Lock()
        self._inited = False
        self._symbol: str | None = None     # resolved working alias
        self._failed_symbols: set[str] = set()
        self._last_ok: float | None = None
        self._last_error = ""
        self._last_tick: dict | None = None

    # ------------------------------------------------------------ state --
    @property
    def available(self) -> bool:
        return self._mt5 is not None

    @property
    def resolved_symbol(self) -> str | None:
        with self._lock:
            return self._symbol

    @property
    def last_error(self) -> str:
        with self._lock:
            return self._last_error

    def last_tick_age(self) -> float | None:
        with self._lock:
            if self._last_ok is None:
                return None
            return time.time() - self._last_ok

    # ------------------------------------------------------------ read --
    def read(self) -> dict | None:
        """One broker tick sample → dict or None (never raises)."""
        if self._mt5 is None:
            return None
        with self._lock:
            try:
                return self._read_locked()
            except Exception as e:  # noqa: BLE001 — broker IPC is hostile
                self._last_error = f"{type(e).__name__}: {e}"
                logger.debug("[broker-tick] read failed: %s", self._last_error)
                # force a clean re-attach on the next attempt
                try:
                    self._mt5.shutdown()
                except Exception:  # noqa: BLE001
                    pass
                self._inited = False
                return None

    # ---------------------------------------------------------- helpers --
    def _read_locked(self) -> dict | None:
        mt5 = self._mt5
        if not self._inited:
            if not mt5.initialize(timeout=self._timeout_ms):
                self._last_error = f"initialize failed: {mt5.last_error()}"
                return None
            self._inited = True

        symbol = self._pick_symbol()
        if symbol is None:
            return None

        info = mt5.symbol_info_tick(symbol)
        if info is None or (not info.bid and not info.ask and not info.last):
            self._last_error = f"no tick for {symbol}: {mt5.last_error()}"
            return None

        # terminal tick time is in SERVER wall-clock; for freshness we only
        # compare against local receive time — no timezone math needed here.
        now = time.time()
        bid = float(info.bid or 0)
        ask = float(info.ask or 0)
        last = float(info.last or 0)
        if bid <= 0 and ask <= 0 and last > 0:
            bid = ask = last          # exchange-style tick: last only
        mid = (bid + ask) / 2.0 if (bid > 0 and ask > 0) else (bid or ask or last)
        if mid <= 0:
            self._last_error = f"degenerate tick for {symbol}"
            return None

        digits = 2
        try:
            si = mt5.symbol_info(symbol)
            if si is not None and getattr(si, "digits", None):
                digits = int(si.digits)
        except Exception:  # noqa: BLE001 — cosmetic only
            pass

        tick_time = getattr(info, "time", None)
        tick_epoch = int(tick_time) if tick_time else 0
        tick_utc = None
        if tick_time:
            try:
                tick_utc = datetime.fromtimestamp(int(tick_time), tz=timezone.utc) \
                    .isoformat(timespec="seconds")
            except (OverflowError, OSError, ValueError):
                tick_utc = None

        self._last_ok = now
        self._last_error = ""
        self._last_tick = {
            "symbol": symbol,
            "bid": round(bid, digits if digits <= 3 else 2),
            "ask": round(ask, digits if digits <= 3 else 2),
            "last": round(last, digits if digits <= 3 else 2),
            "mid": round(mid, digits if digits <= 3 else 2),
            "digits": digits,
            "time_utc": tick_utc,
            # v1.8: the tick's own EVENT epoch (terminal clock) — the market-feed
            # uses it to evaluate market_open honestly instead of forcing True
            "tick_epoch": tick_epoch,
            "received_at": now,
            "source": f"MT5 broker tick ({symbol})",
        }
        return dict(self._last_tick)

    def _pick_symbol(self) -> str | None:
        """First alias that has a valid symbol/tick in the terminal (cached)."""
        mt5 = self._mt5
        if self._symbol:
            return self._symbol
        for alias in self._aliases:
            if alias in self._failed_symbols:
                continue
            si = mt5.symbol_info(alias)
            if si is None:
                # try to unhide from Market Watch once
                if not mt5.symbol_select(alias, True):
                    self._failed_symbols.add(alias)
                    continue
                si = mt5.symbol_info(alias)
                if si is None:
                    self._failed_symbols.add(alias)
                    continue
            if getattr(si, "trade_mode", None) is not None and si.visible is False:
                mt5.symbol_select(alias, True)
            self._symbol = alias
            logger.info("[broker-tick] resolved broker symbol: %s", alias)
            return alias
        self._last_error = (
            f"none of the aliases {self._aliases} exist in the terminal "
            f"(tried {sorted(self._failed_symbols) or '—'})")
        return None

    # ---------------------------------------------------------- teardown --
    def shutdown(self) -> None:
        with self._lock:
            if self._mt5 is not None and self._inited:
                try:
                    self._mt5.shutdown()
                except Exception:  # noqa: BLE001
                    pass
                self._inited = False


def load_persisted_basis(path) -> dict | None:
    """Previous auto-measured basis (JSON) or None. Fresh < 24h only."""
    try:
        import json
        from pathlib import Path

        p = Path(path)
        if not p.exists():
            return None
        data = json.loads(p.read_text(encoding="utf-8"))
        updated = float(data.get("updated_epoch", 0) or 0)
        if time.time() - updated > 86400:
            return None
        return data
    except Exception:  # noqa: BLE001 — display-only helper
        return None


def persist_basis(path, residual_ema: float, offset: float, samples: int,
                  broker_symbol: str | None) -> None:
    """Persist the measured basis so the panel can show calibration history."""
    try:
        import json
        from pathlib import Path

        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({
            "residual_ema": round(float(residual_ema), 3),
            "offset_at_measure": round(float(offset), 2),
            "samples": int(samples),
            "broker_symbol": broker_symbol,
            "updated_epoch": time.time(),
            "updated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }, indent=2), encoding="utf-8")
    except Exception:  # noqa: BLE001 — never break the feed for a cache write
        logger.debug("basis persist failed", exc_info=True)

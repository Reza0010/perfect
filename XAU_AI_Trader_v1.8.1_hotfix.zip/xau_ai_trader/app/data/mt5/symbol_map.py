"""Symbol alias resolution / discovery.

Broker symbol names vary: XAUUSD, XAUUSDm, XAUUSD., GOLD, GOLDm ...
``resolve_symbol`` normalises the configured primary symbol to whatever the
attached provider actually offers, using normalisation + cached discovery.
"""

from __future__ import annotations

import re

from app.core.exceptions import SymbolNotFoundError
from app.data.market.models import SymbolInfo


def normalize_symbol(name: str) -> str:
    """Lowercase, strip broker suffixes/prefixes and separators."""
    s = name.strip().lower()
    s = re.sub(r"[^a-z]", "", s)  # drop dots, #, m-suffix handled next
    # common broker decorations: xauusdm, xauusda, goldm, xauusdpro ...
    s = re.sub(r"^(xauusd|gold)(m|a|c|pro|i|x|\.*)?$", r"\1", s)
    return s


class SymbolResolver:
    def __init__(self) -> None:
        self._cache: dict[str, str] = {}

    def resolve(self, requested: str, available: list[SymbolInfo]) -> SymbolInfo:
        key = normalize_symbol(requested)
        if key in self._cache:
            match_name = self._cache[key]
            for info in available:
                if info.name == match_name:
                    return info
        wanted = normalize_symbol(requested)
        for info in available:
            if normalize_symbol(info.name) == wanted:
                self._cache[key] = info.name
                return info
        raise SymbolNotFoundError(
            f"Symbol '{requested}' not found. Available: {[i.name for i in available]}"
        )

"""PHASE 66 (§2) — MT5 historical bulk provider with FULL broker provenance.

Windows-only (MetaTrader 5 package). Downloads XAUUSD M1/M5/M15/M30/H1/H4/D1
via ``copy_rates_range`` month-by-month (this also forces the terminal to
synchronise its history cache) and stores:

    data/raw/<SYMBOL>_<TF>.parquet          + <SYMBOL>_<TF>.meta.json sidecar

The metadata sidecar captures EVERY broker-specific field required by the
directive — broker name, server, account type, digits, point, tick size/value,
contract size, volume min/max/step, stops level, freeze level, spread info,
swap long/short, timezone, data start/end, bar count, download timestamp,
MT5 build, symbol description. Broker-specific values are NEVER silently
normalised — they are stored verbatim in ``DatasetMetadata.extra.broker_specs``.

On non-Windows hosts the constructor raises an honest, actionable error.
"""

from __future__ import annotations

import json
import logging
import platform
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

from app.config.schema import MT5_TF_CODE
from app.data.dataset_meta import DatasetMetadata, save_metadata as write_metadata

logger = logging.getLogger(__name__)

ALL_TIMEFRAMES = ["M1", "M5", "M15", "M30", "H1", "H4", "D1"]


def _require_windows_mt5() -> None:
    if platform.system() != "Windows":
        raise RuntimeError(
            "MT5HistoricalProvider requires Windows with a MetaTrader 5 terminal "
            f"(platform={platform.system()}). NOTHING is faked here. Run "
            "`scripts/download_mt5_data.py` on your Windows machine with MT5 "
            "installed; the produced parquet+meta files drop straight into "
            "data/raw/ and every Phase 66 pipeline accepts them.")


class MT5HistoricalProvider:
    """Bulk historical downloader + broker-spec capture (download only —
    read-only; it never sends orders)."""

    name = "mt5_historical"

    def __init__(self, server_utc_offset_hours: float = 0.0) -> None:
        _require_windows_mt5()
        import MetaTrader5 as mt5  # type: ignore

        self._mt5 = mt5
        self._utc_offset = server_utc_offset_hours

    # ------------------------------------------------------------- session --
    def connect(self, login: int | None = None, password: str | None = None,
                server: str | None = None, terminal_path: str | None = None,
                timeout_s: int = 60) -> None:
        kwargs: dict = {"timeout": timeout_s * 1000}
        if terminal_path:
            kwargs["path"] = terminal_path
        if login and password and server:
            kwargs.update(login=int(login), password=password, server=server)
        if not self._mt5.initialize(**kwargs):
            raise RuntimeError(f"MT5 initialize failed: {self._mt5.last_error()}")

    def disconnect(self) -> None:
        try:
            self._mt5.shutdown()
        except Exception:  # pragma: no cover
            pass

    # ---------------------------------------------------------- provenance --
    def capture_broker_provenance(self, symbol: str) -> dict:
        """Capture broker/terminal/account/symbol metadata — verbatim,
        never normalised (§2)."""
        mt5 = self._mt5
        term = mt5.terminal_info()
        acc = mt5.account_info()
        mt5.symbol_select(symbol, True)  # ensure visible in Market Watch (no symbols_select in MT5 API)
        sym = mt5.symbol_info(symbol)
        if sym is None:
            raise RuntimeError(f"symbol_info({symbol}) returned None — is the symbol "
                               "visible in Market Watch?")
        tick = mt5.symbol_info_tick(symbol)
        account_type = {0: "DEMO", 1: "CONTEST", 2: "REAL"}.get(
            getattr(acc, "trade_mode", None), "UNKNOWN")

        def _v(x):
            return x if x is not None else None

        return {
            "broker_name": _v(getattr(term, "company", None)),
            "broker_server": _v(getattr(acc, "server", None)),
            "account_type": account_type,
            "account_login": str(getattr(acc, "login", "")),
            "account_currency": _v(getattr(acc, "currency", None)),
            "account_leverage": _v(getattr(acc, "leverage", None)),
            "symbol": _v(sym.name),
            "symbol_description": _v(getattr(sym, "description", None)),
            "symbol_path": _v(getattr(sym, "path", None)),
            "digits": int(sym.digits),
            "point": float(sym.point),
            "tick_size": float(sym.trade_tick_size or sym.point),
            "tick_value": float(sym.trade_tick_value or 0.0),
            "contract_size": float(sym.trade_contract_size),
            "volume_min": float(sym.volume_min),
            "volume_max": float(sym.volume_max),
            "volume_step": float(sym.volume_step),
            "stops_level_points": int(sym.trade_stops_level),
            "freeze_level_points": int(sym.trade_freeze_level),
            "spread_points_current": int(sym.spread),
            "spread_mode": "floating (broker-reported point spread at download time)",
            "swap_long": float(sym.swap_long),
            "swap_short": float(sym.swap_short),
            "swap_3day": int(getattr(sym, "swap_rollover3days", -1)),
            "trading_mode": int(sym.trade_mode),
            "session_dealing": int(getattr(sym, "session_dealing", 0)),
            "timezone": (f"server time; converted to UTC by subtracting the "
                         f"OPERATOR-PROVIDED server_utc_offset_hours={self._utc_offset} "
                         f"(not measured here — use scripts/download_mt5_data.py "
                         f"for offset measurement); DST is NOT handled by a "
                         f"fixed offset and must be audited per broker"),
            "terminal_name": _v(getattr(term, "name", None)),
            "mt5_build": int(getattr(term, "build", 0)),
            "last_tick": {
                "time_epoch": int(tick.time) if tick else None,
                "bid": float(tick.bid) if tick else None,
                "ask": float(tick.ask) if tick else None,
                "last": float(tick.last) if tick else None,
            },
            "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        }

    # ------------------------------------------------------------ download --
    def _download_tf(self, symbol: str, timeframe: str, years_back: float,
                     chunk_months: int = 3) -> pd.DataFrame:
        """Download one timeframe via ranged requests in month chunks — the
        first call also triggers the terminal's history sync; we retry until
        the returned bar count stops growing."""
        mt5 = self._mt5
        tf_code = MT5_TF_CODE[timeframe]
        end = datetime.now(timezone.utc)
        start = end - timedelta(days=int(365.25 * years_back) + 10)
        # v1.5 fix (N3): copy_rates_range interprets bounds as SERVER wall
        # clock, not UTC. Convert the UTC bounds into server time so the most
        # recent `offset` hours of bars are not silently dropped when the
        # broker runs ahead of UTC (EET/EEST brokers).
        offset = timedelta(hours=self._utc_offset)

        frames: list[pd.DataFrame] = []
        cursor = start
        stable_rounds = 0
        prev_total = -1
        while cursor < end:
            chunk_end = min(cursor + timedelta(days=30 * chunk_months), end)
            rows = None
            for attempt in range(4):
                rows = mt5.copy_rates_range(symbol, tf_code,
                                            cursor + offset, chunk_end + offset)
                if rows is not None and len(rows) > 0:
                    break
                time.sleep(1.0 + attempt)  # allow terminal history sync
            if rows is not None and len(rows) > 0:
                frames.append(pd.DataFrame(rows))
            total = sum(len(f) for f in frames)
            if total == prev_total:
                stable_rounds += 1
                if stable_rounds >= 2 and cursor > end - timedelta(days=45):
                    break
            else:
                stable_rounds = 0
                prev_total = total
            cursor = chunk_end

        if not frames:
            raise RuntimeError(f"no data returned for {symbol} {timeframe} — "
                               "open a chart for this symbol/TF in the terminal first, "
                               "then retry (MT5 syncs history on demand)")
        df = pd.concat(frames).drop_duplicates(subset="time").sort_values("time")
        df["time"] = pd.to_datetime(df["time"], unit="s", utc=True) - pd.Timedelta(hours=self._utc_offset)
        df = df.set_index("time")
        df = df[["open", "high", "low", "close", "tick_volume", "real_volume", "spread"]]
        df = df[~df.index.duplicated(keep="last")].sort_index()
        df.index.name = "time"
        return df.astype(float)

    def download_all(self, symbol: str, out_dir: str | Path = "data/raw",
                     timeframes: list[str] | None = None, years_back: float = 3.0) -> dict:
        """Download all requested timeframes + write parquet + metadata sidecar."""
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        specs = self.capture_broker_provenance(symbol)
        results: dict[str, dict] = {}
        for tf in (timeframes or ALL_TIMEFRAMES):
            df = self._download_tf(symbol, tf, years_back)
            parquet_path = out_dir / f"{symbol}_{tf}.parquet"
            df.to_parquet(parquet_path)
            meta = DatasetMetadata(
                symbol=symbol, timeframe=tf, source="MetaTrader5 (broker terminal)",
                data_kind="REAL_BROKER", instrument=specs.get("symbol_description") or symbol,
                broker=specs.get("broker_name") or "unknown-broker",
                timezone=specs.get("timezone") or "server-time",
                start=str(df.index[0]), end=str(df.index[-1]),
                download_date=datetime.now(timezone.utc).isoformat(),
                bar_count=int(len(df)),
                spread_available=bool((df["spread"] > 0).any()),
                volume_kind="tick_volume (broker); real_volume if broker provides it",
                columns=list(df.columns),
                spread_units="POINTS",
                notes=("Downloaded by MT5HistoricalProvider (PHASE 66 §2). Broker specs "
                       "stored verbatim in extra.broker_specs — never normalised. "
                       "spread column is in BROKER POINTS (multiply by point for price)."),
                extra={"broker_specs": specs},
            )
            write_metadata(parquet_path, meta)
            results[tf] = {"bars": int(len(df)), "start": str(df.index[0]),
                           "end": str(df.index[-1]), "path": str(parquet_path)}
            logger.info("downloaded %s %s: %d bars", symbol, tf, len(df))
        return {"symbol": symbol, "broker_specs": specs, "timeframes": results}

    # ------------------------------------------------- demo-account safety --
    @staticmethod
    def ensure_demo_account(account_info) -> None:
        """Refuse to proceed on a live account (§20). account_info is the raw
        MT5 namedtuple; trade_mode 0 == DEMO."""
        mode = getattr(account_info, "trade_mode", None)
        if mode != 0:
            raise PermissionError(
                f"REFUSED: account is not DEMO (trade_mode={mode}). "
                "DEMO ONLY safety gate — set up a demo account. There is NO "
                "automatic path to live trading (LIVE_TRADING_ENABLED=false).")

"""PHASE 6/10 — Gaussian HMM regime model (v1.5: real filtering posterior).

Fixes applied in v1.5 (audit findings 6/7/N2/N7):
- ``_posterior`` now returns the true observation-dependent filtering
  posterior (hmmlearn ``predict_proba`` = forward-backward). The old
  implementation tiled the *stationary distribution* — a constant
  independent of the data — so "confidence" was meaningless.
- RSI is NORMALIZED to [0,1] (``rsi/100``) before entering the model via
  :func:`hmm_feature_matrix`; the old path fed 0..100 into a clip([-10,10])
  which collapsed ~98% of values to the constant 10.
- The exact training columns are stored with the model and sliced at
  inference; previously the pipeline passed the full ~90-column feature
  matrix into a 3-feature model, the resulting broadcast error was
  swallowed at DEBUG level and the HMM was silently dead forever.
- ``predict``/``predict_last`` surface errors instead of hiding them
  (fail-closed), and state mapping is deterministic.

Parameters are persisted as .npz (no pickle → no unsafe deserialization).
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from app.config.schema import HMMConfig
from app.core.exceptions import ModelNotTrainedError

# Single source of truth for the HMM state-feature contract. Column names
# refer to the feature-builder frame; the transform for each column is
# implemented in :func:`hmm_feature_matrix`.
STATE_FEATURES = ["log_return", "atr_pct", "rsi"]


def hmm_feature_matrix(features_df) -> np.ndarray:
    """Build the HMM input matrix from the shared feature frame.

    v1.5: ONE helper used by BOTH training (train_service) and inference
    (pipeline) so the two can never drift apart again. Transforms:
    - log_return  → as-is (winsorised to ±10σ-equivalent bounds)
    - atr_pct     → as-is
    - rsi         → (rsi - 50) / 50 ∈ [-1, 1]  (was 0..100 raw!)
    NaN/inf are replaced with 0 AFTER normalization (0 = neutral for all
    three features), then per-feature bounds are applied.
    """
    import pandas as pd

    if not isinstance(features_df, pd.DataFrame):
        features_df = pd.DataFrame(features_df)
    missing = [c for c in STATE_FEATURES if c not in features_df.columns]
    if missing:
        raise ModelNotTrainedError(
            f"HMM feature matrix missing columns {missing} — "
            f"the feature frame must contain {STATE_FEATURES}")
    cols = np.column_stack([
        features_df["log_return"].astype(float).values,
        features_df["atr_pct"].astype(float).values,
        (features_df["rsi"].astype(float).values - 50.0) / 50.0,
    ])
    cols = np.nan_to_num(cols, nan=0.0, posinf=0.0, neginf=0.0)
    return np.clip(cols, -10.0, 10.0)


class HMMRegimeModel:
    name = "hmm"

    def __init__(self, cfg: HMMConfig | None = None) -> None:
        self.cfg = cfg or HMMConfig()
        self.model = None
        self.state_map: dict[int, str] = {}

    def _make(self):
        from hmmlearn.hmm import GaussianHMM

        return GaussianHMM(
            n_components=self.cfg.n_states,
            covariance_type="full",
            n_iter=self.cfg.n_iter,
            random_state=self.cfg.random_state,
        )

    def _prepare(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
        return np.clip(X, -10, 10)

    def fit(self, features: np.ndarray) -> None:
        X = self._prepare(features)
        if len(X) < self.cfg.min_bars_to_train:
            raise ModelNotTrainedError(f"HMM needs >= {self.cfg.min_bars_to_train} rows, got {len(X)}")
        model = self._make()
        model.fit(X)
        self.model = model
        self._map_states(X)

    def _map_states(self, X: np.ndarray) -> None:
        states = self.model.predict(X)
        means = np.array([X[states == s][:, 0].mean() if (states == s).any() else 0.0
                          for s in range(self.cfg.n_states)])
        vols = np.array([X[states == s][:, 1].mean() if (states == s).any() else 0.0
                         for s in range(self.cfg.n_states)])
        order = np.argsort(means)  # low → high return states
        self.state_map = {}
        n = self.cfg.n_states
        for rank, s in enumerate(order):
            if rank == n - 1:
                self.state_map[int(s)] = "TRENDING_BULL"
            elif rank == 0 and n >= 3:
                self.state_map[int(s)] = "TRENDING_BEAR"
            else:
                self.state_map[int(s)] = "HIGH_VOLATILITY" if vols[s] >= np.median(vols) else "RANGING"

    def predict(self, features: np.ndarray) -> tuple[np.ndarray, list[str]]:
        if self.model is None:
            raise ModelNotTrainedError("HMM model is not trained/loaded")
        X = self._prepare(features)
        states = self.model.predict(X)
        # v1.5: true filtering posterior — observation-dependent, NOT the
        # stationary distribution (which is a constant w.r.t. the data).
        probs = self._posterior(X)
        labels = [self.state_map.get(int(s), "UNCERTAIN") for s in states]
        conf = probs.max(axis=1)
        return conf, labels

    def predict_last(self, features: np.ndarray) -> tuple[str, float]:
        if self.model is None:
            raise ModelNotTrainedError("HMM model is not trained/loaded")
        # v1.5: the decision for "now" must use the posterior of the LAST
        # observation. A 30-row mean of posteriors averages away the very
        # information the filter just extracted.
        X = self._prepare(features[-1:])
        probs = self._posterior(X)
        s = int(probs[-1].argmax())
        label = self.state_map.get(s, "UNCERTAIN")
        return label, float(probs[-1, s])

    def _posterior(self, X: np.ndarray) -> np.ndarray:
        """Filtering/smoothing posterior via hmmlearn's forward-backward."""
        # predict_proba(X)[i] = P(state_i | full observation sequence X)
        # (hmmlearn 0.2+ implements forward-backward smoothing here.)
        return np.asarray(self.model.predict_proba(X), dtype=float)

    def _stationary(self) -> np.ndarray:
        transmat = self.model.transmat_
        vals, vecs = np.linalg.eig(transmat.T)
        stationary = np.real(vecs[:, np.argmax(vals)])
        stationary = np.abs(stationary)
        return stationary / stationary.sum()

    def save(self, directory: str | Path) -> None:
        if self.model is None:
            raise ModelNotTrainedError("nothing to save — HMM not trained")
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            directory / "hmm_params.npz",
            means=self.model.means_,
            covars=self.model.covars_,
            transmat=self.model.transmat_,
            startprob=self.model.startprob_,
            state_map=np.array([f"{k}:{v}" for k, v in self.state_map.items()]),
            n_states=np.array(self.cfg.n_states),
            state_features=np.array(",".join(STATE_FEATURES)),
        )

    def load(self, directory: str | Path) -> None:
        data = np.load(Path(directory) / "hmm_params.npz", allow_pickle=False)
        model = self._make()
        model.means_ = data["means"]
        model.covars_ = data["covars"]
        model.transmat_ = data["transmat"]
        model.startprob_ = data["startprob"]
        model.n_features_in_ = model.means_.shape[1]
        self.model = model
        self.state_map = {int(k.split(":")[0]): k.split(":", 1)[1] for k in data["state_map"].tolist()}

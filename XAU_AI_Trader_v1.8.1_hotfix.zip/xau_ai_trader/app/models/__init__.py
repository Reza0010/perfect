"""Sub-package placeholders for optional advanced ML (PHASE 53/54).

Status per PHASE 61 (NO FAKE FEATURES): these are **Not implemented**.
CatBoost / LSTM / Transformer stacking and RL (PPO/SAC) are deliberate
non-features until the base system is validated out-of-sample. The layout is
reserved so future modules slot in without restructuring.
"""

"""PHASE 38 — Model Registry: versioned metadata for every trained model.

v1.8 forensic upgrades:
- ``register`` PRESERVES superseded history (``superseded_versions``) —
  previously the previous entry was silently overwritten in place, so a bad
  retrain erased the audit trail of what was deployed before.
- paths are stored RELATIVE to the registry root (absolute checkout paths
  went stale the moment the project moved).
- ``deployment_readiness`` — a load-time quality gate. It exposes (not
  hides) one-sided models, below-chance models and models trained on
  synthetic data, exactly as the forensic audit required.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from app.core.exceptions import ModelError

logger = logging.getLogger(__name__)

REGISTRY_FILE = "registry.json"
MAX_SUPERSEDED = 5          # bounded history per model_id


class ModelRegistry:
    def __init__(self, base_dir: str | Path) -> None:
        self.base = Path(base_dir)
        self.base.mkdir(parents=True, exist_ok=True)
        self.index_path = self.base / REGISTRY_FILE
        if self.index_path.exists():
            self.index = json.loads(self.index_path.read_text(encoding="utf-8"))
        else:
            self.index = {}

    def _persist(self) -> None:
        self.index_path.write_text(json.dumps(self.index, indent=2), encoding="utf-8")

    def register(
        self,
        model_id: str,
        algo: str,
        directory: str | Path,
        params: dict,
        metrics: dict,
        dataset_version: str = "",
        feature_version: str = "",
        extra: dict | None = None,
    ) -> dict:
        # v1.8: store the path RELATIVE to the registry root so the entry
        # survives project moves (absolute paths were stale provenance).
        try:
            rel = str(Path(directory).resolve().relative_to(self.base.resolve()))
        except (ValueError, OSError):
            rel = str(directory)

        entry = {
            "model_id": model_id,
            "algo": algo,
            "version": 1,
            "training_date": datetime.now(timezone.utc).isoformat(),
            "dataset_version": dataset_version,
            "feature_version": feature_version,
            "parameters": params,
            "metrics": metrics,
            "path": rel,
            "extra": extra or {},
        }
        prev = self.index.get(model_id)
        if prev:
            entry["version"] = prev.get("version", 1) + 1
            # v1.8: keep the superseded entry's metadata (bounded) — the old
            # in-place overwrite destroyed the audit trail.
            history = list(prev.get("superseded_versions") or [])
            history.append({k: prev.get(k) for k in
                            ("version", "training_date", "metrics", "extra")})
            entry["superseded_versions"] = history[-MAX_SUPERSEDED:]
        self.index[model_id] = entry
        self._persist()
        return entry

    def get(self, model_id: str) -> dict:
        if model_id not in self.index:
            raise ModelError(f"model_id '{model_id}' not found in registry")
        return self.index[model_id]

    def latest(self, algo_prefix: str | None = None) -> dict | None:
        candidates = [e for e in self.index.values()
                      if algo_prefix is None or e["algo"].startswith(algo_prefix)]
        if not candidates:
            return None
        return max(candidates, key=lambda e: e["training_date"])

    def list(self) -> list[dict]:
        return list(self.index.values())

    # ------------------------------------------------------ readiness gate --
    @staticmethod
    def deployment_readiness(entry: dict) -> dict:
        """Honest load-time assessment of a registry entry.

        Returns ``{ready, warnings, data_source}``. This gate NEVER fabricates
        trust: it surfaces one-sided classifiers, below-chance models,
        synthetic-data provenance and missing metadata as explicit warnings
        so the trader/UI can label the deployed model as NOT validated.

        Checks (each independent, all reported):
        - provenance: ``extra.data_source`` present? synthetic?
        - one-sidedness: any actionable class recall < 5% while another > 90%
        - below chance: roc_auc_ovr < 0.50 on the test set
        - degenerate classes: a class with zero support never predicted
        """
        warnings: list[str] = []
        extra = entry.get("extra") or {}
        metrics = entry.get("metrics") or {}
        data_source = extra.get("data_source") or {}

        # --- provenance ---------------------------------------------------
        if not data_source or not data_source.get("kind"):
            warnings.append("NO_DATA_SOURCE_PROVENANCE: registry entry does not "
                            "record what data the model was trained on")
        elif data_source.get("kind") == "simulated":
            warnings.append("SYNTHETIC_DATA_MODEL: trained on simulated data — "
                            "says nothing about real-market performance")
        if not extra.get("windows"):
            warnings.append("NO_TRAINING_WINDOW: train/val/test date ranges not "
                            "recorded (cannot verify recency)")

        # --- one-sided classifier ------------------------------------------
        recalls = {cls: metrics.get(f"recall_{cls}")
                   for cls in ("SELL", "NO_EDGE", "BUY")}
        action = {k: v for k, v in recalls.items()
                  if isinstance(v, (int, float))}
        if len(action) >= 2:
            vals = sorted(action.values())
            if vals[-1] > 0.90 and vals[0] < 0.05:
                warnings.append(
                    f"ONE_SIDED_MODEL: class recalls {action} — the model "
                    "effectively predicts a single class; NO_EDGE/counter-"
                    "direction are never recognized")

        # --- below chance -----------------------------------------------------
        auc = metrics.get("roc_auc_ovr")
        if isinstance(auc, (int, float)) and auc < 0.50:
            warnings.append(
                f"BELOW_CHANCE_MODEL: test ROC-AUC {auc:.3f} < 0.50 — worse "
                "than a random baseline; not deployable on this evidence")

        # --- degenerate support ------------------------------------------------
        support = metrics.get("class_support") or {}
        if isinstance(support, dict) and support:
            total = sum(v for v in support.values() if isinstance(v, (int, float)))
            if total and all((v / total) < 0.02 or not isinstance(v, (int, float))
                             for v in support.values()):
                warnings.append("DEGENERATE_CLASS_SUPPORT: some classes have "
                                "almost no samples in the test set")

        return {"ready": not warnings,
                "warnings": warnings,
                "data_source": data_source,
                "model_id": entry.get("model_id", ""),
                "version": entry.get("version")}

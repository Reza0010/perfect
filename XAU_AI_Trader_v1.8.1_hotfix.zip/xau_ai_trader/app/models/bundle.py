"""Model bundle: everything needed for inference, loaded from the registry."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from app.core.exceptions import ModelNotTrainedError
from app.models.calibration import ProbabilityCalibrator
from app.models.lgbm_model import LGBMModel
from app.models.xgb_model import XGBModel


@dataclass
class ModelBundle:
    lgbm: LGBMModel | None = None
    xgb: XGBModel | None = None
    lgbm_calibrator: ProbabilityCalibrator | None = None
    xgb_calibrator: ProbabilityCalibrator | None = None
    scaler_state: dict = field(default_factory=dict)
    feature_names: list[str] = field(default_factory=list)
    feature_version: str = ""
    dataset_version: str = ""
    model_ids: dict = field(default_factory=dict)
    # v1.8: honest deployment-readiness labels (populated by load_bundle).
    # Non-empty deployment_warnings ⇒ the models ARE loaded and paper trading
    # continues, but they are NOT validated for real-money use and the UI /
    # state.json must say so.
    deployment_warnings: list[str] = field(default_factory=list)
    model_metadata: dict = field(default_factory=dict)

    @property
    def validated_for_deployment(self) -> bool:
        return not self.deployment_warnings

    def _prepare(self, X: pd.DataFrame) -> pd.DataFrame:
        missing = set(self.feature_names) - set(X.columns)
        if missing:
            # v1.5: a missing-feature case is a data/validation error, not a
            # "model not trained" error (N12) — surface the correct contract.
            from app.core.exceptions import DataError
            raise DataError(f"feature matrix missing columns: {sorted(missing)[:5]}…")
        X = X[self.feature_names]
        if self.feature_names and self.scaler_state.get("kind", "none") == "none" \
                and self.scaler_state.get("_required", False):
            # v1.5 (N12): a model trained on scaled inputs that loads WITHOUT
            # its scaler state would silently apply no scaling — distribution
            # shift by construction. scaler.json absence is refused at load
            # time in load_bundle; this guard catches hand-built bundles.
            raise DataError("model was trained with a scaler but bundle has no scaler state")
        if self.scaler_state.get("kind", "none") != "none":
            center = np.asarray(self.scaler_state["center"])
            scale = np.asarray(self.scaler_state["scale"])
            scale = np.where(scale == 0, 1.0, scale)
            X = pd.DataFrame((X.values - center) / scale, index=X.index, columns=X.columns)
        return X

    def predict(self, X: pd.DataFrame) -> dict:
        """Returns calibrated probabilities per model: {'lgbm': (n,3), 'xgb': (n,3)}."""
        Xp = self._prepare(X)
        out: dict = {}
        if self.lgbm is not None:
            raw = self.lgbm.predict_proba(Xp)
            out["lgbm"] = self.lgbm_calibrator.transform(raw) if self.lgbm_calibrator else raw
        if self.xgb is not None:
            raw = self.xgb.predict_proba(Xp)
            out["xgb"] = self.xgb_calibrator.transform(raw) if self.xgb_calibrator else raw
        if not out:
            raise ModelNotTrainedError("ModelBundle has no models loaded")
        return out

    def average_proba(self, X: pd.DataFrame) -> np.ndarray:
        preds = list(self.predict(X).values())
        return np.mean(preds, axis=0)

"""PHASE 7 — Triple Barrier labeling (v1.5: executable-fill semantics,
v1.8: SYMMETRIC long/short geometry).

Contract (Mission 6 + v1.8 forensic fix):
- signal time = t, execution time = t+1 open
- BUY  entry = open_{t+1} + spread/2 + slippage   (ask side, adverse)
- SELL entry = open_{t+1} - spread/2 - slippage   (bid side, adverse)
- barriers are built FROM the executable entry, not from close[t]
- barrier touches are evaluated on executable-side marks exactly like the
  backtest engine: a LONG exits at the bid (``mid - spread/2``), a SHORT
  exits at the ask (``mid + spread/2``)

v1.8 SYMMETRIC LABELS — root-cause fix for the degenerate SELL-majority
models. The pre-v1.8 code evaluated ONLY the long geometry: SELL was
assigned whenever the LONG trade's stop (1×ATR below the long entry) was hit
before the long TP (2×ATR above). A −1 ATR move therefore produced SELL,
while BUY required a +2 ATR move — SELL was systematically ~2× easier to
earn, which (together with drift) is exactly the asymmetry visible in the
registry (``lgbm_main``: recall_SELL 0.996 vs recall_BUY 0.005) and does
NOT match the trade engine, which manages shorts symmetrically. Both
directions are now evaluated with identical barrier multiples:

    BUY  ⇔ long TP (+tp_mult×ATR) hit strictly before long SL (−sl_mult×ATR)
    SELL ⇔ short TP (−tp_mult×ATR) hit strictly before short SL (+sl_mult×ATR)

A bar where BOTH directions fire (whipsaw both ways) or where a direction's
TP and SL are hit on the same bar (order unknowable without tick history —
documented limitation) cannot be attributed to a side → NO_EDGE, NOT the
opposite side. The ``ambiguous`` parameter is kept for API compatibility;
both of its modes now resolve ties to "direction unconfirmed".

- the final ``horizon`` bars have no full future window → label = NaN,
  ``valid_label = False``; a real NO_EDGE is ``label == 0`` with
  ``valid_label == True`` (first-class class, never conflated with
  "no future data")

All cost parameters are explicit PRICE units (never points) to keep the
system-wide unit contract unambiguous (Mission 19).

Labels touch the future BY DESIGN — they are merged to features at time t and
never used as inputs; purged CV + embargo prevent train/test contamination.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

CLASS_LABELS = {0: "SELL", 1: "NO_EDGE", 2: "BUY"}  # y_enc = y_raw + 1


def _first_hit(hit: np.ndarray) -> int:
    return int(np.argmax(hit)) if hit.any() else 10 ** 9


def triple_barrier_labels(
    df: pd.DataFrame,
    horizon: int = 48,
    tp_atr_mult: float = 2.0,
    sl_atr_mult: float = 1.0,
    atr_col: str = "atr",
    ambiguous: str = "zero",
    spread_price: float = 0.0,
    slippage_price: float = 0.0,
    commission_price: float = 0.0,
) -> pd.Series:
    """SYMMETRIC triple-barrier labels anchored on executable entry prices.

    Returns a float Series where invalid rows (tail without a full future
    horizon, or non-positive/NaN ATR) are **NaN** — use :func:`label_validity`
    to obtain the companion ``valid_label`` mask. ``label == 0`` (valid) is a
    genuine NO_EDGE observation.

    Parameters are PRICE-unit round costs:
    - ``spread_price``: full bid/ask spread in price units
    - ``slippage_price``: one-way adverse slippage in price units
    - ``commission_price``: round-turn commission expressed in price units
      (shifts both barriers outward so the label requires net profitability)
    - ``ambiguous``: kept for API compatibility; same-bar TP/SL ties and
      both-directions-fire cases resolve to "direction unconfirmed" (never
      the opposite side) under both modes.
    """
    close = df["close"].values
    high = df["high"].values
    low = df["low"].values
    open_ = df["open"].values
    atr = df[atr_col].values
    n = len(df)
    labels = np.full(n, np.nan, dtype=np.float64)
    half_spread = float(spread_price) / 2.0
    slip = float(slippage_price)
    comm_half = float(commission_price) / 2.0

    for i in range(n - horizon):
        a = atr[i]
        if np.isnan(a) or a <= 0:
            continue
        o1 = open_[i + 1]

        # ---- LONG geometry: entry at ask, exits at bid ------------------
        long_entry = o1 + half_spread + slip
        long_tp = long_entry + tp_atr_mult * a + comm_half
        long_sl = long_entry - sl_atr_mult * a - comm_half
        hi_bid = high[i + 1: i + 1 + horizon] - half_spread
        lo_bid = low[i + 1: i + 1 + horizon] - half_spread
        f_long_tp = _first_hit(hi_bid >= long_tp)
        f_long_sl = _first_hit(lo_bid <= long_sl)
        # BUY requires the TP hit strictly before the SL (a same-bar tie has
        # unknowable order without tick history → direction unconfirmed)
        long_ok = f_long_tp < f_long_sl

        # ---- SHORT geometry: entry at bid, exits at ask -----------------
        short_entry = o1 - half_spread - slip
        short_tp = short_entry - tp_atr_mult * a - comm_half
        short_sl = short_entry + sl_atr_mult * a + comm_half
        lo_ask = low[i + 1: i + 1 + horizon] + half_spread
        hi_ask = high[i + 1: i + 1 + horizon] + half_spread
        f_short_tp = _first_hit(lo_ask <= short_tp)
        f_short_sl = _first_hit(hi_ask >= short_sl)
        short_ok = f_short_tp < f_short_sl

        if long_ok and short_ok:
            # whipsaw both ways within the horizon — no attributable side
            labels[i] = 0
        elif long_ok:
            labels[i] = 1
        elif short_ok:
            labels[i] = -1
        else:
            labels[i] = 0          # real NO_EDGE (full future window existed)
    return pd.Series(labels, index=df.index, name="label")


def label_validity(df: pd.DataFrame, horizon: int, atr_col: str = "atr") -> pd.Series:
    """Boolean mask: True where a full future horizon exists AND ATR is usable.

    Tail rows (last ``horizon`` bars) and NaN/non-positive ATR rows are
    invalid — they must be excluded from training/evaluation, never merged
    into the NO_EDGE class (Mission 6 / finding 16).
    """
    n = len(df)
    valid = np.ones(n, dtype=bool)
    valid[max(0, n - horizon):] = False          # no full future window
    atr = df[atr_col].values if atr_col in df.columns else np.full(n, np.nan)
    valid &= ~(np.isnan(atr) | (atr <= 0))
    return pd.Series(valid, index=df.index, name="valid_label")

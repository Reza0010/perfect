"""PHASE 6 — XGBoost 3-class classifier wrapper (independent model)."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import xgboost as xgb

from app.config.schema import XGBParams
from app.core.exceptions import ModelNotTrainedError


class XGBModel:
    name = "xgboost"

    def __init__(self, params: XGBParams | None = None) -> None:
        self.params = params or XGBParams()
        self.model: xgb.XGBClassifier | None = None

    def fit(self, X, y, X_val=None, y_val=None) -> None:
        params = {
            "n_estimators": self.params.n_estimators,
            "learning_rate": self.params.learning_rate,
            "max_depth": self.params.max_depth,
            "min_child_weight": self.params.min_child_weight,
            "subsample": self.params.subsample,
            "colsample_bytree": self.params.colsample_bytree,
            "reg_lambda": self.params.reg_lambda,
            "objective": "multi:softprob",
            "num_class": 3,
            "tree_method": "hist",
            "eval_metric": "mlogloss",
            "early_stopping_rounds": self.params.early_stopping_rounds if X_val is not None else None,
            "random_state": 42,
            "verbosity": 0,
        }
        params = {k: v for k, v in params.items() if v is not None}
        model = xgb.XGBClassifier(**params)
        if X_val is not None and y_val is not None:
            model.fit(np.asarray(X), np.asarray(y), eval_set=[(np.asarray(X_val), np.asarray(y_val))], verbose=False)
        else:
            model.fit(np.asarray(X), np.asarray(y))
        self.model = model

    def predict_proba(self, X) -> np.ndarray:
        if self.model is None:
            raise ModelNotTrainedError("XGBoost model is not trained/loaded")
        return self.model.predict_proba(np.asarray(X))

    def save(self, directory: str | Path) -> None:
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        self.model.save_model(str(directory / "model.json"))
        (directory / "params.json").write_text(json.dumps(self.params.model_dump()), encoding="utf-8")

    def load(self, directory: str | Path) -> None:
        model = xgb.XGBClassifier()
        model.load_model(str(Path(directory) / "model.json"))
        self.model = model

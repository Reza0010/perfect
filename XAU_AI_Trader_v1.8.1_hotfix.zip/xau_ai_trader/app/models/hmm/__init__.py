"""Reserved subpackage layout (models live in app/models/ root modules)."""

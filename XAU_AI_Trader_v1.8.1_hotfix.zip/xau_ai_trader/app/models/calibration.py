"""PHASE 9 — Probability calibration (isotonic / Platt), JSON-serialisable.

Raw model probabilities must never be used directly for sizing decisions;
the calibrated value replaces them (e.g. 0.82 raw → 0.74 calibrated).
"""

from __future__ import annotations

import numpy as np
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression

from app.core.exceptions import CalibrationError

CLASSES = [0, 1, 2]  # SELL, NO_EDGE, BUY


class ProbabilityCalibrator:
    """One-vs-rest calibration per class; outputs renormalised probabilities."""

    def __init__(self, method: str = "isotonic") -> None:
        if method not in ("isotonic", "platt"):
            raise CalibrationError(f"unknown calibration method {method}")
        self.method = method
        self.models: dict[int, dict] = {}

    def fit(self, probs: np.ndarray, y_true: np.ndarray) -> None:
        probs = np.asarray(probs, dtype=float)
        y_true = np.asarray(y_true)
        if probs.ndim != 2 or probs.shape[1] != 3:
            raise CalibrationError("probs must be (n,3)")
        if len(probs) < 50:
            raise CalibrationError(f"too few samples for calibration: {len(probs)}")
        for c in CLASSES:
            target = (y_true == c).astype(float)
            p_c = probs[:, c]
            if target.sum() < 5 or (1 - target).sum() < 5:
                self.models[c] = {"identity": True}
                continue
            if self.method == "isotonic":
                iso = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
                iso.fit(p_c, target)
                self.models[c] = {
                    "identity": False,
                    "X_thresholds": iso.X_thresholds_.tolist(),
                    "y_thresholds": iso.y_thresholds_.tolist(),
                }
            else:
                lr = LogisticRegression(C=1e6, max_iter=1000)
                lr.fit(p_c.reshape(-1, 1), target)
                self.models[c] = {"identity": False, "coef": float(lr.coef_[0][0]),
                                  "intercept": float(lr.intercept_[0])}

    def _raw_map(self, c: int, p: np.ndarray) -> np.ndarray:
        m = self.models.get(c, {"identity": True})
        if m.get("identity"):
            return p
        if self.method == "isotonic":
            # piecewise-linear interpolation of isotonic thresholds —
            # equivalent to sklearn's transform without fragile internals
            x = np.asarray(m["X_thresholds"], dtype=float)
            y = np.asarray(m["y_thresholds"], dtype=float)
            return np.clip(np.interp(p, x, y), 0.0, 1.0)
        z = m["coef"] * p + m["intercept"]
        return 1.0 / (1.0 + np.exp(-z))

    def transform(self, probs: np.ndarray) -> np.ndarray:
        probs = np.asarray(probs, dtype=float)
        if probs.ndim != 2 or probs.shape[1] != 3:
            raise CalibrationError("probs must be (n,3)")
        out = np.column_stack([self._raw_map(c, probs[:, c]) for c in CLASSES])
        sums = out.sum(axis=1, keepdims=True)
        sums[sums == 0] = 1.0
        return out / sums

    def to_dict(self) -> dict:
        return {"method": self.method, "models": {str(k): v for k, v in self.models.items()}}

    @classmethod
    def from_dict(cls, d: dict) -> "ProbabilityCalibrator":
        cal = cls(d["method"])
        cal.models = {int(k): v for k, v in d["models"].items()}
        return cal

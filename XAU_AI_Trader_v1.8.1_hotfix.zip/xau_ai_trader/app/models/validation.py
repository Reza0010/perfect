"""PHASE 8 — Validation: purged K-Fold, walk-forward splits, metrics."""

from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)

CLASS_NAMES = {0: "SELL", 1: "NO_EDGE", 2: "BUY"}


def purged_kfold(n: int, n_splits: int = 5, purge: int = 64, embargo: int = 64):
    """K-Fold with purge (gap around the val fold) and embargo (gap after)."""
    idx = np.arange(n)
    fold_sizes = np.full(n_splits, n // n_splits, dtype=int)
    fold_sizes[: n % n_splits] += 1
    splits = []
    start = 0
    for fs in fold_sizes:
        val = idx[start: start + fs]
        start += fs
        lo, hi = int(val[0]), int(val[-1])
        train = idx[(idx < lo - purge) | (idx > hi + purge + embargo)]
        if len(train) and len(val):
            splits.append((train, val))
    return splits


def walk_forward_splits(n: int, train_bars: int, val_bars: int, test_bars: int, step: int,
                        purge: int = 0, embargo: int = 0, min_folds: int = 0):
    """Rolling (train, val, test) windows with REAL purge/embargo gaps.

    v1.5 (Mission 8 / N4): the three windows used to be directly adjacent,
    so 48-bar labels straddled every boundary (train-tail labels looked into
    the val window, val-tail labels into test) while the walkforward report
    claimed 'purge/embargo applied'. Now:
      train | purge-gap | val | embargo-gap | test
    and if ``min_folds`` > 0 and fewer folds fit the data, a ValueError is
    raised instead of silently returning insufficient OOS evidence.
    """
    out = []
    start = 0
    purge = max(0, int(purge))
    embargo = max(0, int(embargo))
    while True:
        train_end = start + train_bars
        val_start = train_end + purge
        val_end = val_start + val_bars
        test_start = val_end + embargo
        if test_start + test_bars > n:
            break
        train = np.arange(start, train_end)
        val = np.arange(val_start, val_end)
        test = np.arange(test_start, test_start + test_bars)
        out.append((train, val, test))
        start += step
    if min_folds and len(out) < min_folds:
        raise ValueError(
            f"walk-forward produced {len(out)} OOS folds < required {min_folds} — "
            "insufficient out-of-sample evidence (Mission 30); "
            "provide more history or reduce window sizes")
    return out


def classification_metrics(y_true: np.ndarray, probs: np.ndarray) -> dict:
    y_true = np.asarray(y_true)
    probs = np.asarray(probs)
    y_pred = probs.argmax(axis=1)
    out: dict = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "precision_macro": float(precision_score(y_true, y_pred, average="macro", zero_division=0)),
        "recall_macro": float(recall_score(y_true, y_pred, average="macro", zero_division=0)),
        "f1_macro": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
    }
    try:
        if len(np.unique(y_true)) > 1:
            out["roc_auc_ovr"] = float(roc_auc_score(y_true, probs, multi_class="ovr", labels=[0, 1, 2]))
        else:
            out["roc_auc_ovr"] = None
    except Exception:
        out["roc_auc_ovr"] = None
    try:
        out["log_loss"] = float(log_loss(y_true, probs, labels=[0, 1, 2]))
    except Exception:
        out["log_loss"] = None
    # v1.5 (Mission 9): Brier (multiclass, mean of per-class) + ECE for the
    # confidence calibration quality of the DEPLOYED decision path.
    try:
        onehot = np.eye(3)[y_true]
        out["brier_multiclass"] = float(np.mean(np.sum((probs - onehot) ** 2, axis=1)))
    except Exception:
        out["brier_multiclass"] = None
    try:
        conf = probs.max(axis=1)
        pred = probs.argmax(axis=1)
        correct = (pred == y_true).astype(float)
        bins = np.clip((conf * 10).astype(int), 0, 9)
        ece = 0.0
        for b in range(10):
            m = bins == b
            if m.sum():
                ece += m.mean() * abs(correct[m].mean() - conf[m].mean())
        out["ece"] = float(ece)
    except Exception:
        out["ece"] = None
    # per-class precision/recall
    for c, name in CLASS_NAMES.items():
        out[f"precision_{name}"] = float(precision_score(y_true, y_pred, labels=[c], average="macro", zero_division=0))
        out[f"recall_{name}"] = float(recall_score(y_true, y_pred, labels=[c], average="macro", zero_division=0))
    # v1.8 forensic additions: per-class F1, class support (counts) and the
    # CONFUSION MATRIX — accuracy-only reporting hid the degenerate
    # SELL-majority models behind class imbalance (77% accuracy, 0.0
    # NO_EDGE recall). These fields feed the registry readiness gate.
    for c, name in CLASS_NAMES.items():
        out[f"f1_{name}"] = float(f1_score(y_true, y_pred, labels=[c], average="macro", zero_division=0))
        out.setdefault("class_support", {})[name] = int((y_true == c).sum())
    try:
        cm = confusion_matrix(y_true, y_pred, labels=[0, 1, 2])
        out["confusion_matrix"] = cm.astype(int).tolist()
        out["confusion_matrix_order"] = [CLASS_NAMES[i] for i in (0, 1, 2)]
    except Exception:
        pass
    return out


def calibration_bins(y_true: np.ndarray, probs: np.ndarray, n_bins: int = 10) -> list[dict]:
    """Reliability diagram data per class."""
    report = []
    y_true = np.asarray(y_true)
    probs = np.asarray(probs)
    for c, name in CLASS_NAMES.items():
        target = (y_true == c).astype(float)
        p = probs[:, c]
        bins = []
        edges = np.linspace(0, 1, n_bins + 1)
        for b in range(n_bins):
            lo, hi = edges[b], edges[b + 1]
            mask = (p >= lo) & (p < hi if b < n_bins - 1 else p <= hi)
            if mask.sum() > 0:
                bins.append({"bin": b, "mean_pred": float(p[mask].mean()),
                             "freq": float(target[mask].mean()), "count": int(mask.sum())})
        try:
            brier = float(brier_score_loss(target, p)) if len(np.unique(target)) > 1 else None
        except Exception:
            brier = None
        report.append({"class": name, "brier": brier, "bins": bins})
    return report

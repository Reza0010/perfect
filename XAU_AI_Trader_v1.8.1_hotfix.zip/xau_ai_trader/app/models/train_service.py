"""Training orchestration: build dataset → leakage audit → train LGBM/XGB/HMM
→ calibrate → evaluate → register.

Used by train.py, walkforward.py and optimize.py.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from app.config.schema import AppConfig, Timeframe
from app.core import exceptions as exc
from app.data.market.base import MarketDataProvider
from app.features.builder import FeatureBuilder
from app.models.bundle import ModelBundle
from app.models.calibration import ProbabilityCalibrator
from app.models.dataset import Dataset, _apply_scaler, _fit_scaler
from app.models.labels import triple_barrier_labels
from app.models.lgbm_model import LGBMModel
from app.models.leakage import LeakageAuditReport, check_split_purity
from app.models.registry import ModelRegistry
from app.models.validation import classification_metrics, calibration_bins, purged_kfold
from app.models.xgb_model import XGBModel
from app.smc.engine import SMCEngine

logger = logging.getLogger(__name__)


@dataclass
class TrainOutput:
    bundle: ModelBundle
    metrics: dict = field(default_factory=dict)
    audit: LeakageAuditReport | None = None
    dataset_meta: dict = field(default_factory=dict)
    feature_importance: list = field(default_factory=list)


def build_frames(provider: MarketDataProvider, cfg: AppConfig, days: int | None = None) -> dict[str, pd.DataFrame]:
    """Fetch every enabled timeframe spanning the SAME window as the base TF.

    Bar counts are derived from the history depth so higher/lower timeframes
    align with the base timeframe span (trimmed to [base_start, base_end]).
    """
    days = days or cfg.provider.simulated_days
    per_day = {"M1": 1440, "M5": 288, "M15": 96, "M30": 48, "H1": 24, "H4": 6, "D1": 1}
    frames: dict[str, pd.DataFrame] = {}
    for tf in cfg.timeframes.enabled:
        bars = max(200, int(days * per_day.get(tf.value, 96)))
        frames[tf.value] = provider.get_candles(cfg.symbol.primary, tf.value, bars)
    base_key = cfg.timeframes.base.value
    base_idx = frames[base_key].index
    start, end = base_idx[0], base_idx[-1]
    for tf, df in frames.items():
        frames[tf] = df[(df.index >= start) & (df.index <= end)]
    return frames


def make_feature_builder(cfg: AppConfig) -> FeatureBuilder:
    return FeatureBuilder(cfg.features, cfg.indicators, cfg.sessions, cfg.smc)


def build_xy(
    cfg: AppConfig,
    frames: dict[str, pd.DataFrame],
    feature_builder: FeatureBuilder,
) -> tuple[pd.DataFrame, pd.Series, pd.Series, str]:
    """Returns (features_df, labels, close, feature_version).

    v1.5: labels use executable-fill anchoring (entry at t+1 open ± spread/2
    ± slippage, barriers from the executable entry) and carry NaN for rows
    without a full future horizon — tail rows are NOT silently converted to
    NO_EDGE. The feature_version now hashes the FULL feature contract.
    """
    base_key = cfg.timeframes.base.value
    features, names = feature_builder.build(frames, cfg.timeframes.base)
    version = FeatureBuilder.feature_version(
        names, cfg.features.version_tag,
        indicator_cfg=cfg.indicators, feature_cfg=cfg.features,
        sessions_cfg=cfg.sessions, smc_cfg=cfg.smc,
        label_spec=cfg.labels.model_dump(),
        scaler_kind=cfg.dataset.scaler,
    )
    base = frames[base_key]
    # labels scan future bars of the base frame; ATR comes from the causal
    # feature matrix (already computed at time t only)
    label_frame = base[["open", "high", "low", "close"]].join(features[["atr"]], how="left")
    labels = triple_barrier_labels(
        label_frame,
        horizon=cfg.labels.horizon_bars,
        tp_atr_mult=cfg.labels.tp_atr_mult,
        sl_atr_mult=cfg.labels.sl_atr_mult,
        ambiguous=cfg.labels.ambiguous,
        spread_price=cfg.validation.label_spread_price,
        slippage_price=cfg.validation.label_slippage_price,
        commission_price=cfg.validation.label_commission_price,
    )
    return features, labels, base["close"], version


def temporal_split(n: int, cfg: AppConfig) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """TRAIN → PURGE → VALIDATION → PURGE → TEST with REAL gaps.

    v1.5 (Mission 8): the purge now ENFORCES ``purge_bars >= horizon_bars``
    (a label at the segment tail looks up to ``horizon`` bars into the
    future, so any smaller gap leaks). The old code only shrank the train/
    val ends — the val→test boundary gap came from shifting the test start
    while val kept its full length; now both gaps are explicit and
    symmetric, and the embargo window additionally separates train from
    test evaluation.
    """
    horizon = cfg.labels.horizon_bars
    purge = max(cfg.validation.purge_bars, horizon)
    embargo = cfg.validation.embargo_bars
    train_end = int(n * cfg.validation.train_ratio)
    val_end = int(n * (cfg.validation.train_ratio + cfg.validation.val_ratio))
    train = np.arange(0, max(0, train_end - purge))
    val = np.arange(train_end + purge, max(train_end + purge, val_end - purge))
    test = np.arange(val_end + purge + embargo, n)
    return train, val, test


def clean_feature_frame(features: pd.DataFrame, labels: pd.Series) -> pd.DataFrame:
    """Join labels, drop unusable columns (all-NaN / >60% NaN — e.g. warmup
    artefacts of very slow higher-TF indicators), then drop remaining NaN rows.

    v1.5 (Mission 6/finding 16): rows whose label is NaN (tail rows without a
    full future horizon, or invalid ATR) are DROPPED, not turned into
    NO_EDGE. ``label == 0`` after cleaning is a genuine NO_EDGE observation.
    """
    df = features.copy()
    df["label"] = labels
    df = df.replace([np.inf, -np.inf], np.nan)
    keep = [c for c in df.columns
            if c == "label" or df[c].notna().mean() >= 0.40]
    dropped = [c for c in df.columns if c not in keep]
    if dropped:
        logger.info("dropped %d degenerate feature columns: %s", len(dropped), dropped[:6])
    df = df[keep]
    n_before = len(df)
    df = df.dropna(axis=0, how="any")  # includes NaN labels (invalid tail)
    n_invalid = n_before - len(df)
    if n_invalid:
        logger.info("dropped %d rows with invalid/NaN labels (tail horizon or bad ATR)", n_invalid)
    return df


def train_models(cfg: AppConfig, frames: dict[str, pd.DataFrame],
                 register: bool = True, registry_tag: str = "main",
                 data_source: dict | None = None) -> TrainOutput:
    """Train LGBM/XGB/HMM + calibrate + (optionally) register.

    ``registry_tag`` separates model families in the registry, e.g. ``main``
    (unit-test/simulated) vs ``real`` (real-dataset training, PHASE 65 §7) so
    real models can never be silently overwritten by synthetic-data runs.

    ``data_source`` (v1.8): provenance descriptor from
    ``app.data.providers_factory.provider_data_source(provider)`` — recorded
    in the registry so a simulated-data model can never masquerade as a
    real-data model again.
    """
    fb = make_feature_builder(cfg)
    features, labels, close, fversion = build_xy(cfg, frames, fb)

    dataset = clean_feature_frame(features, labels)
    if len(dataset) < cfg.dataset.min_rows:
        raise exc.LeakageError(f"dataset too small: {len(dataset)} < {cfg.dataset.min_rows}")

    X = dataset.drop(columns=["label"])
    y = (dataset["label"].astype(int) + 1).astype(int).values
    n = len(X)

    train_idx, val_idx, test_idx = temporal_split(n, cfg)
    if len(train_idx) < 500 or len(val_idx) < 100 or len(test_idx) < 100:
        raise exc.LeakageError(
            f"splits too small: train={len(train_idx)} val={len(val_idx)} test={len(test_idx)}"
        )

    # purity audit on the temporal split (real gap assertions)
    audit = LeakageAuditReport()
    audit.checks.append(check_split_purity(train_idx, test_idx,
                                           max(cfg.validation.purge_bars, cfg.labels.horizon_bars),
                                           cfg.validation.embargo_bars))
    audit.checks.append(check_split_purity(train_idx, val_idx,
                                           max(cfg.validation.purge_bars, cfg.labels.horizon_bars),
                                           cfg.validation.embargo_bars))

    # scaler fit on TRAIN only (leakage rule)
    scaler_state = _fit_scaler(X.iloc[train_idx], cfg.dataset.scaler)
    Xs = _apply_scaler(X, scaler_state)

    # v1.5 (Mission 8): run the FULL leakage audit (causal features, horizon,
    # alignment, scaler center AND scale) — previously run_full_audit existed
    # but was never called by the real training path. The RAW label series
    # (with NaN tails) is audited here — after clean_feature_frame the NaN
    # rows are already dropped and the tail check would be vacuous.
    from app.models.leakage import run_full_audit
    # v1.8 forensic fix: the audit is FAIL-CLOSED. Previously any non-
    # LeakageError exception (e.g. a schema surprise in the audit inputs)
    # was swallowed with a warning and training continued — a silently
    # skipped audit is indistinguishable from a passed one.
    # X (UNSCALED) is passed for the scaler audit — comparing scaled-matrix
    # statistics against the raw center/scale would be meaningless.
    full_audit = run_full_audit(features, labels, train_idx, test_idx,
                                purge=max(cfg.validation.purge_bars, cfg.labels.horizon_bars),
                                embargo=cfg.validation.embargo_bars,
                                scaler_state=scaler_state, X_scaled=X,
                                horizon=cfg.labels.horizon_bars)
    for chk in full_audit.checks:
        audit.checks.append(chk)
    failed = [c.name for c in audit.checks if not c.passed]
    if failed:
        raise exc.LeakageError(f"leakage audit failed: {failed}")

    # v1.5 (Mission 8 / N6): the purged K-fold is now actually USED — an OOS
    # cross-validated log-loss on the TRAIN segment quantifies model variance
    # and populates registry provenance. (Previously computed and discarded.)
    # v1.8: purge clamped to >= label horizon (same rule as temporal_split —
    # a fold gap smaller than the horizon leaks label windows into training).
    cv_splits = purged_kfold(len(train_idx), cfg.validation.n_splits,
                             max(cfg.validation.purge_bars, cfg.labels.horizon_bars),
                             cfg.validation.embargo_bars)
    if not cv_splits:
        raise exc.LeakageError("purged CV produced no usable splits")
    cv_log_losses: list[float] = []
    for tr_i, te_i in cv_splits:
        if len(te_i) < 30 or len(np.unique(y[train_idx][tr_i])) < 3:
            continue
        fold_model = LGBMModel(cfg.lgbm)
        fold_model.fit(Xs.iloc[train_idx].iloc[tr_i], y[train_idx][tr_i],
                       Xs.iloc[train_idx].iloc[te_i], y[train_idx][te_i])
        p = fold_model.predict_proba(Xs.iloc[train_idx].iloc[te_i])
        cv_log_losses.append(round(float(classification_metrics(y[train_idx][te_i], p)["log_loss"]), 5))
    logger.info("purged-CV log-loss on train segment: %s", cv_log_losses)

    y_train = y[train_idx]
    if len(np.unique(y_train)) < 3:
        raise exc.LeakageError(
            f"training labels degenerate: only classes {np.unique(y_train)} present — "
            "adjust label barriers or provide more history"
        )

    lgbm = LGBMModel(cfg.lgbm)
    lgbm.fit(Xs.iloc[train_idx], y_train, Xs.iloc[val_idx], y[val_idx])
    xgb = XGBModel(cfg.xgb)
    xgb.fit(Xs.iloc[train_idx], y_train, Xs.iloc[val_idx], y[val_idx])

    lgbm_val_probs = lgbm.predict_proba(Xs.iloc[val_idx])
    xgb_val_probs = xgb.predict_proba(Xs.iloc[val_idx])
    lgbm_cal = ProbabilityCalibrator(cfg.calibration.method)
    xgb_cal = ProbabilityCalibrator(cfg.calibration.method)
    # v1.5 (Mission 9 / N9): honour the configured min_validation_samples
    # (previously a dead knob; code hard-coded 50) and never fit calibration
    # on too little data.
    min_val_samples = cfg.calibration.min_validation_samples
    calibration_meta: dict = {"method": cfg.calibration.method, "fitted": False,
                              "min_validation_samples": min_val_samples,
                              "val_samples": int(len(val_idx))}
    if len(val_idx) < min_val_samples:
        logger.warning("calibration skipped: validation too small (%d < %d)",
                       len(val_idx), min_val_samples)
        lgbm_cal = xgb_cal = None
    else:
        try:
            lgbm_cal.fit(lgbm_val_probs, y[val_idx])
            xgb_cal.fit(xgb_val_probs, y[val_idx])
            calibration_meta["fitted"] = True
        except exc.CalibrationError as e:
            logger.warning("calibration skipped: %s", e)
            lgbm_cal = xgb_cal = None

    # v1.5 (Mission 9 / finding 17): evaluate BOTH raw and CALIBRATED
    # probabilities on the test set. The deployed path (bundle.predict)
    # calibrates — metrics must describe the probabilities that actually
    # trade, not the raw ones.
    lgbm_test_probs = lgbm.predict_proba(Xs.iloc[test_idx])
    xgb_test_probs = xgb.predict_proba(Xs.iloc[test_idx])
    metrics = {
        "lgbm_test_raw": classification_metrics(y[test_idx], lgbm_test_probs),
        "xgb_test_raw": classification_metrics(y[test_idx], xgb_test_probs),
        "lgbm_test": classification_metrics(y[test_idx], lgbm_test_probs),
        "xgb_test": classification_metrics(y[test_idx], xgb_test_probs),
        "rows": {"train": int(len(train_idx)), "val": int(len(val_idx)), "test": int(len(test_idx))},
        "cv_log_loss_train": cv_log_losses,
        "calibration": calibration_meta,
    }
    if lgbm_cal is not None:
        lgbm_cal_test = np.asarray(lgbm_cal.transform(lgbm_test_probs), dtype=float)
        metrics["lgbm_test_calibrated"] = classification_metrics(y[test_idx], lgbm_cal_test)
        metrics["lgbm_test"] = metrics["lgbm_test_calibrated"]  # headline = deployed
    if xgb_cal is not None:
        xgb_cal_test = np.asarray(xgb_cal.transform(xgb_test_probs), dtype=float)
        metrics["xgb_test_calibrated"] = classification_metrics(y[test_idx], xgb_cal_test)
        metrics["xgb_test"] = metrics["xgb_test_calibrated"]

    # HMM
    hmm_model = None
    if cfg.hmm.enabled:
        try:
            from app.models.hmm_model import HMMRegimeModel, hmm_feature_matrix

            # v1.5: shared feature matrix helper (rsi normalized to [-1,1]) —
            # exactly the same transform used at inference.
            # v1.8 fix: fit strictly on the TRAIN window. Previously the fit
            # window was computed on the RAW feature frame (``features[:n*]
            # where n = len(dataset)``) — since ``features`` has MORE rows
            # than the cleaned dataset, the HMM silently trained past the
            # train/val boundary into (and beyond) the validation segment.
            hmm_features = hmm_feature_matrix(
                features.loc[:dataset.index[train_idx[-1]]])
            hmm_model = HMMRegimeModel(cfg.hmm)
            hmm_model.fit(hmm_features)
        except Exception as e:
            logger.warning("HMM training skipped: %s", e)
            hmm_model = None

    bundle = ModelBundle(
        lgbm=lgbm, xgb=xgb, lgbm_calibrator=lgbm_cal, xgb_calibrator=xgb_cal,
        scaler_state=scaler_state, feature_names=list(X.columns),
        feature_version=fversion,
        model_ids={"lgbm": f"lgbm_{registry_tag}", "xgb": f"xgb_{registry_tag}"},
    )

    if register:
        import hashlib
        import json as _json
        from pathlib import Path

        registry_root = Path(cfg.paths.models_dir) / "registry"
        registry = ModelRegistry(registry_root)
        lgbm_dir = str(registry_root / f"lgbm_{registry_tag}")
        xgb_dir = str(registry_root / f"xgb_{registry_tag}")
        lgbm.save(lgbm_dir)
        xgb.save(xgb_dir)
        Path(lgbm_dir).joinpath("calibrator.json").write_text(
            _json.dumps(lgbm_cal.to_dict() if lgbm_cal else {}), encoding="utf-8")
        Path(xgb_dir).joinpath("calibrator.json").write_text(
            _json.dumps(xgb_cal.to_dict() if xgb_cal else {}), encoding="utf-8")
        Path(lgbm_dir).joinpath("scaler.json").write_text(_json.dumps(scaler_state), encoding="utf-8")
        Path(lgbm_dir).joinpath("feature_names.json").write_text(
            _json.dumps(list(X.columns)), encoding="utf-8")
        # v1.5 (Mission 28 / finding 11): full model provenance — data hash,
        # config hash, windows, calibration, cost assumptions, artifact
        # sha256. A model without provenance must not load in LIVE.
        def _artifact_hash(path: str) -> str:
            p = Path(path)
            h = hashlib.sha256()
            for f in sorted(p.glob("*")):
                if f.is_file():
                    h.update(f.name.encode())
                    h.update(f.read_bytes())
            return h.hexdigest()

        cfg_hash = hashlib.sha256(cfg.model_dump_json().encode()).hexdigest()[:16]
        windows = {
            "train": [str(dataset.index[train_idx[0]]), str(dataset.index[train_idx[-1]])],
            "val": [str(dataset.index[val_idx[0]]), str(dataset.index[val_idx[-1]])],
            "test": [str(dataset.index[test_idx[0]]), str(dataset.index[test_idx[-1]])],
        }
        cost_assumptions = {
            "spread_price": cfg.validation.label_spread_price,
            "slippage_price": cfg.validation.label_slippage_price,
            "commission_price": cfg.validation.label_commission_price,
            "units": "PRICE",
        }
        # v1.8: CONTENT hash of the feature matrix (the old "hash" was just
        # ``rows:first_ts:last_ts`` — different data with the same span and
        # row count produced the same id). Hash the label column too so a
        # label-semantics change (v1.8 symmetric labels) invalidates it.
        content_hasher = hashlib.sha256()
        content_hasher.update(np.ascontiguousarray(
            X.to_numpy(dtype=np.float32)).tobytes())
        content_hasher.update(y.astype(np.int8).tobytes())
        data_content_hash = content_hasher.hexdigest()[:16]
        # v1.8: class distribution — a degenerate split is visible at a
        # glance instead of being discovered from zero recalls later.
        class_distribution = {
            "SELL": int((y == 0).sum()), "NO_EDGE": int((y == 1).sum()),
            "BUY": int((y == 2).sum())}
        provenance = {
            # v1.8 (CRITICAL): the data source that ACTUALLY trained this
            # model — from providers_factory.provider_data_source(). A
            # synthetic-data model is now machine-detectable at load time.
            "data_source": data_source or {"kind": "unrecorded",
                                            "label": "data source not recorded"},
            "registry_tag": registry_tag,
            "training_data_hash": f"{len(dataset)}rows:{str(dataset.index[0])}:{str(dataset.index[-1])}",
            "training_data_content_sha256": data_content_hash,
            "symbol": cfg.symbol.primary,
            "base_timeframe": cfg.timeframes.base.value,
            "label_version": "v1.8-symmetric-triple-barrier",
            "config_hash": cfg_hash,
            "feature_version": fversion,
            "windows": windows,
            "class_distribution": class_distribution,
            "calibration": calibration_meta,
            "cost_assumptions": cost_assumptions,
            "label_spec": cfg.labels.model_dump(),
            "scaler": scaler_state.get("kind", "none") if isinstance(scaler_state, dict) else "unknown",
        }
        registry.register(f"lgbm_{registry_tag}", "lightgbm", lgbm_dir, cfg.lgbm.model_dump(),
                          metrics.get("lgbm_test", {}), dataset_version=fversion,
                          feature_version=fversion,
                          extra={**provenance, "artifact_sha256": _artifact_hash(lgbm_dir)})
        registry.register(f"xgb_{registry_tag}", "xgboost", xgb_dir, cfg.xgb.model_dump(),
                          metrics.get("xgb_test", {}), dataset_version=fversion,
                          feature_version=fversion,
                          extra={**provenance, "artifact_sha256": _artifact_hash(xgb_dir)})
        if hmm_model is not None:
            hmm_dir = str(registry_root / f"hmm_{registry_tag}")
            hmm_model.save(hmm_dir)
            registry.register(f"hmm_{registry_tag}", "hmm", hmm_dir, cfg.hmm.model_dump(),
                              {"note": "regime model — no class metrics"},
                              dataset_version=fversion, feature_version=fversion,
                              extra={**provenance, "artifact_sha256": _artifact_hash(hmm_dir)})

    importance = lgbm.feature_importance(list(X.columns), top=15) if lgbm.model is not None else []
    return TrainOutput(bundle=bundle, metrics=metrics, audit=audit,
                       dataset_meta={"rows": int(n), "first": str(dataset.index[0]),
                                     "last": str(dataset.index[-1]), "feature_version": fversion},
                       feature_importance=importance)


def load_bundle(cfg: AppConfig, model_ids=None, registry_tag: str = "main") -> ModelBundle:
    """Load registered models for inference.

    v1.8: every loaded bundle is passed through the registry's
    ``deployment_readiness`` gate and carries ``deployment_warnings`` +
    ``model_metadata``. A degenerate/synthetic model still loads (paper
    trading must keep running for observation) but the trader exposes the
    warnings in state.json so the UI labels it NOT validated.
    """
    import json
    from pathlib import Path

    base = Path(cfg.paths.models_dir) / "registry"
    lgbm_dir = base / f"lgbm_{registry_tag}"
    xgb_dir = base / f"xgb_{registry_tag}"
    if not lgbm_dir.exists() and not xgb_dir.exists():
        raise exc.ModelNotTrainedError(
            "no trained models found — run `python train.py` first"
        )
    bundle = ModelBundle()
    registry = ModelRegistry(base)
    warnings_out: list[str] = []
    metadata: dict = {"registry_tag": registry_tag, "models": {}}
    if lgbm_dir.exists():
        lgbm = LGBMModel()
        lgbm.load(lgbm_dir)
        bundle.lgbm = lgbm
        cal_file = lgbm_dir / "calibrator.json"
        if cal_file.exists():
            data = json.loads(cal_file.read_text(encoding="utf-8"))
            if data:
                bundle.lgbm_calibrator = ProbabilityCalibrator.from_dict(data)
        scaler_file = lgbm_dir / "scaler.json"
        if scaler_file.exists():
            bundle.scaler_state = json.loads(scaler_file.read_text(encoding="utf-8"))
        else:
            # v1.5 (N12): a missing scaler state silently applied NO scaling
            # to a model trained on scaled inputs — distribution shift.
            raise exc.ModelError(
                f"scaler.json missing for {lgbm_dir.name} — model provenance "
                "incomplete; retrain or restore the artifact")
        names_file = lgbm_dir / "feature_names.json"
        if names_file.exists():
            bundle.feature_names = json.loads(names_file.read_text(encoding="utf-8"))
    if xgb_dir.exists():
        xgb = XGBModel()
        xgb.load(xgb_dir)
        bundle.xgb = xgb
        cal_file = xgb_dir / "calibrator.json"
        if cal_file.exists():
            data = json.loads(cal_file.read_text(encoding="utf-8"))
            if data:
                bundle.xgb_calibrator = ProbabilityCalibrator.from_dict(data)
    bundle.model_ids = model_ids or {"lgbm": f"lgbm_{registry_tag}", "xgb": f"xgb_{registry_tag}"}

    # v1.8 deployment-readiness gate (per model, honest labels)
    for role, mid in bundle.model_ids.items():
        try:
            entry = registry.get(mid)
            readiness = ModelRegistry.deployment_readiness(entry)
            metadata["models"][mid] = readiness
            for w in readiness["warnings"]:
                tag = f"{mid}: {w}"
                if tag not in warnings_out:
                    warnings_out.append(tag)
        except exc.ModelError:
            metadata["models"][mid] = {"ready": False,
                                      "warnings": ["NOT_IN_REGISTRY"]}
    bundle.deployment_warnings = warnings_out
    bundle.model_metadata = metadata
    if warnings_out:
        logger.warning("MODEL READINESS: %s — models are NOT validated for "
                      "real-money use: %s", registry_tag, warnings_out)
    return bundle


def load_hmm(cfg: AppConfig, registry_tag: str = "main"):
    from pathlib import Path

    hmm_dir = Path(cfg.paths.models_dir) / "registry" / f"hmm_{registry_tag}"
    if not (hmm_dir / "hmm_params.npz").exists():
        return None
    try:
        from app.models.hmm_model import HMMRegimeModel

        model = HMMRegimeModel(cfg.hmm)
        model.load(hmm_dir)
        return model
    except Exception as e:
        logger.warning("HMM load failed: %s", e)
        return None

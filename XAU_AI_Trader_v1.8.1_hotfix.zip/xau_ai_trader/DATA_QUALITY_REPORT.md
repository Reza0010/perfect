# DATA_QUALITY_REPORT — v1.5 Forensic Upgrade

**Scope: shipped `data/raw` provenance, data-layer correctness fixes, and
the honest state of the datasets in this release.**

## 1. Shipped datasets (data/raw)

The repo ships 9 broker parquet files + sidecars (OtetGroup-MT5, ECN
account) plus GC futures comparisons. Critical provenance finding that
**survives from v1.4** and must be fixed at the next MT5-host session:

- `XAUUSD.ecn_H1.meta.json` records `utc_offset_hours_applied: 0.0` while
  the broker runs EET/EEST. The stored index is therefore SERVER TIME
  masquerading as UTC (Friday close lands at ~23:57 "UTC" instead of
  ~21:00–22:00 UTC). Consequences if used as-is: session flags off by 2–3 h,
  PDH/PDL day boundaries shifted, swap/rollover modelling misaligned.
- v1.5 mitigations applied NOW: `DatasetMetadata.spread_units="POINTS"`
  stamped (MT5 spread column is points), provenance text corrected to state
  the offset is operator-provided (NOT measured) and DST-unaware,
  `server_to_utc` single conversion point, `copy_rates_range` server-time
  bound conversion, and historical download warns on the issue.
- **Action required (MT5 host):** re-run `scripts/download_mt5_data.py`
  (which MEASURES the offset), verify Friday-close band, re-download all
  timeframes, then re-run the full validation stack. Until then the broker
  datasets remain RESEARCH-ONLY and the simulated provider is the only
  end-to-end source (and carries no edge claim).

## 2. Data-layer fixes in v1.5

| Fix | Where | Contract |
|-----|-------|----------|
| Closed-bar guarantee | `provider.get_candles` | never returns the forming bar; single chokepoint filter `open+duration ≤ cutoff` |
| `end_time` enforcement | same | bars after `end_time − duration` excluded (silent look-ahead removed) |
| Time-base unity | `provider.server_to_utc` | candles, ticks and position open-times share one conversion |
| Staleness anchor | `quality.check_candles` | weekend/holiday exemption checks the REAL quiet interval (old anchor was `2·last_ts − now` ⇒ false alarms every Monday) |
| `stale_after_bars` wired | quality config | knob was dead; threshold now `tf_minutes × stale_after_bars` |
| NaN inference row | pipeline | `FEATURES_NAN:<cols>` WAIT instead of silent zero-fill (0 = extreme tail after robust scaling) |
| HTF alignment | `features.builder` | availability at `bar_open + duration` (merge-asof equivalent), gap-robust |
| SMC cache identity | `features.builder` | window fingerprint (ts head/tail, len, last OHLC, SMC config) |
| Dataset metadata | `dataset_meta.py` | `spread_units` field; dead sidecar line removed |
| Replay/parquet tz | market/replay, parquet_store | naive timestamps refused unless sidecar declares a timezone (silent `tz_localize("UTC")` removed — REVIEW note: the parquet store retains a documented legacy path) |

## 3. Quality-gate behaviour (tests)

- Gaps / duplicates / ordering / impossible OHLC / spread anomalies /
  staleness / tz-awareness are scored with hard failure thresholds
  (existing suite, still green).
- New v1.5 tests: `test_staleness_weekend_anchor_no_false_error`,
  `test_smc_cache_refreshes_on_same_length_rolling_window`,
  `test_htf_alignment_by_completion_time`.

## 4. Honest limitations

- No tick data is shipped; backtests are OHLC-conservative (SL-first on
  same-bar ambiguity, gap-through-SL fills at the worse open).
- Cross-asset context (DXY / US10Y / VIX) adapters remain unimplemented by
  design (no provenance-safe offline source; Mission 22 optional).
- The static news CSV is OFFLINE-ONLY by contract; live mode with
  `provider: none` fails closed (UNKNOWN → WAIT).

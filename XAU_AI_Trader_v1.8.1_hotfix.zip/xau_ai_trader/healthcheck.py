#!/usr/bin/env python3
"""PHASE 57 — healthcheck.py: pre-start self-diagnostic.

    python healthcheck.py

Exit code 0 = healthy enough to start, 1 = critical failure.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.config.loader import load_config


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    rows: list[tuple[str, str, str]] = []

    # --- config -----------------------------------------------------------
    rows.append(("Config", "✓", "loaded & validated"))

    # --- provider -----------------------------------------------------------
    try:
        if cfg.provider.kind == "mt5":
            from app.data.mt5.provider import MT5DataProvider

            provider = MT5DataProvider(
                login_env=cfg.mt5.login_env, password_env=cfg.mt5.password_env,
                server=cfg.mt5.server, terminal_path=cfg.mt5.terminal_path,
                server_utc_offset_hours=cfg.mt5.server_utc_offset_hours,
            )
            provider.connect()
            provider.disconnect()
            rows.append(("MT5", "✓", "connected & shut down cleanly"))
        else:
            from app.data.market.simulated import SimulatedProvider

            provider = SimulatedProvider(days=5)
            provider.connect()
            df = provider.get_candles(cfg.symbol.primary, "M5", 100)
            ok = len(df) > 50
            rows.append(("Market Data (simulated)", "✓" if ok else "✗",
                         f"{len(df)} M5 bars"))
    except Exception as e:
        rows.append(("MT5/Market Data", "✗", str(e)[:80]))

    # --- data quality ---------------------------------------------------------
    try:
        from app.data.quality import check_candles

        df = provider.get_candles(cfg.symbol.primary, "M5", 500)
        rep = check_candles(df, cfg.symbol.primary, "M5", 5)
        rows.append(("Data Quality", "✓" if rep.passed else "⚠", f"score={rep.score:.0f}"))
    except Exception as e:
        rows.append(("Data Quality", "✗", str(e)[:80]))

    # --- models -----------------------------------------------------------------
    try:
        from app.models.train_service import load_bundle

        bundle = load_bundle(cfg)
        rows.append(("LightGBM", "✓", "registered"))
        rows.append(("XGBoost", "✓" if bundle.xgb else "⚠",
                     "registered" if bundle.xgb else "missing"))
    except Exception as e:
        rows.append(("LightGBM", "✗", "no trained models (run train.py)"))
        rows.append(("XGBoost", "✗", str(e)[:40]))

    # --- HMM ----------------------------------------------------------------------
    try:
        from app.models.train_service import load_hmm

        hmm = load_hmm(cfg)
        rows.append(("HMM", "✓" if hmm else "⚠", "registered" if hmm else "not trained"))
    except Exception:
        rows.append(("HMM", "✗", "load error"))

    # --- AI providers ---------------------------------------------------------------
    from app.ai.gateway import AIGateway

    gw = AIGateway(cfg.ai)
    if gw.available_providers:
        rows.append(("AI Providers", "✓", ",".join(gw.available_providers)))
    else:
        rows.append(("AI Providers", "⚠" if cfg.ai.require_ai_for_trade else "−",
                     "none configured → SAFE MODE/WAIT" if cfg.ai.require_ai_for_trade
                     else "not required by config"))
    import asyncio

    asyncio.run(gw.aclose())

    # --- news --------------------------------------------------------------------------
    try:
        from app.news.engine import NewsEngine
        from app.news.providers import build_news_provider

        engine = NewsEngine(build_news_provider(cfg.news), cfg.news)
        ok = engine.provider.healthy()
        rows.append(("News", "✓" if ok else "⚠", cfg.news.provider))
    except Exception as e:
        rows.append(("News", "✗", str(e)[:60]))

    # --- risk engine ---------------------------------------------------------------------
    ok = cfg.risk.risk_percent <= cfg.risk.max_risk_percent and cfg.risk.min_rr >= 1.0
    rows.append(("Risk Engine", "✓" if ok else "✗",
                 f"risk={cfg.risk.risk_percent}% max_daily_loss={cfg.risk.max_daily_loss_percent}%"))
    rows.append(("Execution Mode", "•", f"{cfg.execution.mode.value}"
                 + (" (LIVE ENABLED!)" if cfg.execution.live_trading_enabled else "")))

    # --- journal db -------------------------------------------------------------------------
    try:
        from app.journal.journal import Journal

        j = Journal(Path(cfg.paths.logs_dir) / "journal.db")
        j.close()
        rows.append(("Journal DB", "✓", "writable"))
    except Exception as e:
        rows.append(("Journal DB", "✗", str(e)[:60]))

    print("\nXAU AI TRADER — HEALTH CHECK")
    print("-" * 62)
    critical_fail = False
    for name, mark, detail in rows:
        print(f"  {name:<26} {mark}  {detail}")
        if mark == "✗" and name in ("Config", "Risk Engine"):
            critical_fail = True
    print("-" * 62)
    print("  Note: ⚠ means degraded-but-safe (system will WAIT more often).")
    return 1 if critical_fail else 0


if __name__ == "__main__":
    raise SystemExit(main())

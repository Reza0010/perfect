#!/usr/bin/env python3
"""PHASE 35 — optimize.py: Optuna hyperparameter search (v1.5: TEST-BLIND).

v1.5 fix (audit N1 — CRITICAL): the old objective computed expectancy AND
accuracy on the temporal TEST segment and maximised them — i.e. the final
report's test set was the tuning target, leaking test information into
model selection. The objective now evaluates candidates ONLY on purged
CV folds of the train segment + the validation segment. The test segment
is never touched here (it is reserved for the single final evaluation).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))

from app.config.loader import load_config
from app.core.logging import setup_logging


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    parser.add_argument("--trials", type=int, default=None)
    parser.add_argument("--provider", choices=["config", "simulated"], default="config",
                        help="data provider: 'config' honours provider.kind; "
                             "'simulated' EXPLICITLY forces synthetic data")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    import optuna

    optuna.logging.set_verbosity(optuna.logging.WARNING)

    from app.data.providers_factory import build_data_provider, explicit_simulated, provider_data_source
    from app.models.dataset import _apply_scaler, _fit_scaler
    from app.models.labels import triple_barrier_labels
    from app.models.lgbm_model import LGBMModel
    from app.models.train_service import build_frames, make_feature_builder, temporal_split
    from app.models.validation import classification_metrics, purged_kfold

    # v1.8 forensic fix: optimization used to ALWAYS run on SimulatedProvider —
    # tuned parameters on synthetic data were presented as if meaningful.
    # The provider now follows the config and the report records what ran.
    if args.provider == "simulated":
        provider = explicit_simulated(cfg)
        print("[optimize] ⚠ PROVIDER: SIMULATED (explicitly forced) — tuned "
              "parameters say NOTHING about real-market performance")
    else:
        provider = build_data_provider(cfg)
    src = provider_data_source(provider)
    print(f"[optimize] ACTUAL data source: {src['label']} "
          f"(real_market={src['real_market']})")
    provider.connect()
    frames = build_frames(provider, cfg)
    fb = make_feature_builder(cfg)
    features, names = fb.build(frames, cfg.timeframes.base)
    base = frames[cfg.timeframes.base.value]
    label_frame = base[["open", "high", "low", "close"]].join(features[["atr"]], how="left")
    labels = triple_barrier_labels(label_frame, cfg.labels.horizon_bars,
                                   cfg.labels.tp_atr_mult, cfg.labels.sl_atr_mult,
                                   ambiguous=cfg.labels.ambiguous,
                                   spread_price=cfg.validation.label_spread_price,
                                   slippage_price=cfg.validation.label_slippage_price,
                                   commission_price=cfg.validation.label_commission_price)
    df = features.copy()
    df["label"] = labels
    df = df.dropna(axis=0, how="any")
    X = df.drop(columns=["label"])
    y = (df["label"].astype(int) + 1).astype(int).values
    train_idx, val_idx, test_idx = temporal_split(len(X), cfg)
    # NOTE: test_idx is deliberately NOT used in the objective (v1.5).

    # expectancy proxy evaluated on TRAIN-segment CV folds + validation only.
    # It uses the real label function with the candidate sl barrier so the
    # tuned parameter targets a quantity the deployed system realizes.
    fwd_log_ret = np.log(base["close"] / base["close"].shift(1)).reindex(X.index).values

    def _expectancy(pred_probs: np.ndarray, rows: np.ndarray, min_conf: float,
                    sl_mult: float) -> tuple[float, int]:
        conf = pred_probs.max(axis=1)
        pred = pred_probs.argmax(axis=1)
        mask = (pred != 1) & (conf >= min_conf)
        if mask.sum() < cfg.optimize.min_trades:
            return -1.0, int(mask.sum())
        # horizon-limited forward return proxy: direction * cumulative forward
        # return over horizon bars, scaled by barrier ratio — cost-aware via
        # a per-trade flat cost in bp (spread+slippage proxy).
        horizon = cfg.labels.horizon_bars
        fwd = pd.Series(fwd_log_ret).rolling(horizon).sum().shift(-horizon).values
        direction = np.where(pred == 2, 1.0, -1.0)
        pnl = direction[mask] * fwd[rows][mask]
        pnl = pnl[np.isfinite(pnl)]
        if len(pnl) == 0:
            return -1.0, int(mask.sum())
        pnl = pnl * (sl_mult / cfg.labels.tp_atr_mult)
        cost_bp = (cfg.validation.label_spread_price + cfg.validation.label_slippage_price) / 20.0
        expectancy = float((np.mean(pnl) * 10000) - cost_bp)
        return expectancy, int(mask.sum())

    cv_folds = purged_kfold(len(train_idx), cfg.validation.n_splits,
                            max(cfg.validation.purge_bars, cfg.labels.horizon_bars),
                            cfg.validation.embargo_bars)

    def objective(trial: "optuna.Trial") -> float:
        space = cfg.optimize.search_space
        sl_mult = trial.suggest_categorical("sl_atr_mult", space["sl_atr_mult"])
        min_conf = trial.suggest_categorical("min_ml_confidence", space["min_ml_confidence"])
        params = cfg.lgbm.model_dump()
        params["learning_rate"] = trial.suggest_categorical(
            "learning_rate", [0.02, 0.03, 0.05, 0.08])
        params["num_leaves"] = trial.suggest_categorical("num_leaves", [15, 31, 63])
        params["min_child_samples"] = trial.suggest_categorical(
            "min_child_samples", [20, 40, 80])

        from app.config.schema import LGBMParams

        scaler = _fit_scaler(X.iloc[train_idx], cfg.dataset.scaler)
        Xs = _apply_scaler(X, scaler)

        # 1) purged-CV expectancy on the TRAIN segment (OOS within train)
        cv_expectancies: list[float] = []
        for tr_i, te_i in cv_folds:
            if len(te_i) < 30 or len(np.unique(y[train_idx][tr_i])) < 3:
                continue
            m = LGBMModel(LGBMParams(**params))
            m.fit(Xs.iloc[train_idx].iloc[tr_i], y[train_idx][tr_i],
                  Xs.iloc[train_idx].iloc[te_i], y[train_idx][te_i])
            p = m.predict_proba(Xs.iloc[train_idx].iloc[te_i])
            rows = train_idx[te_i]
            e, _ = _expectancy(p, rows, min_conf, sl_mult)
            cv_expectancies.append(e)
        if not cv_expectancies:
            return -1.0
        # 2) validation expectancy (hyperparams never see test)
        model = LGBMModel(LGBMParams(**params))
        model.fit(Xs.iloc[train_idx], y[train_idx], Xs.iloc[val_idx], y[val_idx])
        val_probs = model.predict_proba(Xs.iloc[val_idx])
        val_exp, _ = _expectancy(val_probs, val_idx, min_conf, sl_mult)
        # combined score: average CV expectancy + validation expectancy
        score = float(np.mean(cv_expectancies)) * 0.5 + val_exp * 0.5
        return score

    study = optuna.create_study(direction="maximize",
                                sampler=optuna.samplers.TPESampler(seed=13))
    n_trials = args.trials or cfg.optimize.n_trials
    study.optimize(objective, n_trials=n_trials, show_progress_bar=False)

    print("[optimize] best value:", round(study.best_value, 3))
    print("[optimize] best params:", study.best_params)
    out = Path(cfg.paths.reports_dir) / "optimize_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({
        "best_value": study.best_value, "best_params": study.best_params,
        "n_trials": n_trials,
        "objective": "purged-CV expectancy (train) + validation expectancy — TEST-BLIND",
        # v1.8: the data source that actually ran — synthetic tuning results
        # can no longer masquerade as real evidence.
        "data_source": src,
        "warning": ("hyperparameters selected on train-CV + validation only; "
                    "confirm with walk-forward and evaluate test exactly once"
                    + ("; SIMULATED data — parameters are NOT transferable to "
                       "real markets" if not src["real_market"] else "")),
    }, indent=2), encoding="utf-8")
    print(f"[optimize] report → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

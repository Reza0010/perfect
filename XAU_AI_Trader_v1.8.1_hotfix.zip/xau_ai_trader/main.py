#!/usr/bin/env python3
"""v1.4 — main.py: run the trading system.

Modes (v1.4 §54 — honest naming, no paper-backed "live" label):
    python main.py --mode paper            # default paper loop
    python main.py --mode mt5-readonly     # attach real MT5 provider, read-only
    python main.py --mode paper --once     # single iteration (smoke test)
    python main.py --mode mt5-demo         # → redirected to the demo test script
    python main.py --mode mt5-live         # HARD REFUSED (gates incomplete)
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.config.loader import load_config
from app.config.schema import TradingMode
from app.core.logging import setup_logging


def build_provider(cfg):
    """v1.8: thin wrapper over the SHARED provider factory.

    train.py / walkforward.py / optimize.py / backtest.py used to each build
    their own (silently Simulated) provider; everything now routes through
    app.data.providers_factory so the configured source is the source that
    actually runs, everywhere.
    """
    from app.data.providers_factory import build_data_provider

    return build_data_provider(cfg)


def build_system(cfg, argv=None, registry_tag: str = "main"):
    from app.ai.gateway import AIGateway
    from app.execution.paper import PaperExecutor
    from app.journal.journal import Journal
    from app.models.train_service import load_bundle, load_hmm
    from app.monitoring.health import HealthRegistry
    from app.monitoring.state import StateStore
    from app.news.engine import NewsEngine
    from app.news.providers import build_news_provider
    from app.notifications.telegram import build_notifier
    from app.pipeline import AnalysisPipeline
    from app.regime.engine import RegimeEngine
    from app.risk.engine import RiskEngine
    from app.risk.kill_switch import KillSwitch
    from app.signals.ensemble import SignalEnsemble
    from app.trader import TradingSystem

    provider = build_provider(cfg)

    # v1.8.1 (hotfix F27): MT5 providers MUST be connected before anything can
    # resolve symbols — connect() is the only place the available-symbol list is
    # populated. Previously build_system called get_symbol_info() on a NEVER-
    # CONNECTED provider → guaranteed SymbolNotFoundError → the panel trading
    # loop crashed for every user who selected provider.kind=mt5. The connect
    # is best-effort: an unreachable terminal degrades to assumed fallback
    # specs (clearly marked) + honest WAIT in the loop, never a crash.
    if getattr(provider, "name", "") == "mt5" and hasattr(provider, "connect"):
        try:
            provider.connect()
        except Exception as e:
            logging.getLogger(__name__).warning(
                "MT5 connect failed at build time (%s) — the paper executor "
                "will run on ASSUMED symbol specs and the loop will WAIT "
                "(retrying) until the terminal is reachable", e)

    symbol_info = None
    try:
        symbol_info = provider.get_symbol_info(cfg.symbol.primary)
    except Exception as e:
        # v1.8.1 (hotfix F27): provider unreachable / symbol unresolvable →
        # fall back to the DOCUMENTED assumed specs instead of crashing. The
        # specs are marked specs_source="assumed_fallback" so no downstream
        # consumer can mistake them for real broker values (paper-safe).
        from app.data.market.models import SymbolInfo

        fb = cfg.symbol.fallback_symbol_info
        symbol_info = SymbolInfo(name=cfg.symbol.primary, **fb.model_dump(),
                                 specs_source="assumed_fallback",
                                 description="ASSUMED fallback specs (broker "
                                             "unreachable) — NOT broker values")
        logging.getLogger(__name__).warning(
            "symbol specs unavailable from provider (%s) — using ASSUMED "
            "fallback specs for the paper executor (documented defaults, "
            "NOT broker values)", e)

    news_engine = NewsEngine(build_news_provider(cfg.news), cfg.news)
    regime_engine = RegimeEngine(cfg.regime)
    from app.models.train_service import make_feature_builder

    bundle = None
    hmm_model = None
    try:
        bundle = load_bundle(cfg, registry_tag=registry_tag)
        hmm_model = load_hmm(cfg, registry_tag=registry_tag)
    except Exception as e:
        logging.getLogger(__name__).warning("models not loaded: %s", e)
    feature_builder = make_feature_builder(cfg)
    pipeline = AnalysisPipeline(cfg, provider, feature_builder, regime_engine,
                                news_engine, bundle, hmm_model)
    journal = Journal(Path(cfg.paths.logs_dir) / "journal.db")
    gateway = AIGateway(cfg.ai, ledger=journal)
    kill_switch = KillSwitch(cfg.kill_switch)
    risk = RiskEngine(cfg.risk, kill_switch)
    ensemble = SignalEnsemble(cfg.ensemble)
    executor = PaperExecutor(provider, symbol_info, cfg.execution)
    system = TradingSystem(
        cfg=cfg, provider=provider, pipeline=pipeline, ensemble=ensemble,
        risk=risk, executor=executor, gateway=gateway, journal=journal,
        health=HealthRegistry(), kill_switch=kill_switch,
        state_store=StateStore(Path(cfg.paths.logs_dir) / "state.json"),
        notifiers=build_notifier(cfg.notifications),
    )
    return system


def main() -> int:
    parser = argparse.ArgumentParser(description="XAU AI Trader")
    # v1.4 §54 — honest mode naming. `--mode live` (old label) is kept ONLY
    # as a deprecated alias that HARD REFUSES with guidance, because the
    # runtime executor was paper-backed while the label said "live".
    parser.add_argument("--mode", choices=["paper", "mt5-readonly", "mt5-demo",
                                           "mt5-live", "live"],
                        default="paper")
    parser.add_argument("--config", default=None)
    parser.add_argument("--once", action="store_true", help="single iteration")
    parser.add_argument("--loops", type=int, default=None)
    parser.add_argument("--registry-tag", default=None,
                        help="model registry family: 'main' (unit-test) or 'real' "
                             "(real-data models from run_real_validation.py); "
                             "defaults to real_data.registry_tag from the config")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)
    log = logging.getLogger(__name__)

    # v1.5 (Mission 26/27): enforce the NO-AUTO-RETRAIN policy at startup —
    # previously assert_no_auto_retrain existed but was only ever called by
    # tests, while generate_final_audit claimed it was active.
    from app.monitoring.no_retrain import assert_no_auto_retrain

    assert_no_auto_retrain(cfg)

    if args.mode in ("live", "mt5-live"):
        # v1.4 §54: hard refusal. No runtime path may place live orders in
        # this build — the MT5 execution path is exercised exclusively via
        # scripts/mt5_demo_execution_test.py against a DEMO account.
        print("[LIVE HARD REFUSED] mt5-live is not enabled in this build: "
              "acceptance gates (§61) are incomplete. Use --mode paper, "
              "--mode mt5-readonly (read-only broker validation) or run the "
              "demo execution test on a DEMO account.", file=sys.stderr)
        raise SystemExit(2)
    if args.mode == "mt5-demo":
        print("[mt5-demo] use scripts/mt5_demo_execution_test.py --send on a "
              "DEMO account — the runtime loop does not place broker orders.",
              file=sys.stderr)
        raise SystemExit(2)

    # paper (default) and mt5-readonly both run the paper-backed loop;
    # mt5-readonly additionally connects the MT5 provider read-only so the
    # user can validate symbol/tick/history plumbing without any order risk.
    cfg.execution.mode = TradingMode.PAPER
    if args.mode == "mt5-readonly" and cfg.provider.kind != "mt5":
        print(f"[mt5-readonly] provider.kind={cfg.provider.kind!r} is not an "
              "MT5 provider — nothing to validate read-only.", file=sys.stderr)
        raise SystemExit(2)
    if args.mode == "mt5-readonly":
        log.info("mt5-readonly: MT5 provider attached READ-ONLY (no order "
                 "sends exist on this path)")

    registry_tag = args.registry_tag
    if registry_tag is None:
        registry_tag = getattr(cfg.real_data, "registry_tag", "main") or "main"

    system = build_system(cfg, registry_tag=registry_tag)
    try:
        asyncio.run(system.run(once=args.once, max_loops=args.loops))
    except KeyboardInterrupt:
        system.stop()
    finally:
        asyncio.run(system.gateway.aclose())
        system.journal.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

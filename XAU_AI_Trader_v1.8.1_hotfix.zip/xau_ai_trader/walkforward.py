#!/usr/bin/env python3
"""PHASE 34 — walkforward.py: purged walk-forward train/val/test evaluation.

No test data is ever used for training. Aggregated OOS report written to
reports/walkforward_report.json.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))

from app.config.loader import load_config
from app.core.logging import setup_logging


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    parser.add_argument("--provider", choices=["config", "simulated"], default="config",
                        help="data provider: 'config' honours provider.kind; "
                             "'simulated' EXPLICITLY forces synthetic data")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    from app.data.providers_factory import build_data_provider, explicit_simulated, provider_data_source
    from app.models.dataset import _apply_scaler, _fit_scaler
    from app.models.labels import triple_barrier_labels
    from app.models.lgbm_model import LGBMModel
    from app.models.train_service import build_frames, make_feature_builder
    from app.models.validation import classification_metrics, walk_forward_splits
    from app.models.xgb_model import XGBModel

    # v1.8 forensic fix: walk-forward used to ALWAYS run on SimulatedProvider
    # — every published OOS number was synthetic while presented as evidence.
    # The provider now follows the config and the report records what ran.
    if args.provider == "simulated":
        provider = explicit_simulated(cfg)
        print("[walkforward] ⚠ PROVIDER: SIMULATED (explicitly forced) — OOS "
              "results say NOTHING about real-market performance")
    else:
        provider = build_data_provider(cfg)
    src = provider_data_source(provider)
    print(f"[walkforward] ACTUAL data source: {src['label']} "
          f"(real_market={src['real_market']})")
    provider.connect()
    frames = build_frames(provider, cfg)
    fb = make_feature_builder(cfg)
    features, names = fb.build(frames, cfg.timeframes.base)
    base = frames[cfg.timeframes.base.value]
    label_frame = base[["open", "high", "low", "close"]].join(features[["atr"]], how="left")
    # v1.5: executable-fill labels; NaN tail rows are dropped (never NO_EDGE)
    labels = triple_barrier_labels(label_frame, cfg.labels.horizon_bars,
                                   cfg.labels.tp_atr_mult, cfg.labels.sl_atr_mult,
                                   ambiguous=cfg.labels.ambiguous,
                                   spread_price=cfg.validation.label_spread_price,
                                   slippage_price=cfg.validation.label_slippage_price,
                                   commission_price=cfg.validation.label_commission_price)

    df = features.copy()
    df["label"] = labels
    df = df.dropna(axis=0, how="any")
    X = df.drop(columns=["label"])
    y = (df["label"].astype(int) + 1).astype(int).values
    n = len(X)

    # v1.5 (Mission 8): REAL purge/embargo gaps between train/val/test;
    # purge must cover the label horizon. Fold count is validated against
    # validation.min_oos_folds instead of silently accepting fewer.
    try:
        wf = walk_forward_splits(n, cfg.validation.walk_forward_train_bars,
                                 cfg.validation.walk_forward_val_bars,
                                 cfg.validation.walk_forward_test_bars,
                                 cfg.validation.walk_forward_step_bars,
                                 purge=max(cfg.validation.purge_bars, cfg.labels.horizon_bars),
                                 embargo=cfg.validation.embargo_bars,
                                 min_folds=cfg.validation.min_oos_folds)
    except ValueError as e:
        print(f"[walkforward] REFUSED: {e}")
        return 1
    if not wf:
        print("[walkforward] not enough data for the configured windows — "
              "increase provider.simulated_days or reduce walk_forward windows")
        return 1
    print(f"[walkforward] {len(wf)} folds, rows={n}")

    folds_report = []
    all_test_idx = []
    aggregate_correct = aggregate_n = 0
    # v1.8: accuracy-only aggregation HID the degenerate SELL-majority models
    # (77% accuracy, 0.0 NO_EDGE recall). Aggregate balanced accuracy, F1 and
    # per-class recalls as well — they are the honest headline numbers.
    agg = {"balanced_accuracy": [], "f1_macro": [], "log_loss": []}
    agg_recall = {f"recall_{c}": [] for c in ("SELL", "NO_EDGE", "BUY")}
    for k, (tr, va, te) in enumerate(wf):
        scaler = _fit_scaler(X.iloc[tr], cfg.dataset.scaler)
        Xs = _apply_scaler(X, scaler)
        lgbm = LGBMModel(cfg.lgbm)
        lgbm.fit(Xs.iloc[tr], y[tr], Xs.iloc[va], y[va])
        xgb = XGBModel(cfg.xgb)
        xgb.fit(Xs.iloc[tr], y[tr], Xs.iloc[va], y[va])
        probs = (lgbm.predict_proba(Xs.iloc[te]) + xgb.predict_proba(Xs.iloc[te])) / 2.0
        metrics = classification_metrics(y[te], probs)
        folds_report.append({"fold": k, "train": [int(tr[0]), int(tr[-1])],
                             "test": [int(te[0]), int(te[-1])], "metrics": metrics})
        aggregate_correct += int((probs.argmax(axis=1) == y[te]).sum())
        aggregate_n += len(te)
        agg["balanced_accuracy"].append(metrics.get("balanced_accuracy"))
        agg["f1_macro"].append(metrics.get("f1_macro"))
        agg["log_loss"].append(metrics.get("log_loss"))
        for c in agg_recall:
            agg_recall[c].append(metrics.get(c))
        all_test_idx.extend(te.tolist())
        print(f"  fold {k}: acc={metrics['accuracy']:.3f} "
              f"bal_acc={metrics['balanced_accuracy']:.3f} f1={metrics['f1_macro']:.3f} n={len(te)}")

    def _mean(xs):
        vals = [v for v in xs if isinstance(v, (int, float))]
        return round(sum(vals) / len(vals), 4) if vals else None

    oos = {"oos_accuracy": aggregate_correct / max(1, aggregate_n),
           "oos_balanced_accuracy": _mean(agg["balanced_accuracy"]),
           "oos_f1_macro": _mean(agg["f1_macro"]),
           "oos_log_loss": _mean(agg["log_loss"]),
           "oos_recall_per_class": {c: _mean(v) for c, v in agg_recall.items()},
           "n_oos_predictions": int(aggregate_n)}
    print(f"[walkforward] OOS accuracy: {oos['oos_accuracy']:.3f} "
          f"| balanced: {oos['oos_balanced_accuracy']} | f1_macro: {oos['oos_f1_macro']} "
          f"({aggregate_n} out-of-sample predictions)")

    out = Path(cfg.paths.reports_dir) / "walkforward_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({
        "n_folds": len(wf), **oos,
        "folds": folds_report,
        "purge_bars": max(cfg.validation.purge_bars, cfg.labels.horizon_bars),
        "embargo_bars": cfg.validation.embargo_bars,
        "min_oos_folds_required": cfg.validation.min_oos_folds,
        # v1.8: the data source that actually ran — a synthetic run can no
        # longer masquerade as real evidence in the report.
        "data_source": src,
        "note": ("test segments never used for training; REAL purge/embargo gaps "
                 "between train/val/test (v1.5); labels executable-fill anchored "
                 "and SYMMETRIC long/short (v1.8); tail rows without future "
                 "horizon excluded; accuracy is NOT a sufficient headline for "
                 "imbalanced 3-class — read the per-class recalls"),
    }, indent=2), encoding="utf-8")
    print(f"[walkforward] report → {out}")
    if not src["real_market"]:
        print("[walkforward] ⚠ SIMULATED data — results are NOT evidence of "
              "real-market edge")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

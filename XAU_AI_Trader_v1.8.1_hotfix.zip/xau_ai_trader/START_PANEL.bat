@echo off
rem ============================================================
rem  XAU AI Trader — Control Panel  (double-click launcher)
rem  Starts the whole system and opens the panel in your browser
rem ============================================================
title XAU AI Trader - Control Panel
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py run_panel.py %*
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        python run_panel.py %*
    ) else (
        echo Python not found. Install Python 3.10+ from https://www.python.org/downloads/
        echo and check "Add python.exe to PATH" during installation.
        pause
        exit /b 2
    )
)
pause
